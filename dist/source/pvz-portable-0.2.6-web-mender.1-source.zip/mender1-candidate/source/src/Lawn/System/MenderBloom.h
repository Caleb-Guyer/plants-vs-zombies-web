// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <algorithm>
#include <cmath>

namespace Sexy { class Image; class Graphics; }
class Plant;
class Reanimation;

// The native Plant's existing state/glow counters carry this ability through
// checkpoints. No fields or original seed/cache/chooser IDs are extended.
namespace MenderBloom
{
inline constexpr SeedType kSeed = SEED_MENDERBLOOM;
inline constexpr int kCost = 125;
inline constexpr int kRecharge = 1500;
inline constexpr int kPulseInterval = 300;
inline constexpr int kHealAmount = 10;
inline constexpr int kHealingFrames = 60;
inline constexpr float kIdlePeriodSeconds = 3.2f;

constexpr bool InRange(int deltaCol, int deltaRow)
{
    return deltaCol >= -1 && deltaCol <= 1 && deltaRow >= -1 && deltaRow <= 1 &&
        (deltaCol != 0 || deltaRow != 0);
}

constexpr int BoundedHeal(int health, int maximum)
{
    return health <= 0 || maximum <= health ? health :
        health + std::min(kHealAmount, maximum - health);
}

constexpr bool IsPersistentTargetSeed(SeedType seed)
{
    if (seed == kSeed || seed == SEED_LANTERNSHROOM) return true;
    if (seed < SEED_PEASHOOTER || seed >= NUM_SEED_TYPES) return false;
    switch (seed)
    {
    case SEED_CHERRYBOMB: case SEED_POTATOMINE: case SEED_SQUASH:
    case SEED_GRAVEBUSTER: case SEED_ICESHROOM: case SEED_DOOMSHROOM:
    case SEED_LILYPAD: case SEED_TANGLEKELP: case SEED_JALAPENO:
    case SEED_BLOVER: case SEED_FLOWERPOT: case SEED_INSTANT_COFFEE:
    case SEED_IMITATER: case SEED_EXPLODE_O_NUT: case SEED_GIANT_WALLNUT:
    case SEED_SPROUT:
        return false;
    default:
        return true;
    }
}

struct LayerPose
{
    float centerX = 40.0f;
    float centerY = 40.0f;
    float scaleX = 1.0f;
    float scaleY = 1.0f;
    float angle = 0.0f;
};

inline LayerPose GetStemPose(float animTime)
{
    LayerPose pose;
    const float breath = 0.5f - 0.5f * std::cos(animTime * 6.28318530718f);
    pose.scaleY = 1.0f - 0.008f * breath;
    pose.centerY = 72.0f - 32.0f * pose.scaleY;
    return pose;
}

inline LayerPose GetHeadPose(float animTime, int glow)
{
    LayerPose pose;
    const float phase = animTime * 6.28318530718f;
    const float breath = 0.5f - 0.5f * std::cos(phase);
    const float healing = glow > 0 ? std::sin(3.14159265359f *
        (1.0f - std::clamp(glow, 0, kHealingFrames) / static_cast<float>(kHealingFrames))) : 0.0f;
    pose.angle = 0.015f * std::sin(phase);
    pose.scaleX = 1.0f + 0.008f * breath + 0.025f * healing;
    pose.scaleY = 1.0f + 0.008f * breath + 0.040f * healing;
    // Pivot the head around its stem connection, not its outer canvas center.
    pose.centerX = 40.0f - 10.0f * std::sin(pose.angle) * pose.scaleY;
    pose.centerY = 50.0f - 10.0f * std::cos(pose.angle) * pose.scaleY -
        0.5f * breath - 2.0f * healing;
    return pose;
}

bool IsEligibleTarget(const Plant& healer, const Plant& target);
void Update(Plant& healer);
Sexy::Image* GetImage();
void DisposeImage();
void EnsurePlantReanimation(Plant& plant);
void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier);
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY);

static_assert(static_cast<int>(kSeed) == 76);
}
