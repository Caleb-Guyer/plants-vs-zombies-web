# Mender.1 support plant and custom Almanac revision

Starts from exact published SeedSwap.1 source SHA-256
0db62a66059ebc4891181044609fa949d2c623b0a05181930c2734a0f7aeeb18.
The parent archive has 782 source files under seedswap1-candidate/source/.
Its complete frozen engine metadata remains in parent-engine-provenance.json.

Adds Mender-bloom (external seed ID 76), unlocked by a valid Seed Swap win,
with slow healing of adjacent plants. Adds native Almanac entries for both
Mender-bloom and Chill-shroom. All five bonus minigames, original seed IDs,
the native 53-entry arrays and serialized layouts remain unchanged.

Run build-chill.py with the retained local Release Emscripten toolchain, then
all ten tests/test-*.py production-method suites, including test-mender-bloom.py.
Build flags are CMAKE_BUILD_TYPE=Release, DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF and
LOW_MEMORY=OFF. These native method tests do not open an audio device or start
the full game. Browser testing uses ?testing=1 and generated QA profiles only.

Run package-chill.py after the build and tests. It checks source-coherent
receipts and reconstructs both raw-upstream and exact SeedSwap.1 parent patches.
It stages the versioned source archive, web-mender.1.patch,
seedswap1-to-mender1.patch, binaries and provenance in a new candidate-local
staging directory. The archive uses the mender1-candidate/ prefix and includes
the exact build/package recipes, ten test suites, source pins and build receipt.
Source and recipe bytes must stay frozen during packaging. Packaging does not
install or publish the staging directory. Installed native executables and
private player files are never distribution inputs.
