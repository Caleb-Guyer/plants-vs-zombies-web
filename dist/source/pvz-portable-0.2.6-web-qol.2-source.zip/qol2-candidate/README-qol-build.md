# QoL.2 native engine build

This version retains QoL.1 and adds the requested original-style options, hotkeys,
focus-loss pause, per-profile preferences, saved plant decks and cooldown numbers.
Browser save history and recovery are separate shell modules in the website source.

Build with the existing Emscripten toolchain recipe:

    python build-qol.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python package-qol.py

Each test runner accepts --native for a host C++20 compiler. No test starts the
full game or an audio device. The build recipe expects work/toolchain beside this
workspace; configure the SDK paths for another machine. Release uses
DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF and LOW_MEMORY=OFF.

The packaging helper requires a successful full build, all three focused test
reports, unchanged input source hashes, matching binary hashes and a new staging
directory. It verifies both full-upstream and QoL.1 incremental patches by applying
them to temporary source trees and comparing every resulting byte. The source
archive includes full current source, recipes, test code/results, source manifests
and build receipts; compiled programs, original game resources, private saves and
credentials are excluded. Runtime game resources are separately bundled.

For another staging pass after installing QoL.2 in the release folder, pass
--parent-manifest pointing to the frozen QoL.1 engine-provenance.json and --output
pointing to a new candidate staging directory. The parent identity is still checked.
