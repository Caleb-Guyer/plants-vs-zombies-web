# SeedSwap.1 native minigame revision

Starts from exact published Garden.1 source SHA-256
34807be9b16aafc8e1e8bc9fd4da840df0ce9ae5667157cf51e61f4571d95122.
Adds Seed Swap with a fixed defense, zombie seed drops and replacement-only
planting. Original IDs and saved members remain; mode77 owns unused record76.

Run build-chill.py with the retained local Release Emscripten toolchain, all nine
tests/test-*.py production-method suites, then package-chill.py. Packaging checks
source-coherent receipts and reconstructs raw-upstream and exact parent patches.
Browser testing uses ?testing=1 and generated QA profiles only. Installed native
executables and private player files are never distribution inputs.
