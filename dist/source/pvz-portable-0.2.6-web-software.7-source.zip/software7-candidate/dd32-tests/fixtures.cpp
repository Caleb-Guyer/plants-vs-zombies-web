#include "native-dd32-reference.h"
using NativeDD32Reference::Tint;
int checks=0,failures=0,oldDifferences=0;
void compare(uint32_t oldPixel,uint32_t newPixel,uint32_t reference,const char* label){
 ++checks;oldDifferences+=((oldPixel&0xffffff)!=(reference&0xffffff));
 if(newPixel!=reference){if(failures<8)std::printf("FAIL %s old=%08x candidate=%08x reference=%08x\n",label,oldPixel,newPixel,reference);++failures;}
}
void initialize(MemoryImage& target,int w,int h,uint32_t pixel){target.Create(w,h);for(int i=0;i<w*h;++i)target.GetBits()[i]=pixel;target.BitsChanged();target.SetImageMode(false,false);}
void one(uint32_t pixel,uint32_t background,Tint tint,int mode,bool fast,int forced=-1){
 App app;MemoryImage source(&app),old(&app);SoftwareScreenImage target(&app);
 source.Create(1,1);source.GetBits()[0]=pixel;source.BitsChanged();source.CommitBits();
 NativeDD32Reference::SourceFlags flags{int(pixel>>24)>0&&int(pixel>>24)<255,int(pixel>>24)==0};
 if(forced>=0){flags={bool(forced&1),bool(forced&2)};source.SetImageMode(flags.hasTrans,flags.hasAlpha);}
 initialize(old,1,1,background);initialize(target,1,1,background);
 Color color(tint.r,tint.g,tint.b,tint.a);
 MemoryImage* base=&target; // Exercise actual virtual screen destination dispatch.
 if(fast){old.StretchBlt(&source,Rect(0,0,1,1),Rect(0,0,1,1),Rect(0,0,1,1),color,mode,true);base->StretchBlt(&source,Rect(0,0,1,1),Rect(0,0,1,1),Rect(0,0,1,1),color,mode,true);}
 else{old.Blt(&source,0,0,Rect(0,0,1,1),color,mode,false);base->Blt(&source,0,0,Rect(0,0,1,1),color,mode,false);}
 uint32_t reference=fast?NativeDD32Reference::FastPixel(pixel,background,tint,mode):NativeDD32Reference::BltPixel(pixel,background,tint,mode,flags);
 compare(old.GetBits()[0],target.GetBits()[0],reference,fast?"fast pixel":"Blt pixel");
 if(target.GetBits()[1]!=0x4beefade||old.GetBits()[1]!=0x4beefade)++failures;
}
void grid(Tint tint,int mode,bool fast,bool clipped,bool palette){
 App app;MemoryImage source(&app),old(&app),referenceTemp(&app);SoftwareScreenImage target(&app);
 source.Create(10,9);const uint32_t colors[]={0x00f08020,0x013f8123,0x4081c47f,0x7fffffff,0x80818181,0xbf902010,0xfe71ef05,0xff818181};
 std::vector<uint32_t> original(90);
 for(int i=0;i<90;++i)source.GetBits()[i]=original[i]=colors[(i+i/10)%8];source.BitsChanged();source.CommitBits();
 auto installPalette=[&](){source.mColorTable=std::make_unique<uint32_t[]>(256);source.mColorIndices=std::make_unique<uchar[]>(90);for(int i=0;i<256;++i)source.mColorTable[i]=colors[i%8];for(int i=0;i<90;++i){source.mColorIndices[i]=(i+i/10+3)%8;original[i]=colors[(i+i/10+3)%8];}source.mBits.reset();source.BitsChanged();};
 if(palette)installPalette();
 initialize(old,12,12,0xff818181);initialize(target,12,12,0xff818181);
 NativeDD32Reference::Rect src{1,1,8,7},draw=clipped?NativeDD32Reference::Rect{-2,-1,15,14}:NativeDD32Reference::Rect{0,0,12,12};
 NativeDD32Reference::Rect clip=clipped?NativeDD32Reference::Rect{1,2,9,8}:NativeDD32Reference::Rect{0,0,12,12};
 auto c=NativeDD32Reference::Clip(src,draw,clip);
 Rect s(src.x,src.y,src.w,src.h),d(draw.x,draw.y,draw.w,draw.h),clipRect(clip.x,clip.y,clip.w,clip.h);Color color(tint.r,tint.g,tint.b,tint.a);
 old.StretchBlt(&source,d,s,clipRect,color,mode,fast);
 // The old path may expand/clear palette storage. Restore it so the actual
 // candidate, not only the old control, receives indexed source data.
 if(palette){installPalette();if(source.mBits||!source.mColorTable||!source.mColorIndices)++failures;}
 MemoryImage* base=&target;base->StretchBlt(&source,d,s,clipRect,color,mode,fast);
 std::vector<uint32_t> expected(144,0xff818181);
 if(fast){auto indices=NativeDD32Reference::FastIndices(c,10);int i=0;for(int y=0;y<c.destination.h;++y)for(int x=0;x<c.destination.w;++x){int index=(c.destination.y+y)*12+c.destination.x+x;expected[index]=NativeDD32Reference::FastPixel(original[indices[i++]],expected[index],tint,mode);}}
 else{
  // Independent native DD dispatch transcription: literalMI3 native white-normal
  // temporary (audited separately), then native DD Blt math with original tint/mode.
  referenceTemp.Create(c.destination.w,c.destination.h);
  referenceTemp.SlowStretchBlt(&source,Rect(0,0,c.destination.w,c.destination.h),FRect(c.sx,c.sy,c.sw,c.sh),Color::White,0);referenceTemp.CommitBits();
  NativeDD32Reference::SourceFlags flags{referenceTemp.mHasAlpha,referenceTemp.mHasTrans};
  for(int y=0;y<c.destination.h;++y)for(int x=0;x<c.destination.w;++x){int index=(c.destination.y+y)*12+c.destination.x+x;expected[index]=NativeDD32Reference::BltPixel(referenceTemp.GetBits()[y*c.destination.w+x],expected[index],tint,mode,flags);}
 }
 for(int i=0;i<144;++i)compare(old.GetBits()[i],target.GetBits()[i],expected[i],fast?"fixed16 grid":"native slow-temp dispatch");
 if(target.GetBits()[144]!=0x4beefade||old.GetBits()[144]!=0x4beefade)++failures;
}
void mirrorDispatch(){
 // Preserve all7 earlier assertions. Native white mirror dispatch is now mapped:
 // DD mirror stretch59A1B8..59A2CC samples source forward, writes right-to-left.
 App app;MemoryImage source(&app),old(&app);SoftwareScreenImage target(&app);source.Create(3,1);
 const uint32_t pixels[]={0x40818020,0x8081c47f,0xff818181};for(int i=0;i<3;++i)source.GetBits()[i]=pixels[i];source.BitsChanged();source.CommitBits();
 initialize(old,3,1,0xff818181);initialize(target,3,1,0xff818181);MemoryImage* base=&target;
 old.BltMirror(&source,0,0,Rect(0,0,3,1),Color::White,0,false);base->BltMirror(&source,0,0,Rect(0,0,3,1),Color::White,0,false);
 for(int i=0;i<3;++i)compare(old.GetBits()[i],target.GetBits()[i],NativeDD32Reference::BltPixel(pixels[2-i],0xff818181,Tint{},0,{true,false}),"inherited mirror virtualBlt dispatch");
 initialize(old,4,1,0xff818181);initialize(target,4,1,0xff818181);
 old.StretchBltMirror(&source,Rect(0,0,4,1),Rect(0,0,3,1),Rect(0,0,4,1),Color::White,0,true);base->StretchBltMirror(&source,Rect(0,0,4,1),Rect(0,0,3,1),Rect(0,0,4,1),Color::White,0,true);
 auto clipped=NativeDD32Reference::Clip({0,0,3,1},{0,0,4,1},{0,0,4,1});auto indices=NativeDD32Reference::FastIndices(clipped,3);
 for(int i=0;i<4;++i)compare(old.GetBits()[i],target.GetBits()[i],NativeDD32Reference::FastPixel(pixels[indices[3-i]],0xff818181,Tint{},0),"native mirrored stretch source-forward destination-reverse dispatch");
}
int main(){
 const Tint tints[]={{255,255,255,255},{128,64,32,255},{255,255,254,255},{128,128,128,255},{128,64,32,128},{255,255,255,0}};
 for(int alpha:{0,1,64,127,128,254,255})for(int channel:{0,1,20,128,129,254,255})for(int dest:{0,1,127,128,254,255})for(Tint tint:tints)for(int mode:{0,1})for(bool fast:{false,true}){
  uint32_t pixel=(uint32_t(alpha)<<24)|(channel<<16)|((255-channel)<<8)|channel;
  uint32_t bg=0xff000000|(dest<<16)|(dest<<8)|dest;one(pixel,bg,tint,mode,fast);
 }
 for(int forced=0;forced<4;++forced)for(int alpha:{0,128,255})one((uint32_t(alpha)<<24)|0x819083,0xff818181,Tint{},0,false,forced);
 for(Tint tint:tints)for(int mode:{0,1})for(bool fast:{false,true})for(bool clipped:{false,true})for(bool palette:{false,true})grid(tint,mode,fast,clipped,palette);
 mirrorDispatch();
 // Original Blt rejects unknown modes; original Stretch maps nonzero to additive.
 App app;MemoryImage src(&app);SoftwareScreenImage target(&app);src.Create(1,1);src.GetBits()[0]=0xff808080;src.CommitBits();initialize(target,1,1,0xff123456);target.Blt(&src,0,0,Rect(0,0,1,1),Color::White,2,false);++checks;if(target.GetBits()[0]!=0xff123456)++failures;
 std::printf("DD32: checks=%d candidateFailures=%d Software3RGBDifferences=%d; actual screen/base virtual calls, synthetic only\n",checks,failures,oldDifferences);
 return failures||oldDifferences==0?1:0;
}
