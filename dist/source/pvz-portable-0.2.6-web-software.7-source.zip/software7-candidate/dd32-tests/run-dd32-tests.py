import re
"""Actual dedicated-screen methods against independent native DD32 equations; no game/audio."""
from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'dd32-tests/results';OUT.mkdir(exist_ok=True);(OUT/'inc_routines').mkdir(exist_ok=True);(OUT/'temp').mkdir(exist_ok=True)
WORK=ROOT.parents[1];SDK=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
GRAPHICS=ROOT/'source/src/SexyAppFramework/graphics'
tree=ast.parse((ROOT/'tests/prepare-primitives.py').read_text());prefix=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='prefix' for t in n.targets))
prefix=prefix.replace('void Create(int w,int h)','virtual void Create(int w,int h)').replace('void Blt(Image*','virtual void Blt(Image*').replace('void StretchBlt(Image*','virtual void StretchBlt(Image*')
prefix=prefix.replace('void FillRect(const Rect&,const Color&,int);','virtual void FillRect(const Rect&,const Color&,int);')
prefix=prefix.replace('bool mHasAlpha=false,','bool mIsVolatile=false,mPurgeBits=false,mHasAlpha=false,').replace('EXTRA_DECLARATIONS','void SlowStretchResample(Image*,const Rect&,const FRect&,bool); void BltMirror(Image*,int,int,const Rect&,const Color&,int,bool=true) override; void StretchBltMirror(Image*,const Rect&,const Rect&,const Rect&,const Color&,int,bool) override; bool StretchBltMirrorClipHelper(const Rect&,const Rect&,const Rect&,FRect&,Rect&);')
def function(text,signature):
 assert text.count(signature)==1,signature
 start=text.index(signature);brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if depth==0:return text[start:end+1]
 raise AssertionError(signature)
prefix=prefix.replace(function(prefix,'uint32_t* GetBits('),'''uint32_t* GetBits(){
 if(!mBits){mBits=std::make_unique<uint32_t[]>(mWidth*mHeight+1);mBits[mWidth*mHeight]=0x4beefade;
  if(mColorTable){for(int i=0;i<mWidth*mHeight;++i)mBits[i]=mColorTable[mColorIndices[i]];mColorTable.reset();mColorIndices.reset();}}
 return mBits.get();
}''')
memory=(GRAPHICS/'MemoryImage.cpp').read_text();image=(GRAPHICS/'Image.cpp').read_text();screen=(GRAPHICS/'SoftwareScreenImage.cpp').read_text();header=(GRAPHICS/'SoftwareScreenImage.h').read_text()
methods=['void MemoryImage::CommitBits(','void MemoryImage::SetImageMode(','void MemoryImage::FillRect(','void MemoryImage::NormalBlt(','void MemoryImage::AdditiveBlt(','void MemoryImage::Blt(','bool MemoryImage::StretchBltClipHelper(','bool MemoryImage::StretchBltMirrorClipHelper(','void MemoryImage::FastStretchBlt(','void MemoryImage::SlowStretchBlt(','void MemoryImage::SlowStretchResample(','void MemoryImage::StretchBlt(','void MemoryImage::BltMirror(','void MemoryImage::StretchBltMirror(']
screen_methods=['SoftwareScreenImage::SoftwareScreenImage(','void SoftwareScreenImage::Create(','uint32_t SoftwareScreenImage::CompositePixel(','void SoftwareScreenImage::Blt(','void SoftwareScreenImage::StretchBlt(','void SoftwareScreenImage::StretchBltMirror(','void SoftwareScreenImage::FillRect(','void SoftwareScreenImage::BltMirror(']
header=re.sub(r'\n\s*void Blt(?:Matrix|TrianglesTex)\([^;]+;', '', header)
declaration=header[header.index('class SoftwareScreenImage final'):header.index('\n};',header.index('class SoftwareScreenImage final'))+3]
generated=prefix+'\nusing SexyAppBase=App;\n'+declaration+'\n'+function(image,'void Image::BltMirror(')+'\n'+function(image,'void Image::StretchBltMirror(')+'\n'+'\n'.join(function(memory,s) for s in methods)+'\n'+'\n'.join(function(screen,s) for s in screen_methods)+'\n'+(ROOT/'dd32-tests/fixtures.cpp').read_text()
(OUT/'actual-screen.cpp').write_text(generated)
include_hashes={}
for name in ['MI_NormalBlt.inc','MI_AdditiveBlt.inc','MI_SlowStretchBlt.inc']:
 p=GRAPHICS/'inc_routines'/name;shutil.copyfile(p,OUT/'inc_routines'/name);include_hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(ROOT/'dd32-tests/native-dd32-reference.h',OUT/'native-dd32-reference.h')
# Literal offscreen MI sources must remain exactly Software.3.
frozen3=json.loads((ROOT/'retained4/software3-parent.json').read_text())['baseSourceFingerprint']
for name in ['MemoryImage.cpp','MemoryImage.h','inc_routines/MI_SlowStretchBlt.inc']:
 assert hashlib.sha256((GRAPHICS/name).read_bytes()).hexdigest()==frozen3['src/SexyAppFramework/graphics/'+name],name
env=dict(os.environ,EM_CONFIG=str(SDK/'.emscripten'),EM_CACHE=str(WORK/'toolchain/em-cache'),EMCC_TEMP_DIR=str(OUT/'temp'),PYTHONNOUSERSITE='1')
cmd=[SDK/'python/3.13.3_64bit/python.exe',SDK/'upstream/emscripten/em++.py',OUT/'actual-screen.cpp','-std=c++20','-O1','-sENVIRONMENT=node','-o',OUT/'actual-screen.js']
r=subprocess.run(list(map(str,cmd)),env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
assert 'AudioContext' not in (OUT/'actual-screen.js').read_text()
r=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(OUT/'actual-screen.js')],capture_output=True,text=True);print(r.stdout+r.stderr,end='')
report={'candidate':'0.2.6-web-software.7','exitCode':r.returncode,'output':r.stdout+r.stderr,'actualMemoryImageSha256':hashlib.sha256((GRAPHICS/'MemoryImage.cpp').read_bytes()).hexdigest(),'actualScreenSha256':hashlib.sha256((GRAPHICS/'SoftwareScreenImage.cpp').read_bytes()).hexdigest(),'actualScreenHeaderSha256':hashlib.sha256((GRAPHICS/'SoftwareScreenImage.h').read_bytes()).hexdigest(),'generatedSha256':hashlib.sha256(generated.encode()).hexdigest(),'includeSha256':include_hashes,'independentReferenceSha256':hashlib.sha256((ROOT/'dd32-tests/native-dd32-reference.h').read_bytes()).hexdigest(),'scope':'Retained20893 ordinary equation assertions and7 white mirror assertions preserved; stretched mirror indices updated to proved source-forward/destination-reverse order. Indexed fixtures strengthened with distinct palette data/null raw bits and faithful lazy GetBits. Literal MI3 unchanged. No driver surface/DD16/volatile/framebuffer/game/browser/audio proof.'}
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0
