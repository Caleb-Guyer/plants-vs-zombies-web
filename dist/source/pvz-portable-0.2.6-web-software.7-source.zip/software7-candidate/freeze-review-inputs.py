"""Freeze bounded7 review inputs, excluding later build/package outputs."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
paths=['software6-parent.json','software7-change-record.json','README.txt','prepare-candidate.py','prepare-retained-tests.py']
paths += ['matrix-tests/'+n for n in ['README.txt','native-matrix-rgb888-reference.h','run-callback-tests.py','run-paired-tests.py','context-fixtures.cpp','run-context-tests.py','verify-source-inputs.py','results/results.json','results/context-results.json','results/baseline6/results.json','results/candidate7/results.json','results/context-baseline6/results.json','results/context-candidate7/results.json']]
paths += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'reference-tests').iterdir()) if p.is_file()]
change=json.loads((ROOT/'software7-change-record.json').read_text());sources=change['changedExisting']+change['added']
paths += ['source/'+n for n in sources]
record={'candidate':'0.2.6-web-software.7','sourceFiles':757,'scope':'Screen-only closed RGB888 alpha callback source/test inputs; current build/package/runtime status is recorded separately in verification.json and package.json','files':{n:{'bytes':(ROOT/n).stat().st_size,'sha256':sha((ROOT/n).read_bytes())} for n in sorted(paths)}}
(ROOT/'software7-review-inputs.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'files':len(paths),'manifestSha256':sha((ROOT/'software7-review-inputs.json').read_bytes()),'sourcePaths':sources},indent=2))
