Private Software.5 screen-fill regression (no engine/audio initialization)

Run from the workspace:
  python work/portable-build/software5-candidate/fill-tests/run-fill-tests.py

Uses only the existing Emscripten/Python/Node SDK under work/toolchain.
No installed original files, original code execution, game assets, browser,
SDL/game startup, personal data or audio are needed. Only fill-tests/results
is generated. The runner verifies production source hashes before/after and
checks that MemoryImage.cpp remains byte-identical to frozen Software.4.

Reference
  native-dd32-fill-reference.h is authored scalar C++ math derived independently
  from the addressed native RGB888 FillRect proof. The production override uses
  unsigned packed masks, while this reference uses direct integer channels:
    normal A255: C==0?0:C-1
    normal A0..254: D*(256-A)/256 + (C*A+127)/256 (separate integer divisions)
    additive: min(255,D+C*A/255)
  Native addresses and conditions are in comments; no original binary/disassembly
  is included. Normal-line first-pixel controls use the distinct half-mask-derived
  scalar formula rather than assuming that line and fill arithmetic are shared.

Actual production extraction
  Both variants compile their actual class declarations, ctor/Create, MemoryImage
  function bodies and include routines, plus SoftwareScreenImage methods.
  Minimal app/image/surface dependencies are doubles; active rendering methods
  are not rewritten in the harness. This tests virtual image dispatch, not merely
  direct invocation of the new helper. The actual Image::FillScanLines and
  inherited MemoryImage::DrawLine/DrawLineAA execute the axis-to-FillRect route.

Baseline
  software4-baseline contains8 exact authored engine source/include fixtures
  copied from frozen Software.4 source archive SHA256:
  649863914351065e939ada9a09cd61f63c12839de970912eb984420910b94458
  manifest.json pins each byte. The runner also checks each fingerprint against
  software4-parent.json. No original/native/asset/backup files are included.

Final current result
  Same2,118,543 assertions per variant:
    frozen4: expected exit1,539,971 differences
    candidate5: exit0,0 differences
  The full grid makes1,048,576 FillRect calls (both modes, all256 channel values,
  all256 alpha values,8 destination colors); each call checks RGB and opaque
  transport. Mixed RGB channels check separation/carries as well as gray values.
  The remaining checks cover valid/full/empty rectangles, untouched neighbors,
  allocation guards, axis/reversed-axis/point lines and AA through Image*,
  base span routing, unsupported draw-mode no-op, four literal offscreen MI
  fixtures and ten nonaxis normal/additive first-pixel controls.

Limits
  Conditional successful-lock RGB888 ordinary software-screen math only.
  This is synthetic isolated actual-code proof, not a native framebuffer test.
  DD16, other pixel formats, D3D, driver shortcuts, volatile paths and failed-lock
  fallbacks are excluded. Native unused alpha bits are not compared; A255 is
  the CPU transport invariant. The extra screen-bounds clipping is defensive
  behavior outside valid native geometry and has no native equivalence credit.
  Normal nonaxis line geometry/full AA math remain unproved. Additive nonaxis
  AA's native no-op is a tracked unimplemented API difference, deliberately
  outside this authorized fill/axis scope. Plain offscreen MI remains unchanged.
