/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
#include "native-dd32-fill-reference.h"

uint64_t checks = 0, failures = 0;
std::vector<std::pair<const char*, uint64_t>> groups;
void check(bool good, const char* group)
{
    ++checks;
    if (good) return;
    ++failures;
    auto found = std::find_if(groups.begin(), groups.end(),
        [group](const auto& item) { return std::strcmp(group, item.first) == 0; });
    if (found == groups.end()) groups.push_back({group, 1});
    else ++found->second;
}
void reset(MemoryImage& image, int width, int height, uint32_t pixel)
{
    image.Create(width, height);
    image.SetImageMode(false, false);
    for (int i = 0; i < width * height; ++i) image.GetBits()[i] = pixel;
}
void checkRect(const MemoryImage& image, const uint32_t* bits, const Rect& rect,
    uint32_t initial, const Color& color, int mode, const char* group)
{
    for (int y = 0; y < image.mHeight; ++y)
        for (int x = 0; x < image.mWidth; ++x)
        {
            const bool inside = x >= rect.mX && y >= rect.mY &&
                x < rect.mX + rect.mWidth && y < rect.mY + rect.mHeight;
            const uint32_t expected = inside ? NativeFillRGB(initial, color, mode) : initial & 0xffffff;
            check((bits[y * image.mWidth + x] & 0xffffff) == expected, group);
            check((bits[y * image.mWidth + x] >> 24) == 255, "opaque transport alpha");
        }
    check(bits[image.mWidth * image.mHeight] == 0x4beefade, "allocation guard");
}
int main()
{
    App app;
    SoftwareScreenImage screen(&app);
    Image* base = &screen;
    // Every channel and alpha value, eight destination colors, both modes.
    // Mixed RGB channels distinguish packed-channel/carry errors from gray-only matches.
    reset(screen, 1, 1, 0xff000000);
    for (int mode = 0; mode <= 1; ++mode)
        for (int alpha = 0; alpha <= 255; ++alpha)
            for (int c = 0; c <= 255; ++c)
                for (int d : {0, 1, 11, 63, 127, 128, 254, 255})
                {
                    Color color(c, c ^ 0x55, 255 - c, alpha);
                    const uint32_t initial = 0xff000000 | (d << 16) | ((255 - d) << 8) | ((d + 37) & 255);
                    screen.GetBits()[0] = initial;
                    base->FillRect(Rect(0, 0, 1, 1), color, mode);
                    check((screen.GetBits()[0] & 0xffffff) == NativeFillRGB(initial, color, mode),
                        mode ? "additive full color-alpha grid" : "normal full color-alpha grid");
                    check((screen.GetBits()[0] >> 24) == 255, "opaque transport alpha");
                }
    check(screen.GetBits()[1] == 0x4beefade, "allocation guard");

    for (int mode = 0; mode <= 1; ++mode)
        for (int alpha : {0, 1, 127, 128, 210, 254, 255})
        {
            const uint32_t initial = 0xff0b7fdf;
            Color color(200, 255, 1, alpha);
            // Native callers hand valid clipped rectangles to the primitive.
            // Empty and full rectangles plus untouched-neighbor/guard checks.
            for (Rect rect : {Rect(1, 2, 4, 3), Rect(0, 0, 8, 7), Rect(3, 3, 0, 1)})
            {
                reset(screen, 8, 7, initial);
                base->FillRect(rect, color, mode);
                checkRect(screen, screen.GetBits(), rect, initial, color, mode, "valid rectangle RGB");
            }
            // Actual inherited MemoryImage public methods, called through Image*.
            // Integer axis endpoints have the native inclusive virtualFillRect routing.
            struct Axis {int x0,y0,x1,y1;Rect rect;};
            for (const Axis& line : {
                Axis{1,2,4,2,Rect(1,2,4,1)}, Axis{4,2,1,2,Rect(1,2,4,1)},
                Axis{2,1,2,4,Rect(2,1,1,4)}, Axis{2,4,2,1,Rect(2,1,1,4)},
                Axis{2,2,2,2,Rect(2,2,1,1)}})
            {
                reset(screen, 8, 7, initial);
                base->DrawLine(line.x0,line.y0,line.x1,line.y1,color,mode);
                checkRect(screen, screen.GetBits(), line.rect, initial, color, mode, "inherited axis line virtualFill RGB");
                reset(screen, 8, 7, initial);
                base->DrawLineAA(line.x0,line.y0,line.x1,line.y1,color,mode);
                checkRect(screen, screen.GetBits(), line.rect, initial, color, mode, "inherited axis AA virtualFill RGB");
            }
            reset(screen, 8, 7, initial);
            Span spans[] = {{1,2,4}, {2,4,3}};
            base->FillScanLines(spans, 2, color, mode);
            for (int y=0;y<7;++y)for(int x=0;x<8;++x)
            {
                const bool inside=(y==2&&x>=1&&x<5)||(y==4&&x>=2&&x<5);
                check((screen.GetBits()[y*8+x]&0xffffff)==(inside?NativeFillRGB(initial,color,mode):(initial&0xffffff)),
                    "actual base span virtualFill RGB");
            }
            check(screen.GetBits()[56]==0x4beefade,"allocation guard");
        }

    // Original dispatch admits only normal/additive. No extra draw mode is invented.
    for (int mode : {-1, 2, 7})
    {
        reset(screen, 2, 2, 0xff123456);
        base->FillRect(Rect(0,0,2,2),Color(128,64,255,128),mode);
        for (int i=0;i<4;++i)check(screen.GetBits()[i]==0xff123456,"unknown fill mode unchanged");
    }

    // Preserve the distinct literal MemoryImage offscreen arithmetic.
    MemoryImage offscreen(&app);
    struct OldCase {uint32_t initial;Color color;int mode;uint32_t expected;};
    for (const auto& item : {
        OldCase{0xff5a5a5a,Color(128,128,128,255),0,0xff808080},
        OldCase{0xff000000,Color(255,255,255,1),0,0xff000000},
        OldCase{0xff010101,Color(1,1,1,128),0,0xff010101},
        OldCase{0xff000000,Color(255,255,255,128),1,0xff7f7f7f}})
    {
        reset(offscreen,1,1,item.initial);
        offscreen.FillRect(Rect(0,0,1,1),item.color,item.mode);
        check(offscreen.GetBits()[0]==item.expected,"literal offscreen MI unchanged");
    }
    // No nonaxis normal/additive line change: test its actual first drawn pixel.
    for(int mode=0;mode<2;++mode)for(int alpha:{0,1,128,254,255})
    {
        const uint32_t initial=0xff315a01;Color color(128,21,255,alpha);
        reset(screen,8,7,initial);base->DrawLine(1,1,6,4,color,mode);
        const uint32_t expected=mode?NativeFillRGB(initial,color,1):NativeNormalLineFirstRGB(initial,color);
        check((screen.GetBits()[9]&0xffffff)==expected,"nonaxis line first-pixel unchanged");
    }
    for(const auto& group:groups)
        std::printf("DIFFERENCE %s: %llu\n",group.first,static_cast<unsigned long long>(group.second));
    std::printf("%s %llu checks, %llu differences; actual source, no game/audio initialization.\n",
        failures?"FAIL":"PASS",static_cast<unsigned long long>(checks),static_cast<unsigned long long>(failures));
    return failures?1:0;
}
