/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
#pragma once

// Authored scalar reference, not extracted original executable code.
// Conditional successful-lock opaque DD32 RGB888 software path:
// NormalFillRect0x57b817..0x57ba3e; AdditiveFillRect0x57bd51..0x57bee6.
// C/A/D are ordinary8-bit channel/alpha/destination values. Conversion of
// the native unsigned-mask expressions gives these scalar integer equations.
// Native unused high alpha bits are excluded; the CPU transport uses A255.
uint32_t NativeFillRGB(uint32_t destination, const Color& color, int mode)
{
    if (mode != 0 && mode != 1)
        return destination & 0xffffff;
    uint32_t output = 0;
    for (int shift : {0, 8, 16})
    {
        const int c = shift == 16 ? color.mRed : shift == 8 ? color.mGreen : color.mBlue;
        const int d = (destination >> shift) & 255;
        const int a = color.mAlpha;
        int channel;
        if (mode == 1)
            channel = std::min(255, d + c * a / 255);
        else if (a == 255)
            channel = c == 0 ? 0 : c - 1;
        else
            channel = d * (256 - a) / 256 + (c * a + 127) / 256;
        output |= uint32_t(channel) << shift;
    }
    return output;
}

// Nonaxis NormalDrawLine first-pixel control only:0x573b0b..0x573b4d,
// 0x5747dc..0x574818,0x574d7e..0x574dfa,0x574f47..0x574fb0.
// Its half-mask correction differs from FillRect's full-mask correction.
uint32_t NativeNormalLineFirstRGB(uint32_t destination, const Color& color)
{
    uint32_t output = 0;
    for (int shift : {0, 8, 16})
    {
        const int c = shift == 16 ? color.mRed : shift == 8 ? color.mGreen : color.mBlue;
        const int d = (destination >> shift) & 255;
        const int a = color.mAlpha;
        int channel;
        if (a == 255)
            channel = (c * 255 + 127) / 256;
        else
        {
            const int q = (c * a + 128) / 256;
            channel = (q * 255 + 127) / 256 + (d * (256 - a) + 127) / 256;
        }
        output |= uint32_t(channel) << shift;
    }
    return output;
}
