"""Prepare an isolated7 from authenticated immutable6; no original/game data."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent/'software6-candidate'
assert ROOT.name=='software7-candidate'
def sha(data):return hashlib.sha256(data).hexdigest()
archive=BASE/'pvz-portable-0.2.6-web-software.6-source.zip'
assert sha(archive.read_bytes())=='0358d6b633c2c900f49a89d948dc6b72ab542a56bea6fa8de66f33f40d708794'
with zipfile.ZipFile(archive) as z:
 prefix='software6-candidate/source/'
 pinned={n[len(prefix):]:z.read(n) for n in z.namelist() if n.startswith(prefix) and not n.endswith('/')}
current={p.relative_to(BASE/'source').as_posix():p.read_bytes() for p in (BASE/'source').rglob('*') if p.is_file() and '.git' not in p.relative_to(BASE/'source').parts}
assert current==pinned and len(pinned)==755
assert not (ROOT/'source').exists(),'Do not overwrite an isolated candidate'
shutil.copytree(BASE/'source',ROOT/'source')
parent={'candidate':'0.2.6-web-software.6','archiveSha256':sha(archive.read_bytes()),'sourceFiles':{n:sha(d) for n,d in pinned.items()},'artifacts':{n:sha((BASE/n).read_bytes()) for n in ['verification.json','package.json','web-software.6.patch','build/pvz-portable.js','build/pvz-portable.wasm']}}
(ROOT/'software6-parent.json').write_text(json.dumps(parent,indent=2)+'\n')
for folder in ['tests','presenter-tests','stretch-tests','dd32-tests','mirror-tests','fill-tests','unscaled-mirror-tests','matte-regression','retained4','retained5']:
 shutil.copytree(BASE/folder,ROOT/folder,ignore=shutil.ignore_patterns('generated*','results','*.wasm','*.o','*.obj','*.pyc','__pycache__'))
for name in ['build-candidate.ps1']:
 shutil.copyfile(BASE/name,ROOT/name)
print(json.dumps({'sourceFiles':len(pinned),'copiedSource':'software7-candidate/source','baseline6Authenticated':True}))
