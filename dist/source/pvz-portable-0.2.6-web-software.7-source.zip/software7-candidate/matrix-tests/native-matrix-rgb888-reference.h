// Independent scalar transcription of addressed original RGB888 kernels.
// Valid UV domain [0,width*65536] x [0,height*65536]; raw committed texture.
// Not a whole-triangle scan converter or a native runtime capture.
#pragma once
#include <algorithm>
#include <cstdint>
namespace NativeMatrixRGB888 {
struct Tint { unsigned a,r,g,b; };
inline uint32_t Sample(const uint32_t *p,int width,int height,int u,int v,bool linear) {
  if(!linear) {
    uint32_t pos=(uint32_t(v)>>16)*unsigned(width)+(uint32_t(u)>>16);
    return pos<unsigned(width*height)?p[pos]:0;
  }
  int qx=u-0x8000,qy=v-0x8000;
  int bx=qx>0?(qx&~0xffff):0,by=qy>0?(qy&~0xffff):0;
  int dx=qx>0 && (bx>>16)<width-1?1:0;
  int dy=qy>0 && (by>>16)<height-1?width:0;
  unsigned fx=(unsigned(qx-bx)&0xfffe)+1,fy=(unsigned(qy-by)&0xfffe)+1;
  unsigned weights[4]={unsigned((uint32_t(65536-fx)*(65536-fy))>>16),
    unsigned((uint32_t(fx)*(65536-fy))>>16),
    unsigned((uint32_t(65536-fx)*fy)>>16),unsigned((uint32_t(fx)*fy)>>16)};
  int pos=(by>>16)*width+(bx>>16);
  uint32_t pixels[4]={p[pos],p[pos+dx],p[pos+dy],p[pos+dx+dy]};
  unsigned alphas[4],a=0;for(int i=0;i<4;i++){alphas[i]=((pixels[i]>>24)*weights[i])>>16;a+=alphas[i];}
  uint32_t result=(a&255)<<24;
  for(unsigned shift:{0u,8u,16u}) {
    unsigned sum=0;for(int i=0;i<4;i++)sum+=((pixels[i]>>shift)&255)*alphas[i];
    result|=((sum>>8)&255)<<shift;
  }
  return result;
}
inline uint32_t Pixel(uint32_t texture,uint32_t dest,Tint tint,bool global,bool linear,bool additive) {
  unsigned a=texture>>24;if(a<=8)return dest;
  unsigned channels[3]={tint.b,tint.g,tint.r};
  unsigned effective=global?(a*tint.a>>8):a;
  uint32_t result=0xff000000;
  for(unsigned k=0;k<3;k++) {
    unsigned shift=k*8,s=(texture>>shift)&255,d=(dest>>shift)&255;
    if(global)s=s*channels[k]>>8;
    if(linear && global)s=s*tint.a>>8;
    unsigned value;
    if(additive)value=std::min(255u,d+(linear?s:(s*effective>>8)));
    else if(effective>=240)value=s;
    else value=(linear?s:(s*effective>>8))+(d*(255-effective)>>8);
    result|=value<<shift;
  }
  return result;
}
}
