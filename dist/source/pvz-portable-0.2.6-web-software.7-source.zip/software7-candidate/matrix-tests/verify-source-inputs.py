"""Pin the six-path7 scope and preserve every existing6 method/source input."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent.parent;BASE=ROOT.parent/'software6-candidate'
def sha(data):return hashlib.sha256(data).hexdigest()
parent=json.loads((ROOT/'software6-parent.json').read_text())
def files(root):return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}
assert files(BASE/'source')==parent['sourceFiles']
for path,pin in parent['artifacts'].items():assert sha((BASE/path).read_bytes())==pin,path
current=files(ROOT/'source')
changed=sorted(n for n in parent['sourceFiles'] if current[n]!=parent['sourceFiles'][n]);added=sorted(set(current)-set(parent['sourceFiles']))
assert changed==['CMake/ProjectVersion.cmake','src/PvzpLib/PvzpDrawTriangle.inc','src/SexyAppFramework/graphics/SoftwareScreenImage.cpp','src/SexyAppFramework/graphics/SoftwareScreenImage.h']
assert added==['src/PvzpLib/PvzpNativeScreenPixel888.inc','src/PvzpLib/PvzpNativeScreenTexel.inc'] and len(current)==757
def body(text,start):
 brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if not depth:return text[start:end+1]
 raise AssertionError(start)
path='src/SexyAppFramework/graphics/SoftwareScreenImage.cpp';before=(BASE/'source'/path).read_text();after=(ROOT/'source'/path).read_text();methods={}
for match in re.finditer(r'(?:void|uint32_t) SoftwareScreenImage::\w+\(|SoftwareScreenImage::SoftwareScreenImage\(',before):
 signature=match[0];assert after.count(signature)==1
 left=body(before,match.start());right=body(after,after.index(signature));assert left==right,signature
 methods[signature]=sha(left.encode())
receipt={'candidate':'0.2.6-web-software.7','sourceFiles':757,'changedExisting':changed,'added':added,'unchangedExisting6Files':751,'existing6MethodBodiesPreserved':methods,'fullSourceFingerprint':current,'baseline6SourceAndArtifactsUnchanged':True}
(ROOT/'software7-change-record.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'sourceFiles':757,'changedExisting':len(changed),'added':len(added),'unchanged6Files':751,'existingMethodBodiesPreserved':len(methods)},indent=2))
