"""Frozen6 registered RGB888 texture-alpha callbacks vs static native scalar math.
Runs only authored 4x4 triangle fixtures, not engine or original code.
"""
from pathlib import Path
import hashlib,json,os,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
SRC=Path(os.environ.get('MATRIX_SOURCE_ROOT',str(ROOT/'source')))/'src'
SDK=ROOT.parents[1]/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
OUT=Path(os.environ.get('MATRIX_TEST_OUTPUT',str(HERE/'results/candidate')));OUT.mkdir(parents=True,exist_ok=True)
qa=json.loads((ROOT/'reference-tests/reference.json').read_text());assert qa['schemaVersion']==1
qa_rows=[]
for c in qa['cases']:
 assert len(c['pixels'])==c['width']*c['height']<=9
 pixels=','.join('0x'+p+'u' for p in c['pixels'])
 values=[c['width'],c['height'],c['u16'],c['v16'],c['tintKind'],int(c['linear']),int(c['additive']),*c['tint']]
 qa_rows.append('{'+','.join(map(str,values))+',0x'+c['dest']+'u,0x'+c['expected']+'u,{'+pixels+'}}')
pre=r'''
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <initializer_list>
#include "native-matrix-rgb888-reference.h"
using ulong=unsigned long;static_assert(sizeof(ulong)==4);
static bool fixtureScreenContext=true;
namespace Sexy { bool NativeScreenRasterTargetMatches(const void*,unsigned){return fixtureScreenContext;} }
struct SWHelper{struct SWVertex{int x,y,a,r,g,b,u,v;};struct SWTextureInfo{const unsigned*pTexture;int pitch;unsigned endpos;};struct SWDiffuse{unsigned a,r,g,b;};using signed64=int64_t;};
bool gPvzpTriangleDrawAdditive=false;
static int FixedFloor(int x){return x>0?(x&0xffff0000):(x&0xffff0000)-0x10000;}
'''
declarations=[];bodies=[]
for global_color in (0,1,2):
 for linear in (0,1):
  if global_color==2 and not linear:continue
  mod=1 if global_color==2 else 0
  glob=1 if global_color==1 else 0
  name=f'PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD{mod}_GLOB{glob}_BLEND{linear}'
  declarations.append(f'void {name}_ADDITIVE(SWHelper::SWVertex*,void*,unsigned,const SWHelper::SWTextureInfo*,SWHelper::SWDiffuse&);')
  for additive in (False,True):
   defs=f'#define TRI0 1\n#define TRI2 1\n#define TRI3 {mod}\n#define TRI4 {glob}\n#define TRI5 {linear}\n'
   bodies.append(defs+('#define NAME_ADDITIVE\n' if additive else '')+'#include "PvzpLib/PvzpDrawTriangle.inc"\n'+('#undef NAME_ADDITIVE\n' if additive else '')+'\n'.join(f'#undef TRI{k}' for k in (0,2,3,4,5))+'\n')
main=r'''
using Func=void(*)(SWHelper::SWVertex*,void*,unsigned,const SWHelper::SWTextureInfo*,SWHelper::SWDiffuse&);
struct QACase{int width,height,u,v,kind,linear,additive,A,R,G,B;uint32_t dest,expected,pixels[9];};
static const QACase qaCases[]={__QA_CASES__};
int main(){
  Func funcs[3][2]={{PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0,PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1},{PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0,PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1},{nullptr,PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1}};
  NativeMatrixRGB888::Tint tints[]={{255,255,255,255},{255,75,75,255},{255,100,100,100},{128,75,75,255},{0,255,255,255},{1,255,128,64},{254,1,254,255}};
  const int uv[][2]={{0,0},{0x4000,0x4000},{0x8000,0x8000},{0x8001,0x8001},{0x10000,0x10000},{0x18000,0x18000},{0x20000,0x10000},{0x28000,0x28000},{0x2ffff,0x2ffff},{0x30000,0x30000},{0x8000,0x18000},{0x18000,0x8000}};
  unsigned long long checks[3][2][2]={},differences[3][2][2]={},interiorNormalFailures=0;
  unsigned witness6=0,witnessNative=0,edge6=0,edgeNative=0,vertex6=0,vertexNative=0;
  uint64_t offscreenHash=1469598103934665603ull;
  for(unsigned a=0;a<256;a++)for(unsigned c:{0u,64u,128u,255u})for(unsigned d:{0u,32u,128u,255u})
  for(int g=0;g<3;g++)for(int l=0;l<2;l++)for(int add=0;add<2;add++)for(int ti=0;ti<(g?7:1);ti++)for(auto&p:uv){
    if(g==2&&!l)continue;
    uint32_t pixels[9];for(unsigned i=0;i<9;i++){
      unsigned r=(c+i*23)&255,b=(c^0x55)+i*7;
      pixels[i]=(a<<24)|(r<<16)|(((255-c+i*11)&255)<<8)|(b&255);
    }
    uint32_t dst=0xff000000|(d<<16)|((d^0xaa)<<8)|(255-d),output[16];std::fill_n(output,16,dst);
    auto tint=tints[ti];SWHelper::SWDiffuse gd{tint.a,tint.r,tint.g,tint.b};SWHelper::SWTextureInfo texture{pixels,3,9};
    SWHelper::SWVertex verts[3]={{0,0,0,0,0,0,p[0],p[1]},{4<<16,0,0,0,0,0,p[0],p[1]},{0,4<<16,0,0,0,0,p[0],p[1]}};
    if(g==2){gd={255,255,255,255};for(auto&v:verts){v.a=tint.a<<16;v.r=tint.r<<16;v.g=tint.g<<16;v.b=tint.b<<16;}}
    gPvzpTriangleDrawAdditive=add;funcs[g][l](verts,output,16,&texture,gd);
    auto sample=NativeMatrixRGB888::Sample(pixels,3,3,p[0],p[1],l);
    auto expected=NativeMatrixRGB888::Pixel(sample,dst,tint,g,l,add);
    for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){
      auto want=x<4-y?expected:dst;checks[g][l][add]++;
      if(output[y*4+x]!=want){differences[g][l][add]++;if(!add&&p[0]>0x8000&&p[0]<0x28000&&p[1]>0x8000&&p[1]<0x28000)interiorNormalFailures++;}
    }
    if(a==128&&c==128&&d==32&&g==1&&l==1&&add==1&&ti==1&&p[0]==0x10000&&p[1]==0x10000){witness6=output[0];witnessNative=expected;}
    if(a==255&&c==128&&d==32&&g==0&&l==1&&add==0&&p[0]==0x8000&&p[1]==0x8000){edge6=output[0];edgeNative=expected;}
    if(a==128&&c==128&&d==32&&g==2&&l==1&&add==1&&ti==1&&p[0]==0x10000&&p[1]==0x10000){vertex6=output[0];vertexNative=expected;}
    std::fill_n(output,16,dst);fixtureScreenContext=false;
    funcs[g][l](verts,output,16,&texture,gd);fixtureScreenContext=true;
    for(auto word:output){offscreenHash^=word;offscreenHash*=1099511628211ull;}
  }
  unsigned qaFailures=0,qaReferenceFailures=0,qaAssertions=0;
  for(const auto&c:qaCases){
    uint32_t output[16];std::fill_n(output,16,c.dest);
    auto tint=NativeMatrixRGB888::Tint{unsigned(c.A),unsigned(c.R),unsigned(c.G),unsigned(c.B)};
    auto sample=NativeMatrixRGB888::Sample(c.pixels,c.width,c.height,c.u,c.v,c.linear);
    if(NativeMatrixRGB888::Pixel(sample,c.dest,tint,c.kind!=0,c.linear,c.additive)!=c.expected)qaReferenceFailures++;
    SWHelper::SWDiffuse gd{unsigned(c.A),unsigned(c.R),unsigned(c.G),unsigned(c.B)};
    SWHelper::SWTextureInfo texture{c.pixels,c.width,unsigned(c.width*c.height)};
    SWHelper::SWVertex verts[3]={{0,0,0,0,0,0,c.u,c.v},{4<<16,0,0,0,0,0,c.u,c.v},{0,4<<16,0,0,0,0,c.u,c.v}};
    if(c.kind==2){gd={255,255,255,255};for(auto&v:verts){v.a=c.A<<16;v.r=c.R<<16;v.g=c.G<<16;v.b=c.B<<16;}}
    gPvzpTriangleDrawAdditive=c.additive;funcs[c.kind][c.linear](verts,output,16,&texture,gd);
    for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++){qaAssertions++;if(output[y*4+x]!=(x<4-y?c.expected:c.dest))qaFailures++;}
    std::fill_n(output,16,c.dest);fixtureScreenContext=false;funcs[c.kind][c.linear](verts,output,16,&texture,gd);fixtureScreenContext=true;
    for(auto word:output){offscreenHash^=word;offscreenHash*=1099511628211ull;}
  }
  printf("{\"groups\":[");bool comma=false;
  for(int g=0;g<3;g++)for(int l=0;l<2;l++)for(int add=0;add<2;add++){
    if(g==2&&!l)continue;
    printf("%s{\"tintKind\":%d,\"bilinear\":%d,\"additive\":%d,\"assertions\":%llu,\"differences\":%llu}",comma?",":"",g,l,add,checks[g][l][add],differences[g][l][add]);comma=true;
  }
  printf("],\"interiorNormalFailures\":%llu,\"tintedBilinearActual\":\"%08x\",\"tintedBilinearNative\":\"%08x\",\"normalEdgeActual\":\"%08x\",\"normalEdgeNative\":\"%08x\",\"atlasVertexActual\":\"%08x\",\"atlasVertexNative\":\"%08x\",\"qaCases\":%zu,\"qaAssertions\":%u,\"qaFailures\":%u,\"qaReferenceFailures\":%u,\"offscreenHash\":\"%016llx\"}\n",interiorNormalFailures,witness6,witnessNative,edge6,edgeNative,vertex6,vertexNative,sizeof(qaCases)/sizeof(qaCases[0]),qaAssertions,qaFailures,qaReferenceFailures,(unsigned long long)offscreenHash);
  uint64_t total=qaFailures+qaReferenceFailures;for(auto &g: differences)for(auto &l:g)for(auto n:l)total+=n;
  return total?1:0;
}
'''
main=main.replace('__QA_CASES__',',\n'.join(qa_rows))
cpp=OUT/'actual.cpp';cpp.write_text(pre+'\n'.join(declarations)+'\n'+'\n'.join(bodies)+main,encoding='utf-8',newline='\n')
temp=OUT/'tmp';temp.mkdir(exist_ok=True)
env=os.environ.copy();env.update({'TEMP':str(temp),'TMP':str(temp),'EMCC_TEMP_DIR':str(temp),'EMSDK_NODE':str(SDK/'node/24.19.0_64bit/node.exe')})
cmd=[str(SDK/'python/3.13.3_64bit/python.exe'),str(SDK/'upstream/emscripten/em++.py'),str(cpp),'-I'+str(SRC),'-I'+str(SRC/'SexyAppFramework'),'-I'+str(HERE),'-std=c++20','-O2','-sENVIRONMENT=node','-o',str(OUT/'actual.js')]
build=subprocess.run(cmd,capture_output=True,text=True,env=env)
if build.returncode:raise RuntimeError(build.stderr)
run=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(OUT/'actual.js')],capture_output=True,text=True)
result=json.loads(run.stdout.strip().splitlines()[-1]);result['exitCode']=run.returncode
files=['PvzpLib/PvzpDrawTriangle.inc','SexyAppFramework/graphics/SWTri/SWTri_Loop.inc','SexyAppFramework/graphics/SWTri/SWTri_Pixel888.inc','SexyAppFramework/graphics/SWTri/SWTri_GetTexel.inc','SexyAppFramework/graphics/SWTri/SWTri_TexelARGB.inc']
files+=[f for f in ['PvzpLib/PvzpNativeScreenPixel888.inc','PvzpLib/PvzpNativeScreenTexel.inc'] if (SRC/f).exists()]
result['inputSha256']={f:hashlib.sha256((SRC/f).read_bytes()).hexdigest() for f in files}
result['generatedFileSha256']=hashlib.sha256(cpp.read_bytes()).hexdigest();result['referenceSha256']=hashlib.sha256((HERE/'native-matrix-rgb888-reference.h').read_bytes()).hexdigest()
result['qaFixtureSha256']=hashlib.sha256((ROOT/'reference-tests/reference.json').read_bytes()).hexdigest()
result['scope']='Actual registered RGB888 alpha callbacks with controlled screen-context dependency; full triangle functions/flatUV. Unchanged independent native header plus13920 independent mixed-alpha/dimension cases. Separate actual-production virtual/context suite covers context ownership. No original execution or complete scene/geometry proof.'
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(run.returncode)
