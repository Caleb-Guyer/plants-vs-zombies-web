"""Actual virtual7 screen/context methods + actual callbacks; base draw double.
Geometry remains MI6, pinned separately. No engine/native/UI initialization.
"""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,zipfile
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
SDK=ROOT.parents[1]/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
def sha(data):return hashlib.sha256(data).hexdigest()
def function(text,signature):
 start=text.index(signature);brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if not depth:return text[start:end+1]
 raise AssertionError(signature)
parent=json.loads((ROOT/'software6-parent.json').read_text());baseline=HERE/'context-baseline'
paths=['src/PvzpLib/PvzpDrawTriangle.inc','src/PvzpLib/PvzpDrawTriangleInc.inc','src/PvzpLib/EffectSystem.h','src/SexyAppFramework/graphics/SoftwareScreenImage.cpp','src/SexyAppFramework/graphics/SoftwareScreenImage.h','src/SexyAppFramework/graphics/SWTri.cpp']
paths+=['src/SexyAppFramework/graphics/SWTri/'+n for n in ['SWTri_Loop.inc','SWTri_Pixel888.inc','SWTri_Pixel8888.inc','SWTri_Pixel565.inc','SWTri_Pixel555.inc','SWTri_GetTexel.inc','SWTri_TexelARGB.inc']]
if not baseline.exists():
 archive=ROOT.parent/'software6-candidate/pvz-portable-0.2.6-web-software.6-source.zip';assert sha(archive.read_bytes())==parent['archiveSha256']
 with zipfile.ZipFile(archive) as z:
  for name in paths:
   data=z.read('software6-candidate/source/'+name);assert sha(data)==parent['sourceFiles'][name]
   p=baseline/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (baseline/'manifest.json').write_text(json.dumps({n:parent['sourceFiles'][n] for n in paths},indent=2)+'\n')
for name in paths:assert sha((baseline/name).read_bytes())==parent['sourceFiles'][name]
results={};expanded={}
for tag,source in [('baseline6',baseline),('candidate7',ROOT/'source')]:
 output=HERE/'results'/('context-'+tag);output.mkdir(parents=True,exist_ok=True)
 graphics=source/'src/SexyAppFramework/graphics';screen=(graphics/'SoftwareScreenImage.cpp').read_text();header=(graphics/'SoftwareScreenImage.h').read_text()
 candidate='void SoftwareScreenImage::BltMatrix(' in screen
 methods=''
 if candidate:methods=screen[screen.index('namespace\n{'):screen.index('SoftwareScreenImage::SoftwareScreenImage')]
 else:methods='bool Sexy::NativeScreenRasterTargetMatches(const void*,unsigned){return false;}\n'
 methods+=function(screen,'SoftwareScreenImage::SoftwareScreenImage(')+'\n'+function(screen,'void SoftwareScreenImage::Create(')
 declarations=''
 if candidate:
  methods+='\n'+function(screen,'void SoftwareScreenImage::BltMatrix(')+'\n'+function(screen,'void SoftwareScreenImage::BltTrianglesTex(')
  declarations='void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)override;\nvoid BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)override;'
 callback_declarations='\n'.join(l for l in (source/'src/PvzpLib/EffectSystem.h').read_text().splitlines() if l.startswith('extern void PvzpDrawTriangle_'))
 cpp=(HERE/'context-fixtures.cpp').read_text().replace('SCREEN_DECLARATIONS',declarations).replace('PRODUCTION_METHODS',methods).replace('FIXED_FLOOR',function((graphics/'SWTri.cpp').read_text(),'static int FixedFloor(')).replace('CALLBACK_DECLARATIONS',callback_declarations).replace('IS_CANDIDATE','true' if candidate else 'false')
 generated=output/'actual.cpp';generated.write_text(cpp,encoding='utf-8',newline='\n')
 temp=output/'tmp';temp.mkdir(exist_ok=True)
 env=os.environ.copy();env.update({'TEMP':str(temp),'TMP':str(temp),'EMCC_TEMP_DIR':str(temp),'EMSDK_NODE':str(SDK/'node/24.19.0_64bit/node.exe')})
 cmd=[str(SDK/'python/3.13.3_64bit/python.exe'),str(SDK/'upstream/emscripten/em++.py'),str(generated),'-I'+str(source/'src'),'-I'+str(source/'src/SexyAppFramework'),'-std=c++20','-O2','-sENVIRONMENT=node','-o',str(output/'actual.js')]
 build=subprocess.run(cmd,capture_output=True,text=True,env=env);assert not build.returncode,build.stderr
 preprocess=cmd[:-2]+['-E','-P'];pre=subprocess.run(preprocess,capture_output=True,env=env);assert not pre.returncode,pre.stderr.decode()
 (output/'expanded.cpp').write_bytes(pre.stdout)
 text=pre.stdout.decode();bodies={}
 for match in re.finditer(r'\bvoid\s+(PvzpDrawTriangle_\w+)\([^;{}]*\)\s*\{',text):
  brace=match.end()-1;depth=0
  for end in range(brace,len(text)):
   depth+=(text[end]=='{')-(text[end]=='}')
   if not depth:break
  bodies[match[1]]=re.sub(r'\s+','',text[brace:end+1])
 expanded[tag]=bodies
 run=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(output/'actual.js')],capture_output=True,text=True)
 result=json.loads(run.stdout.strip().splitlines()[-1]);result['exitCode']=run.returncode;result['generatedFileSha256']=sha(generated.read_bytes())
 result['sourceSha256']={name:sha((source/name).read_bytes()) for name in paths}
 (output/'results.json').write_text(json.dumps(result,indent=2)+'\n');assert not run.returncode,(tag,result)
 results[tag]=result
assert results['baseline6']['preservationHash']==results['candidate7']['preservationHash']
assert set(expanded['baseline6'])==set(expanded['candidate7']) and len(expanded['baseline6'])==92
unchanged=[];closed=[]
for name,body in expanded['baseline6'].items():
 match=re.fullmatch(r'PvzpDrawTriangle_(\d+)_TEX1_TALPHA([01])_MOD([01])_GLOB([01])_BLEND([01])(?:_ADDITIVE)?',name);assert match,name
 fmt,alpha,vertex,glob,linear=match.groups()
 is_closed=fmt=='0888' and alpha=='1' and (vertex=='0' or glob=='0' and linear=='1')
 if is_closed:closed.append(name)
 else:assert body==expanded['candidate7'][name],name;unchanged.append(name)
assert len(closed)==10 and len(unchanged)==82
receipt={'status':'PASS','variants':results,'invalidAndUnprovedBranchesPreserved':True,'unchangedExpandedCallbacks':unchanged,'closedExpandedCallbacks':closed,'scope':'Extracted actual constructors/Create/newvirtualmethods/RAII/query plus actual callbacks, base draw hook supplies authored flat triangle. Nested offscreen/screen, both virtual boundaries, early-return and outside-scope restoration. All82unclosed callback bodies preprocessed exact6. No inherited MI geometry/native execution claim.'}
(HERE/'results/context-results.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'status':'PASS','checksPerVariant':results['candidate7']['checks'],'failures':results['candidate7']['failures'],'unprovedBranchesPreserved':True,'unchangedExpandedCallbacks':len(unchanged)},indent=2))
