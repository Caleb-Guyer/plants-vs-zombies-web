Reproduce from this candidate folder using Python:
  python matrix-tests/run-paired-tests.py
  python matrix-tests/run-context-tests.py

Source7 callback tests compile actual complete PvzpDrawTriangle.inc normal
and additive specializations with their real loop/pixel/texel includes.
Their external target-query dependency is controlled for the arithmetic
grid. The separate context tests compile the actual production target state,
RAII/query and virtual wrappers. Its base draw double supplies the callback
triangle; it deliberately does not emulate MI clipping/transform geometry.
All MI/SWTri geometry inputs are separately pinned exact6.

Frozen6 baseline source fragments are authenticated against the immutable6
sourceZIP and parent fingerprint. The two regression commands above use the
included baseline fragments; they do not require sibling6 source or binaries.
The already installed pinned SDK runtime is required.
The independent C++ reference a4e0af...c864 is unchanged from the reviewed
static proof. reference-tests/ contains another agent's13,920 authored
Python/math expected cases plus26 hand-worked literal anchors, no game data.
generatedFileSha256 hashes actual UTF8/LF C++ bytes compiled in each run.
The inherited retained suites preserve their historical logical-text hash
convention where applicable; new7 suites use actual disk-byte hashes.

Exit0 of the paired runner requires frozen6 expected failure,7zero failures,
all independent reference checks and identical offscreen output hash. The
context runner requires all169 checks and82 unchanged expanded callbacks.
Neither runner initializes the game, browser, audio or original executable.

Producer-only preservation guard: matrix-tests/verify-source-inputs.py
requires the live sibling software6-candidate source and recorded build/
package artifacts. It writes software7-change-record.json. It is intended
for the original producer workspace and is not part of standalone regression
reproduction or a read-only archive check.
