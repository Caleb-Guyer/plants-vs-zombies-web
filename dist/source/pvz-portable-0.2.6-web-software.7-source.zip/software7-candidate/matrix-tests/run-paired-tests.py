"""Immutable6 baseline fail / isolated7 pass; no game/native initialization."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
def sha(data):return hashlib.sha256(data).hexdigest()
parent=json.loads((ROOT/'software6-parent.json').read_text())
archive=ROOT.parent/'software6-candidate/pvz-portable-0.2.6-web-software.6-source.zip'
baseline=HERE/'software6-baseline'
files=['src/PvzpLib/PvzpDrawTriangle.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Loop.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Pixel888.inc','src/SexyAppFramework/graphics/SWTri/SWTri_GetTexel.inc','src/SexyAppFramework/graphics/SWTri/SWTri_TexelARGB.inc']
if not baseline.exists():
 assert sha(archive.read_bytes())==parent['archiveSha256']
 with zipfile.ZipFile(archive) as z:
  for name in files:
   data=z.read('software6-candidate/source/'+name);assert sha(data)==parent['sourceFiles'][name]
   path=baseline/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 (baseline/'manifest.json').write_text(json.dumps({'sourceArchiveSha256':parent['archiveSha256'],'files':{n:parent['sourceFiles'][n] for n in files}},indent=2)+'\n')
for name in files:assert sha((baseline/name).read_bytes())==parent['sourceFiles'][name]
assert sha((HERE/'native-matrix-rgb888-reference.h').read_bytes())=='a4e0af0695974ae8e6a8763b9282b93271c57b924ddf499b0a8f5b6df38dc864'
receipts={}
for tag,source in [('baseline6',baseline),('candidate7',ROOT/'source')]:
 output=HERE/'results'/tag
 env=os.environ.copy();env.update({'MATRIX_SOURCE_ROOT':str(source),'MATRIX_TEST_OUTPUT':str(output)})
 run=subprocess.run([sys.executable,str(HERE/'run-callback-tests.py')],env=env,capture_output=True,text=True)
 (HERE/(tag+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8',newline='\n')
 assert (output/'results.json').exists(),run.stderr
 receipt=json.loads((output/'results.json').read_text());assert receipt['exitCode']==run.returncode
 assert receipt['qaReferenceFailures']==0 and receipt['qaCases']==13920
 assert run.returncode==(1 if tag=='baseline6' else 0),(tag,receipt)
 receipts[tag]=receipt
assert receipts['baseline6']['offscreenHash']==receipts['candidate7']['offscreenHash'],'Every opaque offscreen buffer must stay6'
assert sum(g['differences'] for g in receipts['baseline6']['groups'])>0
assert not sum(g['differences'] for g in receipts['candidate7']['groups'])
result={'baseline6':receipts['baseline6'],'candidate7':receipts['candidate7'],'offscreenPreserved':True,'status':'PASS actual6 expected failure / actual7 native-equation pass; independent mixed-alpha controls pass'}
(HERE/'results/results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','baseline6Differences':sum(g['differences'] for g in receipts['baseline6']['groups']),'candidate7Differences':sum(g['differences'] for g in receipts['candidate7']['groups']),'candidateQAChecks':receipts['candidate7']['qaAssertions'],'candidateQAFailures':receipts['candidate7']['qaFailures'],'offscreenPreserved':True},indent=2))
