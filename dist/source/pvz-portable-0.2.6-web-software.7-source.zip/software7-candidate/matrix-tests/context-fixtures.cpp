// Authored boundary tests. Actual screen methods/context and all registered
// Pvzp callback bodies are inserted by run-context-tests.py.
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <vector>
using ulong=unsigned long;static_assert(sizeof(ulong)==4);
namespace Sexy {
struct SexyAppBase{};struct Rect{int mX=0,mY=0,mWidth=4,mHeight=4;};
struct Color{int mRed=255,mGreen=255,mBlue=255,mAlpha=255;};
struct SexyMatrix3{};struct TriVertex{float x,y,u,v;uint32_t color;};
struct SWHelper{struct SWVertex{int x,y,a,r,g,b,u,v;};struct SWTextureInfo{const unsigned*pTexture;int pitch;unsigned endpos;};struct SWDiffuse{unsigned a,r,g,b;};using signed64=int64_t;};
class MemoryImage;using Hook=void(*)(MemoryImage*);static Hook drawHook=nullptr;
class Image {
public:
 virtual ~Image()=default;
 virtual void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)=0;
 virtual void BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)=0;
};
class MemoryImage:public Image {
public:
 int mWidth=0,mHeight=0;bool mPurgeBits=false,mForcedMode=false,mHasAlpha=true,mHasTrans=true;
 std::vector<uint32_t> bits;
 explicit MemoryImage(SexyAppBase*){}
 virtual void Create(int w,int h){mWidth=w;mHeight=h;bits.assign(w*h+1,0xff208adf);bits[w*h]=0x4beefade;}
 uint32_t* GetBits(){return bits.data();}
 void SetImageMode(bool trans,bool alpha){mForcedMode=true;mHasTrans=trans;mHasAlpha=alpha;}
 void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)override{if(drawHook)drawHook(this);}
 void BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)override{if(drawHook)drawHook(this);}
};
bool NativeScreenRasterTargetMatches(const void*,unsigned);
class SoftwareScreenImage final:public MemoryImage {
public:
 explicit SoftwareScreenImage(SexyAppBase*);
 void Create(int,int)override;
 SCREEN_DECLARATIONS
};
}
using namespace Sexy;
PRODUCTION_METHODS
FIXED_FLOOR
bool gPvzpTriangleDrawAdditive=false;
CALLBACK_DECLARATIONS
#include "PvzpLib/PvzpDrawTriangleInc.inc"
using Func=void(*)(SWHelper::SWVertex*,void*,unsigned,const SWHelper::SWTextureInfo*,SWHelper::SWDiffuse&);
static Func selected=PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1;
static int hookMode=0,depth=0,checks=0,failures=0;
static bool early=false;
static int sourcePitch=3,sourceEnd=9,uv=0x10000;
static SWHelper::SWDiffuse tint{255,75,75,255};
static uint64_t preservationHash=1469598103934665603ull;
static void check(bool ok){checks++;if(!ok)failures++;}
static void callVirtual(MemoryImage& image,bool triangles){
 Image* base=&image;Rect r;Color c;SexyMatrix3 m;TriVertex v[1][3]{};
 if(triangles)base->BltTrianglesTex(nullptr,v,1,r,c,1,0,0,true);
 else base->BltMatrix(nullptr,0,0,m,r,c,1,r,true);
}
static void raster(MemoryImage* target){
 const bool screen=dynamic_cast<SoftwareScreenImage*>(target)!=nullptr;
 auto surface=target->GetBits();const bool shouldMatch=IS_CANDIDATE&&screen;
 check(NativeScreenRasterTargetMatches(surface,16)==shouldMatch);
 check(!NativeScreenRasterTargetMatches(surface,20));
 uint32_t other=0;check(!NativeScreenRasterTargetMatches(&other,16));
 if(hookMode==1){early=true;return;}
 if(depth==0&&hookMode==2){
   MemoryImage nested(nullptr);nested.Create(4,4);depth++;callVirtual(nested,true);depth--;
   check(!NativeScreenRasterTargetMatches(nested.GetBits(),16));
   check(NativeScreenRasterTargetMatches(surface,16)==shouldMatch);
 }
 if(depth==0&&hookMode==3){
   SoftwareScreenImage nested(nullptr);nested.Create(4,4);depth++;callVirtual(nested,false);depth--;
   check(!NativeScreenRasterTargetMatches(nested.GetBits(),16));
   check(NativeScreenRasterTargetMatches(surface,16)==shouldMatch);
 }
 const unsigned pixels[9]={0x80807fd5,0x80978adc,0x80ae95e3,0x80c5a0ea,0x80dcabf1,0x80f3b6f8,0x800ac1ff,0x8021cc06,0x8038d70d};
 SWHelper::SWTextureInfo texture{pixels,sourcePitch,unsigned(sourceEnd)};
 SWHelper::SWVertex vertices[3]={{0,0,255<<16,75<<16,75<<16,255<<16,uv,uv},
   {4<<16,0,255<<16,75<<16,75<<16,255<<16,uv,uv},{0,4<<16,255<<16,75<<16,75<<16,255<<16,uv,uv}};
 selected(vertices,surface,16,&texture,tint);
 check(target->bits[16]==0x4beefade);
}
int main(){
 drawHook=raster;gPvzpTriangleDrawAdditive=true;
 for(bool triangles:{false,true})for(bool screen:{false,true})for(int mode=0;mode<4;mode++){
   MemoryImage plain(nullptr);SoftwareScreenImage actual(nullptr);
   MemoryImage&target=screen?static_cast<MemoryImage&>(actual):plain;target.Create(4,4);
   hookMode=mode;early=false;callVirtual(target,triangles);
   check(!NativeScreenRasterTargetMatches(target.GetBits(),16));
   if(mode==1){check(early);check(target.bits[0]==0xff208adf);}
   else check(target.bits[0]==((IS_CANDIDATE&&screen)?0xff379eff:0xff275ade));
 }
 // Invalid/unproved parameters must preserve6 even inside the screen scope.
 SoftwareScreenImage target(nullptr);hookMode=0;
 for(int c=0;c<5;c++){
   target.Create(4,4);sourcePitch=3;sourceEnd=9;uv=0x10000;tint={255,75,75,255};
   selected=PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1;
   if(c==0)sourcePitch=2; // endpos9 is not a complete height
   if(c==1)uv=-65536; // UV outside proved range
   if(c==2)tint.a=300; // outside proved color range
   if(c==3)selected=PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0; // vertex-nearest unclosed
   if(c==4)selected=PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1; // combined modulation unclosed
   callVirtual(target,c&1);check(!NativeScreenRasterTargetMatches(target.GetBits(),16));
   for(int i=0;i<16;i++){preservationHash^=target.bits[i];preservationHash*=1099511628211ull;}
 }
 printf("{\"checks\":%d,\"failures\":%d,\"preservationHash\":\"%016llx\"}\n",checks,failures,(unsigned long long)preservationHash);
 return failures?1:0;
}
