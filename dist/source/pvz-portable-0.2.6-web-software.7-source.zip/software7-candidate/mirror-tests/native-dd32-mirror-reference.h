// Authored transcription of native DD32 mirror-stretch math; no original assets.
// Valid finite/int32 geometry, nonvolatile RGB888, successful DD lock only.
#pragma once
namespace NativeDD32Mirror {
struct Tint { int r=255,g=255,b=255,a=255; };
struct ClipResult { double x,y,w,h; Rect destination; };
inline ClipResult Clip(const Rect& s,const Rect& d,const Rect& clip) {
 //5B3330..34C2: intersect first, derive RIGHT-side clip before scaling.
 Rect c=d.Intersection(clip);double fx=double(s.mWidth)/d.mWidth,fy=double(s.mHeight)/d.mHeight;
 int total=d.mWidth-c.mWidth,left=c.mX-d.mX,right=total-left;
 return {s.mX+right*fx,s.mY+(c.mY-d.mY)*fy,
   s.mWidth+(c.mWidth-d.mWidth)*fx,s.mHeight+(c.mHeight-d.mHeight)*fy,c};
}
inline uint32_t Pixel(uint32_t s,uint32_t d,Tint tint,int mode) {
 // NativeAlpha raw5AF7BA..7FE /palette5AF8B6..8FA.
 const int A=s>>24;const bool white=tint.r==255&&tint.g==255&&tint.b==255&&tint.a==255;
 const int a=white?A:A*tint.a/255;
 if(mode==0&&a==0)return d|0xff000000u;
 uint32_t out=0xff000000u;
 for(int channel=0;channel<3;++channel){int shift=channel*8,S=(s>>shift)&255,D=(d>>shift)&255;
  int P=S*(A+1)/256,C=channel==0?tint.b:channel==1?tint.g:tint.r,k=C*tint.a/255,result;
  // Normal raw32 white59A235..2A4, tint59A786..86B.
  // Additive white59B9A3..BA77, tint59BFA7..C0B1 + saturation tables.
  if(mode==0)result=white?D*(256-A)/256+P:(D*(256-a)+P*k)/256;
  else result=std::min(255,D+(white?P:P*k/256)); //599E33: EVERY nonzero mode.
  out|=uint32_t(result)<<shift;
 }return out;
}
inline std::vector<uint32_t> Draw(const std::vector<uint32_t>& source,int sourceWidth,int width,int height,
 const Rect& src,const Rect& draw,const Rect& clip,uint32_t background,Tint tint,int mode) {
 auto c=Clip(src,draw,clip);std::vector<uint32_t> result(width*height,background);
 if(c.destination.mWidth<=0||c.destination.mHeight<=0||c.w<=0||c.h<=0)return result;
 //599E72..EA8;59A173..181: truncate after mirrored clipping, no half-pixel.
 int qy=int(c.y*65536.0),stepY=int(c.h*65536.0/c.destination.mHeight);
 const int qxStart=int(c.x*65536.0),stepX=int(c.w*65536.0/c.destination.mWidth);
 for(int y=0;y<c.destination.mHeight;++y,qy+=stepY){int qx=qxStart;
  for(int x=0;x<c.destination.mWidth;++x,qx+=stepX){
   //59A1B8..2CC: source-first then increment; destination begins at RIGHT.
   int to=(c.destination.mY+y)*width+c.destination.mX+c.destination.mWidth-1-x;
   result[to]=Pixel(source[(qy>>16)*sourceWidth+(qx>>16)],result[to],tint,mode);
  }}return result;
}
}
