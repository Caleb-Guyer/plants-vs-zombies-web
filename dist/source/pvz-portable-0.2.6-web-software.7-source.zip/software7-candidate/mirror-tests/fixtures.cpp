#include "native-dd32-mirror-reference.h"
using NativeDD32Mirror::Tint;
int checks=0,failures=0,draws=0,paletteDraws=0;
void check(bool value,const char* label){++checks;if(!value){if(failures<8)std::printf("FAIL %s\n",label);++failures;}}
void initialize(MemoryImage& image,int w,int h,uint32_t color){image.Create(w,h);for(int i=0;i<w*h;++i)image.GetBits()[i]=color;image.BitsChanged();image.SetImageMode(false,false);}
void one(uint32_t pixel,uint32_t background,Tint tint,int mode,bool fast,int forced=-1){
 App app;MemoryImage source(&app);SoftwareScreenImage target(&app);source.Create(1,1);source.GetBits()[0]=pixel;source.BitsChanged();source.CommitBits();
 if(forced>=0)source.SetImageMode(bool(forced&2),bool(forced&1));
 initialize(target,1,1,background);MemoryImage* base=&target;
 base->StretchBltMirror(&source,Rect(0,0,1,1),Rect(0,0,1,1),Rect(0,0,1,1),Color(tint.r,tint.g,tint.b,tint.a),mode,fast);
 check(target.GetBits()[0]==NativeDD32Mirror::Pixel(pixel,background,tint,mode),"one native mirror pixel/mode/alpha");
 check(target.GetBits()[1]==0x4beefade,"one guard");++draws;
}
std::vector<uint32_t> grid(Tint tint,int mode,bool fast,int layout,bool palette){
 App app;MemoryImage source(&app);SoftwareScreenImage target(&app);source.Create(10,9);
 const uint32_t colors[]={0x00f08020,0x013f8123,0x4081c47f,0x7fffffff,0x80818181,0xbf902010,0xfe71ef05,0xff818181};
 std::vector<uint32_t> pixels(90);for(int i=0;i<90;++i)source.GetBits()[i]=pixels[i]=colors[(i+i/10)%8];source.BitsChanged();source.CommitBits();
 if(palette){source.mColorTable=std::make_unique<uint32_t[]>(256);source.mColorIndices=std::make_unique<uchar[]>(90);for(int i=0;i<256;++i)source.mColorTable[i]=colors[(i*3+1)%8];for(int i=0;i<90;++i){source.mColorIndices[i]=(i+i/10)%8;pixels[i]=colors[(((i+i/10)%8)*3+1)%8];}}
 initialize(target,12,12,0xff818181);const Rect src(1,1,8,7);
 const Rect drawRects[]={{0,0,12,12},{-2,-1,15,14},{0,0,8,7},{1,2,10,9}};
 const Rect clips[]={{0,0,12,12},{1,2,9,8},{0,0,12,12},{2,3,7,6}};
 const Rect draw=drawRects[layout],clip=clips[layout];
 auto expected=NativeDD32Mirror::Draw(pixels,10,12,12,src,draw,clip,0xff818181,tint,mode);
 if(palette){source.mBits.reset();source.BitsChanged();check(!source.mBits&&bool(source.mColorTable)&&bool(source.mColorIndices),"null raw bits plus indexed source immediately before actual virtual call");++paletteDraws;}
 MemoryImage* base=&target;base->StretchBltMirror(&source,draw,src,clip,Color(tint.r,tint.g,tint.b,tint.a),mode,fast);
 std::vector<uint32_t> output(144);for(int i=0;i<144;++i){output[i]=target.GetBits()[i];check(output[i]==expected[i],"native mirrored clip/fixed16/raw-or-indexed grid");}
 check(target.GetBits()[144]==0x4beefade,"grid guard");++draws;return output;
}
void namedBoundary(){
 App app;MemoryImage source(&app);SoftwareScreenImage target(&app);source.Create(3,1);
 const uint32_t p[]={0xff808080,0xffabc7e1,0xffd60e42};for(int i=0;i<3;++i)source.GetBits()[i]=p[i];source.BitsChanged();source.CommitBits();
 const int nativeIndices[]={2,1,1,0,0};
 for(bool fast:{true,false}){initialize(target,5,1,0xff123456);MemoryImage* base=&target;base->StretchBltMirror(&source,Rect(0,0,5,1),Rect(0,0,3,1),Rect(0,0,5,1),Color::White,0,fast);
  for(int i=0;i<5;++i)check(target.GetBits()[i]==p[nativeIndices[i]],"native3to5 boundary [2,1,1,0,0], both fast flags");}
}
int main(){
 const Tint tints[]={{255,255,255,255},{128,64,32,255},{255,255,254,255},{128,128,128,255},{128,64,32,128},{255,255,255,0},{255,128,64,1}};
 for(int alpha:{0,1,64,127,128,254,255})for(int channel:{0,1,20,128,129,254,255})for(int dest:{0,1,127,128,254,255})for(Tint tint:tints)for(int mode:{0,1,2,-1})for(bool fast:{false,true})
  one((uint32_t(alpha)<<24)|(channel<<16)|((255-channel)<<8)|channel,0xff000000|(dest<<16)|(dest<<8)|dest,tint,mode,fast);
 for(Tint tint:tints)for(int mode:{0,1,2,-1})for(bool fast:{false,true})for(int layout=0;layout<4;++layout)for(bool palette:{false,true})grid(tint,mode,fast,layout,palette);
 for(int forced=0;forced<4;++forced)for(int alpha:{0,128,255})for(int mode:{0,1})for(bool fast:{false,true})one((uint32_t(alpha)<<24)|0x819083,0xff818181,Tint{},mode,fast,forced);
 // Native software ignores fastStretch. These paired actual calls also verify
 // raw/indexed input reaches the actual screen override on both values.
 for(bool palette:{false,true}){auto a=grid(Tint{128,64,32,128},0,false,1,palette),b=grid(Tint{128,64,32,128},0,true,1,palette);check(a==b,"fast flag ignored by native software mirror path");}
 namedBoundary();
 std::printf("Mirror DD32: checks=%d failures=%d draws=%d paletteDraws=%d; actual inherited-or-screen virtual mirror calls vs independent addressed reference\n",checks,failures,draws,paletteDraws);
 return failures?1:0;
}
