PRIVATE SOFTWARE.7 — CPU SCREEN REANIMATION RASTER CORRECTIONS

Starts from immutable Software.6 source ZIP0358d6b6...d708794. Four existing
engine files change: version, SoftwareScreenImage.cpp/.h, PvzpDrawTriangle.inc.
Two authored narrow sampler/pixel includes are added (757 engine files).
All751 other6 files and every8 existing6 screen method bodies are exact.
Literal MemoryImage geometry, SWTri clipping/interpolation, shared pixel
includes, renderer selection, audio and game/content logic stay6 code.

Native original DD32 matrix/triangle dispatch selects RGB888 then the same
software helper/callback family. Ordinary reanimation atlas tracks encode
tint in vertex color; direct image tracks use global tint. In6 the game's
_ADDITIVE callbacks use normal pixel blending. Its linear sampler also uses
transparent/out-of-bounds neighbors where the original repeats whole-texture
edge pixels. These were separately addressed and independently reviewed.
No original machine code, image/assets, disassembly or private saves are in
these tests. The packaged native reference is authored functional scalar math.

7 enters a restoring thread-local target context only in the actual screen's
virtual BltMatrix/BltTrianglesTex boundaries, then calls inherited6 geometry.
The callback must match that destination buffer AND bytepitch. It corrects
only RGB888+texture-alpha: white/global nearest+linear, vertex-only linear.
Other82 registered callback bodies preprocess exactly6. Offscreen rendering,
8888/565/555, no-texture-alpha, vertex-nearest and combined vertex/global
paths retain6 behavior. Per-triangle complete dimensions and bounded valid
UV/color state are required; unproved inputs use the old implementation.
The edge rule is for the entire texture, never each atlas subrectangle.

Current actual-code tests (no engine/browser/audio initialization):
matrix-tests/run-paired-tests.py:36,175,872 broad buffer assertions plus
222,720 assertions from13,920 independently authored mixed-alpha/multicolor
fixtures per variant. Frozen6 fails13,512,240 broad comparisons as expected;
current7 has0 broad or independent-fixture failures. The unchanged native
C++ reference agrees with all13,920 independent Python expected pixels.
Screen-disabled buffers match6 across both populations. Covers1x1/1x4/4x1/
2x2/3x3, edge/corner/center/half-texel±1, global alpha endpoints and saturation.

matrix-tests/run-context-tests.py:169 checks per variant,0failures. Compiles
actual production constructors/Create/RAII/query/new virtual methods plus
all92 production Pvzp callbacks. A base draw double supplies a flat authored
triangle, allowing actual virtual screen/offscreen/nested/early-return and
restoration checks without claiming MI geometry. Invalid dimensions/UV/
colors and unclosed combinations preserve6;82 unclosed expanded callback
bodies are exact6. This is synthetic actual-code evidence, not native game
execution, full scene/framebuffer parity or Software.7 UI validation.

All retained6 suites have passed current7 extraction:149 CPU primitives,
20MI white-stretch fixtures,20,900DD32 assertions,98,802 scaled-mirror,
2,118,543 fill/axis/span,3,039,478 unscaled-mirror, renderer-mode failures,
presenter/batcher and9matte fixtures (historical baseline failures expected).
Existing test fixtures/references are unchanged; retained wrappers remove
only new untested matrix/triangle declarations from their focused class
doubles and identify7. New actual boundaries are tested separately above.

Limits remain active: whole native framebuffer/asset/cache recovery and
driver/D3D/DD16/volatile paths; other callback combinations and offscreen
tint/additive; clipped vertex gradients/changingUV/scan interpolation/float
precision; actual7 performance and gameplay/UI. Full Release and packaging
were pending at the historical source/test review point. They have since
passed; verification.json, package.json and BUILD-STATUS.txt record the
current private build/package results. Own7 browser/gameplay/runtime checks
remain pending. No publication or whole-game parity credit is implied.
