"""Run retained6 assertions unchanged; wrappers identify/extract current7."""
from pathlib import Path
import concurrent.futures,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
tasks={
 'primitives':['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tests/run-primitives.ps1')],
 'mode':['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'tests/run-mode-tests.ps1')],
 'presenter':['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'presenter-tests/run-presenter-test.ps1')],
 'mi-stretch':[sys.executable,str(ROOT/'stretch-tests/run-native-stretch.py')],
 'matte':['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'matte-regression/run-matte-regression.ps1')],
 'dd32':[sys.executable,str(ROOT/'dd32-tests/run-dd32-tests.py')],
 'mirror':[sys.executable,str(ROOT/'mirror-tests/run-mirror-tests.py')],
 'fill':[sys.executable,str(ROOT/'fill-tests/run-fill-tests.py')],
 'unscaled-mirror':[sys.executable,str(ROOT/'unscaled-mirror-tests/run-unscaled-mirror-tests.py')]}
names=list(tasks) if '--all' in sys.argv else ['primitives','mode','presenter','mi-stretch','matte']
def run(name):
 r=subprocess.run(tasks[name],cwd=ROOT,capture_output=True,text=True)
 (ROOT/(name+'-retained-test.log')).write_text(r.stdout+r.stderr,encoding='utf-8',newline='\n')
 print(name+': exit'+str(r.returncode),flush=True);return name,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=dict(pool.map(run,names))
(ROOT/'retained-test-exits.json').write_text(json.dumps(results,indent=2)+'\n');assert not any(results.values()),results
