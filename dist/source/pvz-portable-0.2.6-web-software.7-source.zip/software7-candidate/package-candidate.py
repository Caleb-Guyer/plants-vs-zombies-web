"""Strict complete7 corresponding source, authored tests and raw-upstream patch.
No original resources, native audits, personal saves, compiled game/test data.
"""
from pathlib import Path
import ast,hashlib,json,subprocess,time,zipfile,zlib
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent/'software6-candidate';VERSION='0.2.6-web-software.7'
assert ROOT.name=='software7-candidate'
def sha(data):return hashlib.sha256(data).hexdigest()
def record(data):return {'bytes':len(data),'sha256':sha(data),'crc32':f'{zlib.crc32(data):08x}'}
def files(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
source=files(ROOT/'source');verification=json.loads((ROOT/'verification.json').read_text());changes=json.loads((ROOT/'software7-change-record.json').read_text())
assert len(source)==757 and verification['candidate']==VERSION and {n:sha(d) for n,d in source.items()}==changes['fullSourceFingerprint']
assert changes['unchangedExisting6Files']==751 and len(changes['changedExisting'])==4 and len(changes['added'])==2
for item in verification['artifacts']:assert sha((ROOT/item['path']).read_bytes())==item['sha256']
upstream=BASE/'preview/dist/source/pvz-portable-0.2.6-source.zip';assert sha(upstream.read_bytes())==verification['upstreamSourceArchive']['sha256']
with zipfile.ZipFile(upstream) as archive:
 prefix='PvZ-Portable-0.2.6/';originals={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix) and not n.endswith('/')}
assert len(originals)==753
check=ROOT/'patch-check'/('run-'+str(time.time_ns()))/'raw-upstream';check.mkdir(parents=True)
for name,data in originals.items():p=check/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def git(*args):
 r=subprocess.run(['git',*args],cwd=check,capture_output=True,text=True);assert r.returncode==0,(args,r.stdout,r.stderr)
 return {'arguments':list(args),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
git('init','--quiet');patch=ROOT/'web-software.7.patch'
a=git('apply','--check',str(patch));b=git('apply',str(patch));assert files(check)==source
patch_receipt={'baseArchiveSha256':sha(upstream.read_bytes()),'baseFiles':753,'combinedPatchSha256':sha(patch.read_bytes()),'gitApplyCheckExitCode':a['exitCode'],'gitApplyExitCode':b['exitCode'],'reconstructedFiles':757,'everySourceByteMatchesCandidate':True,'scope':'Real initialized raw-upstream fixture with .gitattributes; actual git apply, no normalization/whitespace-ignore fallback.'}
(ROOT/'patch-check.json').write_text(json.dumps(patch_receipt,indent=2)+'\n')
entries={'software7-candidate/source/'+n:d for n,d in source.items()}
top=['README.txt','BUILD-STATUS.txt','prepare-candidate.py','prepare-retained-tests.py','freeze-review-inputs.py','run-retained-tests.py','build-candidate.ps1','build-and-record.py','write-provenance.py','package-candidate.py','verification.json','software5-parent.json','software6-parent.json','software7-change-record.json','software7-review-inputs.json','software6-to-software7.patch','web-software.7.patch','patch-check.json','retained-test-exits.json']
top += [n+'-retained-test.log' for n in ['primitives','mode','presenter','mi-stretch','matte','dd32','mirror','fill','unscaled']]
top += ['logs/build.log','logs/build-result.json']
# Reuse the previously audited exact retained test-file allowlist as data.
old_ast=ast.parse((ROOT/'retained6/package-candidate.py').read_text())
old_allow=next(ast.literal_eval(n.value) for n in old_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='allow' for t in n.targets))
folders=('tests/','presenter-tests/','stretch-tests/','matte-regression/','dd32-tests/','mirror-tests/','fill-tests/','unscaled-mirror-tests/')
top += [n for n in old_allow if n.startswith(folders)]
top += ['matrix-tests/'+n for n in ['README.txt','native-matrix-rgb888-reference.h','run-callback-tests.py','run-paired-tests.py','context-fixtures.cpp','run-context-tests.py','verify-source-inputs.py','results/results.json','results/context-results.json','results/baseline6/results.json','results/candidate7/results.json','results/context-baseline6/results.json','results/context-candidate7/results.json','baseline6.log','candidate7.log']]
for name in sorted(set(top)):entries['software7-candidate/'+name]=(ROOT/name).read_bytes()
for folder in ['tests/baseline','matte-regression/baseline','stretch-tests/software2-baseline','mirror-tests/software4-baseline','fill-tests/software4-baseline','unscaled-mirror-tests/software5-baseline','matrix-tests/software6-baseline','matrix-tests/context-baseline','reference-tests','retained4','retained5','retained6']:
 for name,data in files(ROOT/folder).items():
  assert '__pycache__' not in Path(name).parts and Path(name).suffix!='.pyc',name
  entries['software7-candidate/'+folder+'/'+name]=data
entries['software7-candidate/compiled-version-header.txt']=(ROOT/'build/ProjectVersion.h').read_bytes()
scope={'candidate':VERSION,'engineFiles':757,'engineSourceBytes':sum(map(len,source.values())),'sourceManifest':{n:record(d) for n,d in source.items()},'included':'Complete current source; licensed historical recipe/source fixtures; authored functional references/synthetic mixed-alpha controls/tests and bounded output receipts.','excluded':['.git','compiled engine/test binaries and objects','original EXE/DLL/PAK/artwork/assets','native audit/disassembly files','native/personal/actualQA saves/settings/private exports/account state'],'limits':verification['limits']}
entries['software7-candidate/source-manifest.json']=(json.dumps(scope,indent=2)+'\n').encode()
for name in entries:
 p=Path(name);assert p.suffix.lower() not in {'.exe','.dll','.pak','.dat','.regemu','.wasm','.o','.obj','.pyc','.zip'},name
 assert not any(v in {'.git','game-assets','userdata','native-reference-tools','backups','__pycache__'} for v in p.parts),name
 assert 'disassembly' not in p.name.lower() and not p.name.startswith('original-'),name
destination=ROOT/('pvz-portable-'+VERSION+'-source.zip');assert not destination.exists(),'Keep completed source archive immutable'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,(2026,10,27,0,0,0));info.external_attr=0o100644<<16;archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(destination) as archive:
 assert archive.testzip() is None and len(archive.infolist())==len(entries)
 for name,data in entries.items():assert archive.read(name)==data,name
assert files(ROOT/'source')==source
parent=json.loads((ROOT/'software6-parent.json').read_text());assert {n:sha(d) for n,d in files(BASE/'source').items()}==parent['sourceFiles']
for name,pin in parent['artifacts'].items():assert sha((BASE/name).read_bytes())==pin,name
report={'candidate':VERSION,'scope':'Private full Release engine/corresponding source package; not deployed/browser-runtime validated','sourceArchive':{'path':destination.name,**record(destination.read_bytes()),'entries':len(entries),'uncompressedBytes':sum(map(len,entries.values()))},'sourceFiles':757,'sourceBytes':sum(map(len,source.values())),'sourceDeltaVsSoftware6':verification['software6Delta']['sourceChanges'],'combinedUpstreamPatch':{'path':patch.name,**record(patch.read_bytes()),'changedPaths':22,'base':verification['base'],'applyCheck':patch_receipt},'software6IncrementalPatch':{'path':'software6-to-software7.patch',**record((ROOT/'software6-to-software7.patch').read_bytes()),'changedPaths':6},'engineArtifacts':verification['artifacts'],'allEntriesCrcAndByteCompared':True,'stable6SourceAndArtifactsUnchanged':True,'751OtherExistingSourceFilesAndEightMethodsUnchanged':True,'publicOrStageNotWrittenByPreparation':True,'engineInitialized':False,'browserLaunched':False,'audioDeviceOpened':False,'codeArchiveExclusions':scope['excluded'],'limits':verification['limits']}
(ROOT/'package.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['sourceDeltaVsSoftware6','limits','codeArchiveExclusions']},indent=2))
