PRIVATE SOFTWARE.6 — ORDINARY RGB888 SCREEN UNSCALED MIRROR

This candidate starts from frozen Software.5 source ZIP SHA256
82abbd0420c088805756598398ceecbbf07dbd93412a4e58117fe4e1ffe567af. Only three
engine paths differ: CMake/ProjectVersion.cmake and SoftwareScreenImage.cpp/.h.
All752 other engine files remain exact5 bytes; every existing5 screen method
body and literal offscreen MemoryImage code is unchanged. No public or stable
candidate source/artifact/site-stage/audio/save state is modified here.

New ordinary-screen BltMirror behavior
Original DD unscaled mirror has its own normal/additive kernels. Unlike ordinary
Blt's no-alpha shortcut, those kernels always use source pixel alpha. In5 the
inherited helper reversed the source into a temporary and forced the ORIGINAL
source opacity flags onto it. A source whose opacity flags were stale/forced
could consequently take ordinaryBlt's opaque copy instead of native mirror
composition. This also occurs through ordinary unforced use: CommitBits on an
opaque image, change to partial/zero alpha, BitsChanged, then mirror before lazy
CommitBits. Over202020, source80808080 gave actual5 RGB404040 versus native505050;
source00808080 gave black versus native unchanged202020. Raw and truly indexed
input cases were reproduced with extracted actual5 code and addressed math.
These are synthetic/API examples, not an observed game-scene or native capture.

Software.6 adds only a dedicated screen BltMirror override: mode0/1 guard,
source CommitBits, existing alias-safe reversed temporary and clipping, then
force the temporary's general-alpha path. This preserves native white/tint/
global-alpha normal/additive equations, including the unscaled opaque-tint
special case. Source hasAlpha/hasTrans flags no longer choose a different
ordinary screen mirror equation. Offscreen mirror, ordinary screen Blt/Stretch,
mirrorStretch, FillRect, nonaxis lines, renderer selection and audio stay5 code.
Volatile inputs retain the previous fallback; no new volatile/format rule is
invented. Extra bounds guards are defensive outside valid native geometry.

Current6 source regressions (isolated synthetic C++/Wasm/Node)
unscaled-mirror-tests/run-unscaled-mirror-tests.py compares actual frozen5 and6
against independent addressed scalar native equations:3,039,478 assertions,
1,505,732 draws,226 indexed calls. Frozen5 fails14,336 as expected;6 fails0.
Includes all256 source alpha values, endpoint/interior RGB and destination
values, white/tint/global alpha, natural and forced source flags, ordinary
BitsChanged→lazy-Commit state, raw/indexed data, modes0/1/invalid and native
Graphics preclip/right crop. Indexed data is distinct, raw bits are null directly
before actual calls, and GetBits uses faithful lazy allocation/expansion.
Aliasing is an explicit preservation control, not extra native recovery proof.
The new runner writes UTF-8/LF and hashes actual compiled actual.cpp disk bytes.

Retained assertions/fixtures are preserved and rerun with current6 extraction:
DD32 ordinary20,900; mirrorStretch98,802 (old4 fails21,208/current6 zero);
FillRect/axis/span2,118,543 (old4 fails539,971/current6 zero);149 primitives;
20 MI stretch fixtures; mode transition; presenter/shared batcher; nine matte
compositor fixtures with expected baseline/partial-control failures. Only current
identity, new virtual-method extraction and an archived parent-path adaptation
were needed in copied5 runners. Prior recipes/receipts are archived under
retained5/retained4. Inherited generatedSha256 receipt fields retain their prior
logical-text meaning; new unscaled generatedSha256 is actual compiled-file SHA.
Unchanged historical JPEG/fullscreen/pinata/download test sources are retained.

An independent read-only review authenticated addressed native ranges, source
preservation, gates/math/right crop, genuine indexed/stale fixtures and actual
compiled-file receipt hashes. No blocker was found in the bounded ordinary
nonvolatile RGB888 scope. Actual source/test/build/package hashes and limitations
are recorded in verification.json/package.json/source-manifest.json.

Build and source reproduction
Use the same installed Emscripten6.0.13/CMake3.31.9/Ninja1.13.2 cache/recipe:
 powershell -NoProfile -ExecutionPolicy Bypass -File .../build-candidate.ps1
 python .../unscaled-mirror-tests/run-unscaled-mirror-tests.py
Retained runners are beside their fixtures. Flags stay Release,
DO_FIX_BUGS=OFF/PVZ_DEBUG=OFF/LOW_MEMORY=OFF. The exact shallow upstream0.2.6 tag
metadata is commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca,count1,date2026-10-25,
with the complete755-file source overlaid. Git metadata is excluded from ZIPs;
the private version override executes after collection of tag metadata.

web-software.6.patch is the true complete raw-upstream0.2.6→6 patch;
software5-to-software6.patch is the separately labeled three-path delta.
The complete source builds without applying a patch. Both clean check/apply and
every reconstructed source byte are verified before packaging. The explicit
code allowlist contains source, recipes, authored functional references, synthetic
tests and logs. No installed game data, native disassembly/audit, executable,
actual save/settings/export/account/credential or compiled test binary is an
archive input. Licensed unchanged upstream library/example/icon fixtures remain
part of the complete upstream code tree.

Limits and runtime status
Static proof assumes successful ordinary nonvolatile RGB888 software lock,
valid integer/preclipped coordinates and current native caches. Actual original
host framebuffer/format was not captured. Volatile/DD16/other masks/D3D/driver,
cache/device recovery, fractional/rotated/matrix/triangle/coverage and offscreen
tint/additive remain separate limits. Nonaxis additive AA's native no-op/port
extension is left unchanged; no game call site was found. Nonaxis line controls
cover first pixels rather than every endpoint/coverage value. CPU composition
still uses the existing WebGL context for final bitmap presentation.
Full original pixels, all effects, dense/display performance and whole-game
parity are unverified. A successful build supplies no game/UI credit. Software6
needs its own browser scenes/mode/save/reload checks;5UI results stay separate.
No publication is performed by these private recipes or tests.
