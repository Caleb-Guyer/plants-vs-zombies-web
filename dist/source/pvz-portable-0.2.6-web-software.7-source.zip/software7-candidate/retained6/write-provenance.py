"""Private6 exact source/build/test receipt and true raw-upstream combined patch."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[1]
BASE=ROOT.parent/'software5-candidate'
VERSION='0.2.6-web-software.6'
def sha(data):return hashlib.sha256(data).hexdigest()
def files(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
source=files(ROOT/'source');parent=json.loads((ROOT/'software5-parent.json').read_text())
assert len(source)==755 and set(source)==set(parent['baseSourceFingerprint'])
with zipfile.ZipFile(BASE/'pvz-portable-0.2.6-web-software.5-source.zip') as archive:
 assert sha((BASE/'pvz-portable-0.2.6-web-software.5-source.zip').read_bytes())==parent['sourceArchiveSha256']
 prefix='software5-candidate/source/'
 old5={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix)}
assert {n:sha(d) for n,d in old5.items()}==parent['baseSourceFingerprint']
assert files(BASE/'source')==old5,'Frozen5 source changed'
def body(data,signature):
 text=data.decode('utf-8');assert text.count(signature)==1
 start=text.index(signature);brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if depth==0:return text[start:end+1].encode('utf-8')
 raise AssertionError(signature)
screen_path='src/SexyAppFramework/graphics/SoftwareScreenImage.cpp'
preserved_screen={}
for signature in ['SoftwareScreenImage::SoftwareScreenImage(','void SoftwareScreenImage::Create(','uint32_t SoftwareScreenImage::CompositePixel(',
                  'void SoftwareScreenImage::Blt(','void SoftwareScreenImage::StretchBlt(','void SoftwareScreenImage::StretchBltMirror(','void SoftwareScreenImage::FillRect(']:
 assert body(old5[screen_path],signature)==body(source[screen_path],signature),signature
 preserved_screen[signature]=sha(body(source[screen_path],signature))
def patch(before,after,destination):
 changes=[];lines=[]
 for name in sorted(before.keys()|after.keys()):
  old=before.get(name,b'');new=after.get(name,b'')
  if old==new:continue
  changes.append({'path':name,'beforeSha256':sha(old),'afterSha256':sha(new)})
  lines+=difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)
 destination.write_bytes(''.join(lines).encode());return changes
delta=patch(old5,source,ROOT/'software5-to-software6.patch')
assert {item['path'] for item in delta}=={'CMake/ProjectVersion.cmake','src/SexyAppFramework/graphics/SoftwareScreenImage.cpp','src/SexyAppFramework/graphics/SoftwareScreenImage.h'}
upstream_path=BASE/'preview/dist/source/pvz-portable-0.2.6-source.zip'
assert sha(upstream_path.read_bytes())=='40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
with zipfile.ZipFile(upstream_path) as archive:
 assert archive.testzip() is None
 prefix='PvZ-Portable-0.2.6/'
 upstream={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix) and not n.endswith('/')}
assert len(upstream)==753
combined=patch(upstream,source,ROOT/'web-software.6.patch')
assert len(combined)==19
artifacts=[]
for name in ['pvz-portable.html','pvz-portable.js','pvz-portable.wasm','ProjectVersion.h']:
 data=(ROOT/'build'/name).read_bytes();artifacts.append({'path':'build/'+name,'bytes':len(data),'sha256':sha(data)})
version=(ROOT/'build/ProjectVersion.h').read_text()
assert VERSION in version and '#define PVZP_BUILD_NUMBER 1' in version and '2026-10-25' in version
cache=(ROOT/'build/CMakeCache.txt').read_text()
assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+str(ROOT/'source').replace('\\','/') in cache
assert all(value in cache for value in ['CMAKE_BUILD_TYPE:STRING=Release','DO_FIX_BUGS:BOOL=OFF','PVZ_DEBUG:BOOL=OFF','LOW_MEMORY:BOOL=OFF'])
node=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154/node/24.19.0_64bit/node.exe'
subprocess.run([str(node),'--check',str(ROOT/'build/pvz-portable.js')],check=True)
subprocess.run([str(node),'-e','const fs=require("node:fs");if(!WebAssembly.validate(fs.readFileSync(process.argv[1])))process.exit(1)',str(ROOT/'build/pvz-portable.wasm')],check=True)
assert VERSION.encode() in (ROOT/'build/pvz-portable.wasm').read_bytes()
mirror=json.loads((ROOT/'mirror-tests/results/results.json').read_text());fill=json.loads((ROOT/'fill-tests/results/results.json').read_text())
unscaled=json.loads((ROOT/'unscaled-mirror-tests/results/results.json').read_text())
assert mirror['status']==fill['status']=='PASS'
assert unscaled['status']=='PASS' and unscaled['variants']['frozen5']['exitCode']==1 and unscaled['variants']['candidate6']['exitCode']==0
assert unscaled['baselineMatchesFrozenParentFingerprint']
for role,item in unscaled['variants'].items():assert sha((ROOT/'unscaled-mirror-tests/results'/role/'actual.cpp').read_bytes())==item['generatedSha256']
assert mirror['variants']['frozen4']['exitCode']==1 and mirror['variants']['candidate6']['exitCode']==0
assert fill['variants']['frozen4']['differences']==539971 and fill['variants']['candidate6']['differences']==0
dd32=json.loads((ROOT/'dd32-tests/results/results.json').read_text());assert dd32['exitCode']==0
logs={n:sha((ROOT/n).read_bytes()) for n in ['primitives-retained-test.log','mode-retained-test.log','presenter-retained-test.log','mi-stretch-retained-test.log','dd32-retained-test.log','matte-retained-test.log','mirror-regression.log','fill-regression.log','unscaled-mirror-regression.log','logs/build.log']}
limits=['Conditional successful-lock nonvolatile CPU RGB888 bitmap/stretch/mirror-stretch/unscaled-mirror/fill paths with valid integer/preclipped geometry and current native caches; no original framebuffer capture/equivalence claim.',
 'DD16/other layouts, driver/D3D shortcuts, volatile inputs and native cache/device recovery remain unverified.',
 'Fractional/rotated/matrix/triangle/coverage dispatch and offscreen tint/additive remain separate limits.',
 'Native nonaxis additive AA is a confirmed no-op/port extension left unchanged; no game call site found.',
 'Normal nonaxis line controls cover first pixels only; no all-endpoint/coverage proof.',
 'CPU composition still needs the existing WebGL context for one final bitmap transport.',
 'No6 browser scenes, save/preference persistence, dense-scene/display FPS, all effects or whole-game parity verified; no5 UI credit transfers.']
verification={'candidate':VERSION,'scope':'Private dedicated RGB888 screen unscaled mirror source-commit/alpha correction, retaining5 mirror-stretch and FillRect; no publication/browser/runtime equivalence claim',
 'base':'Raw upstream0.2.6 commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca','sourceFilesCompared':755,
 'sourceChanges':combined,'sourcePatchPath':'web-software.6.patch','sourcePatchSha256':sha((ROOT/'web-software.6.patch').read_bytes()),
 'software5Delta':{'path':'software5-to-software6.patch','sha256':sha((ROOT/'software5-to-software6.patch').read_bytes()),'sourceChanges':delta},
 'upstreamSourceArchive':{'name':upstream_path.name,'sha256':sha(upstream_path.read_bytes()),'files':753},'artifacts':artifacts,
 'checks':{'unscaledMirror':unscaled,'retainedMirrorStretch':mirror,'retainedFill':fill,'retainedDD32':dd32,'retainedPrimitives':'PASS149/149; baseline31/149 expected failure',
  'preservedMIStretch':'PASS20fixtures/zero differences; unchanged MI3 inputs','mode':'PASS actual transition with doubles',
  'presenter':'PASS actual batcher/presenter with GL/SDL doubles','matte':'PASS9fixtures; original/partial controls fail as expected',
  'fullEngineCompileLink':'PASS isolated Release with pinned tools/flags','jsSyntaxAndWasmValidation':'PASS without initialization',
  'browserOrNativeUi':'NOT RUN','denseDisplayPerformance':'NOT MEASURED','verificationLogSha256':logs},
 'independentReviews':{'unscaledMirror':'garden_input independently authenticated addressed gates/math/clipping, source/preservation, genuine indexed/stale fixtures and final actual-file hashes; PASS bounded source/test review',
  'retainedFillAndMirrorStretch':'Software5 independently reviewed functions and all source fixtures preserved; current6 extraction/link tests pass',
  'generatedHashScope':'New unscaled suite hashes actual compiled UTF-8/LF disk bytes. Inherited source5 suite generatedSha256 fields retain their logical-text hash definition.'},'limits':limits}
(ROOT/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
record={'candidate':VERSION,'base':'Frozen0.2.6-web-software.5 immutable corresponding source','sourceChanges':delta,
 'fullSourceFingerprint':{name:sha(data) for name,data in source.items()},'sourceFiles':755,'sourceBytes':sum(map(len,source.values())),
 'unchangedSourceFiles':752,'preservedOffscreenMI':{name:sha(source['src/SexyAppFramework/graphics/'+name]) for name in ['MemoryImage.cpp','MemoryImage.h','inc_routines/MI_SlowStretchBlt.inc']},
 'allSevenExistingScreenMethodBodiesUnchanged':preserved_screen,
 'newBehavior':['Dedicated screen unscaled BltMirror commits source then uses an alias-safe reversed temporary with general alpha flags; native white/tint/global-alpha normal/additive/mode0+1 pixel paths ignore source opacity flags',
  'Preserves all5 ordinary screen Blt/Stretch, mirrorStretch, FillRect and literal offscreen MI; no renderer/audio changes'],
 'engineInitialized':False,'browserLaunched':False,'audioDeviceOpened':False,'publicOrStable5ModifiedByPreparation':False,
 'testInputSummary':{'unscaledMirrorAssertions':3039478,'unscaledMirrorOld5ExpectedFailures':14336,'unscaledMirror6Failures':0,'mirrorAssertions':98802,'mirrorOld4ExpectedFailures':21208,'mirror6Failures':0,'fillAssertions':2118543,'fillOld4ExpectedDifferences':539971,'fill6Differences':0,'retainedDD32Assertions':20900},'limits':limits}
(ROOT/'software6-change-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'candidate':VERSION,'sourceFiles':len(source),'deltaPaths':len(delta),'combinedPaths':len(combined),'artifacts':artifacts},indent=2))
