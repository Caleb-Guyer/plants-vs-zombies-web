"""Adapt retained harness identity/interface only; all old fixtures unchanged."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent;BASE=ROOT.parent/'software6-candidate'
shutil.copyfile(BASE/'software5-parent.json',ROOT/'software5-parent.json')
for name in ['dd32-tests/run-dd32-tests.py','mirror-tests/run-mirror-tests.py','fill-tests/run-fill-tests.py','unscaled-mirror-tests/run-unscaled-mirror-tests.py']:
 text=(BASE/name).read_text()
 text='import re\n'+text.replace('candidate6','candidate7').replace('0.2.6-web-software.6','0.2.6-web-software.7')
 # Existing tests focus pre7 methods. New virtual boundaries are tested using
 # their actual production bodies in matrix-tests/run-context-tests.py.
 needle='declaration='
 if needle in text:
  start=text.index(needle);indent=text[text.rfind('\n',0,start)+1:start]
  text=text[:start]+"header=re.sub(r'\\n\\s*void Blt(?:Matrix|TrianglesTex)\\([^;]+;', '', header)\n"+indent+text[start:]
 else:
  needle='declaration =';start=text.index(needle);indent=text[text.rfind('\n',0,start)+1:start]
  text=text[:start]+"header = re.sub(r'\\n\\s*void Blt(?:Matrix|TrianglesTex)\\([^;]+;', '', header)\n"+indent+text[start:]
 (ROOT/name).write_text(text,encoding='utf-8',newline='\n')
print('Retained four interfaces adapted; fixtures/references unchanged.')
