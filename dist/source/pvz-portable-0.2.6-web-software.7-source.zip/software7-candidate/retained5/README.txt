PRIVATE SOFTWARE.5 — MIRROR STRETCH AND RGB888 SCREEN FILL

This candidate starts from the exact frozen Software.4 corresponding-source
ZIP (SHA256649863914351065e939ada9a09cd61f63c12839de970912eb984420910b94458).
Only three engine paths change: CMake/ProjectVersion.cmake and the dedicated
SoftwareScreenImage.cpp/.h. All other752 engine files remain exact4 bytes.
No public source, stable4 source/artifact/site stage, audio behavior or saved
state is changed by this preparation. It remains private until its own UI and
integration review. Earlier4 UI observations do not establish5 runtime behavior.

New behavior and addressed scope
StretchBltMirror on the ordinary CPU screen now uses mirrored clipping then
forward16.16 source samples written right-to-left. Native software ignores the
fastStretch flag, including false; no slow filter or reversed-source temporary
is used. Modes0/other select normal/additive, respectively. The existing native
DD32 stretch equations handle white/tint/global alpha and raw/indexed sources.
Plain offscreen MemoryImage mirror/stretch math is unchanged. Unstretched screen
Blt, ordinary screen StretchBlt and renderer selection are unchanged.

The screen FillRect override uses original conditional RGB888 mask arithmetic:
opaque normal fill maps each positive channel to channel-1; partial normal fill
rounds source(C*A+127)>>8 and floors destination separately; additive contribution
uses C*A/255 with saturation. Fill supports only modes0/1. Existing inherited
axis DrawLine/DrawLineAA and Image::FillScanLines reach this virtual fill. Plain
MemoryImage fill and normal nonaxis line bodies are unchanged. Bounds clipping
is defensive outside the native valid-geometry scope, not a new pixel oracle.

Actual source regressions (synthetic Wasm/Node only)
mirror-tests/run-mirror-tests.py:98,802 checks,16,964 draws,226 indexed calls.
Frozen4 fails21,208 checks as expected; candidate5 fails0. The independent
reference covers normal/nonzero-additive, white/tint/global alpha, alpha
endpoints/partials, forced source flags, both fast values and mirror clipping.
Indexed fixtures remove raw bits, install distinct palette data immediately
before the actual call, and use the production GetBits lazy-expansion condition.

fill-tests/run-fill-tests.py: independently authored scalar reference versus
actual packed-mask implementation,2,118,543 checks per variant. Frozen4 fails
539,971 checks as expected; candidate5 fails0. Covers every0..255 color/alpha,
eight destination RGBs, both modes, valid rectangles/guards/unknown modes,
actual virtual FillRect, inherited axisLine/AA and base span routes, unchanged
offscreen fill and nonaxis first-pixel controls. Independent source/math review
found no issue within the stated conditional RGB888 scope.

Retained DD32 tests:20,900 assertions pass. All20,893 ordinary equation cases
remain; seven white mirror assertions remain with stretched indices corrected
to the newly proved native order. Indexed inputs are strengthened as above.
tests/run-primitives.ps1:149/149; native MI stretch20fixtures/zero differences;
mode transition, presenter/batcher and nine matte compositor fixtures pass.
Historic parity4 JPEG/fullscreen/pinata/download fixtures and receipts are
preserved under retained4; their production inputs are byte unchanged.

Build/package status is recorded in verification.json after the isolated full
Release build. No browser, game, native executable or audio is initialized by
these tests or build tools. Compilation alone supplies no new scene/UI credit.

Reproduction
Use the existing pinned Emscripten6.0.13, CMake3.31.9 and Ninja1.13.2 cache.
  powershell -NoProfile -ExecutionPolicy Bypass -File .../build-candidate.ps1
  python .../mirror-tests/run-mirror-tests.py
  python .../fill-tests/run-fill-tests.py
Retained test runners are supplied beside their fixtures. Build flags remain
Release, DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF. The build uses the exact
shallow upstream0.2.6 tag metadata (commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca,
count1/date2026-10-25) with complete755-file source overlaid. Git metadata stays
outside the source ZIP. Private version is set after Git metadata collection.

web-software.5.patch is the complete diff from unmodified upstream0.2.6;
software4-to-software5.patch is the separately labeled three-path delta. The
complete source builds without applying a patch. Archive metadata and exact
build/source hashes live in package.json/verification.json/source-manifest.json.
Only source/recipes/authored functional references/tests/logs are allowlisted;
no game resources, native machine-code audits/disassembly, executables, real
saves/settings, account state or private exports are distribution inputs.

Remaining limits
Proof is conditional on successful ordinary nonvolatile RGB888 software paths,
valid finite/int32 coordinates. Actual original host format/framebuffer was not
captured. DD16/other masks, driver/D3D shortcuts, source volatility, cache/device
recovery, complete unscaled mirror behavior, fractional/rotated/matrix/triangle
and coverage paths remain separate limits. Nonaxis additive AA is a confirmed
native no-op/port extension left unchanged here; no game call site was found.
Normal nonaxis line checks cover first pixels, not all endpoint/coverage math.
Offscreen tint/additive extensions, all assets/effects, dense-scene performance,
whole-game equality and original framebuffer pixels remain unverified. CPU
composition still uses the existing WebGL context to present one final bitmap.
