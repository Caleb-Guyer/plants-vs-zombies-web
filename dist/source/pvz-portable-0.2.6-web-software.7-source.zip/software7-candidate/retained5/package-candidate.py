"""Package only complete Software5 code/recipes/authored tests; no game data."""
from pathlib import Path
import hashlib
import json
import subprocess
import time
import zipfile
import zlib

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'software4-candidate'
VERSION='0.2.6-web-software.5'
assert ROOT.name=='software5-candidate'
def sha(data):return hashlib.sha256(data).hexdigest()
def record(data):return {'bytes':len(data),'sha256':sha(data),'crc32':f'{zlib.crc32(data):08x}'}
def files(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
source=files(ROOT/'source');assert len(source)==755
verification=json.loads((ROOT/'verification.json').read_text());changes=json.loads((ROOT/'software5-change-record.json').read_text())
assert verification['candidate']==changes['candidate']==VERSION
assert {n:sha(d) for n,d in source.items()}==changes['fullSourceFingerprint']
assert changes['unchangedSourceFiles']==752 and len(changes['sourceChanges'])==3
for artifact in verification['artifacts']:assert sha((ROOT/artifact['path']).read_bytes())==artifact['sha256']
upstream=BASE/'preview/dist/source/pvz-portable-0.2.6-source.zip'
assert sha(upstream.read_bytes())=='40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
check_root=ROOT/'patch-check'/('run-'+str(time.time_ns()))/'raw-upstream';check_root.mkdir(parents=True)
with zipfile.ZipFile(upstream) as archive:
 prefix='PvZ-Portable-0.2.6/'
 originals={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix) and not n.endswith('/')}
assert len(originals)==753
for name,data in originals.items():
 path=check_root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
def git(*args):
 result=subprocess.run(['git',*args],cwd=check_root,capture_output=True,text=True)
 assert result.returncode==0,(args,result.stdout,result.stderr)
 return {'arguments':list(args),'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
git('init','--quiet') # honor source .gitattributes in a real repository
patch=ROOT/'web-software.5.patch'
apply_check=git('apply','--check',str(patch));apply_result=git('apply',str(patch))
assert files(check_root)==source,'Combined raw-upstream patch must reconstruct every source byte'
patch_receipt={'baseArchiveSha256':sha(upstream.read_bytes()),'baseFiles':753,'combinedPatchSha256':sha(patch.read_bytes()),
 'gitApplyCheckExitCode':apply_check['exitCode'],'gitApplyExitCode':apply_result['exitCode'],
 'reconstructedFiles':755,'everySourceByteMatchesCandidate':True,'scope':'Initialized raw-upstream fixture with source .gitattributes; actual git apply, no whitespace-ignore/normalization fallback.'}
(ROOT/'patch-check.json').write_text(json.dumps(patch_receipt,indent=2)+'\n')

entries={'software5-candidate/source/'+n:d for n,d in source.items()}
allow=['README.txt','build-candidate.ps1','write-provenance.py','package-candidate.py','verification.json',
 'software4-parent.json','software5-change-record.json','software4-to-software5.patch','web-software.5.patch','patch-check.json',
 'tests/prepare-primitives.py','tests/run-primitives.ps1','tests/prepare-mode-tests.py','tests/run-mode-tests.ps1',
 'presenter-tests/prepare-presenter-test.py','presenter-tests/run-presenter-test.ps1','presenter-tests/presenter-harness.cpp',
 'matte-regression/test-matte-compositor.py','matte-regression/run-matte-regression.ps1',
 'stretch-tests/run-native-stretch.py','stretch-tests/fixtures.cpp','stretch-tests/results/results.json',
 'dd32-tests/run-dd32-tests.py','dd32-tests/fixtures.cpp','dd32-tests/native-dd32-reference.h','dd32-tests/results/results.json',
 'mirror-tests/run-mirror-tests.py','mirror-tests/fixtures.cpp','mirror-tests/native-dd32-mirror-reference.h','mirror-tests/results/results.json',
 'fill-tests/run-fill-tests.py','fill-tests/fixtures.cpp','fill-tests/native-dd32-fill-reference.h','fill-tests/README.txt','fill-tests/results/results.json',
 'primitives-retained-test.log','mode-retained-test.log','presenter-retained-test.log','mi-stretch-retained-test.log',
 'dd32-retained-test.log','matte-retained-test.log','mirror-regression.log','logs/build.log']
for name in allow:entries['software5-candidate/'+name]=(ROOT/name).read_bytes()
for folder in ['tests/baseline','matte-regression/baseline','stretch-tests/software2-baseline',
               'mirror-tests/software4-baseline','fill-tests/software4-baseline','retained4']:
 for name,data in files(ROOT/folder).items():entries['software5-candidate/'+folder+'/'+name]=data
entries['software5-candidate/compiled-version-header.txt']=(ROOT/'build/ProjectVersion.h').read_bytes()
scope={'candidate':VERSION,'engineFiles':755,'engineSourceBytes':sum(map(len,source.values())),
 'sourceManifest':{n:record(d) for n,d in source.items()},
 'included':'Complete current source, pinned previous licensed code fixtures/recipes, independent authored functional math references and synthetic actual-code tests/logs.',
 'excluded':['.git','compiled game/test binaries and objects','original EXE/DLL/PAK/artwork/assets','native audit/disassembly files','native/personal/actualQA saves/settings/private exports/account state'],
 'limits':verification['limits']}
entries['software5-candidate/source-manifest.json']=(json.dumps(scope,indent=2)+'\n').encode()
for name in entries:
 path=Path(name)
 assert path.suffix.lower() not in {'.exe','.dll','.pak','.dat','.regemu','.wasm','.o','.pyc','.zip'},name
 assert not any(p in {'.git','game-assets','userdata','native-reference-tools','backups'} for p in path.parts),name
 assert 'disassembly' not in path.name.lower() and not path.name.startswith('original-dd32-'),name
destination=ROOT/('pvz-portable-'+VERSION+'-source.zip')
assert not destination.exists(),'Keep completed source ZIP immutable; use a new version for changed inputs'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,(2026,10,27,0,0,0));info.external_attr=0o100644<<16
  archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(destination) as archive:
 assert archive.testzip() is None and len(archive.infolist())==len(entries)
 for name,data in entries.items():assert archive.read(name)==data,name
assert source==files(ROOT/'source')
with zipfile.ZipFile(BASE/'pvz-portable-0.2.6-web-software.4-source.zip') as old:
 prefix='software4-candidate/source/'
 for name in old.namelist():
  if name.startswith(prefix):assert old.read(name)==(BASE/'source'/name[len(prefix):]).read_bytes()
for artifact in json.loads((BASE/'verification.json').read_text())['artifacts']:
 assert sha((BASE/artifact['path']).read_bytes())==artifact['sha256']
report={'candidate':VERSION,'scope':'Private full-engine build/corresponding-source package; not deployed or browser-runtime validated',
 'sourceArchive':{'path':destination.name,**record(destination.read_bytes()),'entries':len(entries),'uncompressedBytes':sum(map(len,entries.values()))},
 'sourceFiles':755,'sourceBytes':sum(map(len,source.values())),'sourceDeltaVsSoftware4':changes['sourceChanges'],
 'combinedUpstreamPatch':{'path':patch.name,**record(patch.read_bytes()),'changedPaths':19,'base':verification['base'],'applyCheck':patch_receipt},
 'software4IncrementalPatch':{'path':'software4-to-software5.patch',**record((ROOT/'software4-to-software5.patch').read_bytes()),'changedPaths':3},
 'engineArtifacts':verification['artifacts'],'allEntriesCrcAndByteCompared':True,'stable4SourceAndArtifactsUnchanged':True,
 'offscreenAnd752OtherSourceFilesUnchanged':True,'publicOrStageNotWrittenByPreparation':True,
 'engineInitialized':False,'browserLaunched':False,'audioDeviceOpened':False,'codeArchiveExclusions':scope['excluded'],'limits':verification['limits']}
(ROOT/'package.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['limits','sourceDeltaVsSoftware4','codeArchiveExclusions']},indent=2))
