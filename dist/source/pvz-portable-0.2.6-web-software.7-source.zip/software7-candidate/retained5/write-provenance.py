"""Private5 exact source/build/test receipt and true raw-upstream combined patch."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[1]
BASE=ROOT.parent/'software4-candidate'
VERSION='0.2.6-web-software.5'
def sha(data):return hashlib.sha256(data).hexdigest()
def files(root):return {p.relative_to(root).as_posix():p.read_bytes() for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
source=files(ROOT/'source');parent=json.loads((ROOT/'software4-parent.json').read_text())
assert len(source)==755 and set(source)==set(parent['baseSourceFingerprint'])
with zipfile.ZipFile(BASE/'pvz-portable-0.2.6-web-software.4-source.zip') as archive:
 assert sha((BASE/'pvz-portable-0.2.6-web-software.4-source.zip').read_bytes())==parent['sourceArchiveSha256']
 prefix='software4-candidate/source/'
 old4={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix)}
assert {n:sha(d) for n,d in old4.items()}==parent['baseSourceFingerprint']
assert files(BASE/'source')==old4,'Frozen4 source changed'
def patch(before,after,destination):
 changes=[];lines=[]
 for name in sorted(before.keys()|after.keys()):
  old=before.get(name,b'');new=after.get(name,b'')
  if old==new:continue
  changes.append({'path':name,'beforeSha256':sha(old),'afterSha256':sha(new)})
  lines+=difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)
 destination.write_bytes(''.join(lines).encode());return changes
delta=patch(old4,source,ROOT/'software4-to-software5.patch')
assert {item['path'] for item in delta}=={'CMake/ProjectVersion.cmake','src/SexyAppFramework/graphics/SoftwareScreenImage.cpp','src/SexyAppFramework/graphics/SoftwareScreenImage.h'}
upstream_path=BASE/'preview/dist/source/pvz-portable-0.2.6-source.zip'
assert sha(upstream_path.read_bytes())=='40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
with zipfile.ZipFile(upstream_path) as archive:
 assert archive.testzip() is None
 prefix='PvZ-Portable-0.2.6/'
 upstream={n[len(prefix):]:archive.read(n) for n in archive.namelist() if n.startswith(prefix) and not n.endswith('/')}
assert len(upstream)==753
combined=patch(upstream,source,ROOT/'web-software.5.patch')
assert len(combined)==19
artifacts=[]
for name in ['pvz-portable.html','pvz-portable.js','pvz-portable.wasm','ProjectVersion.h']:
 data=(ROOT/'build'/name).read_bytes();artifacts.append({'path':'build/'+name,'bytes':len(data),'sha256':sha(data)})
version=(ROOT/'build/ProjectVersion.h').read_text()
assert VERSION in version and '#define PVZP_BUILD_NUMBER 1' in version and '2026-10-25' in version
cache=(ROOT/'build/CMakeCache.txt').read_text()
assert 'CMAKE_HOME_DIRECTORY:INTERNAL='+str(ROOT/'source').replace('\\','/') in cache
assert all(value in cache for value in ['CMAKE_BUILD_TYPE:STRING=Release','DO_FIX_BUGS:BOOL=OFF','PVZ_DEBUG:BOOL=OFF','LOW_MEMORY:BOOL=OFF'])
node=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154/node/24.19.0_64bit/node.exe'
subprocess.run([str(node),'--check',str(ROOT/'build/pvz-portable.js')],check=True)
subprocess.run([str(node),'-e','const fs=require("node:fs");if(!WebAssembly.validate(fs.readFileSync(process.argv[1])))process.exit(1)',str(ROOT/'build/pvz-portable.wasm')],check=True)
assert VERSION.encode() in (ROOT/'build/pvz-portable.wasm').read_bytes()
mirror=json.loads((ROOT/'mirror-tests/results/results.json').read_text());fill=json.loads((ROOT/'fill-tests/results/results.json').read_text())
assert mirror['status']==fill['status']=='PASS'
assert mirror['variants']['frozen4']['exitCode']==1 and mirror['variants']['candidate5']['exitCode']==0
assert fill['variants']['frozen4']['differences']==539971 and fill['variants']['candidate5']['differences']==0
dd32=json.loads((ROOT/'dd32-tests/results/results.json').read_text());assert dd32['exitCode']==0
logs={n:sha((ROOT/n).read_bytes()) for n in ['primitives-retained-test.log','mode-retained-test.log','presenter-retained-test.log','mi-stretch-retained-test.log','dd32-retained-test.log','matte-retained-test.log','mirror-regression.log','logs/build.log']}
limits=['Conditional successful-lock nonvolatile CPU RGB888 bitmap/stretch/mirror-stretch/fill paths; no original framebuffer capture/equivalence claim.',
 'DD16/other layouts, driver/D3D shortcuts, volatile inputs and native cache/device recovery remain unverified.',
 'Complete unscaled mirror/fractional/rotated/matrix/triangle/coverage dispatch and offscreen tint/additive remain separate limits.',
 'Native nonaxis additive AA is a confirmed no-op/port extension left unchanged; no game call site found.',
 'Normal nonaxis line controls cover first pixels only; no all-endpoint/coverage proof.',
 'CPU composition still needs the existing WebGL context for one final bitmap transport.',
 'No5 browser scenes, save/preference persistence, dense-scene/display FPS, all effects or whole-game parity verified; no4 UI credit transfers.']
verification={'candidate':VERSION,'scope':'Private dedicated RGB888 screen mirror-stretch and FillRect corrections; no publication/browser/runtime equivalence claim',
 'base':'Raw upstream0.2.6 commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca','sourceFilesCompared':755,
 'sourceChanges':combined,'sourcePatchPath':'web-software.5.patch','sourcePatchSha256':sha((ROOT/'web-software.5.patch').read_bytes()),
 'software4Delta':{'path':'software4-to-software5.patch','sha256':sha((ROOT/'software4-to-software5.patch').read_bytes()),'sourceChanges':delta},
 'upstreamSourceArchive':{'name':upstream_path.name,'sha256':sha(upstream_path.read_bytes()),'files':753},'artifacts':artifacts,
 'checks':{'mirror':mirror,'fill':fill,'retainedDD32':dd32,'retainedPrimitives':'PASS149/149; baseline31/149 expected failure',
  'preservedMIStretch':'PASS20fixtures/zero differences; unchanged MI3 inputs','mode':'PASS actual transition with doubles',
  'presenter':'PASS actual batcher/presenter with GL/SDL doubles','matte':'PASS9fixtures; original/partial controls fail as expected',
  'fullEngineCompileLink':'PASS isolated Release with pinned tools/flags','jsSyntaxAndWasmValidation':'PASS without initialization',
  'browserOrNativeUi':'NOT RUN','denseDisplayPerformance':'NOT MEASURED','verificationLogSha256':logs},
 'independentReviews':{'fill':'garden_input reviewed addressed equations, production source and independently authored scalar reference/actual regressions',
  'mirror':'qa_records reviewed addressed arithmetic/sampling and corrected faithful indexed test inputs; see retained independent receipt summary when packaging'},'limits':limits}
(ROOT/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
record={'candidate':VERSION,'base':'Frozen0.2.6-web-software.4 immutable corresponding source','sourceChanges':delta,
 'fullSourceFingerprint':{name:sha(data) for name,data in source.items()},'sourceFiles':755,'sourceBytes':sum(map(len,source.values())),
 'unchangedSourceFiles':752,'preservedOffscreenMI':{name:sha(source['src/SexyAppFramework/graphics/'+name]) for name in ['MemoryImage.cpp','MemoryImage.h','inc_routines/MI_SlowStretchBlt.inc']},
 'newBehavior':['Dedicated screen mirror clip→forward16.16 samples→right-to-left destination; both fast values use native fixed16; white/tint/global-alpha/normal/nonzero-additive math',
  'Dedicated screen normal/additive RGB888 FillRect; inherited axis Line/AA and span virtual routes; plain MI/nonaxis normal line unchanged'],
 'engineInitialized':False,'browserLaunched':False,'audioDeviceOpened':False,'publicOrStable4ModifiedByPreparation':False,
 'testInputSummary':{'mirrorAssertions':98802,'mirrorOld4ExpectedFailures':21208,'mirror5Failures':0,'fillAssertions':2118543,'fillOld4ExpectedDifferences':539971,'fill5Differences':0,'retainedDD32Assertions':20900},'limits':limits}
(ROOT/'software5-change-record.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'candidate':VERSION,'sourceFiles':len(source),'deltaPaths':len(delta),'combinedPaths':len(combined),'artifacts':artifacts},indent=2))
