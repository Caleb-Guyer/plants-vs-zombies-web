"""Actual frozen4 FAIL/current5 PASS against addressed DD32 mirror equations.

Builds only synthetic isolated C++/Wasm/Node fixtures using the existing SDK.
No native EXE, game, browser, audio or public tree is initialized/modified.
The archived baseline and reference are self-contained, without original assets.
"""
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess

ROOT=Path(__file__).resolve().parent.parent
WORK=ROOT.parents[1]
TEST=ROOT/'mirror-tests'
SDK=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
OUT=TEST/'results';OUT.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
tree=ast.parse((ROOT/'tests/prepare-primitives.py').read_text())
prefix=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='prefix' for t in n.targets))
prefix=prefix.replace('void Create(int w,int h)','virtual void Create(int w,int h)').replace('void Blt(Image*','virtual void Blt(Image*').replace('void StretchBlt(Image*','virtual void StretchBlt(Image*')
prefix=prefix.replace('void FillRect(const Rect&,const Color&,int);','virtual void FillRect(const Rect&,const Color&,int);')
prefix=prefix.replace('bool mHasAlpha=false,','bool mIsVolatile=false,mPurgeBits=false,mHasAlpha=false,').replace('EXTRA_DECLARATIONS','void SlowStretchResample(Image*,const Rect&,const FRect&,bool); void BltMirror(Image*,int,int,const Rect&,const Color&,int,bool=true) override; void StretchBltMirror(Image*,const Rect&,const Rect&,const Rect&,const Color&,int,bool) override; bool StretchBltMirrorClipHelper(const Rect&,const Rect&,const Rect&,FRect&,Rect&);')
def function(text,signature):
 assert text.count(signature)==1,signature
 start=text.index(signature);brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if depth==0:return text[start:end+1]
 raise AssertionError(signature)
prefix=prefix.replace(function(prefix,'uint32_t* GetBits('),'''uint32_t* GetBits(){
 if(!mBits){mBits=std::make_unique<uint32_t[]>(mWidth*mHeight+1);mBits[mWidth*mHeight]=0x4beefade;
  if(mColorTable){for(int i=0;i<mWidth*mHeight;++i)mBits[i]=mColorTable[mColorIndices[i]];mColorTable.reset();mColorIndices.reset();}}
 return mBits.get();
}''')
manifest=json.loads((TEST/'software4-baseline/manifest.json').read_text())
for name,expected in manifest.items():assert sha((TEST/'software4-baseline'/name).read_bytes())==expected,name
before={p.relative_to(ROOT/'source').as_posix():sha(p.read_bytes()) for p in (ROOT/'source').rglob('*') if p.is_file()}
results={}
for variant,graphics in [('frozen4',TEST/'software4-baseline'),('candidate5',ROOT/'source/src/SexyAppFramework/graphics')]:
 out=OUT/variant;out.mkdir(exist_ok=True);(out/'inc_routines').mkdir(exist_ok=True);(out/'temp').mkdir(exist_ok=True)
 memory=(graphics/'MemoryImage.cpp').read_text();image=(graphics/'Image.cpp').read_text();screen=(graphics/'SoftwareScreenImage.cpp').read_text();header=(graphics/'SoftwareScreenImage.h').read_text()
 methods=['void MemoryImage::CommitBits(','void MemoryImage::SetImageMode(','void MemoryImage::FillRect(','void MemoryImage::NormalBlt(','void MemoryImage::AdditiveBlt(','void MemoryImage::Blt(','bool MemoryImage::StretchBltClipHelper(','bool MemoryImage::StretchBltMirrorClipHelper(','void MemoryImage::FastStretchBlt(','void MemoryImage::SlowStretchBlt(','void MemoryImage::SlowStretchResample(','void MemoryImage::StretchBlt(','void MemoryImage::BltMirror(','void MemoryImage::StretchBltMirror(']
 screen_methods=['SoftwareScreenImage::SoftwareScreenImage(','void SoftwareScreenImage::Create(','uint32_t SoftwareScreenImage::CompositePixel(','void SoftwareScreenImage::Blt(','void SoftwareScreenImage::StretchBlt(']
 if variant=='candidate5':screen_methods+=['void SoftwareScreenImage::StretchBltMirror(','void SoftwareScreenImage::FillRect(']
 declaration=header[header.index('class SoftwareScreenImage final'):header.index('\n};',header.index('class SoftwareScreenImage final'))+3]
 generated=prefix+'\nusing SexyAppBase=App;\n'+declaration+'\n'+function(image,'void Image::BltMirror(')+'\n'+function(image,'void Image::StretchBltMirror(')+'\n'+'\n'.join(function(memory,s) for s in methods)+'\n'+'\n'.join(function(screen,s) for s in screen_methods)+'\n'+(TEST/'fixtures.cpp').read_text()
 (out/'actual.cpp').write_text(generated)
 for name in ['MI_NormalBlt.inc','MI_AdditiveBlt.inc','MI_SlowStretchBlt.inc']:shutil.copyfile(graphics/'inc_routines'/name,out/'inc_routines'/name)
 shutil.copyfile(TEST/'native-dd32-mirror-reference.h',out/'native-dd32-mirror-reference.h')
 env=dict(os.environ,EM_CONFIG=str(SDK/'.emscripten'),EM_CACHE=str(WORK/'toolchain/em-cache'),EMCC_TEMP_DIR=str(out/'temp'),PYTHONNOUSERSITE='1')
 command=[SDK/'python/3.13.3_64bit/python.exe',SDK/'upstream/emscripten/em++.py',out/'actual.cpp','-std=c++20','-O1','-sENVIRONMENT=node','-o',out/'actual.js']
 r=subprocess.run(list(map(str,command)),env=env,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
 assert 'AudioContext' not in (out/'actual.js').read_text()
 r=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(out/'actual.js')],capture_output=True,text=True)
 results[variant]={'exitCode':r.returncode,'output':r.stdout+r.stderr,'generatedSha256':sha(generated.encode()),'actualSourceSha256':{name:sha((graphics/name).read_bytes()) for name in ['MemoryImage.cpp','SoftwareScreenImage.cpp','SoftwareScreenImage.h']}}
 print(variant+':\n'+r.stdout+r.stderr)
 assert r.returncode==(1 if variant=='frozen4' else 0),variant
assert before=={p.relative_to(ROOT/'source').as_posix():sha(p.read_bytes()) for p in (ROOT/'source').rglob('*') if p.is_file()}
report={'candidate':'0.2.6-web-software.5','status':'PASS','variants':results,
 'referenceSha256':sha((TEST/'native-dd32-mirror-reference.h').read_bytes()),'fixturesSha256':sha((TEST/'fixtures.cpp').read_bytes()),
 'sourceUnchangedByTests':True,'scope':'Actual source-extracted methods and inherited/base virtual calls vs independent addressed RGB888 mirror clip/fixed16/native-alpha equations; raw/indexed/forced-flags/white/tint/global-alpha/normal/nonzero-additive/both-fast-values.',
 'limits':['No original code execution or full original framebuffer claim.','No game/browser/audio initialization.','DD16/D3D/driver/volatile/cache-recovery and other primitive dispatch remain excluded.']}
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='variants'},indent=2))
