"""Actual frozen4 FAIL/current5 PASS against independent scalar DD32 fill equations.

No installed native files are required/read. Uses synthetic C++/Wasm/Node only.
Production sources, old candidate artifacts and public files are never written.
"""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT.parents[1]
TEST = ROOT / "fill-tests"
SDK = WORK / "toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154"
OUT = TEST / "results"
OUT.mkdir(exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def function(text, signature):
    assert text.count(signature) == 1, signature
    start = text.index(signature)
    brace = text.index("{", start)
    depth = 0
    for end in range(brace, len(text)):
        depth += (text[end] == "{") - (text[end] == "}")
        if depth == 0:
            return text[start:end + 1]
    raise AssertionError(signature)


tree = ast.parse((ROOT / "tests/prepare-primitives.py").read_text(encoding="utf-8"))
prefix = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
              and any(isinstance(target, ast.Name) and target.id == "prefix" for target in node.targets))
prefix = prefix.replace("void Create(int w,int h)", "virtual void Create(int w,int h)")
prefix = prefix.replace("void Blt(Image*", "virtual void Blt(Image*")
prefix = prefix.replace("void StretchBlt(Image*", "virtual void StretchBlt(Image*")
prefix = prefix.replace("void FillRect(const Rect&", "virtual void FillRect(const Rect&")
prefix = prefix.replace("virtual ~Image()=default;", """virtual ~Image()=default;
 virtual void FillRect(const Rect&,const Color&,int){}
 virtual void DrawLine(double,double,double,double,const Color&,int){}
 virtual void DrawLineAA(double,double,double,double,const Color&,int){}
 virtual void FillScanLines(Span*,int,const Color&,int);
""")
prefix = prefix.replace("bool mHasAlpha=false,", "bool mIsVolatile=false,mPurgeBits=false,mHasAlpha=false,")
prefix = prefix.replace("EXTRA_DECLARATIONS", """
 void SlowStretchResample(Image*,const Rect&,const FRect&,bool);
 void BltMirror(Image*,int,int,const Rect&,const Color&,int,bool=true) override;
 void StretchBltMirror(Image*,const Rect&,const Rect&,const Rect&,const Color&,int,bool) override;
 bool StretchBltMirrorClipHelper(const Rect&,const Rect&,const Rect&,FRect&,Rect&);
 void NormalDrawLine(double,double,double,double,const Color&);
 void AdditiveDrawLine(double,double,double,double,const Color&);
 void DrawLine(double,double,double,double,const Color&,int) override;
 void NormalDrawLineAA(double,double,double,double,const Color&);
 void DrawLineAA(double,double,double,double,const Color&,int) override;
""")
manifest = json.loads((TEST / "software4-baseline/manifest.json").read_text(encoding="utf-8"))
parent = json.loads((ROOT / "software4-parent.json").read_text(encoding="utf-8"))
for name, expected in manifest.items():
    assert sha((TEST / "software4-baseline" / name).read_bytes()) == expected, name
    assert parent["baseSourceFingerprint"]["src/SexyAppFramework/graphics/" + name] == expected, name
before = {p.relative_to(ROOT / "source").as_posix(): sha(p.read_bytes())
          for p in (ROOT / "source").rglob("*") if p.is_file() and ".git" not in p.relative_to(ROOT / "source").parts}
results = {}
for variant, graphics in [("frozen4", TEST / "software4-baseline"),
                          ("candidate5", ROOT / "source/src/SexyAppFramework/graphics")]:
    out = OUT / variant
    out.mkdir(exist_ok=True)
    (out / "inc_routines").mkdir(exist_ok=True)
    (out / "temp").mkdir(exist_ok=True)
    memory = (graphics / "MemoryImage.cpp").read_text(encoding="utf-8")
    image = (graphics / "Image.cpp").read_text(encoding="utf-8")
    screen = (graphics / "SoftwareScreenImage.cpp").read_text(encoding="utf-8")
    header = (graphics / "SoftwareScreenImage.h").read_text(encoding="utf-8")
    assert sha((graphics / "MemoryImage.cpp").read_bytes()) == manifest["MemoryImage.cpp"]
    assert "DrawLineAA(" not in header and "DrawLine(" not in header
    methods = ["void MemoryImage::CommitBits(", "void MemoryImage::SetImageMode(",
               "void MemoryImage::NormalBlt(", "void MemoryImage::AdditiveBlt(", "void MemoryImage::Blt(",
               "bool MemoryImage::StretchBltClipHelper(", "bool MemoryImage::StretchBltMirrorClipHelper(",
               "void MemoryImage::FastStretchBlt(", "void MemoryImage::SlowStretchBlt(",
               "void MemoryImage::SlowStretchResample(", "void MemoryImage::StretchBlt(",
               "void MemoryImage::BltMirror(", "void MemoryImage::StretchBltMirror(",
               "void MemoryImage::FillRect(", "void MemoryImage::NormalDrawLine(",
               "void MemoryImage::AdditiveDrawLine(", "void MemoryImage::DrawLine(",
               "void MemoryImage::NormalDrawLineAA(", "void MemoryImage::DrawLineAA("]
    screen_methods = ["SoftwareScreenImage::SoftwareScreenImage(", "void SoftwareScreenImage::Create(",
                      "uint32_t SoftwareScreenImage::CompositePixel(", "void SoftwareScreenImage::Blt(",
                      "void SoftwareScreenImage::StretchBlt("]
    if variant == "candidate5":
        screen_methods += ["void SoftwareScreenImage::StretchBltMirror(", "void SoftwareScreenImage::FillRect("]
    declaration = header[header.index("class SoftwareScreenImage final"):
                         header.index("\n};", header.index("class SoftwareScreenImage final")) + 3]
    generated = prefix + "\nusing SexyAppBase=App;\n" + declaration
    generated += "\n" + "\n".join(function(image, sig) for sig in
                                    ["void Image::BltMirror(", "void Image::StretchBltMirror(", "void Image::FillScanLines("])
    generated += "\n" + "\n".join(function(memory, sig) for sig in methods)
    generated += "\n" + "\n".join(function(screen, sig) for sig in screen_methods)
    generated += "\n" + (TEST / "fixtures.cpp").read_text(encoding="utf-8")
    (out / "actual.cpp").write_text(generated, encoding="utf-8")
    for name in ["MI_NormalBlt.inc", "MI_AdditiveBlt.inc", "MI_SlowStretchBlt.inc"]:
        shutil.copyfile(graphics / "inc_routines" / name, out / "inc_routines" / name)
    # The AA include is needed to link the untouched inherited publicAA method;
    # fixtures execute only its proved axis-to-FillRect route.
    aa = ROOT / "source/src/SexyAppFramework/graphics/inc_routines/GENERIC_DrawLineAA.inc"
    assert sha(aa.read_bytes()) == parent["baseSourceFingerprint"]["src/SexyAppFramework/graphics/inc_routines/GENERIC_DrawLineAA.inc"]
    shutil.copyfile(aa, out / "inc_routines/GENERIC_DrawLineAA.inc")
    shutil.copyfile(TEST / "native-dd32-fill-reference.h", out / "native-dd32-fill-reference.h")
    env = dict(os.environ, EM_CONFIG=str(SDK / ".emscripten"), EM_CACHE=str(WORK / "toolchain/em-cache"),
               EMCC_TEMP_DIR=str(out / "temp"), PYTHONNOUSERSITE="1")
    command = [SDK / "python/3.13.3_64bit/python.exe", SDK / "upstream/emscripten/em++.py",
               out / "actual.cpp", "-std=c++20", "-O1", "-sENVIRONMENT=node", "-o", out / "actual.js"]
    compiled = subprocess.run(list(map(str, command)), env=env, capture_output=True, text=True)
    assert compiled.returncode == 0, compiled.stdout + compiled.stderr
    assert "AudioContext" not in (out / "actual.js").read_text(encoding="utf-8")
    ran = subprocess.run([str(SDK / "node/24.19.0_64bit/node.exe"), str(out / "actual.js")], capture_output=True, text=True)
    summary = re.search(r"(PASS|FAIL) (\d+) checks, (\d+) differences", ran.stdout)
    assert summary, ran.stdout + ran.stderr
    results[variant] = {"exitCode": ran.returncode, "checks": int(summary[2]), "differences": int(summary[3]),
                        "output": ran.stdout + ran.stderr, "generatedSha256": sha(generated.encode()),
                        "actualSourceSha256": {name: sha((graphics / name).read_bytes()) for name in
                                               ["MemoryImage.cpp", "Image.cpp", "SoftwareScreenImage.cpp", "SoftwareScreenImage.h"]}}
    print(variant + ":\n" + ran.stdout + ran.stderr)
    assert ran.returncode == (1 if variant == "frozen4" else 0), variant
assert before == {p.relative_to(ROOT / "source").as_posix(): sha(p.read_bytes())
                  for p in (ROOT / "source").rglob("*") if p.is_file() and ".git" not in p.relative_to(ROOT / "source").parts}
assert results["frozen4"]["checks"] == results["candidate5"]["checks"]
report = {"candidate": "0.2.6-web-software.5", "status": "PASS", "variants": results,
          "referenceSha256": sha((TEST / "native-dd32-fill-reference.h").read_bytes()),
          "fixturesSha256": sha((TEST / "fixtures.cpp").read_bytes()),
          "runnerSha256": sha(Path(__file__).read_bytes()), "sourceUnchangedByTests": True,
          "scope": "Actual source class/header/method extraction versus independently derived scalar native DD32 RGB888 fill equations; full0..255 color+alpha grid/eight destination RGBs/both modes; valid rect/guard, actual inherited axis Line+AA and baseSpan virtual dispatch, unknown-mode guard, offscreen and nonaxis first-pixel controls.",
          "limits": ["No installed original binary is read or executed by this runner.",
                     "No game/browser/audio initialization or full native framebuffer claim.",
                     "RGB888 successful-lock ordinary software path only; DD16/D3D/driver/volatile/failure paths excluded.",
                     "Defensive outside-screen clipping is not asserted as native invalid-geometry equivalence.",
                     "Nonaxis additiveAA remains unchanged and a known API discrepancy; normalAA/full line geometry unproved."]}
(OUT / "results.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": report["status"], "checksPerVariant": results["candidate5"]["checks"],
                  "frozen4Differences": results["frozen4"]["differences"], "candidate5Differences": results["candidate5"]["differences"]}))
