"""Authored scalar RGB888 controls; no game, native code or external inputs.

This is deliberately expressed independently of the C++ reference header:
Cartesian neighbor/weight records, integer division and per-channel arithmetic.
The addressed original floors and thresholds are preserved, not idealized.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

UNIT = 1 << 16


def channels(argb: int) -> tuple[int, int, int, int]:
    return tuple((argb // (1 << shift)) % 256 for shift in (24, 16, 8, 0))


def assemble(a: int, r: int, g: int, b: int) -> int:
    assert all(0 <= value <= 255 for value in (a, r, g, b))
    return a * (1 << 24) + r * (1 << 16) + g * (1 << 8) + b


def axis_neighbors(position: int, extent: int) -> tuple[tuple[int, int], ...]:
    """Two coordinates and fixed16 weights; retain duplicate edge neighbors."""
    shifted = position - UNIT // 2
    cell = shifted // UNIT if shifted > 0 else 0
    neighbor = min(cell + 1, extent - 1) if shifted > 0 else 0
    # The original uses an odd low16 fraction. Modulo also defines negatives.
    fraction = 2 * (((shifted - cell * UNIT) % UNIT) // 2) + 1
    assert 0 <= cell < extent and 0 <= neighbor < extent
    return ((cell, UNIT - fraction), (neighbor, fraction))


def sample(pixels: list[int], width: int, height: int,
           u16: int, v16: int, linear: bool) -> int:
    assert width > 0 and height > 0 and len(pixels) == width * height
    assert 0 <= u16 <= width * UNIT and 0 <= v16 <= height * UNIT
    if not linear:
        # Addressed nearest behavior checks a flattened index, not each axis.
        index = (v16 // UNIT) * width + u16 // UNIT
        return pixels[index] if index < len(pixels) else 0

    # Do NOT merge repeated neighbors before flooring individual alpha terms.
    contributions = []
    for y, wy in axis_neighbors(v16, height):
        for x, wx in axis_neighbors(u16, width):
            weight = ((wx * wy) % (1 << 32)) // UNIT
            rgba = channels(pixels[y * width + x])
            contributions.append((rgba, rgba[0] * weight // UNIT))
    alpha = sum(a for _, a in contributions) % 256
    rgb = [sum(rgba[c] * a for rgba, a in contributions) // 256 % 256
           for c in (1, 2, 3)]
    return assemble(alpha, *rgb)


def composite(texture: int, destination: int, tint_kind: int,
              tint: list[int], linear: bool, additive: bool) -> int:
    assert tint_kind in (0, 1, 2) and (tint_kind != 2 or linear)
    assert len(tint) == 4 and all(0 <= c <= 255 for c in tint)
    tex = channels(texture)
    dst = channels(destination)
    if tex[0] <= 8:  # BEFORE tint/global alpha modulation.
        return destination
    tinted = tint_kind != 0
    effective = tex[0] * tint[0] // 256 if tinted else tex[0]
    rgb = []
    for i in (1, 2, 3):
        source = tex[i] * tint[i] // 256 if tinted else tex[i]
        if linear and tinted:
            source = source * tint[0] // 256
        if additive:
            contribution = source if linear else source * effective // 256
            value = min(255, dst[i] + contribution)
        elif effective >= 240:
            value = source
        else:
            contribution = source if linear else source * effective // 256
            value = contribution + dst[i] * (255 - effective) // 256
        rgb.append(value)
    return assemble(255, *rgb)


def evaluate(case: dict) -> int:
    texture = sample([int(x, 16) for x in case["pixels"]], case["width"],
                     case["height"], case["u16"], case["v16"], case["linear"])
    return composite(texture, int(case["dest"], 16), case["tintKind"],
                     case["tint"], case["linear"], case["additive"])


def fixture_document() -> dict:
    textures = [
        ("single-opaque", 1, 1, [0xFFFFFFFF]),
        ("single-alpha128", 1, 1, [0x80402010]),
        ("single-alpha8", 1, 1, [0x08ABCDEF]),
        ("single-alpha9", 1, 1, [0x09ABCDEF]),
        ("vertical-mixed", 1, 4, [0x00F02040, 0x09A0E010, 0x808030F0, 0xFFF0C060]),
        ("horizontal-mixed", 4, 1, [0xFF2040E0, 0x7FEC1020, 0x0800FF80, 0x00FF007F]),
        ("quad-mixed", 2, 2, [0xFFFF0000, 0x8000FF00, 0x080000FF, 0x00ABCDEF]),
        ("grid-mixed", 3, 3, [0xFF112233, 0x8044CC20, 0x00EE8800,
                              0x01E00080, 0x09A020E0, 0x7F80FF10,
                              0xEFCA3520, 0xF01C70D0, 0xFEF0C080]),
    ]
    tints = [[255, 255, 255, 255], [0, 255, 137, 64], [1, 255, 128, 64],
             [128, 75, 100, 255], [255, 75, 75, 255], [255, 0, 0, 0]]
    destinations = [0xFF000000, 0xFF17395B, 0xFFF0F8FF]
    cases = []
    for name, width, height, pixels in textures:
        right, bottom = width * UNIT, height * UNIT
        points = [("top-left", 0, 0), ("top-right", right, 0),
                  ("bottom-left", 0, bottom), ("bottom-right", right, bottom),
                  ("left-mid", 0, bottom // 2), ("right-mid", right, bottom // 2),
                  ("top-mid", right // 2, 0), ("bottom-mid", right // 2, bottom),
                  ("center", right // 2, bottom // 2),
                  ("first-center", UNIT // 2, UNIT // 2),
                  ("last-center", right - UNIT // 2, bottom - UNIT // 2),
                  ("half-minus-one", UNIT // 2 - 1, UNIT // 2 - 1),
                  ("half-plus-one", UNIT // 2 + 1, UNIT // 2 + 1),
                  ("near-origin", 1, 1), ("near-end", right - 1, bottom - 1),
                  ("first-row-interior", right // 2, UNIT // 2),
                  ("first-col-interior", UNIT // 2, bottom // 2)]
        unique = {}
        for label, u, v in points:
            unique.setdefault((u, v), label)
        for (u, v), label in unique.items():
            for kind in (0, 1, 2):
                for linear in (False, True):
                    if kind == 2 and not linear:
                        continue
                    for tint_index, tint in enumerate(tints if kind else tints[:1]):
                        for additive in (False, True):
                            for dest_index, dest in enumerate(destinations):
                                case = {
                                    "id": f"{name}/{label}/k{kind}/l{int(linear)}/a{int(additive)}/t{tint_index}/d{dest_index}",
                                    "width": width, "height": height,
                                    "pixels": [f"{p:08X}" for p in pixels],
                                    "u16": u, "v16": v, "tintKind": kind,
                                    "linear": linear, "additive": additive,
                                    "tint": tint, "dest": f"{dest:08X}",
                                }
                                case["expected"] = f"{evaluate(case):08X}"
                                cases.append(case)
    assert len(cases) == len({c["id"] for c in cases})
    return {"schemaVersion": 1, "cases": cases}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), "Reference fixtures are immutable; use a new output."
    document = fixture_document()
    args.output.write_text(json.dumps(document, separators=(",", ":")) + "\n", encoding="utf-8")
    print(f"Wrote {len(document['cases'])} authored controls to {args.output}")


if __name__ == "__main__":
    main()
