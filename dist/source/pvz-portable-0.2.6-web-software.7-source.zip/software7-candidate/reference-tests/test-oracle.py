"""Hand-worked scalar controls plus fixture integrity; never initializes a game."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
from oracle import sample, composite, evaluate, fixture_document

HERE = Path(__file__).resolve().parent

# Literal expected words were worked independently from the original addressed
# arithmetic, not copied from a candidate or obtained from the C++ reference.
sample_anchors = [
    ("single-opaque-origin", [0xFFFFFFFF], 1, 1, 0, 0, True, 0xFCFBFBFB),
    ("single-opaque-center", [0xFFFFFFFF], 1, 1, 32768, 32768, True, 0xFEFDFDFD),
    ("single-partial-origin", [0x80402010], 1, 1, 0, 0, True, 0x7D1F0F07),
    ("mixed-quad-center", [0xFFFF0000, 0x8000FF00, 0x080000FF, 0x00ABCDEF],
     2, 2, 65536, 65536, True, 0x5F3E1E00),
    ("thin-horizontal-left", [0xFFFF0000, 0xFF00FF00], 2, 1, 0, 0, True, 0xFCFB0000),
    ("thin-horizontal-right", [0xFFFF0000, 0xFF00FF00], 2, 1, 131072, 0, True, 0xFC00FB00),
    ("thin-vertical-bottom", [0xFFFF0000, 0xFF00FF00], 1, 2, 0, 131072, True, 0xFC00FB00),
    ("nearest-flattened-next-row", [0xFF010203, 0xFF405060, 0xFF8090A0],
     1, 3, 65536, 0, False, 0xFF405060),
    ("nearest-end-is-empty", [0xFF010203], 1, 1, 65536, 0, False, 0),
]

pixel_anchors = [
    ("alpha-eight-skip", 0x08ABCDEF, 0xFF123456, 0, [255]*4, False, False, 0xFF123456),
    ("normal-high-alpha-copy", 0xF0AA5500, 0xFF123456, 0, [255]*4, False, False, 0xFFAA5500),
    ("white-nearest-add", 0x80808080, 0xFF202020, 0, [255]*4, False, True, 0xFF606060),
    ("white-nearest-normal", 0x80808080, 0xFF202020, 0, [255]*4, False, False, 0xFF4F4F4F),
    ("global-zero-normal", 0x80FFFFFF, 0xFF102040, 1, [0,255,137,64], False, False, 0xFF0F1F3F),
    ("global-zero-add", 0x80FFFFFF, 0xFF102040, 1, [0,255,137,64], False, True, 0xFF102040),
    ("gate-before-tint-nine", 0x09FFFFFF, 0xFF102040, 1, [0,255,137,64], False, False, 0xFF0F1F3F),
    ("gate-before-tint-eight", 0x08FFFFFF, 0xFF102040, 1, [0,255,137,64], False, False, 0xFF102040),
    ("global-half-add", 0x80FFFFFF, 0xFF202020, 1, [128,255,255,255], False, True, 0xFF5F5F5F),
    ("global-half-normal", 0x80FFFFFF, 0xFF202020, 1, [128,255,255,255], False, False, 0xFF565656),
    ("explicit-global-white-is-tinted", 0xFF804020, 0xFF123456, 1, [255]*4, False, False, 0xFF7F3F1F),
    ("add-saturation", 0xFFFF8040, 0xFFF0F8FF, 0, [255]*4, False, True, 0xFFFFFFFF),
    ("mixed-linear-normal", 0x5F3E1E00, 0xFF204060, 0, [255]*4, True, False, 0xFF52463C),
    ("mixed-linear-add", 0x5F3E1E00, 0xFF204060, 0, [255]*4, True, True, 0xFF5E5E60),
    ("vertex-half-linear-normal", 0x5F3E1E00, 0xFF204060, 2, [128,255,255,255], True, False, 0xFF38424E),
    ("vertex-half-linear-add", 0x5F3E1E00, 0xFF204060, 2, [128,255,255,255], True, True, 0xFF3E4E60),
    ("global-one-linear-no-source-normal", 0x5F3E1E00, 0xFF204060, 1, [1,255,255,255], True, False, 0xFF1F3F5F),
]

for name, *args, want in sample_anchors:
    actual = sample(*args)
    assert actual == want, (name, f"{actual:08X}", f"{want:08X}")
for name, *args, want in pixel_anchors:
    actual = composite(*args)
    assert actual == want, (name, f"{actual:08X}", f"{want:08X}")

raw = (HERE / "reference.json").read_bytes()
document = json.loads(raw)
assert document == fixture_document(), "Frozen fixtures differ from authored oracle."
cases = document["cases"]
assert len(cases) == len({case["id"] for case in cases})
assert {(c["width"], c["height"]) for c in cases} == {(1,1), (1,4), (4,1), (2,2), (3,3)}
assert {c["tint"][0] for c in cases if c["tintKind"]} >= {0,1,128,255}
assert all(c["linear"] for c in cases if c["tintKind"] == 2)
assert all(f"{evaluate(c):08X}" == c["expected"] for c in cases)
result = {
    "status": "PASS_SCALAR_CONTROLS_AND_FIXTURE_INTEGRITY",
    "handWorkedSampleAnchors": len(sample_anchors),
    "handWorkedPixelAnchors": len(pixel_anchors),
    "fixtureCases": len(cases),
    "referenceJsonSha256": hashlib.sha256(raw).hexdigest(),
    "scope": "Authored independent Python arithmetic and literal controls only. No actual6/7 callback, native code, game, geometry or runtime parity pass supplied by this script.",
}
(HERE / "self-test-results.json").write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
print(json.dumps(result, indent=2))
