Independent authored RGB888 sample/pixel reference controls

Only this reference-tests directory is owned by the control-suite author.
No candidate production source, matrix test runner, build recipe, public file,
original executable/disassembly, artwork or saved state is an input here.
The existing NativeMatrixRGB888 C++ reference header is not modified or copied.

reference.json uses schemaVersion 1 and the agreed flat case fields:
id,width,height,pixels,u16,v16,tintKind,linear,additive,tint,dest,expected.
ARGB words are eight uppercase hexadecimal characters. tint is [A,R,G,B].
kind0 is untinted white; kind1 is global tint; kind2 is constant vertex tint
and is supplied only for linear sampling. The latter is a constant-interpolant
control, not a clipped color-gradient or scan-conversion reference.

oracle.py independently expresses the addressed conditional RGB888 equations
using Cartesian coordinate/weight records and integer division. It preserves:
  sampled-alpha <=8 skip BEFORE modulation;
  normal effective-alpha >=240 source copy, no such additive shortcut;
  original /256 floors and destination*(255-effective)/256;
  linear source already premultiplied by separately floored neighbor alphas;
  tint/global-alpha floors in their original order; saturated additive RGB;
  bilinear full-texture repeated-edge neighbors and odd fixed16 fractions.
Repeated edge neighbors remain four contributions: merging them before alpha
flooring changes results, even for 1x1 textures. No source-rectangle clamp or
ideal normalized-alpha/bilinear interpolation is substituted.

The addressed nearest path retains its flattened index/endpos check. Thus an
inclusive right-boundary coordinate can point to the next row; this is distinct
from the bilinear repeated-edge rule. All UV values are in the proved inclusive
0..width*65536 and 0..height*65536 domain. No invalid-coordinate policy is inferred.

Synthetic textures include 1x1,1x4,4x1,2x2,3x3, varied RGB and neighborhood
alphas 0/1/8/9/127/128/239/240/254/255. Cases cover corners, edge midpoints,
center, first/last texel centers, half-texel minus/plus one and near-endpoints;
CA0/1/128/255, explicit global white versus untinted, zero contribution and
saturation over opaque black/asymmetric/bright destinations. Transparent
texels deliberately retain nonzero RGB to detect incorrect alpha treatment.

test-oracle.py checks 26 hand-worked literal sample/pixel anchors independently
of the C++ reference and verifies fixture integrity/coverage. These controls
are not outputs copied from Software6/7, another implementation or a capture.
The unchanged C++ header and actual frozen6/new7 callbacks must still be checked
against this independent file by the matrix-test owner. A full callback runner
can compare its 10 painted pixels with expected and its 6 untouched pixels with
dest in the authored constant-UV 4x4 triangle. Source/virtual routing and plain
offscreen preservation need their own controls.

Reproduce the scalar controls without any game/compiler/audio initialization:
  python reference-tests/test-oracle.py
To make a new fixture file (the generator refuses overwriting):
  python reference-tests/oracle.py --output <new-file.json>

Functional provenance: original RGB888 white/global/constant-vertex TEX_ALPHA
nearest/linear normal/additive callback equations, reviewed in the separate
private matrix tint/linear audit. In particular normal/additive tint blocks
4CD2A1..4CD3A2,4CC514..4CC60F,4CE8C7..4CE9B3,4D2EB3..4D2FB2,
4D4E2A..4D4F29 and repeated-neighbor blocks4C8DB6..4C8FDA/4CE6B0..4CE8C7.
This is authored functional math metadata, with no original machine-code bytes.

Limits: successful ordinary RGB888 screen conditions; raw committed texture;
constant UV and uniform tint. No native executable or complete framebuffer,
changing UV/color interpolation, clipping/scan conversion, other formats,
combined vertex/global, vertex-nearest, source cache/device recovery, actual
asset edge occurrence, browser scene or whole-game parity is established.
