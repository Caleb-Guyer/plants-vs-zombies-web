"""Private candidate source delta and verification receipt; includes no game assets."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import zipfile

root = Path(__file__).resolve().parent
base = root.parent / 'patched-source'
candidate = root / 'source'


def files(directory):
    result = {}
    for current, dirs, names in os.walk(directory):
        dirs[:] = sorted(d for d in dirs if d != '.git')
        for name in sorted(names):
            path = Path(current) / name
            result[path.relative_to(directory).as_posix()] = path
    return result


original = files(base)
new = files(candidate)
changes = []
patch = []
for relative in sorted(original.keys() | new.keys()):
    old = original[relative].read_bytes() if relative in original else b''
    updated = new[relative].read_bytes() if relative in new else b''
    if old == updated:
        continue
    changes.append({'path': relative, 'beforeSha256': hashlib.sha256(old).hexdigest(), 'afterSha256': hashlib.sha256(updated).hexdigest()})
    patch.extend(difflib.unified_diff(old.decode('utf-8').splitlines(keepends=True), updated.decode('utf-8').splitlines(keepends=True), fromfile='a/'+relative, tofile='b/'+relative))
(root / 'source-changes.patch').write_bytes(''.join(patch).encode('utf-8'))
artifacts = []
for name in ['pvz-portable.html', 'pvz-portable.js', 'pvz-portable.wasm', 'ProjectVersion.h']:
    path = root / 'build' / name
    artifacts.append({'path':'build/'+name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
version = (root/'build/ProjectVersion.h').read_text(encoding='utf-8')
assert '0.2.6-web-software.4' in version, 'Build must carry the private candidate version'
receipt = {
    'candidate':'0.2.6-web-software.4',
    'scope':'Private dedicated nonvolatile DD32 CPU screen plus retained native MemoryImage offscreen arithmetic; not published or browser-runtime verified',
    'base':'Private parity.3 patched-source snapshot plus approved parity.4 matte-only widget merge',
    'sourceFilesCompared':len(new),
    'sourceChanges':changes,
    'sourcePatchSha256':hashlib.sha256((root/'source-changes.patch').read_bytes()).hexdigest(),
    'artifacts':artifacts,
    'checks':{
        'actualPrimitiveAssertions':149,
        'candidatePrimitiveAssertionsPassed':149,
        'baselinePrimitiveAssertionsPassed':31,
        'baselineExpectedFailures':118,
        'actualModeTransitionTests':'PASS with backend/image doubles',
        'actualPresenterSharedBatcherTests':'PASS with GL/SDL doubles',
        'retainedMatteProductionExtraction':'PASS9fixtures; baseline and both partial-fix controls fail as expected',
        'preservedOffscreenMIStretchDiagnostic':{'fixtures':20,'software2DifferentPixels':398,'preservedMI3DifferentPixels':0,'scope':'Actual unchanged MI3 kernel inside Software.4; synthetic only'},
        'dedicatedDD32ScreenDiagnostic':{'pixelAssertions':20900,'nativeEquationAssertions':20893,'inheritedVirtualMirrorDispatchAssertions':7,'candidateFailures':0,'software3RgbDifferences':7360,'scope':'Actual new screen against independent native nonvolatile RGB888 equations; mirror checks establish dispatch only'},
        'fullEngineCompileAndLink':'PASS, Release/Emscripten6.0.13; no game launched',
        'realBrowserOrNativeUi':'NOT RUN',
        'nativeSoftwarePixelParity':'NOT VERIFIED',
        'denseScenePerformance':'NOT MEASURED',
        'browserPreferenceReload':'NOT RUN',
    },
    'limits':[
        'CPU scene composition uses WebGL only for one final bitmap transport; requires existing WebGL context',
        'Temporary mirrored/resampled MemoryImages need performance profiling',
        'Nonvolatile CPU RGB888 Blt/fast/slow dispatch is statically supported and synthetically tested; no original framebuffer equivalence claim',
        'DD16, driver surface Blt shortcuts, volatile sources, native surface/device loss and other formats remain unverified',
        'Fractional/rotated/matrix/triangle/mirror native screen dispatch needs separate original reference; inherited mirror tests establish virtual dispatch only',
        'Offscreen MI tint/additive extensions remain unverified native equivalence; MI3 white-normal equations are unchanged',
        'Mode-specific effects/cache alignment need original/software comparison',
        'Missing-key default remains browser hardware policy; original native automatic selection is conditional',
        'No parity.3/public/native settings changes; no audio/game initialization in isolated tests',
    ],
}
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
previous=files(root.parent/'software3-candidate/source')
delta=[]
changed=[]
for relative in sorted(previous.keys() | new.keys()):
    old=previous[relative].read_bytes() if relative in previous else b''
    updated=new[relative].read_bytes() if relative in new else b''
    if old==updated:continue
    changed.append({'path':relative,'beforeSha256':hashlib.sha256(old).hexdigest(),'afterSha256':hashlib.sha256(updated).hexdigest()})
    delta.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),updated.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
(root/'software3-to-software4.patch').write_bytes(''.join(delta).encode())
(root/'software4-change-record.json').write_text(json.dumps({'candidate':receipt['candidate'],'base':'Frozen0.2.6-web-software.3 source','sourceChanges':changed,
    'patchSha256':hashlib.sha256((root/'software3-to-software4.patch').read_bytes()).hexdigest(),
    'fullSourceFingerprint':{relative:hashlib.sha256(path.read_bytes()).hexdigest() for relative,path in new.items()},
    'dd32Diagnostic':json.loads((root/'dd32-tests/results/results.json').read_text()),
    'preservedMIDiagnostic':json.loads((root/'stretch-tests/results/results.json').read_text()),
    'limits':receipt['limits'],'software3SourceAndPreviewModified':False,'publicModified':False},indent=2)+'\n')
upstream_zip=root.parents[1]/'lawn-defense/dist/source/pvz-portable-0.2.6-source.zip'
upstream_sha=hashlib.sha256(upstream_zip.read_bytes()).hexdigest()
assert upstream_sha=='40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
with zipfile.ZipFile(upstream_zip) as archive:
    assert archive.testzip() is None
    prefix='PvZ-Portable-0.2.6/'
    upstream={name[len(prefix):]:archive.read(name) for name in archive.namelist() if name.startswith(prefix) and not name.endswith('/')}
assert len(upstream)==753
combined=[];upstream_changes=[]
for relative in sorted(upstream.keys()|new.keys()):
    old=upstream.get(relative,b'');updated=new[relative].read_bytes() if relative in new else b''
    if old==updated:continue
    upstream_changes.append({'path':relative,'beforeSha256':hashlib.sha256(old).hexdigest(),'afterSha256':hashlib.sha256(updated).hexdigest()})
    combined.extend(difflib.unified_diff(old.decode().splitlines(keepends=True),updated.decode().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
(root/'web-software.4.patch').write_bytes(''.join(combined).encode())
receipt['privateParity3Delta']={'path':'source-changes.patch','sha256':receipt['sourcePatchSha256'],'changedFiles':receipt['sourceChanges']}
receipt['base']='Raw upstream0.2.6 commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca'
receipt['upstreamSourceArchive']={'name':upstream_zip.name,'sha256':upstream_sha,'files':753}
receipt['sourceChanges']=upstream_changes
receipt['sourcePatchPath']='web-software.4.patch'
receipt['sourcePatchSha256']=hashlib.sha256((root/'web-software.4.patch').read_bytes()).hexdigest()
(root/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'changedSourceFiles':len(changes),'candidate':receipt['candidate'],'artifactCount':len(artifacts),'sourcePatchSha256':receipt['sourcePatchSha256']}))
