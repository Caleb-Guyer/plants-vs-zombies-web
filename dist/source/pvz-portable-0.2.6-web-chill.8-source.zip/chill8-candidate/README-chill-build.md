# Chill.8 bonus minigames and Chill-shroom unlock

This revision starts from the exact published Chill.7 source archive, SHA-256
450613f4d14df23380549081b154d40c11587151d37e749a74f5118a11534605.
Fresh Cone Zone uses native bowling; Night Shift uses a native conveyor; Cold Front
uses a short fixed-budget preparation and defense puzzle. Existing state-zero
checkpoints retain their old challenge rules. Winning Cold Front unlocks the
custom seed in the native chooser through a sparse runtime slot mapping, keeping
original IDs, capacities and saved layouts. Accepted art remains byte-identical.
Meaningful source tests and full muted Cold Front playtesting are separate evidence.

## Retained build and artwork reproduction notes

The source artwork, immutable generated inputs and exact historical prompts
remain in source/artwork/chill-shroom/. Its deterministic Pillow12.2.0 recipe
keeps every approved alpha byte and cap/body partition, and bounds expression
patches to the eyes. No separate per-part fitting is used. Native tint, filter,
flash, attachment and saved-phase behavior remain part of the rig contract.

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Native focused tests start no audio device. Browser testing uses ?testing=1.
Full upstream and Chill.7 delta patches must reconstruct every source byte.
All copied test/build receipts are historical until rerun for this candidate.
Tests and bounded muted review do not prove subjective perfection or exhaustive
original-game parity.
