"""Pack a style repaint without changing the approved character geometry.

Requires Pillow 12.2.0. Generation prompts and immutable inputs are adjacent.
Each full-canvas paint input uses the same whole-character transform. The
approved master supplies every alpha byte and the unchanged cap/body partition.
The generated eye edit supplies only bounded expression patches.
"""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path
from PIL import Image, __version__ as PILLOW_VERSION

ROOT = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_master(name):
    raw=base64.b64decode((ROOT/name).read_bytes())
    return raw,Image.open(io.BytesIO(raw)).convert('RGBA')

def canonicalize(image,recipe):
    image=image.copy()
    image.putalpha(image.getchannel('A').point(lambda a:a if a>recipe['alphaThreshold'] else 0))
    crop=image.crop(recipe['sourceBounds'])
    width,height=recipe['fit'];scale=min(width/crop.width,height/crop.height)
    size=(round(crop.width*scale),round(crop.height*scale))
    resized=crop.resize(size,Image.Resampling.LANCZOS)
    out=Image.new('RGBA',recipe['canvas'])
    out.alpha_composite(resized,tuple(recipe['origin']))
    return out

def partition(master,spec):
    width,height=master.size;pixels=master.load();boundaries={}
    for x in range(width):
        ys=[y for y in range(height) if pixels[x,y][3]>8 and
            pixels[x,y][2]-pixels[x,y][0]>spec['blueMinusRed'] and
            pixels[x,y][2]-pixels[x,y][1]>spec['blueMinusGreen']]
        if ys:boundaries[x]=max(ys)+spec['outlineRows']
    if not boundaries:raise ValueError('Missing blue cap')
    cap=Image.new('RGBA',master.size);body=Image.new('RGBA',master.size)
    for x in range(width):
        boundary=boundaries[min(boundaries,key=lambda i:abs(i-x))]
        for y in range(height):
            (cap if y<=boundary else body).putpixel((x,y),pixels[x,y])
    # Layers partition whole pixels, including alpha; their neutral union is exact.
    assert Image.alpha_composite(body,cap).tobytes()==master.tobytes()
    return cap,body

def paint_on_shape(shape,paint):
    """Transfer generated RGB while retaining all approved alpha bytes.

    Keep the original antialiased contour, where generated alpha can differ by
    a fraction of a native pixel. No generated geometry is used at runtime.
    """
    out=Image.new('RGBA',shape.size)
    for y in range(shape.height):
        for x in range(shape.width):
            original=shape.getpixel((x,y));new=paint.getpixel((x,y))
            if original[3]==0:continue
            rgb=new[:3] if original[3]>=240 and new[3]>=240 else original[:3]
            out.putpixel((x,y),rgb+(original[3],))
    assert out.getchannel('A').tobytes()==shape.getchannel('A').tobytes()
    return out

def apply_partition(paint,cap_shape,body_shape):
    cap=Image.new('RGBA',paint.size);body=Image.new('RGBA',paint.size)
    for y in range(paint.height):
        for x in range(paint.width):
            if cap_shape.getpixel((x,y))[3]:cap.putpixel((x,y),paint.getpixel((x,y)))
            elif body_shape.getpixel((x,y))[3]:body.putpixel((x,y),paint.getpixel((x,y)))
    assert Image.alpha_composite(body,cap).tobytes()==paint.tobytes()
    assert cap.getchannel('A').tobytes()==cap_shape.getchannel('A').tobytes()
    assert body.getchannel('A').tobytes()==body_shape.getchannel('A').tobytes()
    return cap,body

def expression(open_body,closed_master,regions,blend,feather):
    out=open_body.copy()
    for left,top,right,bottom in regions:
        for y in range(top,bottom):
            for x in range(left,right):
                distance=min(x-left,right-1-x,y-top,bottom-1-y)
                weight=blend*min(1.0,distance/feather)
                before=open_body.getpixel((x,y));after=closed_master.getpixel((x,y))
                if before[3]==0:
                    out.putpixel((x,y),(0,0,0,0))
                    continue
                # The shape/alpha is always the approved one. The generated edit
                # supplies only eye-region RGB, with a matching original border.
                out.putpixel((x,y),tuple(round(before[c]*(1-weight)+after[c]*weight)
                    for c in range(3))+(before[3],))
    return out

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--header',type=Path,required=True)
    args=parser.parse_args()
    extraction_raw=(ROOT/'extraction.json').read_bytes();recipe=json.loads(extraction_raw)
    generation_raw=(ROOT/'generation.json').read_bytes();generation=json.loads(generation_raw)
    master_raw,master=read_master(generation['masterSource'])
    historical_closed_raw,_=read_master(generation['closedSource'])
    painted_raw,painted=read_master(generation['paintedSource'])
    closed_raw,closed=read_master(generation['paintedClosedSource'])
    assert sha(master_raw)==generation['approvedMasterSha256']
    assert sha(painted_raw)==generation['paintedMasterSha256']
    assert sha(closed_raw)==generation['paintedClosedMasterSha256']
    # Edit tool may return a different outer canvas. Scale the full edit back to
    # the master frame once; no separate actor bounds or part fitting is used.
    if closed.size!=master.size:closed=closed.resize(master.size,Image.Resampling.LANCZOS)
    if painted.size!=master.size:painted=painted.resize(master.size,Image.Resampling.LANCZOS)
    approved=canonicalize(master,recipe['canonical'])
    assert sha(approved.tobytes())=='c00b7d93e79d2fb8f39ea2dbddd178e02d040ac1f4fd2e8bb62f105502317fb7'
    cap_shape,body_shape=partition(approved,recipe['capPartition'])
    canonical=paint_on_shape(approved,canonicalize(painted,recipe['canonical']))
    closed_canonical=canonicalize(closed,recipe['canonical'])
    cap,body=apply_partition(canonical,cap_shape,body_shape)
    parts={'cap':cap,'body':body,'base':Image.new('RGBA',canonical.size),
           'blink1':expression(body,closed_canonical,recipe['eyeRegions'],recipe['halfExpressionBlend'],recipe['eyeFeatherPixels']),
           'blink2':expression(body,closed_canonical,recipe['eyeRegions'],1.0,recipe['eyeFeatherPixels'])}
    args.output.mkdir(parents=True,exist_ok=True)
    canonical.save(args.output/'canonical.png',compress_level=9)
    header=['// Style repaint on the approved whole-character geometry and shared canvas.',
            '// Generation and extraction source: artwork/chill-shroom/. Straight ARGB.',
            '#pragma once','#include <cstdint>','namespace ChillShroomArt {']
    records={}
    for key,img in parts.items():
        target=args.output/(key+'.png');img.save(target,compress_level=9)
        rgba=img.tobytes();name=key[0].upper()+key[1:]
        pixels=[(rgba[i+3]<<24)|(rgba[i]<<16)|(rgba[i+1]<<8)|rgba[i+2] for i in range(0,len(rgba),4)]
        header.extend([f'inline constexpr int k{name}Width = {img.width};',f'inline constexpr int k{name}Height = {img.height};',f'inline constexpr uint32_t k{name}Argb[] = {{'])
        for i in range(0,len(pixels),10):header.append('    '+', '.join(f'0x{p:08x}u' for p in pixels[i:i+10])+',')
        header.append('};')
        records[key]={'width':img.width,'height':img.height,'pngSha256':sha(target.read_bytes()),'rgbaSha256':sha(rgba)}
    header.append('}');args.header.parent.mkdir(parents=True,exist_ok=True)
    args.header.write_text('\n'.join(header)+'\n',encoding='utf-8',newline='\n')
    manifest={'schema':2,'version':'0.2.6-web-chill.7',
        'method':'Approved silhouette with a painted finish and registered shared-canvas layers',
        'imageGenerationUsed':True,'standaloneChallengeIllustrations':False,'pillowVersion':PILLOW_VERSION,
        'approvedMasterSha256':sha(master_raw),'closedMasterSha256':sha(historical_closed_raw),
        'paintedMasterSha256':sha(painted_raw),'paintedClosedMasterSha256':sha(closed_raw),
        'approvedCanonicalRgbaSha256':sha(approved.tobytes()),
        'canonicalAlphaSha256':sha(canonical.getchannel('A').tobytes()),
        'canonicalPngSha256':sha((args.output/'canonical.png').read_bytes()),'canonicalRgbaSha256':sha(canonical.tobytes()),
        'extractionSha256':sha(extraction_raw),'generationSha256':sha(generation_raw),
        'generatorSha256':sha(Path(__file__).read_bytes()),'headerSha256':sha(args.header.read_bytes()),'parts':records}
    for name,data in [('generation.json',generation_raw),('extraction.json',extraction_raw),('provenance.json',(json.dumps(manifest,indent=2)+'\n').encode())]:(args.output/name).write_bytes(data)
    print(json.dumps(manifest,indent=2))

if __name__=='__main__':main()
