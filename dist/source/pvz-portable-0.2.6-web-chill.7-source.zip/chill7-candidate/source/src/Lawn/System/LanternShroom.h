// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <algorithm>
#include <cmath>

namespace Sexy { class Image; class Graphics; }
class Plant;
class Reanimation;

// Stored in existing Plant counters; native saved-object layouts stay unchanged.
namespace LanternShroom
{
struct PartMotion
{
    float capX = 0.0f;
    float capY = 0.0f;
};
enum class BodyExpression { Auto, Half, Closed };
Sexy::Image* GetImage();
void DisposeImage();
void BindParts(Reanimation& reanimation);
void BindPlantParts(Plant& plant);
void BindCap(Reanimation& reanimation, int glow = 0);
void EnsurePlantReanimation(Plant& plant);
void ConfigureAttackAnimation(Plant& plant);
Sexy::Image* GetBonusImage(GameMode mode);
void DrawAttackPulse(Sexy::Graphics* graphics, const Plant& plant, float offsetY);
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY);
BodyExpression GetPlantBodyExpression(const Plant& plant, Reanimation& carrier);
void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, BodyExpression expression = BodyExpression::Auto, const PartMotion& motion = {});
void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier);

inline constexpr SeedType kSeed = SEED_LANTERNSHROOM;
inline constexpr int kCost = 75;
inline constexpr int kRecharge = 750;
inline constexpr int kPulseInterval = 400;
inline constexpr int kSlowDuration = 150;
inline constexpr int kRadius = 150;
inline constexpr int kPulseFrames = 100;
inline constexpr int kRecoilTicks = 30;
inline constexpr int kWindupTicks = 40;
inline constexpr int kReadyCountdown = kWindupTicks + 1;
inline constexpr float kIdlePeriodSeconds = 2.4f;

enum class AttackPhase { Idle, Windup, Release };
struct AttackPose
{
    float scaleX = 1.0f;
    float scaleY = 1.0f;
    float offsetX = 0.0f;
    float offsetY = 0.0f;
};
constexpr AttackPhase GetAttackPhase(int cooldown, int glow)
{
    // The plume outlives the recoil; breathing resumes while the mist fades.
    if (glow > kPulseFrames - kRecoilTicks) return AttackPhase::Release;
    if (cooldown > 0 && cooldown <= kWindupTicks) return AttackPhase::Windup;
    return AttackPhase::Idle;
}
constexpr float Ease(float value) { return value * value * (3.0f - 2.0f * value); }
constexpr AttackPose GetAttackPose(int cooldown, int glow)
{
    AttackPose pose;
    if (GetAttackPhase(cooldown, glow) == AttackPhase::Windup)
    {
        const float amount = Ease((kWindupTicks - cooldown) / static_cast<float>(kWindupTicks));
        pose.scaleX = 1.0f + 0.08f * amount;
        pose.scaleY = 1.0f - 0.17f * amount;
    }
    else if (GetAttackPhase(cooldown, glow) == AttackPhase::Release)
    {
        const float progress = std::clamp(kPulseFrames - glow, 0, kRecoilTicks) / static_cast<float>(kRecoilTicks);
        if (progress < 1.0f / 3.0f)
        {
            const float amount = Ease(progress * 3.0f);
            pose.scaleX = 1.08f - 0.10f * amount;
            pose.scaleY = 0.83f + 0.21f * amount;
        }
        else
        {
            const float amount = Ease((progress - 1.0f / 3.0f) * 1.5f);
            pose.scaleX = 0.98f + 0.02f * amount;
            pose.scaleY = 1.04f - 0.04f * amount;
        }
    }
    pose.offsetX = 40.0f * (1.0f - pose.scaleX);
    pose.offsetY = 72.0f * (1.0f - pose.scaleY);
    return pose;
}

inline AttackPose GetIdlePose(float animTime)
{
    AttackPose pose;
    const float breath = 0.5f - 0.5f * std::cos(animTime * 6.28318530718f);
    pose.scaleX = 1.0f + 0.012f * breath;
    pose.scaleY = 1.0f - 0.020f * breath;
    // Squash around the body's ground contact instead of bobbing off the lawn.
    pose.offsetX = 40.0f * (1.0f - pose.scaleX);
    pose.offsetY = 72.0f * (1.0f - pose.scaleY);
    return pose;
}

inline AttackPose GetPlantPose(int cooldown, int glow, float animTime)
{
    return GetAttackPhase(cooldown, glow) == AttackPhase::Idle ? GetIdlePose(animTime) : GetAttackPose(cooldown, glow);
}

inline PartMotion GetIdlePartMotion(float animTime)
{
    PartMotion motion;
    // A little cap compression is visible at native size and never opens a seam.
    motion.capY = 0.4f * (1.0f - std::cos(animTime * 6.28318530718f));
    return motion;
}

constexpr PartMotion GetPartMotion(int cooldown, int glow)
{
    PartMotion motion;
    if (GetAttackPhase(cooldown, glow) == AttackPhase::Windup)
    {
        const float amount = Ease((kWindupTicks - cooldown) / static_cast<float>(kWindupTicks));
        motion.capY = 1.2f * amount;
    }
    else if (GetAttackPhase(cooldown, glow) == AttackPhase::Release)
    {
        const float progress = std::clamp(kPulseFrames - glow, 0, kRecoilTicks) / static_cast<float>(kRecoilTicks);
        if (progress < 0.4f)
        {
            const float amount = Ease(progress / 0.4f);
            motion.capY = 1.2f + 0.8f * amount;
        }
        else
        {
            const float amount = 1.0f - Ease((progress - 0.4f) / 0.6f);
            motion.capY = 2.0f * amount;
        }
    }
    return motion;
}

constexpr bool AdvancePulse(int& cooldown, int& glow, bool hasTarget)
{
    if (glow > 0) --glow;
    // Let the cooldown expire on an empty lawn, but reserve the wind-up for an
    // actual target. Recheck each tick so a departing target cancels the shot.
    if (!hasTarget && cooldown <= kReadyCountdown)
    {
        cooldown = kReadyCountdown;
        return false;
    }
    if (cooldown > 0) --cooldown;
    if (cooldown != 0) return false;
    cooldown = kPulseInterval;
    glow = kPulseFrames;
    return true;
}

struct FrostTuft
{
    float distance = 0.0f;
    float scale = 0.0f;
    int alpha = 0;
    int cel = 0;
};

constexpr FrostTuft GetFrostTuft(int glow, int index)
{
    FrostTuft tuft;
    if (index < 0 || index >= 12 || glow <= 0) return tuft;
    const int age = kPulseFrames - std::clamp(glow, 0, kPulseFrames);
    const int delay = (index % 3) * 6;
    const int localAge = age - delay;
    const int life = kPulseFrames - delay;
    if (localAge <= 0 || localAge >= life) return tuft;
    const float travel = Ease(std::clamp(localAge / 55.0f, 0.0f, 1.0f));
    const float fadeIn = std::clamp(localAge / 6.0f, 0.0f, 1.0f);
    const float fadeOut = 1.0f - Ease(std::clamp((localAge - 45.0f) / (life - 45.0f), 0.0f, 1.0f));
    tuft.distance = 12.0f + (kRadius - 12.0f) * travel;
    tuft.scale = 0.35f + 0.25f * Ease(std::clamp(localAge / 55.0f, 0.0f, 1.0f));
    tuft.alpha = static_cast<int>(160.0f * fadeIn * fadeOut);
    tuft.cel = std::min(5, localAge / 16);
    return tuft;
}
constexpr bool InRange(float dx, float dy)
{
    return dx * dx + dy * dy <= static_cast<float>(kRadius * kRadius);
}
static_assert(static_cast<int>(kSeed) == 75);
}
