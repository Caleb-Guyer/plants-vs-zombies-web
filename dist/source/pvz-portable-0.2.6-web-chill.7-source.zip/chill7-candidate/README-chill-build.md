# Chill.7 idle motion, target-aware attacks and native frost effect

This candidate begins with the exact published Chill.6 source ZIP, SHA-256
518d779b9948ac8a2d124db8f7929f13acf1121f38953d4ebee367518da17104.
The accepted whole-character proportions and Chill.6 painted finish remain the
art references. The approved original master SHA-256 is
f861148f8c57bbee31595e8fd5692aa23c1282172ab0016a159adf406f2a373d.
The inherited canonical paint RGBA SHA-256 is
4aed41439898a5f777b5ccefeb97c87a96bdd81f6b3b1ece0ac7541339378eae,
and approved canonical alpha SHA-256 is
0b1b28aa8d5489fe16a29e90c42fd1fb478bfca59a8544c9496306d825383e8e.

The requested changes are restrained idle movement, attack activation only for
eligible zombies in range, and a native-style frost effect with readable travel
and fade. The original shared 80x80 rig, centered packet/card compositions,
compatible IDs and saved-object layouts must remain. Exact current timing and
implementation are established by the current source and tests, not inherited
parent receipts. No standalone generated challenge illustration is added.

The source artwork, immutable generated inputs and exact historical prompts
remain in source/artwork/chill-shroom/. Its deterministic Pillow12.2.0 recipe
keeps every approved alpha byte and cap/body partition, and bounds expression
patches to the eyes. No separate per-part fitting is used. Native tint, filter,
flash, attachment and saved-phase behavior remain part of the rig contract.

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Native focused tests start no audio device. Browser testing uses ?testing=1.
Full upstream and Chill.6 delta patches must reconstruct every source byte.
All copied test/build receipts are historical until rerun for this candidate.
Tests and bounded muted review do not prove subjective perfection or exhaustive
original-game parity.
