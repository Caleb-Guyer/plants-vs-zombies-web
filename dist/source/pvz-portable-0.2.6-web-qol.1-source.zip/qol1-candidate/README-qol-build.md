# QoL.1 native engine build

This source retains PvZ-Portable 0.2.6 and the Software.10 renderer corrections,
and adds the requested native 1x/2x gameplay speed control beside Menu.

Use the existing Emscripten SDK and PowerShell recipe:

```powershell
python build-qol.py
python tests/test-game-speed.py
```

The build uses Release, `DO_FIX_BUGS=OFF`, `PVZ_DEBUG=OFF` and `LOW_MEMORY=OFF`.
The workspace recipe expects the SDK under `work/toolchain`; adjust that path
when building outside this workspace. No original game installation or assets
are needed to compile the engine. Runtime game data is distributed separately.

Before packaging, the build owner records `logs/source-before.json` and
`logs/source-after.json` as complete source-relative filename to SHA-256 maps.
`logs/build-result.json` must contain `exitCode: 0`,
`sourceUnchangedDuringBuild: true`, and an `outputs` map with byte counts and
SHA-256 values for `build/pvz-portable.js`, `build/pvz-portable.wasm`
and `build/ProjectVersion.h`. `build-qol.py` records these automatically.
The helper also verifies the actual CMake cache,
generated version header and focused test result rather than trusting labels.

After successful build and focused tests:

```powershell
python package-qol.py --test-result tests/game-speed-results.json
```

Relative CLI paths resolve from the current working directory. Run from this
candidate directory. The default `staging/` must not exist; packaging refuses
to overwrite prior outputs. It contains the engine artifacts and matching
source/provenance files for the release owner to review and copy into `dist/`.
Authenticated upstream and Software.10 source archives come from the sibling
`work/plants-vs-zombies-web-release/dist/source/` checkout; `--release-root`
overrides its location. Both generated patches are applied to temporary source
trees and every reconstructed source byte is compared before staging output.

The source archive includes the full current source, recipes, focused test
text/results, build receipt, source hash maps and generated version header.
It excludes compiled test programs, engine binaries, game assets,
private saves, credentials and Git metadata. Earlier Software.10 evidence stays
historical; this feature does not certify full original-game parity.
