# Chill.3 custom vector sprite revision

Chill-shroom has five original code-drawn vector sprite parts. Rounded dusty-blue
cap, cream/mint stem, simple eyes, organic base and matching half/closed blink
patches replace the previous Ice-shroom appearance. Original Ice-shroom remains
unchanged. Its native animation rig is reused; custom radial attack logic,
serialized plant/mode IDs, saved layouts and challenge rules are unchanged.

The three Bonus cards remain alpha-centered native sprite compositions. No
standalone image-generated challenge illustration is used. Source artwork is
editable in source/artwork/chill-shroom/design.py and recipe.json. render.py
exports the five SVG/PNG parts and their packed native pixel header using Pillow
12.2.0, 8x path sampling and native-size Lanczos reduction. No network/model is
used by that reproducible art pipeline. Runtime needs neither SVG nor PNG decode.

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Tests compile actual production methods without opening the game or audio device.
Build receipts pin every source byte before and after compilation. Authenticated
Chill.2/upstream source and full/delta patch reconstruction establish byte identity.
