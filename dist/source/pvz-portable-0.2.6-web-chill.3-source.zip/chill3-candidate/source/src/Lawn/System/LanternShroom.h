// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"

namespace Sexy { class Image; class Graphics; }
class Plant;
class Reanimation;

// Stored in existing Plant counters; native saved-object layouts stay unchanged.
namespace LanternShroom
{
Sexy::Image* GetImage();
void DisposeImage();
void BindParts(Reanimation& reanimation);
void BindCap(Reanimation& reanimation, int glow = 0);
void EnsurePlantReanimation(Plant& plant);
void ConfigureAttackAnimation(Plant& plant);
Sexy::Image* GetBonusImage(GameMode mode);
void DrawAttackPulse(Sexy::Graphics* graphics, const Plant& plant, float offsetY);
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY);

inline constexpr SeedType kSeed = SEED_LANTERNSHROOM;
inline constexpr int kCost = 75;
inline constexpr int kRecharge = 750;
inline constexpr int kPulseInterval = 400;
inline constexpr int kSlowDuration = 150;
inline constexpr int kRadius = 150;
inline constexpr int kPulseFrames = 30;
inline constexpr int kWindupTicks = 40;

enum class AttackPhase { Idle, Windup, Release };
struct AttackPose
{
    float scaleX = 1.0f;
    float scaleY = 1.0f;
    float offsetX = 0.0f;
    float offsetY = 0.0f;
};
constexpr AttackPhase GetAttackPhase(int cooldown, int glow)
{
    if (glow > 0) return AttackPhase::Release;
    if (cooldown > 0 && cooldown <= kWindupTicks) return AttackPhase::Windup;
    return AttackPhase::Idle;
}
constexpr float Ease(float value) { return value * value * (3.0f - 2.0f * value); }
constexpr AttackPose GetAttackPose(int cooldown, int glow)
{
    AttackPose pose;
    if (GetAttackPhase(cooldown, glow) == AttackPhase::Windup)
    {
        const float amount = Ease((kWindupTicks - cooldown) / static_cast<float>(kWindupTicks));
        pose.scaleX = 1.0f + 0.12f * amount;
        pose.scaleY = 1.0f - 0.25f * amount;
    }
    else if (GetAttackPhase(cooldown, glow) == AttackPhase::Release)
    {
        const int remaining = glow > kPulseFrames ? kPulseFrames : glow;
        const float progress = 1.0f - remaining / static_cast<float>(kPulseFrames);
        if (progress < 1.0f / 3.0f)
        {
            const float amount = Ease(progress * 3.0f);
            pose.scaleX = 1.12f - 0.16f * amount;
            pose.scaleY = 0.75f + 0.33f * amount;
        }
        else
        {
            const float amount = Ease((progress - 1.0f / 3.0f) * 1.5f);
            pose.scaleX = 0.96f + 0.04f * amount;
            pose.scaleY = 1.08f - 0.08f * amount;
        }
    }
    pose.offsetX = 40.0f * (1.0f - pose.scaleX);
    pose.offsetY = 72.0f * (1.0f - pose.scaleY);
    return pose;
}

constexpr bool AdvancePulse(int& cooldown, int& glow)
{
    if (glow > 0) --glow;
    if (cooldown > 0) --cooldown;
    if (cooldown != 0) return false;
    cooldown = kPulseInterval;
    glow = kPulseFrames;
    return true;
}
constexpr bool InRange(float dx, float dy)
{
    return dx * dx + dy * dy <= static_cast<float>(kRadius * kRadius);
}
static_assert(static_cast<int>(kSeed) == 75);
}
