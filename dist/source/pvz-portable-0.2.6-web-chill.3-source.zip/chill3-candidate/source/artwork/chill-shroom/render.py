"""Render the editable Chill-shroom vector recipe; requires Python and Pillow.

No model, network, downloaded illustration, or original game pixels are used.
The same paths export to SVG and rasterize at 8x before native-size reduction.
Usage: python render.py --output /path/to/public/art --header /path/to/ChillShroomArt.h
"""
import argparse
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image, ImageDraw, __version__ as PILLOW_VERSION

SCALE = 8
ROOT = Path(__file__).resolve().parent


def sampled(commands):
    points = []
    point = (0, 0)
    for command in commands:
        kind, *v = command
        if kind in ('M', 'L'):
            point = tuple(v)
            points.append(point)
        elif kind == 'C':
            start = point
            for i in range(1, 33):
                t = i / 32
                s = 1-t
                points.append((s**3*start[0]+3*s*s*t*v[0]+3*s*t*t*v[2]+t**3*v[4],
                               s**3*start[1]+3*s*s*t*v[1]+3*s*t*t*v[3]+t**3*v[5]))
            point = tuple(v[-2:])
        elif kind == 'Z':
            points.append(points[0])
        else:
            raise ValueError(kind)
    return [(round(x*SCALE), round(y*SCALE)) for x, y in points]


def render(part):
    w, h = part['size']
    result = Image.new('RGBA', (w*SCALE, h*SCALE))
    draw = ImageDraw.Draw(result)
    for shape in part['shapes']:
        points = sampled(shape['path'])
        if 'fill' in shape:
            draw.polygon(points, fill=shape['fill'])
        if 'stroke' in shape:
            width = round(shape.get('width', 1)*SCALE)
            draw.line(points, fill=shape['stroke'], width=width, joint='curve')
            radius = width/2
            for x, y in [points[0], points[-1]]:
                draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=shape['stroke'])
    result = result.resize((w, h), Image.Resampling.LANCZOS)
    if 'transparentFromY' in part:
        result.paste((0, 0, 0, 0), (0, part['transparentFromY'], w, h))
    return result


def svg(part, crop=False):
    root = ET.Element('svg', xmlns='http://www.w3.org/2000/svg',
                      width=str(part['size'][0]), height=str(part['size'][1]),
                      viewBox=f"0 0 {part['size'][0]} {part['size'][1]}")
    if crop:
        root.set('width', '33')
        root.set('height', '9')
        root.set('viewBox', '17 0 33 9')
    ET.SubElement(root, 'title').text = part['name'] + ' — editable code-drawn Chill-shroom artwork'
    for shape in part['shapes']:
        data = ' '.join(cmd[0] + ' '.join(map(str, cmd[1:])) for cmd in shape['path'])
        attrs = {'d': data, 'fill': shape.get('fill', 'none')}
        if 'stroke' in shape:
            attrs.update(stroke=shape['stroke'], **{'stroke-width': str(shape.get('width', 1)),
                         'stroke-linecap': 'round', 'stroke-linejoin': 'round'})
        ET.SubElement(root, 'path', attrs)
    return ET.tostring(root, encoding='unicode') + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--header', type=Path, required=True)
    parser.add_argument('--proof', type=Path)
    args = parser.parse_args()
    recipe_raw = (ROOT / 'recipe.json').read_bytes()
    recipe = json.loads(recipe_raw)
    parts = {}
    args.output.mkdir(parents=True, exist_ok=True)
    for key in ['cap', 'body', 'base']:
        part = recipe['parts'][key]
        parts[key] = render(part)
        (args.output / (key + '.svg')).write_text(svg(part), encoding='utf-8', newline='\n')
    for key, variant in [('blink1', 'halfEyes'), ('blink2', 'closedEyes')]:
        body = dict(recipe['parts']['body'])
        body['shapes'] = body['shapes'][:-len(recipe['openEyes'])] + recipe[variant]
        parts[key] = render(body).crop((17, 0, 50, 9))
        # Matching editable eye paths over the same body background.
        (args.output / (key + '.svg')).write_text(svg(body, crop=True), encoding='utf-8', newline='\n')
    header = ['// Code-drawn artwork. Regenerate with artwork/chill-shroom/render.py.',
              '// Straight ARGB; original game image data is not embedded here.',
              '#pragma once', '#include <cstdint>', 'namespace ChillShroomArt {']
    records = {}
    for key, img in parts.items():
        path = args.output / (key + '.png')
        img.save(path, optimize=False, compress_level=9)
        name = key[0].upper()+key[1:]
        rgba = img.tobytes()
        pixels = [(rgba[i+3] << 24) | (rgba[i] << 16) | (rgba[i+1] << 8) | rgba[i+2]
                  for i in range(0, len(rgba), 4)]
        header.extend([f'inline constexpr int k{name}Width = {img.width};',
                       f'inline constexpr int k{name}Height = {img.height};',
                       f'inline constexpr uint32_t k{name}Argb[] = {{'])
        for index in range(0, len(pixels), 10):
            header.append('    ' + ', '.join(f'0x{p:08x}u' for p in pixels[index:index+10]) + ',')
        header.append('};')
        records[key] = {'width': img.width, 'height': img.height,
                        'pngSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'rgbaSha256': hashlib.sha256(img.tobytes()).hexdigest()}
    header.append('}')
    args.header.parent.mkdir(parents=True, exist_ok=True)
    args.header.write_text('\n'.join(header)+'\n', encoding='utf-8', newline='\n')
    manifest = {'schema': 1, 'version': '0.2.6-web-chill.3',
                'method': 'Editable vector paths with deterministic Pillow rasterization',
                'pillowVersion': PILLOW_VERSION,
                'imageGenerationUsed': False, 'standaloneChallengeIllustrations': False,
                'recipeSha256': hashlib.sha256(recipe_raw).hexdigest(),
                'generatorSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'headerSha256': hashlib.sha256(args.header.read_bytes()).hexdigest(),
                'parts': records}
    (args.output / 'provenance.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8', newline='\n')
    # This proof sheet is not shipped or used as a challenge-card illustration.
    if args.proof:
        sheet = Image.new('RGBA', (100, 90), '#6f805e')
        # Idle frame4 native offsets and .8 image scale, in native draw order.
        for key, x, y in [('body', 13.7, 38.1), ('base', 8.5, 60.1), ('cap', -1.4, 1.5)]:
            img = parts[key]
            img = img.resize((round(img.width*.8), round(img.height*.8)), Image.Resampling.LANCZOS)
            sheet.alpha_composite(img, (round(x+10), round(y+4)))
        sheet.resize((400, 360), Image.Resampling.NEAREST).save(args.proof)
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
