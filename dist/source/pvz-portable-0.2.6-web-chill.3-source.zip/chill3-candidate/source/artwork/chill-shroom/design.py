"""Editable path design for Chill-shroom. Writes its canonical JSON recipe."""
import json
from pathlib import Path


def shape(path, fill=None, stroke=None, width=1):
    value = {'path': path}
    if fill:
        value['fill'] = fill
    if stroke:
        value.update(stroke=stroke, width=width)
    return value


def pill(x, y, w, h, color):
    r = w/2
    return shape([['M', x+r, y], ['C', x+w, y, x+w, y+1, x+w, y+h/2],
                  ['C', x+w, y+h, x+w, y+h, x+r, y+h],
                  ['C', x, y+h, x, y+h-1, x, y+h/2],
                  ['C', x, y, x, y, x+r, y], ['Z']], color)


outline = '#30433e'
cap = [
    shape([['M', 3, 34], ['C', 9, 29, 9, 24, 14, 19],
           ['C', 24, 6, 39, 2, 55, 3], ['C', 73, 1, 87, 12, 92, 24],
           ['C', 95, 29, 99, 31, 100, 35], ['C', 101, 39, 88, 43, 72, 44],
           ['C', 49, 47, 21, 43, 9, 40], ['C', 3, 39, 1, 37, 3, 34], ['Z']],
          '#527b89', '#253e46', 2.4),
    # Broad softly uneven dome and restrained upper-left lighting.
    shape([['M', 4, 34], ['C', 12, 26, 12, 19, 22, 13],
           ['C', 37, 0, 61, 1, 73, 8], ['C', 85, 14, 91, 25, 94, 32],
           ['C', 74, 37, 45, 36, 26, 36], ['C', 17, 37, 8, 38, 4, 34], ['Z']], '#80b4be'),
    shape([['M', 13, 27], ['C', 20, 12, 39, 5, 54, 6],
           ['C', 37, 8, 25, 17, 20, 28], ['C', 16, 31, 12, 31, 13, 27], ['Z']], '#a0cbd0'),
    shape([['M', 73, 10], ['C', 85, 16, 88, 26, 94, 32],
           ['C', 81, 36, 60, 37, 41, 35], ['C', 64, 34, 77, 28, 77, 21],
           ['C', 78, 17, 75, 12, 73, 10], ['Z']], '#68a0af'),
    # Three large irregular pale frost patches instead of crystal spikes.
    shape([['M', 28, 13], ['C', 25, 12, 25, 17, 22, 19],
           ['C', 19, 23, 22, 27, 27, 27], ['C', 30, 27, 31, 24, 36, 25],
           ['C', 42, 26, 44, 23, 41, 19], ['C', 40, 16, 34, 16, 33, 13],
           ['C', 32, 11, 30, 11, 28, 13], ['Z']], '#dce8d8'),
    shape([['M', 58, 10], ['C', 54, 10, 51, 13, 53, 16],
           ['C', 56, 18, 62, 17, 64, 19], ['C', 68, 23, 75, 23, 75, 19],
           ['C', 75, 16, 70, 16, 69, 13], ['C', 67, 10, 62, 10, 58, 10], ['Z']], '#d1e4d5'),
    shape([['M', 67, 28], ['C', 64, 29, 66, 32, 69, 32],
           ['C', 73, 33, 77, 31, 81, 32], ['C', 86, 32, 87, 29, 83, 27],
           ['C', 79, 26, 77, 28, 73, 27], ['C', 71, 27, 69, 27, 67, 28], ['Z']], '#c5dbd1'),
    # The drooping rim has a dark underside and three broad gill strokes.
    shape([['M', 9, 37], ['C', 35, 41, 71, 41, 95, 36]], None, '#37545f', 2.2),
    shape([['M', 33, 40], ['L', 32, 43]], None, '#34505b', 1.2),
    shape([['M', 51, 41], ['L', 51, 44]], None, '#34505b', 1.2),
    shape([['M', 71, 40], ['L', 72, 43]], None, '#34505b', 1.2),
]

body = [
    shape([['M', 11, -3], ['C', 22, -8, 47, -7, 55, -1],
           ['C', 54, 9, 52, 21, 59, 31], ['C', 63, 39, 51, 43, 34, 43],
           ['C', 18, 43, 5, 41, 6, 34], ['C', 8, 28, 13, 17, 11, -3], ['Z']],
          '#e2e1bf', outline, 2.2),
    shape([['M', 44, -3], ['C', 50, -4, 54, -1, 54, 2],
           ['C', 52, 13, 53, 26, 58, 32], ['C', 61, 38, 51, 41, 35, 41],
           ['C', 29, 40, 39, 37, 42, 33], ['C', 47, 25, 44, 7, 44, -3], ['Z']], '#9cb7a4'),
    shape([['M', 15, 9], ['C', 13, 22, 10, 30, 12, 34],
           ['C', 13, 38, 22, 38, 25, 35], ['C', 17, 33, 21, 21, 20, 11],
           ['C', 19, 8, 17, 8, 15, 9], ['Z']], '#f2eed2'),
    shape([['M', 19, 35], ['C', 25, 39, 40, 39, 46, 35]], None, '#bfc8aa', 1.1),
]
open_eyes = [pill(23, .6, 4.4, 7.8, '#283933'), pill(40, .4, 4.4, 7.8, '#283933'),
             pill(24.1, 1.2, .9, 2, '#f2f3db'), pill(41.1, 1, .9, 2, '#f2f3db')]
half_eyes = [pill(23, 4.1, 4.4, 4.1, '#283933'), pill(40, 3.9, 4.4, 4.1, '#283933'),
             shape([['M', 22, 4.2], ['L', 28, 4.2]], None, outline, 1),
             shape([['M', 39, 4], ['L', 45, 4]], None, outline, 1)]
closed_eyes = [shape([['M', 22.5, 5], ['C', 24, 6.2, 26.5, 6.2, 28, 4.8]], None, outline, 1.3),
               shape([['M', 39.5, 4.8], ['C', 41, 6, 43.5, 6, 45, 4.6]], None, outline, 1.3)]
base = [
    shape([['M', 6, 9], ['C', 15, 8, 18, 1, 30, 3],
           ['C', 43, -1, 53, 5, 61, 7], ['C', 69, 7, 73, 10, 70, 14],
           ['C', 67, 19, 55, 16, 46, 18], ['C', 32, 20, 23, 16, 12, 18],
           ['C', 3, 19, 1, 14, 6, 9], ['Z']], '#99b4a0', outline, 2),
    shape([['M', 9, 12], ['C', 22, 14, 23, 8, 34, 8],
           ['C', 46, 6, 55, 11, 65, 11], ['C', 58, 15, 46, 13, 37, 16],
           ['C', 25, 15, 14, 17, 9, 12], ['Z']], '#c4d3b4'),
]

recipe = {'schema': 1, 'design': 'Chill-shroom: low frosted umbrella, cream/mint stem, mouthless radial attacker',
          'imageGenerationUsed': False,
          'parts': {'cap': {'name': 'Cap', 'size': [103, 54], 'transparentFromY': 46, 'shapes': cap},
                    'body': {'name': 'Body', 'size': [66, 45], 'shapes': body+open_eyes},
                    'base': {'name': 'Base', 'size': [75, 21], 'shapes': base}},
          'openEyes': open_eyes, 'halfEyes': half_eyes, 'closedEyes': closed_eyes}
(Path(__file__).resolve().parent / 'recipe.json').write_text(json.dumps(recipe, indent=2)+'\n', encoding='utf-8', newline='\n')
