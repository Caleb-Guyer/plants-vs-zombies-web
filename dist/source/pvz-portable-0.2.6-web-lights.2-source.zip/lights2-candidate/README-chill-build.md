# Lights Out fog and glove-tooltip correction: source and tests

Exact published Lights.1 parent source SHA-256:
5f35953986e985af0de8a572fa8bac4657ceaaee42e6db1f9cd84b7c6d3d7b8e.
The parent archive has 26,618,089 bytes, 934 entries and 832 production files
under lights1-candidate/source/. Current source and recipes use lights2-candidate/.

Lights.2 changes only version metadata and Board.cpp. It removes the internal
rectangular crop from Lights Out fog, retaining the original fog sprites and
their transparent shaped edges. The native glove draws above fog in this mode,
and its native tooltip uses the actual glove button position. All other modes
retain their existing UI behavior. Rules, actors, waves, saved object layouts,
accepted artwork and all ten Bonus cards are unchanged.

Build the normal Release engine with build-chill.py. All eighteen native suites
remain release gates. The five silent complete-engine drivers link the same
124 normal production objects with test-only entry points. Lights Out retains
its 20-case/10-pair matrix and separate synthetic controls; those controls now
exercise natural fog edges at every lamp row in both original fog styles,
actual glove hover/tooltip raster and CPU software glove-over-fog composition.
The fourteen original Plantern/fog inputs include both graded-fog JPEGs.
Primary offscreen MemoryImage exports use graded fog assets to check layout;
they do not claim GPU or browser pixel equivalence. Browser rendering is checked
separately. Earned battles retain their legal input policy,
active-combat save/Continue, Retry, native awards and living-lamp/mower headroom
requirements. Test hardware opens no audio device; normal audio remains usable.

package-chill.py authenticates all source, build, test and artifact receipts.
web-lights.2.patch and lights1-to-lights2.patch reconstruct all 832 production
files byte-for-byte from upstream and the published immediate parent.
