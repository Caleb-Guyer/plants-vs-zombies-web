# Custom-content consistency: source and tests

Exact published Raid.4 parent source SHA-256:
8c068366dc208d692d0e5d7afd286cc4ec34312564e7f8a6deace562d59a5512.
The parent archive has 24,005,557 bytes, 920 entries and 828 production files
under raid4-candidate/source/. Current recipes and source use raid5-candidate/.

Raid.5 refreshes native zombie animation speed in Rally Raid as Rally movement
effects change. Rally Point already used this path. Only
CMake/ProjectVersion.cmake and Zombie.cpp differ from the parent: the release
identity and one UpdatePlaying mode guard. Plant rigs, artwork, native I, Zombie
rendering, authored challenges, economy, unlocks, IDs and saved layouts remain.

Build the normal Release engine with build-chill.py. Muted Care, Chain Reaction,
Rally Zombie and Rally Raid CLI drivers link the same production objects with
test-only entry points. All seventeen native reports and eight backend JS/WASM
artifacts remain required. The added custom-content controls supplement the
retained gameplay matrix; they do not replace winning runs or fabricate awards.
Real font/actor raster checks use the original assets. Test hardware opens no
audio device; normal game audio remains available.

package-chill.py authenticates source/build/test receipts and byte-exact
upstream/Raid.4 patch reconstruction. Patches are web-raid.5.patch and
raid4-to-raid5.patch. Site-source packaging preserves the pinned Rally.3 source
reference and authenticated inherited rendering-negative fixtures.
