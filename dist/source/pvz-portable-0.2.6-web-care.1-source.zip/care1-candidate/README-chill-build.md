# Intensive Lawn Care release

Starts from the exact published Mender.3 source archive, SHA-256
`5a6392e1d5415c3d7f5d3f2bad3114abb54a35bc13df5366be84b718c2d5bd1f`.
Its 816 source inputs use the mender3-candidate/source/ prefix.

Adds a conveyor minigame built around rotating wounded combat plants between a
protected Flower Pot recovery bed beside Mender-blooms and the front lines using
the native gardening glove. Its native challenge card composes existing game
sprites. Accepted Mender-bloom and Chill-shroom art remains byte-for-byte intact.
Existing game modes and serialized member layouts remain unchanged.

Run build-chill.py with the retained local Release Emscripten toolchain, then all
eleven tests/test-*.py production-method suites without launching game/audio.
package-chill.py authenticates exact source/build/test pins and reconstructs both
raw upstream and exact Mender.3 parent patches byte for byte. It stages binaries,
web-care.1.patch, mender3-to-care1.patch, corresponding source and provenance in a
fresh staging directory. The ZIP prefix is care1-candidate/.
Do not package before final source, build and test receipts are frozen.
