// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LanternShroom.h"
#include "ChillShroomArt.h"
#include "MenderBloom.h"
#include "../Plant.h"
#include "../SeedPacket.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../SexyAppFramework/graphics/MemoryImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/FilterEffect.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <memory>
#include <vector>

namespace LanternShroom
{
namespace
{
struct SpriteCache
{
    std::array<std::unique_ptr<Sexy::MemoryImage>, 6> parts;
    std::array<std::array<std::unique_ptr<Sexy::MemoryImage>, NUM_FILTER_EFFECTS>, 5> filtered;
    std::unique_ptr<Sexy::MemoryImage> preview;
    std::array<std::unique_ptr<Sexy::MemoryImage>, 6> bonus;
    const ReanimatorDefinition* definition = nullptr;
    std::array<int, 5> trackIndices = {-1, -1, -1, -1, -1};
};
SpriteCache& CachedSprite()
{
    static SpriteCache cache;
    return cache;
}

std::unique_ptr<Sexy::MemoryImage> MakePartImage(const uint32_t* argb, int width, int height)
{
    std::vector<uint32_t> pixels(argb, argb + width * height);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

const std::array<std::unique_ptr<Sexy::MemoryImage>, 6>& GetPartImages()
{
    static_assert(ChillShroomArt::kCapWidth == 80 && ChillShroomArt::kCapHeight == 80 &&
        ChillShroomArt::kBodyWidth == 80 && ChillShroomArt::kBodyHeight == 80 &&
        ChillShroomArt::kBaseWidth == 80 && ChillShroomArt::kBaseHeight == 80 &&
        ChillShroomArt::kBlink1Width == 80 && ChillShroomArt::kBlink1Height == 80 &&
        ChillShroomArt::kBlink2Width == 80 && ChillShroomArt::kBlink2Height == 80,
        "Chill-shroom parts share one registered canvas");
    SpriteCache& cache = CachedSprite();
    if (!cache.parts[0])
    {
        cache.parts[0] = MakePartImage(ChillShroomArt::kCapArgb, ChillShroomArt::kCapWidth, ChillShroomArt::kCapHeight);
        cache.parts[1] = MakePartImage(ChillShroomArt::kBodyArgb, ChillShroomArt::kBodyWidth, ChillShroomArt::kBodyHeight);
        cache.parts[2] = MakePartImage(ChillShroomArt::kBaseArgb, ChillShroomArt::kBaseWidth, ChillShroomArt::kBaseHeight);
        cache.parts[3] = MakePartImage(ChillShroomArt::kBlink1Argb, ChillShroomArt::kBlink1Width, ChillShroomArt::kBlink1Height);
        cache.parts[4] = MakePartImage(ChillShroomArt::kBlink2Argb, ChillShroomArt::kBlink2Width, ChillShroomArt::kBlink2Height);
        const uint32_t transparent = 0;
        cache.parts[5] = MakePartImage(&transparent, 1, 1);
        for (const int part : {0, 1, 3, 4})
            for (int filter = 0; filter < NUM_FILTER_EFFECTS; ++filter)
                cache.filtered[part][filter].reset(FilterEffectCreateImage(cache.parts[part].get(), static_cast<FilterEffect>(filter)));
    }
    return cache.parts;
}

int FindImageTrack(const Reanimation& reanimation, const char* name)
{
    for (int index = 0; index < reanimation.mDefinition->mTracks.count; ++index)
    {
        const ReanimatorTrack& track = reanimation.mDefinition->mTracks.tracks[index];
        if (std::strcmp(track.mName, name) != 0) continue;
        for (int frame = 0; frame < track.mTransforms.count; ++frame)
            if (track.mTransforms.mTransforms[frame].mImage) return index;
    }
    return -1;
}

const std::array<int, 5>& GetPartTrackIndices(const Reanimation& reanimation)
{
    SpriteCache& cache = CachedSprite();
    if (cache.definition != reanimation.mDefinition)
    {
        static constexpr const char* names[5] = {"IceShroom_head", "anim_face", "IceShroom_base", "anim_sleep", "anim_blink"};
        for (int index = 0; index < 5; ++index)
            cache.trackIndices[index] = FindImageTrack(reanimation, names[index]);
        cache.definition = reanimation.mDefinition;
    }
    return cache.trackIndices;
}

Sexy::Image* GetRigImage(int part, FilterEffect filter)
{
    const auto& images = GetPartImages();
    if (filter >= 0 && filter < NUM_FILTER_EFFECTS && CachedSprite().filtered[part][filter])
        return CachedSprite().filtered[part][filter].get();
    return images[part].get();
}

void DrawRigLayer(Sexy::Graphics* graphics, Reanimation& carrier, int part, float offsetX, float offsetY, float bodyAngle = 0.0f)
{
    Sexy::Image* image = GetRigImage(part, carrier.mFilterEffect);
    SexyMatrix3 local;
    const float sine = std::sin(bodyAngle), cosine = std::cos(bodyAngle);
    local.LoadIdentity();
    local.m00 = cosine;
    local.m10 = -sine;
    local.m01 = sine;
    local.m11 = cosine;
    // ReanimBltMatrix centers the 80px image. The local ground point is
    // (0,32), so this transform keeps (40,72) fixed before native scaling.
    local.m02 = 40.0f + cosine * offsetX + sine * (offsetY - 32.0f);
    local.m12 = 72.0f - sine * offsetX + cosine * (offsetY - 32.0f);
    SexyMatrix3 matrix;
    SexyMatrix3Multiply(matrix, carrier.mOverlayMatrix, local);
    SexyMatrix3Translation(matrix, graphics->mTransX, graphics->mTransY);
    Sexy::Color color = carrier.mColorOverride;
    if (graphics->GetColorizeImages()) color = ColorsMultiply(color, graphics->GetColor());
    if (color.mAlpha <= 0) return;
    const Sexy::Rect source(0, 0, image->GetWidth(), image->GetHeight());
    carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect, color, graphics->GetDrawMode(), source);
    if (carrier.mEnableExtraAdditiveDraw)
    {
        Sexy::Color additive = carrier.mExtraAdditiveColor;
        additive.mAlpha = ColorComponentMultiply(additive.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect, additive, Sexy::Graphics::DRAWMODE_ADDITIVE, source);
    }
    if (carrier.mEnableExtraOverlayDraw)
    {
        Sexy::Color overlay = carrier.mExtraOverlayColor;
        overlay.mAlpha = ColorComponentMultiply(overlay.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, GetRigImage(part, FILTER_EFFECT_WHITE), matrix, graphics->mClipRect,
            overlay, Sexy::Graphics::DRAWMODE_NORMAL, source);
    }
}

std::unique_ptr<Sexy::MemoryImage> MakeBlankImage(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect GetVisibleBounds(Sexy::MemoryImage& image)
{
    const int width = image.GetWidth(), height = image.GetHeight();
    const uint32_t* bits = image.GetBits();
    int left = width, top = height, right = -1, bottom = -1;
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
            if ((bits[y * width + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left || bottom < top ? Sexy::Rect(0, 0, 0, 0) :
        Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}

struct PortraitPlacement
{
    float x = 0.0f;
    float y = 0.0f;
    float scale = 0.0f;
};
PortraitPlacement GetPortraitPlacement(const Sexy::Rect& bounds)
{
    PortraitPlacement placement;
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return placement;
    placement.scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    placement.x = 40.0f - (bounds.mX + bounds.mWidth * 0.5f) * placement.scale;
    placement.y = 32.5f - (bounds.mY + bounds.mHeight * 0.5f) * placement.scale;
    return placement;
}

void DrawCenteredPortrait(Sexy::Graphics& graphics, Sexy::MemoryImage& image)
{
    const PortraitPlacement placement = GetPortraitPlacement(GetVisibleBounds(image));
    if (placement.scale > 0.0f)
        PvzpDrawImageScaledF(&graphics, &image, placement.x, placement.y, placement.scale, placement.scale);
}

std::unique_ptr<Sexy::MemoryImage> MakeCarePortrait()
{
    auto image = MakeBlankImage(120, 120);
    Sexy::Graphics graphics(image.get());
    graphics.SetLinearBlend(true);
    // The approved flower remains the centered hero. Original recovery-pot
    // and glove art make this card distinct without inventing an illustration.
    MenderBloom::DrawSprite(&graphics, 20.0f, 6.0f, 1.0f, 1.0f);
    auto potImage = MakeBlankImage(160, 160);
    Sexy::Graphics potGraphics(potImage.get());
    potGraphics.SetLinearBlend(true);
    Reanimation pot;
    pot.ReanimationInitializeType(40.0f, 30.0f, REANIM_FLOWER_POT);
    pot.SetFramesForLayer("anim_idle");
    pot.Draw(&potGraphics);
    const Sexy::Rect bounds = GetVisibleBounds(*potImage);
    if (bounds.mWidth > 0 && bounds.mHeight > 0)
    {
        const float scale = std::min(34.0f / bounds.mWidth, 28.0f / bounds.mHeight);
        PvzpDrawImageScaledF(&graphics, potImage.get(),
            16.0f - bounds.mX * scale, 64.0f - bounds.mY * scale, scale, scale);
    }
    if (Sexy::IMAGE_ZEN_GARDENGLOVE)
        PvzpDrawImageScaledF(&graphics, Sexy::IMAGE_ZEN_GARDENGLOVE, 76.0f, 56.0f, 0.42f, 0.42f);
    return image;
}

std::unique_ptr<Sexy::MemoryImage> MakeNativePortrait(GameMode mode)
{
    if (mode == GAMEMODE_CHALLENGE_INTENSIVE_CARE) return MakeCarePortrait();
    const bool cone = mode == GAMEMODE_CHALLENGE_CONE_ZONE;
    const bool garden = mode == GAMEMODE_CHALLENGE_GARDEN_SHUFFLE;
    const bool swap = mode == GAMEMODE_CHALLENGE_SEED_SWAP;
    auto image = MakeBlankImage(cone ? 200 : 120, cone ? 210 : 120);
    Sexy::Graphics graphics(image.get());
    graphics.SetLinearBlend(true);
    Reanimation native;
    native.ReanimationInitializeType(cone ? 40.0f : 20.0f, cone ? 40.0f : 20.0f,
        cone ? REANIM_ZOMBIE : garden ? REANIM_PEASHOOTER : swap ? REANIM_WALLNUT :
        mode == GAMEMODE_CHALLENGE_NIGHT_SHIFT ? REANIM_PUFFSHROOM : REANIM_ICESHROOM);
    native.SetFramesForLayer("anim_idle");
    if (cone)
    {
        Zombie::SetupReanimLayers(&native, ZOMBIE_TRAFFIC_CONE);
        native.AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
        native.AssignRenderGroupToPrefix("anim_head", RENDER_GROUP_NORMAL);
        native.AssignRenderGroupToPrefix("anim_cone", RENDER_GROUP_NORMAL);
    }
    else if (mode == GAMEMODE_CHALLENGE_LANTERN_GLOW)
    {
        BindParts(native);
        DrawRig(&graphics, native);
    }
    native.Draw(&graphics);
    if (garden)
    {
        // Peashooter uses the native body and head layers separately.
        native.SetFramesForLayer("anim_head_idle");
        native.Draw(&graphics);
    }
    if (garden && Sexy::IMAGE_ZEN_GARDENGLOVE)
    {
        // The original glove is a subordinate cue; the same bounds-based
        // centering used by the other cards fits the complete composition.
        PvzpDrawImageScaledF(&graphics, Sexy::IMAGE_ZEN_GARDENGLOVE, 73.0f, 68.0f, 0.55f, 0.55f);
    }
    if (swap)
    {
        // A native seed packet beside the Wall-nut shows the replacement choice.
        // Fit the full composition through the same visible-bounds placement.
        Sexy::Graphics packetGraphics(graphics);
        packetGraphics.SetScale(0.55f, 0.55f, 0.0f, 0.0f);
        DrawSeedPacket(&packetGraphics, 68.0f, 65.0f, SEED_REPEATER, SEED_NONE, 0.0f, 255, false, false);
    }
    return image;
}
}

void DisposeImage()
{
    SpriteCache& cache = CachedSprite();
    for (auto& image : cache.bonus) image.reset();
    cache.preview.reset();
    for (auto& part : cache.filtered)
        for (auto& image : part) image.reset();
    for (auto& image : cache.parts) image.reset();
    cache.definition = nullptr;
    cache.trackIndices.fill(-1);
}

void BindParts(Reanimation& reanimation)
{
    if (reanimation.mReanimationType != REANIM_ICESHROOM || !reanimation.mDefinition || !reanimation.mTrackInstances) return;
    const auto& images = GetPartImages();
    const auto& tracks = GetPartTrackIndices(reanimation);
    for (int part = 0; part < 5; ++part)
        if (tracks[part] >= 0)
        {
            Sexy::Image* image = images[5].get();
            ReanimatorTrackInstance& track = reanimation.mTrackInstances[tracks[part]];
            if (track.mImageOverride != image) track.mImageOverride = image;
            if (track.mShakeOverride == 0.0f)
                track.mShakeX = track.mShakeY = 0.0f;
        }
}

void BindCap(Reanimation& reanimation, int glow)
{
    (void)glow;
    BindParts(reanimation);
}

void BindPlantParts(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    if (Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID)) BindParts(*body);
    if (Reanimation* blink = plant.mApp->ReanimationTryToGet(plant.mBlinkReanimID)) BindParts(*blink);
}

BodyExpression GetPlantBodyExpression(const Plant& plant, Reanimation& carrier)
{
    if (plant.mIsAsleep || carrier.IsAnimPlaying("anim_sleep")) return BodyExpression::Closed;
    if (!plant.mApp) return BodyExpression::Auto;
    BodyExpression expression = BodyExpression::Auto;
    Reanimation* blink = plant.mApp->ReanimationTryToGet(plant.mBlinkReanimID);
    if (blink && !blink->mDead && blink->mLoopCount == 0)
    {
        ReanimatorFrameTime frame;
        blink->GetFrameTime(&frame);
        if (frame.mAnimFrameBeforeInt == 2) expression = BodyExpression::Closed;
        else if (frame.mAnimFrameBeforeInt == 1 || frame.mAnimFrameBeforeInt == 3) expression = BodyExpression::Half;
    }
    return expression;
}

void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, BodyExpression expression, const PartMotion& motion)
{
    if (carrier.mDead) return;
    const bool closed = expression == BodyExpression::Closed || carrier.IsAnimPlaying("anim_sleep");
    const int body = closed ? 4 : expression == BodyExpression::Half ? 3 : 1;
    DrawRigLayer(graphics, carrier, body, 0.0f, 0.0f, motion.bodyAngle);
    DrawRigLayer(graphics, carrier, 0, motion.capX, motion.capY, motion.bodyAngle);
}

void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    PartMotion motion;
    if (!plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE)
    {
        motion = GetPartMotion(plant.mStateCountdown, plant.mDoSpecialCountdown);
        if (GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown) == AttackPhase::Idle)
            motion = GetIdlePartMotion(carrier.mAnimTime);
    }
    DrawRig(graphics, carrier, GetPlantBodyExpression(plant, carrier), motion);
}

void ConfigureAttackAnimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body) return;
    const bool winding = !plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE &&
        GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown) == AttackPhase::Windup;
    const char* layer = plant.mIsAsleep || winding ? "anim_sleep" : "anim_idle";
    if (!body->IsAnimPlaying(layer)) body->PlayReanim(layer, REANIM_LOOP, 6, 12.0f);
    // The invisible carrier's native saved phase is also the breathing clock.
    // Reanimation advances by seconds * rate / frameCount, giving a calm loop
    // independent of how many frames the original idle layer contains.
    const bool breathing = !plant.mIsAsleep && !winding && plant.mOnBungeeState == NOT_ON_BUNGEE;
    body->mAnimRate = breathing ? std::max(1, body->mFrameCount) / kIdlePeriodSeconds : 12.0f;
    if (winding)
    {
        plant.EndBlink();
        plant.mBlinkCountdown = std::max(plant.mBlinkCountdown, kWindupTicks + 1);
    }
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (body && body->mReanimationType != REANIM_ICESHROOM)
    {
        // Upgrade the previous muzzle-bearing carrier, retaining the same plant.
        plant.EndBlink();
        plant.mApp->RemoveReanimation(plant.mBodyReanimID);
        plant.mBodyReanimID = REANIMATIONID_NULL;
        body = nullptr;
    }
    if (!body)
    {
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, plant.mSeedType, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0.0f, offsetY, plant.mRenderOrder + 1, REANIM_ICESHROOM);
        body->SetFramesForLayer(plant.mIsAsleep ? "anim_sleep" : "anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mAnimRate = 12.0f;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
        if (plant.mBlinkCountdown <= 0) plant.mBlinkCountdown = 400;
        if (!plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE)
        {
            const AttackPose pose = GetPlantPose(plant.mStateCountdown, plant.mDoSpecialCountdown, body->mAnimTime);
            body->SetPosition(pose.offsetX, offsetY + pose.offsetY);
            body->OverrideScale(pose.scaleX, pose.scaleY);
        }
    }
    ConfigureAttackAnimation(plant);
    if (!plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE &&
        plant.mWakeUpCounter == 0 && plant.mPottedPlantIndex == -1)
    {
        // Refresh older saved squash poses before the first paused draw.
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, plant.mSeedType, plant.mPlantCol, plant.mRow);
        const AttackPose pose = GetPlantPose(plant.mStateCountdown, plant.mDoSpecialCountdown, body->mAnimTime);
        body->SetPosition(plant.mShakeOffsetX + pose.offsetX, offsetY + pose.offsetY);
        body->OverrideScale(pose.scaleX, pose.scaleY);
    }
    BindPlantParts(plant);
}

Sexy::Image* GetImage()
{
    SpriteCache& cache = CachedSprite();
    if (cache.preview) return cache.preview.get();
    cache.preview = MakeNativePortrait(GAMEMODE_CHALLENGE_LANTERN_GLOW);
    return cache.preview.get();
}

Sexy::Image* GetBonusImage(GameMode mode)
{
    const int index = mode == GAMEMODE_CHALLENGE_CONE_ZONE ? 0 : mode == GAMEMODE_CHALLENGE_NIGHT_SHIFT ? 1 :
        mode == GAMEMODE_CHALLENGE_LANTERN_GLOW ? 2 : mode == GAMEMODE_CHALLENGE_GARDEN_SHUFFLE ? 3 :
        mode == GAMEMODE_CHALLENGE_SEED_SWAP ? 4 : mode == GAMEMODE_CHALLENGE_INTENSIVE_CARE ? 5 : -1;
    if (index < 0) return nullptr;
    SpriteCache& cache = CachedSprite();
    if (!cache.bonus[index])
    {
        const bool daytime = index == 0 || index == 3 || index == 4 || index == 5;
        if (!PvzpLoadResources(daytime ? "DelayLoad_Background1" : "DelayLoad_Background2")) return nullptr;
        Sexy::Image* background = daytime ? Sexy::IMAGE_BACKGROUND1 : Sexy::IMAGE_BACKGROUND2;
        if (!background) return nullptr;
        auto picture = MakeBlankImage(80, 65);
        Sexy::Graphics graphics(picture.get());
        graphics.SetLinearBlend(true);
        graphics.DrawImage(background, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
        auto portrait = MakeNativePortrait(mode);
        DrawCenteredPortrait(graphics, *portrait);
        cache.bonus[index] = std::move(picture);
    }
    return cache.bonus[index].get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* preview = GetImage())
        PvzpDrawImageScaledF(graphics, preview, x - 20.0f * scaleX, y - 20.0f * scaleY, scaleX, scaleY);
}

void DrawAttackPulse(Sexy::Graphics* graphics, const Plant& plant, float offsetY)
{
    if (plant.mDead || plant.mPlantHealth < 0 || plant.mSquished || plant.mIsAsleep || plant.mOnBungeeState != NOT_ON_BUNGEE) return;
    const AttackPhase phase = GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown);
    if (phase != AttackPhase::Windup && plant.mDoSpecialCountdown <= 0) return;
    Sexy::Graphics frost(*graphics);
    // Keep transient frost on the lawn, clear of the seed bank and menu.
    frost.ClipRect(-plant.mX, 80 - plant.mY, 800, 520);
    frost.SetColorizeImages(true);
    struct Direction { float x; float y; };
    static constexpr Direction directions[12] = {
        {1,0},{0.8660254f,0.5f},{0.5f,0.8660254f},{0,1},{-0.5f,0.8660254f},{-0.8660254f,0.5f},
        {-1,0},{-0.8660254f,-0.5f},{-0.5f,-0.8660254f},{0,-1},{0.5f,-0.8660254f},{0.8660254f,-0.5f}
    };
    const auto drawCel = [&frost](Sexy::Image* image, float centerX, float centerY, int cel, float scale)
    {
        if (!image) return;
        // This helper takes the unscaled cel's top-left even though its name
        // contains Center. Anchor every tuft to the actual radial origin.
        PvzpDrawImageCelCenterScaledF(&frost, image,
            centerX - image->GetCelWidth() * 0.5f, centerY - image->GetCelHeight() * 0.5f,
            cel, scale, scale);
    };
    if (phase == AttackPhase::Windup)
    {
        const float progress = (kWindupTicks - plant.mStateCountdown) / static_cast<float>(kWindupTicks);
        const float radius = 20.0f - 14.0f * progress;
        frost.SetColor(Sexy::Color(225, 245, 255, 50 + static_cast<int>(progress * 70.0f)));
        if (Sexy::IMAGE_SNOWFLAKES)
            for (int i = 0; i < 12; i += 3)
                drawCel(Sexy::IMAGE_SNOWFLAKES, 40.0f + directions[i].x * radius,
                    36.0f + offsetY + directions[i].y * radius * 0.65f, (i / 3) % 3, 0.35f);
        return;
    }
    // Native snowpea clouds carry the plume. Staggered emission, slower eased
    // travel and a long fade read as drifting frost rather than a fast ring of
    // snowflake icons. The existing radial chill remains a release-time pulse.
    for (int i = 0; i < 12; ++i)
    {
        const FrostTuft tuft = GetFrostTuft(plant.mDoSpecialCountdown, i);
        if (tuft.alpha <= 0) continue;
        const float centerX = 40.0f + directions[i].x * tuft.distance;
        const float centerY = 40.0f + offsetY + directions[i].y * tuft.distance;
        frost.SetColor(Sexy::Color(215, 240, 255, tuft.alpha));
        drawCel(Sexy::IMAGE_SNOWPEA_PUFF, centerX, centerY, tuft.cel, tuft.scale);
        if (i % 3 == 0)
        {
            frost.SetColor(Sexy::Color(230, 248, 255, tuft.alpha / 2));
            drawCel(Sexy::IMAGE_SNOWFLAKES, centerX, centerY, (i / 3) % 3, 0.30f);
        }
    }
}
}
