// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include "NightShift.h"
#include "LanternGlow.h"
#include "GardenShuffle.h"
#include "SeedSwap.h"
#include "IntensiveCare.h"
#include <array>
#include <cstddef>
#include <string_view>

// Stable content identity and native data for the first optional challenge.
// The mode owns an unused record in the existing 100-entry profile array;
// it never changes a saved object layout or an original challenge definition.
namespace BonusChallenge
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_CONE_ZONE;
inline constexpr std::string_view kId = "cone-zone";
inline constexpr int kRevision = 1;
inline constexpr int kStartingSun = 150;
inline constexpr int kWaveCount = 20;
inline constexpr int kLargestWave = 16;
inline constexpr std::array<SeedType, 6> kSeeds = {
    SEED_SUNFLOWER, SEED_PEASHOOTER, SEED_WALLNUT,
    SEED_POTATOMINE, SEED_SNOWPEA, SEED_CHERRYBOMB
};
inline constexpr std::array<ZombieType, 4> kPreviewZombies = {
    ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL
};

struct Wave
{
    int mNormal;
    int mCones;
    int mPoles;
    int mBuckets;
};

// A gentle first three waves leave time for sun production. Coneheads become
// the main threat; occasional poles and buckets reward layered defenses.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {1, 0, 0, 0}, {2, 0, 0, 0}, {3, 0, 0, 0}, {2, 1, 0, 0},
    {2, 2, 0, 0}, {2, 3, 0, 0}, {2, 3, 1, 0}, {2, 4, 0, 0},
    {2, 4, 0, 1}, {4, 5, 1, 1}, {2, 4, 0, 1}, {2, 5, 1, 0},
    {2, 4, 0, 2}, {2, 5, 1, 1}, {2, 5, 0, 2}, {2, 6, 1, 1},
    {2, 6, 0, 2}, {2, 5, 2, 2}, {2, 6, 0, 3}, {3, 7, 2, 3}
}};

constexpr bool IsMode(GameMode mode) { return mode == kMode || NightShift::IsMode(mode) || LanternGlow::IsMode(mode) || GardenShuffle::IsMode(mode) || SeedSwap::IsMode(mode) || IntensiveCare::IsMode(mode); }
constexpr bool IsFlagWave(int wave) { return wave >= 0 && wave < kWaveCount && (wave + 1) % 10 == 0; }
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    const Wave& entry = kWaves[wave];
    return entry.mNormal + entry.mCones + entry.mPoles + entry.mBuckets + (IsFlagWave(wave) ? 1 : 0);
}

// Fail before touching output when a caller lacks room for the terminator.
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const Wave& entry = kWaves[wave];
    int count = 0;
    if (IsFlagWave(wave)) output[count++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mNormal; ++i) output[count++] = ZOMBIE_NORMAL;
    for (int i = 0; i < entry.mCones; ++i) output[count++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mPoles; ++i) output[count++] = ZOMBIE_POLEVAULTER;
    for (int i = 0; i < entry.mBuckets; ++i) output[count++] = ZOMBIE_PAIL;
    return count;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output)
        for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}

template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_PAIL));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kPreviewZombies) output[zombie] = true;
}

template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}

// Shared routing keeps the original Cone Zone data and helpers unchanged.
constexpr int StartingSun(GameMode mode) { return IntensiveCare::IsMode(mode) ? 0 : SeedSwap::IsMode(mode) ? 0 : GardenShuffle::IsMode(mode) ? 0 : LanternGlow::IsMode(mode) ? LanternGlow::kStartingSun : NightShift::IsMode(mode) ? NightShift::kStartingSun : kStartingSun; }
constexpr int SeedCount(GameMode mode) { return IntensiveCare::IsMode(mode) ? IntensiveCare::kSeedCount : SeedSwap::IsMode(mode) ? 0 : GardenShuffle::IsMode(mode) ? 0 : static_cast<int>(LanternGlow::IsMode(mode) ? LanternGlow::kSeeds.size() : NightShift::IsMode(mode) ? NightShift::kSeeds.size() : kSeeds.size()); }

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(GameMode mode, ZombieType (&output)[Waves][Slots])
{
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::PopulateWaves(output);
    if (SeedSwap::IsMode(mode)) return SeedSwap::PopulateWaves(output);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::PopulateWaves(output);
    return LanternGlow::IsMode(mode) ? LanternGlow::PopulateWaves(output) : NightShift::IsMode(mode) ? NightShift::PopulateWaves(output) : PopulateWaves(output);
}

template<std::size_t Count>
void PopulateAllowedZombies(GameMode mode, bool (&output)[Count])
{
    if (IntensiveCare::IsMode(mode)) IntensiveCare::PopulateAllowedZombies(output);
    else if (SeedSwap::IsMode(mode)) SeedSwap::PopulateAllowedZombies(output);
    else if (GardenShuffle::IsMode(mode)) GardenShuffle::PopulateAllowedZombies(output);
    else if (LanternGlow::IsMode(mode)) LanternGlow::PopulateAllowedZombies(output);
    else if (NightShift::IsMode(mode)) NightShift::PopulateAllowedZombies(output);
    else PopulateAllowedZombies(output);
}

template<class Bank>
void FillSeedBank(GameMode mode, Bank& bank)
{
    if (IntensiveCare::IsMode(mode)) IntensiveCare::FillSeedBank(bank);
    else if (SeedSwap::IsMode(mode)) bank.mNumPackets = 0;
    else if (GardenShuffle::IsMode(mode)) bank.mNumPackets = 0;
    else if (LanternGlow::IsMode(mode)) LanternGlow::FillSeedBank(bank);
    else if (NightShift::IsMode(mode)) NightShift::FillSeedBank(bank);
    else FillSeedBank(bank);
}

static_assert(static_cast<int>(kMode) == 73);
// Revision 2 lives in existing serialized Challenge state. Old checkpoints use
// STATECHALLENGE_NORMAL and retain their original bank, waves and mechanics.
inline constexpr ChallengeState kArcadeState = static_cast<ChallengeState>(100);
inline constexpr ChallengeState kColdSetupState = static_cast<ChallengeState>(101);
inline constexpr ChallengeState kColdDefendState = static_cast<ChallengeState>(102);
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::IsCurrentRules(mode, state);
    if (SeedSwap::IsMode(mode)) return SeedSwap::IsCurrentRules(mode, state);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::IsCurrentRules(mode, state);
    return (mode == kMode || NightShift::IsMode(mode)) ? state == kArcadeState :
        LanternGlow::IsMode(mode) && (state == kColdSetupState || state == kColdDefendState);
}
constexpr bool IsConveyor(GameMode mode, ChallengeState state)
{
    return IntensiveCare::IsCurrentRules(mode, state) ||
        ((mode == kMode || NightShift::IsMode(mode)) && state == kArcadeState);
}
constexpr bool IsBowling(GameMode mode, ChallengeState state) { return mode == kMode && state == kArcadeState; }
constexpr bool IsSetup(GameMode mode, ChallengeState state) { return LanternGlow::IsMode(mode) && state == kColdSetupState; }
constexpr bool IsDefending(GameMode mode, ChallengeState state) { return LanternGlow::IsMode(mode) && state == kColdDefendState; }
constexpr int WaveCount(GameMode mode, ChallengeState state)
{
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::kWaveCount;
    if (SeedSwap::IsMode(mode)) return SeedSwap::kWaveCount;
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::kWaveCount;
    return IsCurrentRules(mode, state) ? (LanternGlow::IsMode(mode) ? LanternGlow::kPuzzleWaveCount : 10) : kWaveCount;
}
constexpr int StartingSun(GameMode mode, ChallengeState state)
{
    return IsCurrentRules(mode, state) ? (LanternGlow::IsMode(mode) ? LanternGlow::kPuzzleStartingSun : 0) : StartingSun(mode);
}
constexpr int SeedCount(GameMode mode, ChallengeState state)
{
    return IsConveyor(mode, state) ? 10 : SeedCount(mode);
}
// Cone Zone keeps each original zombie's movement, shield and special behavior.
// Their extra cone uses the native cone helmet damage and 370-point armor.
inline constexpr int kConeHelmHealth = 370;
constexpr bool IsConeHeadType(ZombieType type)
{
    return type == ZOMBIE_TRAFFIC_CONE || type == ZOMBIE_FLAG || type == ZOMBIE_DOOR ||
        type == ZOMBIE_NEWSPAPER || type == ZOMBIE_POLEVAULTER || type == ZOMBIE_LADDER ||
        type == ZOMBIE_JACK_IN_THE_BOX || type == ZOMBIE_FOOTBALL;
}
constexpr bool UsesAttachedCone(ZombieType type)
{
    return IsConeHeadType(type) && type != ZOMBIE_TRAFFIC_CONE && type != ZOMBIE_FLAG && type != ZOMBIE_DOOR;
}
inline constexpr std::array<SeedType, 5> kBowlingOpeningSeeds = {
    SEED_WALLNUT, SEED_WALLNUT, SEED_EXPLODE_O_NUT, SEED_WALLNUT, SEED_GIANT_WALLNUT
};
constexpr SeedType BowlingSeedForDelivery(int ordinal, SeedType weightedPick)
{
    return ordinal >= 0 && ordinal < static_cast<int>(kBowlingOpeningSeeds.size()) ? kBowlingOpeningSeeds[ordinal] :
        ordinal >= 0 && ordinal % 8 == 7 ? SEED_GIANT_WALLNUT : weightedPick;
}
inline constexpr std::array<ZombieType, 8> kMiniPreviewZombies = {
    ZOMBIE_TRAFFIC_CONE, ZOMBIE_DOOR, ZOMBIE_NEWSPAPER, ZOMBIE_POLEVAULTER,
    ZOMBIE_LADDER, ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_FOOTBALL, ZOMBIE_FLAG
};
struct MiniWave
{
    int mCones;
    int mDoors;
    int mNewspapers;
    int mPoles;
    int mLadders;
    int mJacks;
    int mFootball;
};
inline constexpr int kMiniWaveCount = 10;
inline constexpr int kMiniLargestWave = 15;
inline constexpr std::array<MiniWave, kMiniWaveCount> kMiniWaves = {{
    {2,0,0,0,0,0,0}, {3,1,0,0,0,0,0}, {3,1,1,0,0,0,0}, {3,1,1,1,0,0,0},
    {3,2,1,1,0,0,0}, {3,2,1,1,1,0,0}, {3,2,1,1,1,1,0}, {3,2,2,1,1,1,1},
    {4,3,2,1,1,1,1}, {5,3,2,1,1,1,1}
}};
constexpr bool MiniFlagWave(int wave) { return wave == kMiniWaveCount - 1; }
constexpr int MiniZombieCount(int wave)
{
    if (wave < 0 || wave >= kMiniWaveCount) return 0;
    const MiniWave& entry = kMiniWaves[wave];
    return entry.mCones + entry.mDoors + entry.mNewspapers + entry.mPoles + entry.mLadders +
        entry.mJacks + entry.mFootball + (MiniFlagWave(wave) ? 1 : 0);
}
constexpr int ComposeMiniWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kMiniWaveCount || !output || capacity <= MiniZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const MiniWave& entry = kMiniWaves[wave];
    int n = 0;
    if (MiniFlagWave(wave)) output[n++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mCones; ++i) output[n++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mDoors; ++i) output[n++] = ZOMBIE_DOOR;
    for (int i = 0; i < entry.mNewspapers; ++i) output[n++] = ZOMBIE_NEWSPAPER;
    for (int i = 0; i < entry.mPoles; ++i) output[n++] = ZOMBIE_POLEVAULTER;
    for (int i = 0; i < entry.mLadders; ++i) output[n++] = ZOMBIE_LADDER;
    for (int i = 0; i < entry.mJacks; ++i) output[n++] = ZOMBIE_JACK_IN_THE_BOX;
    for (int i = 0; i < entry.mFootball; ++i) output[n++] = ZOMBIE_FOOTBALL;
    return n;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateMiniWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kMiniWaveCount && Slots > kMiniLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kMiniWaveCount; ++i) ComposeMiniWave(i, output[i], static_cast<int>(Slots));
    return kMiniWaveCount;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(GameMode mode, ChallengeState state, ZombieType (&output)[Waves][Slots])
{
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::PopulateWaves(output);
    if (SeedSwap::IsMode(mode)) return SeedSwap::PopulateWaves(output);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::PopulateWaves(output);
    if (!IsCurrentRules(mode, state)) return PopulateWaves(mode, output);
    if (LanternGlow::IsMode(mode)) return LanternGlow::PopulatePuzzleWaves(output);
    if (NightShift::IsMode(mode)) return NightShift::PopulateMiniWaves(output);
    return PopulateMiniWaves(output);
}
template<std::size_t Count>
void PopulateAllowedZombies(GameMode mode, ChallengeState state, bool (&output)[Count])
{
    if (!IsBowling(mode, state)) { PopulateAllowedZombies(mode, output); return; }
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_JACK_IN_THE_BOX));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kMiniPreviewZombies) output[zombie] = true;
}
template<class Bank>
void FillSeedBank(GameMode mode, ChallengeState state, Bank& bank)
{
    if (IntensiveCare::IsMode(mode)) { IntensiveCare::FillSeedBank(bank); return; }
    if (SeedSwap::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (GardenShuffle::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (!IsCurrentRules(mode, state)) { FillSeedBank(mode, bank); return; }
    bank.mNumPackets = SeedCount(mode, state);
    if (IsConveyor(mode, state)) return;
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(LanternGlow::kPuzzleSeeds[i]);
    bank.RefreshAllPackets();
}
static_assert(MiniZombieCount(kMiniWaveCount - 1) == kMiniLargestWave);

static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
