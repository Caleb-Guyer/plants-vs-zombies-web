// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PlantDecksDialog.h"
#include "SeedChooserScreen.h"
#include "GameButton.h"
#include "../Board.h"
#include "../Plant.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../LawnCommon.h"
#include "widget/EditWidget.h"
#include "widget/WidgetManager.h"
#include "graphics/Font.h"
#include "graphics/Image.h"
#include <algorithm>
#include <format>

using namespace Sexy;

namespace
{
int WholeStoneWidth(int width, bool roundUp)
{
    const int caps = IMAGE_BUTTON_LEFT->mWidth + IMAGE_BUTTON_RIGHT->mWidth;
    const int tile = IMAGE_BUTTON_MIDDLE->mWidth;
    if (tile <= 0) return std::max(caps, width);
    const int extra = std::max(0, width - caps);
    return caps + ((extra + (roundUp ? tile - 1 : 0)) / tile) * tile;
}
}

PlantDecksDialog::PlantDecksDialog(LawnApp* app, SeedChooserScreen* chooser) :
    LawnDialog(app, DIALOG_ID, true, "Plant Decks", "", "Done", Dialog::BUTTONS_FOOTER),
    mChooser(chooser)
{
    mVerticalCenterText = false;
    mStoreWritable = mPresets.Load(app);
    mStatus = mStoreWritable ? "Choose a preset to save or load your plants." : "Saved decks could not be read. The file is preserved.";
    for (int i = 0; i < DeckPresets::SLOT_COUNT; ++i)
        mSlots[i] = MakeButton(200 + i, this, mPresets.mDecks[i].mName);
    mSaveButton = MakeButton(300, this, "Save");
    mLoadButton = MakeButton(301, this, "Load");
    mDeleteButton = MakeButton(302, this, "Delete");
    mNameEdit = CreateEditWidget(350, this, this);
    mNameEdit->mMaxChars = DeckPresets::MAX_NAME;
    mNameEdit->AddWidthCheckFont(FONT_BRIANNETOD16, 270);
    CalcSize(650 - mWidth, 550 - mHeight);
    if (chooser->mBoard->StageHasRoof()) mSelected = 3;
    else if (chooser->mBoard->StageHasPool()) mSelected = 2;
    else if (chooser->mBoard->StageIsNight()) mSelected = 1;
    SelectSlot(mSelected);
}

PlantDecksDialog::~PlantDecksDialog() = default;

void PlantDecksDialog::AddedToManager(WidgetManager* manager)
{
    LawnDialog::AddedToManager(manager);
    for (auto& button : mSlots) AddWidget(button.get());
    AddWidget(mSaveButton.get()); AddWidget(mLoadButton.get()); AddWidget(mDeleteButton.get()); AddWidget(mNameEdit.get());
    manager->SetFocus(this);
}

void PlantDecksDialog::RemovedFromManager(WidgetManager* manager)
{
    for (auto& button : mSlots) RemoveWidget(button.get());
    RemoveWidget(mSaveButton.get()); RemoveWidget(mLoadButton.get()); RemoveWidget(mDeleteButton.get()); RemoveWidget(mNameEdit.get());
    LawnDialog::RemovedFromManager(manager);
}

void PlantDecksDialog::Resize(int x, int y, int width, int height)
{
    LawnDialog::Resize(x, y, width, height);
    const int slotWidth = WholeStoneWidth(190, false);
    for (int i = 0; i < DeckPresets::SLOT_COUNT; ++i) mSlots[i]->Resize(36, 104 + i * 39, slotWidth, 36);
    mNameEdit->Resize(255, 116, mWidth - 305, 28);
    LawnStoneButton* actions[] = {mSaveButton.get(), mLoadButton.get(), mDeleteButton.get()};
    int actionWidths[3];
    int groupWidth = 14;
    for (int i = 0; i < 3; ++i)
    {
        actionWidths[i] = WholeStoneWidth(FONT_DWARVENTODCRAFT18GREENINSET->StringWidth(actions[i]->mLabel) + 20, true);
        groupWidth += actionWidths[i];
    }
    int actionX = 250 + (mWidth - 300 - groupWidth) / 2;
    for (int i = 0; i < 3; ++i)
    {
        actions[i]->Resize(actionX, 373, actionWidths[i], 38);
        actionX += actionWidths[i] + 7;
    }
    if (mLawnYesButton)
    {
        const int footerWidth = WholeStoneWidth(mLawnYesButton->mWidth, false);
        mLawnYesButton->Resize((mWidth - footerWidth) / 2, mLawnYesButton->mY, footerWidth, mLawnYesButton->mHeight);
    }
}

void PlantDecksDialog::SelectSlot(int slot)
{
    mSelected = slot;
    mNameEdit->SetText(mPresets.mDecks[slot].mName, true);
    RefreshButtons();
}

void PlantDecksDialog::RefreshButtons()
{
    for (int i = 0; i < DeckPresets::SLOT_COUNT; ++i)
    {
        const auto& deck = mPresets.mDecks[i];
        std::string label = std::format("{}. {}", i + 1, deck.mName);
        const int labelWidth = mSlots[i]->mWidth - 20;
        if (FONT_DWARVENTODCRAFT18GREENINSET->StringWidth(label) > labelWidth)
        {
            while (label.size() > 3 && FONT_DWARVENTODCRAFT18GREENINSET->StringWidth(label + "..") > labelWidth) label.pop_back();
            label += "..";
        }
        mSlots[i]->SetLabel(label);
        mSlots[i]->mInverted = i == mSelected;
    }
    const bool empty = mPresets.mDecks[mSelected].mSeeds.empty();
    mSaveButton->SetDisabled(!mStoreWritable);
    mLoadButton->SetDisabled(empty || !mStoreWritable);
    mDeleteButton->SetDisabled(empty || !mStoreWritable);
}

void PlantDecksDialog::Draw(Graphics* g)
{
    LawnDialog::Draw(g);
    DrawEditBox(g, mNameEdit.get());
    const auto& deck = mPresets.mDecks[mSelected];
    int unavailable = 0;
    for (size_t i = 0; i < deck.mSeeds.size(); ++i)
    {
        const auto& seed = deck.mSeeds[i];
        const bool allowed = mChooser->DeckSeedAvailable(seed);
        if (!allowed) ++unavailable;
        std::string name = Plant::GetNameString(static_cast<SeedType>(seed.mSeed), static_cast<SeedType>(seed.mImitater));
        if (name.size() > 20) name = name.substr(0, 18) + "..";
        if (!allowed) name = "! " + name;
        PvzpDrawString(g, name, 255 + static_cast<int>(i / 5) * 165, 166 + static_cast<int>(i % 5) * 29,
            FONT_BRIANNETOD12, allowed ? Color(224, 187, 98) : Color(255, 125, 105), DS_ALIGN_LEFT);
    }
    if (deck.mSeeds.empty())
        PvzpDrawString(g, "This preset is empty.", 255, 168, FONT_BRIANNETOD16, Color(224, 187, 98), DS_ALIGN_LEFT);
    PvzpDrawString(g, unavailable ? std::format("! {} unavailable on this level", unavailable) :
        std::format("{} saved plants", deck.mSeeds.size()), 255, 329, FONT_BRIANNETOD12, Color(224, 187, 98), DS_ALIGN_LEFT);
    PvzpDrawString(g, "Unavailable plants stay unselected.", 255, 351, FONT_BRIANNETOD12, Color(224, 187, 98), DS_ALIGN_LEFT);
    PvzpDrawString(g, mStatus, 255, 435, FONT_BRIANNETOD12, Color(224, 187, 98), DS_ALIGN_LEFT);
}

void PlantDecksDialog::ButtonDepress(int id)
{
    if (id >= 200 && id < 200 + DeckPresets::SLOT_COUNT)
    {
        SelectSlot(id - 200);
        return;
    }
    if (id == Dialog::ID_YES || id == Dialog::ID_NO)
    {
        mApp->KillDialog(mId);
        mApp->mWidgetManager->SetFocus(mChooser);
        return;
    }
    if (!mStoreWritable) return;
    auto& deck = mPresets.mDecks[mSelected];
    if (id == 300)
    {
        const auto seeds = mChooser->CurrentDeckPreset();
        const std::string name = DeckPresets::CleanName(mNameEdit->mString);
        if (name.empty()) { mStatus = "Enter a name for this preset."; return; }
        if (seeds.empty()) { mStatus = "Choose your plants before saving a deck."; return; }
        const auto previous = deck;
        deck = {name, seeds};
        if (mPresets.Save(mApp)) mStatus = "Your selected plants have been saved.";
        else { deck = previous; mStatus = "The deck could not be saved. Please retry."; }
    }
    else if (id == 301 && !deck.mSeeds.empty())
    {
        const auto result = mChooser->ApplyDeckPreset(deck.mSeeds);
        mStatus = std::format("Loaded {} plants; {} unavailable, {} no room.",
            result.mSeeds.size(), result.mUnavailable, result.mOverflow);
    }
    else if (id == 302 && !deck.mSeeds.empty())
    {
        const auto previous = deck;
        deck.mSeeds.clear();
        if (mPresets.Save(mApp)) mStatus = "The preset has been cleared.";
        else { deck = previous; mStatus = "The deck could not be cleared. Please retry."; }
    }
    RefreshButtons();
}

void PlantDecksDialog::KeyDown(KeyCode key)
{
    if (key == KEYCODE_ESCAPE) ButtonDepress(Dialog::ID_YES);
}

