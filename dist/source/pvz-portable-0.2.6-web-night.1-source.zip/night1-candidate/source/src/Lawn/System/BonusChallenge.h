// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include "NightShift.h"
#include <array>
#include <cstddef>
#include <string_view>

// Stable content identity and native data for the first optional challenge.
// The mode owns an unused record in the existing 100-entry profile array;
// it never changes a saved object layout or an original challenge definition.
namespace BonusChallenge
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_CONE_ZONE;
inline constexpr std::string_view kId = "cone-zone";
inline constexpr int kRevision = 1;
inline constexpr int kStartingSun = 150;
inline constexpr int kWaveCount = 20;
inline constexpr int kLargestWave = 16;
inline constexpr std::array<SeedType, 6> kSeeds = {
    SEED_SUNFLOWER, SEED_PEASHOOTER, SEED_WALLNUT,
    SEED_POTATOMINE, SEED_SNOWPEA, SEED_CHERRYBOMB
};
inline constexpr std::array<ZombieType, 4> kPreviewZombies = {
    ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL
};

struct Wave
{
    int mNormal;
    int mCones;
    int mPoles;
    int mBuckets;
};

// A gentle first three waves leave time for sun production. Coneheads become
// the main threat; occasional poles and buckets reward layered defenses.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {1, 0, 0, 0}, {2, 0, 0, 0}, {3, 0, 0, 0}, {2, 1, 0, 0},
    {2, 2, 0, 0}, {2, 3, 0, 0}, {2, 3, 1, 0}, {2, 4, 0, 0},
    {2, 4, 0, 1}, {4, 5, 1, 1}, {2, 4, 0, 1}, {2, 5, 1, 0},
    {2, 4, 0, 2}, {2, 5, 1, 1}, {2, 5, 0, 2}, {2, 6, 1, 1},
    {2, 6, 0, 2}, {2, 5, 2, 2}, {2, 6, 0, 3}, {3, 7, 2, 3}
}};

constexpr bool IsMode(GameMode mode) { return mode == kMode || NightShift::IsMode(mode); }
constexpr bool IsFlagWave(int wave) { return wave >= 0 && wave < kWaveCount && (wave + 1) % 10 == 0; }
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    const Wave& entry = kWaves[wave];
    return entry.mNormal + entry.mCones + entry.mPoles + entry.mBuckets + (IsFlagWave(wave) ? 1 : 0);
}

// Fail before touching output when a caller lacks room for the terminator.
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const Wave& entry = kWaves[wave];
    int count = 0;
    if (IsFlagWave(wave)) output[count++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mNormal; ++i) output[count++] = ZOMBIE_NORMAL;
    for (int i = 0; i < entry.mCones; ++i) output[count++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mPoles; ++i) output[count++] = ZOMBIE_POLEVAULTER;
    for (int i = 0; i < entry.mBuckets; ++i) output[count++] = ZOMBIE_PAIL;
    return count;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output)
        for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}

template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_PAIL));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kPreviewZombies) output[zombie] = true;
}

template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}

// Shared routing keeps the original Cone Zone data and helpers unchanged.
constexpr int StartingSun(GameMode mode) { return NightShift::IsMode(mode) ? NightShift::kStartingSun : kStartingSun; }
constexpr int SeedCount(GameMode mode) { return static_cast<int>(NightShift::IsMode(mode) ? NightShift::kSeeds.size() : kSeeds.size()); }

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(GameMode mode, ZombieType (&output)[Waves][Slots])
{
    return NightShift::IsMode(mode) ? NightShift::PopulateWaves(output) : PopulateWaves(output);
}

template<std::size_t Count>
void PopulateAllowedZombies(GameMode mode, bool (&output)[Count])
{
    if (NightShift::IsMode(mode)) NightShift::PopulateAllowedZombies(output);
    else PopulateAllowedZombies(output);
}

template<class Bank>
void FillSeedBank(GameMode mode, Bank& bank)
{
    if (NightShift::IsMode(mode)) NightShift::FillSeedBank(bank);
    else FillSeedBank(bank);
}

static_assert(static_cast<int>(kMode) == 73);
static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
