# Night Shift native build

Night.1 appends the optional Night Shift challenge to Polish.1. Existing modes,
Cone Zone, save layouts, controls, background save worker and artwork are retained.

Build with the existing local Emscripten toolchain:

    python build-night.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python package-night.py

All test runners accept --native for a host C++20 compiler and initialize no game
or audio device. Release flags are DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF.
The build recipe expects work/toolchain; configure SDK paths on another machine.
Packaging checks passing receipts against every current production source hash,
reconstructs full-upstream and incremental Polish.1 patches and compares all
source bytes. Each --output must name a new directory inside this candidate.
The source archive includes source, tests, recipes and receipts; it excludes game
resources, private saves, credentials, and compiled test executables.
