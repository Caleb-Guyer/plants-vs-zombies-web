# Rally Zombie

Exact published Chain.1 parent source SHA-256:
2794ff25f7427a2d3c1032bb9e2671f5b425701d7944d274f7c94e26ffb132a7.
820 production inputs under chain1-candidate/source/.

Build the normal Release browser engine with build-chill.py. The separate
silent complete-engine Care, Chain Reaction and Rally Zombie drivers link
the same production objects with test-only entry points. No combat model
fallback and no audio output are used. Run all sixteen suites after source
freezes. Full-engine execution requires authenticated assets via --asset-root.

package-chill.py authenticates current source/build/test receipts and exact
parent/upstream patch reconstruction before staging matching source and
binaries. Test recipes, drivers, executed reports and pinned test artifacts
are included in corresponding source under rally1-candidate/.
