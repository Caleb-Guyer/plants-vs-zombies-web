// SPDX-License-Identifier: LGPL-3.0-or-later
#include "RallyPresentation.h"
#include "RallyZombie.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/MemoryImage.h"
#include "misc/Point.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <initializer_list>
#include <memory>
#include <vector>

namespace RallyPresentation
{
namespace
{
constexpr std::array<const char*, 3> kArms = {
    "Zombie_outerarm_upper", "Zombie_outerarm_lower", "Zombie_outerarm_hand"};
// Only this private arm-only rig uses the group; it never enters saved state.
constexpr int kHandRenderGroup = 10;
struct Cache
{
    std::unique_ptr<Sexy::MemoryImage> horn;
    std::unique_ptr<Sexy::MemoryImage> card;
    std::unique_ptr<Reanimation> arms;
};
Cache& Images() { static Cache cache; return cache; }

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Image* Horn()
{
    Cache& cache = Images();
    if (cache.horn) return cache.horn.get();
    // Paint at three times the game resolution, then filter once. The muted
    // ivory, brick-red rim and uneven dark outlines share the native prop palette.
    auto large = Blank(180, 144);
    Sexy::Graphics g(large.get());
    const auto poly = [&g](Sexy::Color color, std::initializer_list<Sexy::Point> points)
    {
        std::vector<Sexy::Point> scaled;
        for (const auto& p : points) scaled.emplace_back(p.mX * 3, p.mY * 3);
        g.SetColor(color); g.PolyFill(scaled.data(), static_cast<int>(scaled.size()), true);
    };
    const Sexy::Color ink(48, 44, 32);
    // Handle, rear nozzle, flared housing and its warm underpaint.
    poly(ink, {{39,27},{49,28},{47,44},{40,45},{36,31}});
    poly(Sexy::Color(148,58,39), {{40,30},{46,30},{44,41},{41,42},{39,33}});
    poly(ink, {{47,17},{57,17},{59,20},{58,28},{48,29}});
    poly(Sexy::Color(164,73,49), {{49,19},{56,19},{56,26},{49,27}});
    poly(ink, {{13,4},{50,16},{53,21},{51,30},{15,42},{7,34},{7,13}});
    poly(Sexy::Color(189,173,124), {{15,7},{48,18},{50,22},{48,28},{16,39},{10,32},{10,15}});
    poly(Sexy::Color(227,215,167), {{16,8},{47,18},{49,22},{16,33},{10,29},{11,15}});
    poly(Sexy::Color(246,235,195), {{15,9},{45,18},{46,20},{17,25},{11,23},{12,15}});
    poly(Sexy::Color(162,145,96), {{17,33},{49,23},{48,28},{17,38},{12,32}});
    // Thick rounded red lip and dark interior. The facets deliberately avoid
    // a perfect geometric cone; the lower edge is heavier like native props.
    poly(ink, {{9,3},{14,3},{20,8},{22,18},{21,31},{17,41},{11,44},{6,41},{3,33},{2,19},{4,9}});
    poly(Sexy::Color(169,63,39), {{9,6},{13,6},{17,10},{19,20},{18,31},{15,39},{11,41},{8,38},{5,31},{5,19},{6,11}});
    poly(Sexy::Color(213,93,57), {{9,7},{13,7},{16,11},{17,20},{16,31},{13,37},{10,38},{7,30},{7,19},{8,11}});
    poly(Sexy::Color(238,159,107), {{9,8},{12,8},{14,12},{13,17},{10,15},{8,23},{7,20},{8,12}});
    poly(ink, {{10,11},{13,12},{15,20},{14,30},{12,36},{9,34},{7,27},{7,18}});
    poly(Sexy::Color(90,79,53), {{10,14},{12,15},{13,21},{12,30},{10,32},{9,26},{9,19}});
    poly(Sexy::Color(120,101,64), {{10,14},{12,16},{12,21},{10,23},{9,21}});
    // Two tiny scuffs break up the broad housing without noisy decoration.
    poly(Sexy::Color(250,239,199), {{29,15},{39,18},{36,19},{28,17}});
    poly(Sexy::Color(143,125,84), {{27,31},{32,29},{31,31},{27,33}});
    const uint32_t* source = large->GetBits();
    std::vector<uint32_t> pixels(60 * 48, 0);
    for (int y = 0; y < 48; ++y) for (int x = 0; x < 60; ++x)
    {
        unsigned alpha=0, red=0, green=0, blue=0;
        for (int dy=0;dy<3;++dy) for (int dx=0;dx<3;++dx)
        {
            const uint32_t p=source[(y*3+dy)*180+x*3+dx];
            const unsigned a=p>>24; alpha+=a;
            red+=((p>>16)&255)*a; green+=((p>>8)&255)*a; blue+=(p&255)*a;
        }
        if (alpha) pixels[y*60+x]=((alpha/9)<<24)|((red/alpha)<<16)|((green/alpha)<<8)|(blue/alpha);
    }
    cache.horn=std::make_unique<Sexy::MemoryImage>();
    cache.horn->SetBits(pixels.data(),60,48);
    return cache.horn.get();
}

Reanimation& ArmRig(Reanimation& carrier)
{
    Cache& cache=Images();
    if (!cache.arms)
    {
        cache.arms=std::make_unique<Reanimation>();
        cache.arms->ReanimationInitializeType(0,0,REANIM_ZOMBIE);
        cache.arms->AssignRenderGroupToPrefix("",RENDER_GROUP_HIDDEN);
    }
    Reanimation& arms=*cache.arms;
    arms.mOverlayMatrix=carrier.mOverlayMatrix;
    arms.mColorOverride=carrier.mColorOverride;
    arms.mExtraAdditiveColor=carrier.mExtraAdditiveColor;
    arms.mEnableExtraAdditiveDraw=carrier.mEnableExtraAdditiveDraw;
    arms.mExtraOverlayColor=carrier.mExtraOverlayColor;
    arms.mEnableExtraOverlayDraw=carrier.mEnableExtraOverlayDraw;
    arms.mFilterEffect=carrier.mFilterEffect;
    return arms;
}

Sexy::Rect Bounds(Sexy::MemoryImage& image)
{
    int left=image.GetWidth(),top=image.GetHeight(),right=-1,bottom=-1;
    const uint32_t* pixels=image.GetBits();
    for (int y=0;y<image.GetHeight();++y) for (int x=0;x<image.GetWidth();++x)
        if ((pixels[y*image.GetWidth()+x]>>24)>8)
        {left=std::min(left,x);top=std::min(top,y);right=std::max(right,x);bottom=std::max(bottom,y);}
    return right<left ? Sexy::Rect() : Sexy::Rect(left,top,right-left+1,bottom-top+1);
}
}

void PrepareRig(Reanimation& carrier)
{
    if (carrier.mReanimationType!=REANIM_ZOMBIE || !carrier.mDefinition || !carrier.mTrackInstances) return;
    for (const char* track : kArms) if (!carrier.TrackExists(track)) return;
    for (const char* track : kArms)
        carrier.AssignRenderGroupToTrack(track,RENDER_GROUP_HIDDEN);
}

void Initialize(Zombie& zombie)
{
    if (zombie.mZombieType!=ZOMBIE_RALLY || !zombie.mApp) return;
    if (Reanimation* body=zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID)) PrepareRig(*body);
}

void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, bool rallying,
    float progress, bool hasArm, bool hasObject)
{
    // Native burn and death effects can replace the body rig entirely. Their
    // original artwork draws as usual and has no surviving held prop to attach.
    if (carrier.mReanimationType!=REANIM_ZOMBIE || !carrier.mDefinition || !carrier.mTrackInstances) return;
    for (const char* track : kArms) if (!carrier.TrackExists(track)) return;
    Reanimation& arms=ArmRig(carrier);
    const float edge=std::min(std::clamp(progress,0.0f,1.0f)/0.15f,
        (1.0f-std::clamp(progress,0.0f,1.0f))/0.15f);
    float lift=rallying ? std::clamp(edge,0.0f,1.0f) : 0.0f;
    lift=lift*lift*(3.0f-2.0f*lift);
    if (lift>0.0f)
    {
        arms.SetFramesForLayer("anim_eat");
        arms.mAnimTime=0.20f+0.08f*std::sin(progress*25.132741f);
    }
    else
    {
        arms.mFrameStart=carrier.mFrameStart;
        arms.mFrameCount=carrier.mFrameCount;
        arms.mAnimTime=carrier.mAnimTime;
        arms.mLoopType=carrier.mLoopType;
    }
    for (int i=0;i<3;++i)
    {
        const int original=carrier.FindTrackIndex(kArms[i]);
        const int index=arms.FindTrackIndex(kArms[i]);
        auto& track=arms.mTrackInstances[index];
        track.mRenderGroup=(i==0 || hasArm) ?
            (i==2 ? kHandRenderGroup : RENDER_GROUP_NORMAL) : RENDER_GROUP_HIDDEN;
        carrier.GetCurrentTransform(original,&track.mBlendTransform);
        track.mBlendTime=100;
        track.mBlendCounter=lift>0 ? static_cast<int>((1.0f-lift)*100) : 0;
        track.mImageOverride=carrier.mTrackInstances[original].mImageOverride;
        track.mShakeX=0;
        track.mShakeY=i>0 ? lift*11.0f : 0.0f;
    }
    // The upper sleeve and original skin/hand pieces are the actual game's
    // drawing tracks, blended into its reaching pose rather than replacement art.
    arms.DrawRenderGroup(graphics,RENDER_GROUP_NORMAL);
    if (!hasArm) return;
    if (!hasObject)
    {
        arms.DrawRenderGroup(graphics,kHandRenderGroup);
        return;
    }
    SexyTransform2D hand;
    arms.GetTrackMatrix(arms.FindTrackIndex("Zombie_outerarm_hand"),hand);
    SexyMatrix3 local; local.LoadIdentity();
    local.m02=-12.0f; local.m12=-14.0f;
    SexyMatrix3 matrix;
    SexyMatrix3Multiply(matrix,hand,local);
    SexyMatrix3Translation(matrix,graphics->mTransX,graphics->mTransY);
    Sexy::Color color=carrier.mColorOverride;
    if (graphics->GetColorizeImages()) color=ColorsMultiply(color,graphics->GetColor());
    Sexy::Image* horn=Horn();
    carrier.ReanimBltMatrix(graphics,horn,matrix,graphics->mClipRect,color,
        graphics->GetDrawMode(),Sexy::Rect(0,0,60,48));
    if (carrier.mEnableExtraAdditiveDraw)
    {
        Sexy::Color additive=carrier.mExtraAdditiveColor;
        additive.mAlpha=ColorComponentMultiply(additive.mAlpha,color.mAlpha);
        carrier.ReanimBltMatrix(graphics,horn,matrix,graphics->mClipRect,additive,
            Sexy::Graphics::DRAWMODE_ADDITIVE,Sexy::Rect(0,0,60,48));
    }
    // The native fingers overlap the handle, so the prop is held in the hand
    // rather than pasted across it. Each part is drawn only once even on fades.
    arms.DrawRenderGroup(graphics,kHandRenderGroup);
}

void Draw(Zombie& zombie, Sexy::Graphics* graphics, const ZombieDrawPosition&)
{
    if (zombie.mZombieType!=ZOMBIE_RALLY || !zombie.mApp) return;
    // Normal burns kill this carrier and create a separate charred effect;
    // mowing also substitutes another rig. A live headless burned actor keeps
    // its native black arm/stub, but cannot keep the megaphone below.
    if (zombie.mDead || zombie.mZombiePhase==PHASE_ZOMBIE_MOWERED ||
        zombie.mMoweredReanimID!=ReanimationID::REANIMATIONID_NULL) return;
    if (Reanimation* body=zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID))
        DrawRig(graphics,*body,RallyZombie::IsRallying(zombie),
            (RallyZombie::kCallTicks-zombie.mSummonCounter)/static_cast<float>(RallyZombie::kCallTicks),
            zombie.mHasArm,zombie.mHasObject && zombie.mHasHead &&
                zombie.mZombiePhase==PHASE_ZOMBIE_NORMAL);
}

Sexy::Image* GetBonusImage()
{
    Cache& cache=Images();
    if (cache.card) return cache.card.get();
    if (!PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1) return nullptr;
    auto portrait=Blank(240,230);
    Sexy::Graphics native(portrait.get()); native.SetLinearBlend(true);
    Reanimation body;
    body.ReanimationInitializeType(90,45,REANIM_ZOMBIE);
    body.SetFramesForLayer("anim_idle");
    Zombie::SetupReanimLayers(&body,ZOMBIE_RALLY);
    PrepareRig(body);
    body.Draw(&native); DrawRig(&native,body,true,0.45f);
    const Sexy::Rect bounds=Bounds(*portrait);
    auto card=Blank(80,65);
    Sexy::Graphics picture(card.get()); picture.SetLinearBlend(true);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1,Sexy::Rect(0,0,80,65),Sexy::Rect(400,140,480,390));
    if (bounds.mWidth>0 && bounds.mHeight>0)
    {
        const float scale=std::min(68.0f/bounds.mWidth,57.0f/bounds.mHeight);
        PvzpDrawImageScaledF(&picture,portrait.get(),40-(bounds.mX+bounds.mWidth*.5f)*scale,
            32.5f-(bounds.mY+bounds.mHeight*.5f)*scale,scale,scale);
    }
    cache.card=std::move(card);
    return cache.card.get();
}

void DisposeImage()
{
    Cache& cache=Images(); cache.card.reset(); cache.horn.reset(); cache.arms.reset();
}
}
