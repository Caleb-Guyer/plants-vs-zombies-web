# Mender.3 distinct blossom artwork revision

Starts from the exact published Mender.2 source archive, SHA-256
`2d40f382100860e1f64e3475ee2e0b299875df5458e488099b226c19a3d6ee24`.
Its 810 source inputs use the mender2-candidate/source/ prefix.

This revision gives Mender-bloom a distinct coral cupped-blossom head and its own
expression after the Sunflower-like face was rejected. The original stem/leaf
assembly is retained. No mechanics, animation timing, Almanac or chooser layout,
unlock rules, Chill-shroom art, challenge cards or serialized data are changed.
Built-in image generation is scoped to the new Mender-bloom head only; source
masters, prompts and extraction records accompany the corresponding source.

Run build-chill.py with the retained local Release Emscripten toolchain, then all
ten tests/test-*.py production-method suites without launching game/audio output.
package-chill.py authenticates exact source/build/test pins and reconstructs both
raw upstream and exact Mender.2 parent patches byte for byte. It stages binaries,
web-mender.3.patch, mender2-to-mender3.patch, corresponding source and provenance
in a fresh staging directory. The ZIP prefix is mender3-candidate/.
Do not run packaging before the final source, build and test receipts are frozen.
