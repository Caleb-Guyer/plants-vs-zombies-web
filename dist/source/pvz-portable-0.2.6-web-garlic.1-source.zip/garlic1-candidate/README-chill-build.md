# Garlic Run: source and native tests

Exact published Lights.2 parent source SHA-256:
030d6dac37fbb4eca15ec4a852e2904ac6993ff598d824c7ef8a092804b6d26a.
Parent: 26,630,296 bytes, 934 entries, 832 production files under lights2-candidate/source/.
Current archive prefix: garlic1-candidate/. Current source: 836 files.

Garlic Run appends mode83, profile record82 and the eleventh Bonus card without
changing serialized actor layouts or prior mode IDs. Five fixed day-lawn puzzles
use original Garlic diversions/health, Spikeweed damage and Potato Mine arming.
The native glove moves Garlic; the native Let's Rock button starts each board.
Planning freezes enemy movement and mine fuses while normal plant rigs animate.
No shooters, sun, seed bank, mowers, rakes or generated challenge artwork are added.

Build normal Release with build-chill.py. All nineteen native suites remain
release gates. Six silent complete-engine drivers link all 126 normal production
objects except main. Garlic Run's 24 cases cover two seeds at1x/2x: sixteen primary
five-board wins, four additional full native replays, four unattended losses and
four isolated controls. These execute actual native inputs, attacks, health,
diversions, mine fuses, active/planning saves, Retry, Pause and final awards.
Fifty-one original artwork inputs authenticate the card, plants, glove and font.
Offscreen MemoryImage visual exports do not claim browser/GPU equivalence;
muted browser inspection is separate. Test hardware opens no audio device.
Normal game audio remains available.

package-chill.py verifies source/build/test receipts. web-garlic.1.patch and
lights2-to-garlic1.patch reconstruct all836 production files byte-for-byte from
upstream and the exact published immediate parent. Previous regressions remain
mandatory, including Lights Out natural fog, glove hover/pixels and I,Zombie UI.
