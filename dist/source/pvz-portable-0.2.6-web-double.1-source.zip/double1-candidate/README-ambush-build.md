# Vase Ambush native build

This corresponding source adds five reverse Vasebreaker puzzles to the published
Scrap.1 engine. Original Vasebreaker hammer/vases and I, Zombie cardboard plants,
brains, combat and stock zombie statistics supply gameplay and presentation.
No saved object layouts are changed. The new mode is89 and profile record88.

Build the normal Release engine with `python build-chill.py` using the pinned
local Emscripten recipe in `build-candidate.ps1`. The source, normal receipt,
objects, all25 current native reports and exact linked test artifacts are bound
by the staged build provenance. Native automation disables audio output.

The shared lossless CLI artifact pack is decoded without external dependencies
by `python unpack-native-artifacts.py`; it restores the exact24 current JS/WASM
files and the two separately authenticated historical comparator files.
Current native tests rerun their original cases on the current production
objects. Parent scripts/contracts are retained separately and compatibility
adaptations are documented in the retained test adapters. Synthetic controls
and checkpoints are labeled and do not count as earned wins.

Only package a frozen passing source with `python package-ambush.py --output
<new staging directory>`. Browser checks and public deployment are separate;
native raster observations do not establish GPU completion or full game parity.
