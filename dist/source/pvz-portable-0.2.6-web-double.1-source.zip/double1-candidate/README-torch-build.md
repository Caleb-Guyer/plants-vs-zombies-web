# Torchbearer native build

This source adds Torchbearer Zombie and the finite Fire Drill introduction to
the published Ambush.1 engine. The torch uses the original flag-carrier arm,
closed hand and shaft, with original Torchwood flame animation. Fire Drill is
mode90, Bonus card18 and profile record89. Completing it unlocks the new enemy
in later Pool Panic Endless formations. Original saved object layouts remain.

Build the normal Release engine with `python build-chill.py`, using the pinned
local Emscripten recipe in `build-candidate.ps1`. The normal receipt freezes all
868 production source files and142 non-main objects. The release requires all
26 suites:13 retained focused suites,12 retained complete-engine suites and the
combined60-case Torchbearer/Fire Drill driver. Synthetic controls are separately
labeled and do not count as playable wins. Native automation disables audio.

The included standard-library decoder, `python unpack-native-artifacts.py`,
restores26 current JavaScript/WebAssembly test files and two explicitly
historical comparator files. Parent recipes, contracts and fixtures remain
authenticated by the166-input published Ambush.1 snapshot. Current native tests
execute their retained cases against this release; old wins are not reused.

Only package a frozen passing source with `python package-torch.py --output
<new staging directory>`. The packager authenticates the current source,
normal artifacts, all26 reports, complete case matrices, exact test binaries,
native art inputs and reconstructable full/incremental patches before staging.
Browser tests, balance observations and public deployment are separate records.
Native raster checks do not establish GPU parity or exhaustive game equivalence.
