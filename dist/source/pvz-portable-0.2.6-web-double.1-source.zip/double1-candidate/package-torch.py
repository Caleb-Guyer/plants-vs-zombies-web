"""Stage authenticated Torch.1 source/binaries after all26 native suites pass.

Only a new staging directory is published. Candidate executables stay raw and
unchanged; their downloadable copies use the shared lossless artifact codec.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, shutil, sys, tempfile, zipfile

ROOT=Path(__file__).resolve().parent
VERSION='0.2.6-web-torch.1'
PARENT_SHA='6da0b6e19d56b3b345a684d379453abecff055a6d788cc17bd161f412bf3e7c9'
SOURCE_NAME=f'pvz-portable-{VERSION}-source.zip'
FULL_PATCH='web-torch.1.patch';DELTA_PATCH='ambush1-to-torch1.patch'
FOCUSED=['game-speed','qol-controls','decks-cooldowns','bonus-challenge','bonus-completion',
 'night-shift','lantern-shroom','garden-shuffle','seed-swap','mender-bloom','intensive-care','native-layout','care-fatigue']
ENGINES=['care-full-run','chain-reaction','rally-zombie','rally-raid','lights-out','garlic-run',
 'bungee-business','cob-cannon-command','pool-panic','pool-panic-endless','scrap-yard','vase-ambush','torchbearer']
ADDED={'src/Lawn/System/TorchbearerZombie.h','src/Lawn/System/TorchbearerZombie.cpp',
 'src/Lawn/System/TorchbearerPresentation.h','src/Lawn/System/TorchbearerPresentation.cpp',
 'src/Lawn/System/FireDrill.h','src/Lawn/System/FireDrill.cpp',
 'src/Lawn/System/FireDrillPresentation.h','src/Lawn/System/FireDrillPresentation.cpp'}
CHANGED={'CMake/ProjectVersion.cmake','src/ConstEnums.h','src/Lawn/Board.cpp','src/Lawn/Challenge.cpp',
 'src/Lawn/Challenge.h','src/Lawn/Zombie.cpp','src/Lawn/System/BonusChallenge.h',
 'src/Lawn/System/PoolPanicEndless.h','src/Lawn/System/PoolPanicEndless.cpp',
 'src/Lawn/System/ReanimationLawn.cpp','src/Lawn/Widget/AlmanacDialog.h',
 'src/Lawn/Widget/AlmanacDialog.cpp','src/Lawn/Widget/ChallengeScreen.cpp','src/LawnApp.cpp'}
PARENT_INPUTS_SHA='011d5162458ab4523ecee51048e9d2d70e7d98a6806f8b9efcc50cecd98e57a6'

def module(name,filename):
 spec=importlib.util.spec_from_file_location(name,ROOT/filename)
 result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
helpers=module('scrap_packaging_helpers','package-chill.py')
require=helpers.require;digest=helpers.digest;record=helpers.record
read_json=helpers.read_json;json_bytes=helpers.json_bytes;safe_name=helpers.safe_name

def log_pins(value):
 pins=set()
 if isinstance(value,dict):
  for key,item in value.items():
   if key=='logSha256' and isinstance(item,str):pins.add(item)
   else:pins.update(log_pins(item))
 elif isinstance(value,list):
  for item in value:pins.update(log_pins(item))
 return pins

def explicit_care_default_link(normal_bytes):
 receipt_path=ROOT/'tests/care-full-run-build.json';receipt=read_json(receipt_path)
 require(receipt['optimization']=='O2' and receipt['productionBuildReceiptSha256']==digest(normal_bytes),
  'Current Care link must explicitly record its executed normal O2 branch')
 builder=(ROOT/'tests/build-care-full-run.py').read_bytes()
 require(digest(builder)==receipt['builderSha256'] and
  "'-O1' if args.quick else '-O2'" in builder.decode('utf-8'), 'Actual Care builder/optimization branch changed')
 return {'explicitReceipt':True,'effectiveOptimization':'O2','builderSha256':digest(builder),
  'receipt':{'path':'tests/care-full-run-build.json',**record(receipt_path.read_bytes())}}

def validate_reports(source,normal_bytes,care_proof):
 reports={};paths=[];objects=None
 hashes={'source/'+name:digest(data) for name,data in source.items()}
 for name in FOCUSED+ENGINES:
  path=ROOT/'tests'/f'{name}-results.json';report=read_json(path)
  require(str(report.get('status','')).startswith('PASS') and report.get('failures')==0 and
   report.get('exitCode')==0 and isinstance(report.get('checks'),int) and report['checks']>0,
   'Native suite has not actually passed: '+name)
  require(report.get('sourceSha256') and all(hashes.get(key)==pin for key,pin in report['sourceSha256'].items()),
   'Native suite is stale against the current source: '+name)
  require(digest((ROOT/'tests'/f'{name}-harness.cpp').read_bytes())==report['generatedHarnessSha256'],
   'Native suite harness changed: '+name)
  for fixture,pin in report.get('fixturesSha256',{}).items():
   require(digest((ROOT/'tests'/safe_name(fixture)).read_bytes())==pin,'Native fixture changed: '+fixture)
  if name in ENGINES:
   # Every current complete-engine driver explicitly records its executed O2
   # branch, including the retained Care builder's added receipt field.
   optimization_ok=report.get('optimization')=='O2'
   require(report.get('execution')=='complete-production-engine' and optimization_ok and
    report.get('productionObjectCount')==142 and len(report['productionObjectSha256'])==142 and
    report['sourceSha256']==hashes and report['productionBuildReceiptSha256']==digest(normal_bytes),
    'Complete native engine is not bound to the868/142 normal build: '+name)
   if objects is None:objects=report['productionObjectSha256']
   require(report['productionObjectSha256']==objects,'Current native suites link different production objects')
   for field,filename in [('builderSha256',f'build-{name}.py'),('runnerSha256',f'test-{name}.py')]:
    require(digest((ROOT/'tests'/filename).read_bytes())==report[field],'Native recipe changed: '+filename)
   for filename,pin in report['testArtifactSha256'].items():
    require(digest((ROOT/'tests'/safe_name(filename)).read_bytes())==pin,'Native executable changed: '+filename)
   # These retained-only invocations authenticate the complete case matrices,
   # raw logs, native outcomes, artwork, save ledgers and unchanged policies.
   helpers.checked([sys.executable,ROOT/'tests'/f'test-{name}.py'],cwd=ROOT)
  reports[name]=report;paths.append(path)
 require(len(reports)==26,'Exactly26 current native suites are required')
 endless=reports['pool-panic-endless']
 require(not endless.get('basePrefixReuse') and endless['lateGame']['earnedFlagCount']==48 and
  endless['lateGame']['syntheticEarnedFlagCount']==0,'All retained Endless32+28 cases must execute freshly')
 require(len(endless['scenarios'])==24 and len(endless['openingCorpus'])==8,'Retained Endless32 case set missing')
 require(len(reports['scrap-yard']['scenarios'])==18,'All18 Scrap Yard cases are required')
 require(len(reports['vase-ambush']['scenarios'])==30,'All30 Vase Ambush cases are required')
 require(len(reports['torchbearer']['scenarios'])==60,'All60 Torchbearer cases are required')
 return reports,paths

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--release-root',type=Path,default=ROOT.parents[1]/'plants-vs-zombies-web-release')
 parser.add_argument('--output',type=Path,default=ROOT/'staging-torch-final')
 args=parser.parse_args();output=args.output.resolve();release=args.release_root.resolve()
 require(output.is_relative_to(ROOT) and output!=ROOT and not output.exists(),'Output must be a NEW candidate staging directory')
 source=helpers.source_tree(ROOT/'source');require(len(source)==868,'Expected868 production source files')
 hashes={name:digest(data) for name,data in source.items()}
 normal_path=ROOT/'logs/build-result.json';normal_bytes=normal_path.read_bytes();normal=json.loads(normal_bytes)
 require(normal.get('status')=='PASS' and normal.get('exitCode')==0 and normal.get('sourceUnchangedDuringBuild') is True and
  normal.get('sourceFiles')==868,'Passing unchanged normal868-source build required')
 for name in ['source-before.json','source-after.json']:
  require(read_json(ROOT/'logs'/name)==hashes,'Normal build source snapshot differs')
 cache={}
 for line in (ROOT/'build/CMakeCache.txt').read_text(encoding='utf-8').splitlines():
  if not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
   key,value=line.split('=',1);cache[key.split(':',1)[0]]=value
 require(all(cache.get(key)==value for key,value in helpers.FLAGS.items()),'Unexpected normal Release build flags')
 require(Path(cache['CMAKE_HOME_DIRECTORY']).resolve()==(ROOT/'source').resolve(),'Foreign normal build source directory')
 artifacts={}
 for name in ['pvz-portable.js','pvz-portable.wasm','ProjectVersion.h']:
  data=(ROOT/'build'/name).read_bytes();pin=record(data);expected=normal['outputs']['build/'+name]
  require(pin['bytes']==expected['bytes'] and pin['sha256']==expected['sha256'],'Normal artifact changed: '+name)
  artifacts[name]=pin
 require(VERSION.encode() in source['CMake/ProjectVersion.cmake'] and VERSION.encode() in
  (ROOT/'build/ProjectVersion.h').read_bytes(),'Source and compiled Torchbearer version differ')
 care_proof=explicit_care_default_link(normal_bytes)
 reports,report_paths=validate_reports(source,normal_bytes,care_proof)
 historical_paths,historical=helpers.historical_comparison_inputs(release)
 require(len(historical_paths)==2,'Both separately authenticated .2 comparator files are required')
 parent_path=release/'dist/source/pvz-portable-0.2.6-web-ambush.1-source.zip'
 parent=helpers.archive_source(parent_path,PARENT_SHA,'ambush1-candidate/source/',860)
 snapshot_raw=(ROOT/'tests/torch1-retained-parent/manifest.json').read_bytes()
 require(digest(snapshot_raw)==PARENT_INPUTS_SHA,'Published parent-input inventory changed')
 snapshot=json.loads(snapshot_raw)
 require(snapshot['parentEngineId']=='0.2.6-web-ambush.1' and snapshot['parentArchiveSha256']==PARENT_SHA and
  len(snapshot['files'])==166,'Exactly166 authenticated published Ambush test inputs are required')
 with zipfile.ZipFile(parent_path) as archive:
  for name,pin in snapshot['files'].items():
   require(safe_name(name)==name and '/' not in name,'Parent input must have a safe flat name')
   original=archive.read(pin['publishedArchivePath'])
   require(pin['publishedArchivePath']=='ambush1-candidate/tests/'+name and
    len(original)==pin['bytes'] and digest(original)==pin['sha256'] and
    (ROOT/'tests/torch1-retained-parent'/name).read_bytes()==original,'Published parent input changed: '+name)
  historical_test_names={name.removeprefix('ambush1-candidate/') for name in archive.namelist()
   if name.startswith('ambush1-candidate/tests/') and not name.endswith('/')}
 require(set(parent)<set(source) and set(source)-set(parent)==ADDED,'Production additions exceed the eight reviewed Torchbearer/Fire Drill files')
 require({name for name in parent if parent[name]!=source[name]}==CHANGED,'Production changes exceed the fourteen reviewed integration paths')
 parent_raw=(ROOT/'parent-engine-provenance.json').read_bytes();parent_manifest=json.loads(parent_raw)
 require(parent_manifest['id']=='0.2.6-web-ambush.1' and parent_manifest['artifacts']['sourceSha256']==PARENT_SHA,'Wrong immediate parent metadata')
 upstream=helpers.archive_source(release/'dist/source/pvz-portable-0.2.6-source.zip',helpers.UPSTREAM_SHA,'PvZ-Portable-0.2.6/',753)
 full_patch,full_changes=helpers.make_patch(upstream,source);delta_patch,delta_changes=helpers.make_patch(parent,source)
 patch_checks={'upstream':helpers.reconstruct(upstream,full_patch,source),'ambush1':helpers.reconstruct(parent,delta_patch,source)}
 codec=module('scrap_native_codec','pack-native-artifacts.py')
 packed,metadata_bytes,native_names=codec.pack(ROOT/'tests');metadata=json.loads(metadata_bytes)
 expected={name+'-engine'+suffix for name in ENGINES+['endless3-parent'] for suffix in ['.js','.wasm']}
 require(native_names==expected and len(native_names)==28,'Expected26 current and2 historical executable files')
 # Select complete test evidence. Temporary compiler/cache trees and objects are
 # excluded; all fixed contracts, original failures, logs and native saves stay.
 tests={}
 accepted_log_pins=log_pins(reports)
 fixed_evidence_logs={'tests/vase-ambush-development-first-failure.log':
  '5cb399d538939b66b998ead38b342ea7cf95b23ddc003b542932b9d7d07d54fd'}
 # A new contract may preserve a failing development log as an explicit input.
 # Such a log is evidence, never a passing playable scenario.
 torch_contract=read_json(ROOT/'tests/torchbearer-verification-contract.json')
 fixed_evidence_inputs={}
 for relative,pin in torch_contract.get('fixtureSha256',{}).items():
  safe_name(relative)
  require(relative.startswith('tests/') and digest((ROOT/relative).read_bytes())==pin,
   'Contract-bound native input changed: '+relative)
  fixed_evidence_inputs[relative]=pin
  if Path(relative).suffix=='.log':
   require(relative not in fixed_evidence_logs or fixed_evidence_logs[relative]==pin,
    'Conflicting historical evidence pin: '+relative)
   fixed_evidence_logs[relative]=pin
 # Pre-game seed scans deliberately have no per-row log hash in the historical
 # report schema. Preserve only their explicitly reported, independently
 # checked raw observations as well as the hash-pinned gameplay cases.
 scan_names=set()
 for index,sample in enumerate(reports['pool-panic-endless']['openingCorpusSeedScan']):
  require(sample['seed']==100+index and sample['preGameSeedOnly'] is True,'Opening seed-scan identity changed')
  name=f"tests/pool-panic-endless-logs/variation-probe-1x-{sample['seed']}.log"
  lines=(ROOT/name).read_text(encoding='utf-8').splitlines();prefix='POOL_PANIC_ENDLESS_RESULT '
  rows=[json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
  require(len(rows)==1 and rows[0].get('execution')=='pre-game-variation-scan' and
   all(rows[0].get(key)==value for key,value in sample.items()),'Opening seed-scan differs from raw native output')
  scan_names.add(name)
 for path in sorted((ROOT/'tests').rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(ROOT).as_posix()
  if relative in fixed_evidence_logs:
   require(digest(path.read_bytes())==fixed_evidence_logs[relative], 'Frozen initial native failure changed')
  focused_retention=relative.startswith(('tests/scrap1-focused-retention/','tests/scrap1-packaging-evidence/','tests/ambush1-focused-retention/','tests/ambush1-retained-parent/','tests/torch1-focused-retention/','tests/torch1-retained-parent/'))
  require(path.suffix.lower()!='.pak','Private packed game assets cannot enter corresponding source')
  if any(part in {'__pycache__','node_modules'} for part in path.relative_to(ROOT/'tests').parts):continue
  # Focused suites rebuild their small harnesses. Only the complete-engine
  # executable set belongs in the prelinked pack; do not duplicate compiler
  # outputs from earlier focused/development runs in corresponding source.
  if path.name in native_names or path.suffix.lower() in {'.js','.wasm','.o','.obj','.a','.lib','.pyc','.tmp','.exe','.dll','.pdb','.so','.dylib'} or path.name.endswith('-harness-native'):continue
  if path.name in helpers.DEVELOPMENT_ONLY_TEST_FILES:continue
  # The published historical evidence remains available. Newly generated raw
  # logs must be referenced by an actual passing report; exploratory failures
  # remain private rather than being swept into the source download.
  if not focused_retention and relative not in historical_test_names and relative not in scan_names and relative not in fixed_evidence_logs and path.suffix=='.log' and digest(path.read_bytes()) not in accepted_log_pins:continue
  if not focused_retention and relative not in historical_test_names and relative not in fixed_evidence_inputs and path.name.endswith('-build.json') and path.name not in {name+'-build.json' for name in FOCUSED+ENGINES}:continue
  require(not path.is_symlink(),'Test evidence symlinks are not supported')
  tests[relative]=path.read_bytes()
 for relative,pin in fixed_evidence_inputs.items():
  require(relative in tests and digest(tests[relative])==pin,
   'Corresponding source omits or changes a final-contract input: '+relative)
 tests['tests/native-artifacts.xz']=packed;tests['tests/native-artifacts.json']=metadata_bytes
 recipes=['build-candidate.ps1','build-chill.py','package-chill.py','package-ambush.py','package-torch.py','pack-native-artifacts.py',
  'unpack-native-artifacts.py','README-torch-build.md','README-ambush-build.md','README-chill-build.md','parent-engine-provenance.json','parent-source-pin.json']
 recipe_inputs={name:(ROOT/name).read_bytes() for name in recipes}
 members={'source/'+name:data for name,data in source.items()};members.update(tests);members.update(recipe_inputs)
 require(not any(Path(name).suffix.lower() in {'.pak','.exe','.dll','.so','.dylib'} for name in members),
  'Corresponding source contains a private game archive or host binary')
 for name in ['logs/build-result.json','logs/source-before.json','logs/source-after.json','build/ProjectVersion.h']:
  members[name]=(ROOT/name).read_bytes()
 members['source-manifest.json']=json_bytes({'version':VERSION,'files':{name:record(data) for name,data in source.items()}})
 # Validate the shipped decoder using only its staged data, then compare every
 # restored file to the untouched original candidate executable.
 with tempfile.TemporaryDirectory(prefix='ambush-codec-check-',dir=ROOT) as temporary:
  folder=Path(temporary);(folder/'tests').mkdir();(folder/'tests/native-artifacts.xz').write_bytes(packed)
  (folder/'tests/native-artifacts.json').write_bytes(metadata_bytes)
  helpers.checked([sys.executable,ROOT/'unpack-native-artifacts.py','--root',folder])
  require(all((folder/'tests'/name).read_bytes()==(ROOT/'tests'/name).read_bytes() for name in native_names),
   'Lossless native executable reconstruction differs')
 require(helpers.source_tree(ROOT/'source')==source,'Source changed during packaging validation')
 require(all((ROOT/name).read_bytes()==data for name,data in recipe_inputs.items()),'Recipe changed during packaging validation')
 # All26 suites and every validation above have passed before final output exists.
 output.mkdir();(output/'game').mkdir();(output/'source').mkdir()
 for name in ['pvz-portable.js','pvz-portable.wasm']:shutil.copyfile(ROOT/'build'/name,output/'game'/name)
 (output/'source'/FULL_PATCH).write_bytes(full_patch);(output/'source'/DELTA_PATCH).write_bytes(delta_patch)
 archive_path=output/'source'/SOURCE_NAME;prefix='torch1-candidate/'
 with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,data in sorted(members.items()):
   safe_name(name);info=zipfile.ZipInfo(prefix+name,date_time=(2026,11,10,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   info.create_system=3;info.external_attr=0o100644<<16;archive.writestr(info,data)
 with zipfile.ZipFile(archive_path) as archive:
  require(archive.testzip() is None and len(archive.namelist())==len(members),'Invalid corresponding-source ZIP')
  require(all(archive.read(prefix+name)==data for name,data in members.items()),'Corresponding-source archive byte mismatch')
 source_record={'path':SOURCE_NAME,**record(archive_path.read_bytes()),'entries':len(members),'uncompressedBytes':sum(map(len,members.values()))}
 packing={'format':metadata['format'],'rawFiles':28,'currentFiles':26,'historicalFiles':2,
  'metadata':{'path':'tests/native-artifacts.json',**record(metadata_bytes)},'archive':{'path':'tests/native-artifacts.xz',**record(packed)},
  'decoder':{'path':'unpack-native-artifacts.py',**record(recipe_inputs['unpack-native-artifacts.py'])},
  'rawBytes':metadata['rawBytes'],'rawSha256':metadata['rawSha256']}
 checks=sum(report['checks'] for report in reports.values());late=reports['pool-panic-endless']['lateGame']['checks']
 limits=['Torchbearer Zombie carries one native-art torch: frost extinguishes it permanently; an uninterrupted native-target windup consumes one edible plant and spends it. Fire Drill introduces the actor with six finite authored formations; winning unlocks later Pool Panic Endless torch formations. Existing saved object layouts, original actors and the eighteen-card native UI are retained.',
  'Synthetic controls and developer checkpoints do not count as earned progress. Native raster tests are not GPU/browser parity proof. Muted browser validation and public deployment are recorded separately. Full original-game parity remains unverified.']
 provenance={'id':VERSION,'upstream':parent_manifest['upstream'],'sourceArchive':source_record,
  'artifacts':[{'path':'build/'+name,**pin} for name,pin in artifacts.items()],
  'sourceFiles':868,'sourceBytes':sum(map(len,source.values())),'sourceDeltaVsAmbush1':delta_changes,
  'compiledVersionHeader':(ROOT/'build/ProjectVersion.h').read_text(encoding='utf-8'),'nativeArtifactPacking':packing,
  'checks':{'ExplicitCareOptimization':care_proof,'fullRelease':{'exitCode':0,'flags':helpers.FLAGS,'sourceUnchangedDuringBuild':True,
    'receipt':{'path':'logs/build-result.json',**record(normal_bytes)}},
   'focusedNativeTests':{'status':'PASS26 native suites','failures':0,'checks':checks,'lateChecks':late,'totalChecksWithLate':checks+late,
    'scope':'13 focused native production suites and13 current complete-engine suites; all retained32base+28late Endless cases freshly executed; audio output disabled.',
    'endlessBasePrefixReuse':{'performed':False},'reports':[{'path':p.relative_to(ROOT).as_posix(),**record(p.read_bytes()),'checks':reports[p.name.removesuffix('-results.json')]['checks']} for p in report_paths]},
   'patchReconstruction':patch_checks,'historicalComparison':historical},
  'combinedPatch':{'path':FULL_PATCH,**record(full_patch),'sourcePaths':len(full_changes)},
  'incrementalPatch':{'path':DELTA_PATCH,**record(delta_patch),'sourcePaths':len(delta_changes)},
  'parent':{'id':parent_manifest['id'],'sourceArchiveSha256':PARENT_SHA,'releaseManifestSha256':digest(parent_raw)},'limits':limits}
 engine={'id':VERSION,'upstream':parent_manifest['upstream'],'artifacts':{'jsSha256':artifacts['pvz-portable.js']['sha256'],
  'wasmSha256':artifacts['pvz-portable.wasm']['sha256'],'source':'../source/'+SOURCE_NAME,'sourceSha256':source_record['sha256'],
  'patch':'../source/'+FULL_PATCH,'patchSha256':digest(full_patch)},'buildRecord':'../source/build-provenance.json',
  'change':'Adds Torchbearer Zombie, an original-art one-use fire attacker, the finite Fire Drill introduction and earned Pool Panic Endless torch formations. Native combat, prior modes, original artwork and saved layouts remain preserved outside the reviewed additions.',
  'caption':'with Torchbearer Zombie and Fire Drill.','gameAssetsIncluded':parent_manifest['gameAssetsIncluded'],
  'assetManifest':parent_manifest['assetManifest'],'assetBundleId':parent_manifest['assetBundleId'],
  'parent':parent_manifest,'parentScope':'Historical Ambush.1 release metadata; current results are recorded separately.','limits':limits}
 (output/'source/build-provenance.json').write_bytes(json_bytes(provenance));(output/'game/engine-provenance.json').write_bytes(json_bytes(engine))
 require(helpers.source_tree(ROOT/'source')==source,'Source changed while writing staged artifacts')
 print(json.dumps({'status':'PASS staged Torch.1 source/binaries/provenance','staging':str(output),'sourceArchive':source_record,
  'sourceFiles':868,'nativeSuites':26,'nativeArtifactPacking':packing,'changedSourcePaths':[x['path'] for x in delta_changes]},indent=2))

if __name__=='__main__':main()
