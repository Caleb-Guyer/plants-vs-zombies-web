# Pool Panic Endless.2: source and native tests

Exact published Endless.1 parent source SHA-256:
eee4ae6dfeaaa49bbf203c37cf45ad73dad56b85d3d0079e549ed11bc3d45f25.
Parent:39,931,636 bytes,1009 entries,852 production files under
endless1-candidate/source/. Current archive prefix:endless2-candidate/.
Current production retains852 files; nine reviewed paths change.

Endless.2 reworks mode87/profile record86 around persistent original defenses:
Repeater, Threepeater, Tall-nut, Torchwood, Spikeweed and Lily Pad, with
occasional Squash, Tangle Kelp, Cherry Bomb and Jalapeno. Six opening packets
provide construction time. Finite Pool Panic retains its four disposable plants.
Each flag has ten formations and a48-packet allowance. Accepted packets and
surviving defenses carry; only unissued quota expires at a clear. Native entry
admission prevents offscreen conveyor backlog. Delivery weights consider native
legal spaces, existing plants and waiting duplicates. Torchwood is supplied for
unserved lanes, with at most one waiting packet. Lily Pad supply stops at14
planted pads, leaving bare water for Kelp. Native placement stays unrestricted.
Only empty original rear support cells regain Lily Pads. Existing health and
used mowers carry unchanged. Native shop purchases are respected.

Health-based pacing uses native wave fields. The first three flags have37,47
and57 actors including Flag Zombies. Generated flags introduce Jack-in-the-Box
and Ladder zombies at flag4, Zamboni at5 and Gargantuar at6, with unchanged
native statistics. Density caps at12 per formation. Eight saved spatial variants
vary the lanes. The native huge-wave warning and a brief clear banner mark
progress. A six-second intermission plus two-second lead-in permits repairs.
The native shovel follows the bank slide. Menu and speed share the original top menu strip, preserving native actor layering and head space. Pause
and dialogs suppress advice. A compact native-font best stamp leaves the card
portrait visible. Stock Survival rendering remains unchanged.

A mode-local native MTRand seed chain uses an existing saved field to preserve
future deliveries through Continue. No serialized structure is enlarged. Legacy
checkpoints retain accepted cards/order, actors, health, mowers, flags and best;
only excessive offscreen offsets are compacted once. At a boundary, native board
and profile files are written before the browser save queue is requested. Retry
starts at zero and retains the best. There is no finite award or trophy.

Build normal Release with build-chill.py. All23 native suites are packaging
gates. Ten silent complete-engine drivers link the same134 production objects
except main. The Endless policy uses identifiable cards and visible actors,
actual packet/tile input, latency and one missed decision per flag. Normal
primary/replay runs play six flags; other progress cases play three. Eight
legitimate seeded openings cover all saved variants. Hidden observer fields do
not drive actions. Separate controls check migration, future supply, save graphs,
pause and layout; synthetic controls do not count as earned progression. Exact
outcomes, headroom and pins are specified by the frozen verification contract.

All643 original artwork inputs are pinned, preserving every469 earlier pin.
MemoryImage exports are layout fixtures, not battle or GPU proof. Muted browser
inspection separately checks an opening flag and the shipping controls/saves.
Normal audio remains available. web-endless.2.patch and endless1-to-endless2.patch
reconstruct all production bytes. Prior cards, accepted bitmaps, native actor
layouts and all earlier regression suites remain gates. These checks do not
establish indefinite successful play or exhaustive original-game parity.
