// SPDX-License-Identifier: LGPL-3.0-or-later
#include "TorchbearerPresentation.h"
#include "TorchbearerZombie.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/ReanimAtlas.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <cmath>
#include <memory>
#include <vector>

namespace TorchbearerPresentation
{
namespace
{
constexpr int kFingersGroup = 10;
constexpr const char* kHand = "Zombie_flaghand";
constexpr const char* kArm = "Zombie_innerarm_screendoor";
struct Cache
{
    std::unique_ptr<Reanimation> arms;
    std::unique_ptr<Reanimation> flame;
    std::unique_ptr<Sexy::MemoryImage> shaft;
};
Cache& Images() { static Cache cache; return cache; }

std::unique_ptr<Sexy::MemoryImage> CopyTrackImage(Reanimation& rig, const char* name)
{
    const int index = rig.FindTrackIndex(name);
    Sexy::Image* source = rig.mDefinition->mTracks.tracks[index].mTransforms.mTransforms[0].mImage;
    if (!source) return nullptr;
    Sexy::Rect bounds;
    if (auto* atlas = rig.mDefinition->mReanimAtlas)
    {
        const auto* image = atlas->GetEncodedReanimAtlas(source);
        if (!image) return nullptr;
        bounds = Sexy::Rect(image->mX, image->mY, image->mWidth, image->mHeight);
        source = atlas->mMemoryImage.get();
    }
    else bounds = Sexy::Rect(0, 0, source->GetCelWidth(), source->GetCelHeight());
    auto* original = dynamic_cast<Sexy::MemoryImage*>(source);
    if (!original) return nullptr;
    std::vector<uint32_t> pixels(bounds.mWidth * bounds.mHeight);
    for (int y = 0; y < bounds.mHeight; ++y)
        std::copy_n(original->GetBits() + (bounds.mY + y) * original->GetWidth() + bounds.mX,
            bounds.mWidth, pixels.data() + y * bounds.mWidth);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), bounds.mWidth, bounds.mHeight);
    return image;
}

Sexy::MemoryImage* Shaft()
{
    Cache& cache = Images();
    if (!cache.shaft)
    {
        Reanimation original;
        original.ReanimationInitializeType(0, 0, REANIM_FLAG);
        cache.shaft = CopyTrackImage(original, "Zombie_flagpole");
    }
    return cache.shaft.get();
}

void CopyAppearance(Reanimation& target, const Reanimation& source)
{
    target.mOverlayMatrix = source.mOverlayMatrix;
    target.mColorOverride = source.mColorOverride;
    target.mExtraAdditiveColor = source.mExtraAdditiveColor;
    target.mEnableExtraAdditiveDraw = source.mEnableExtraAdditiveDraw;
    target.mExtraOverlayColor = source.mExtraOverlayColor;
    target.mEnableExtraOverlayDraw = source.mEnableExtraOverlayDraw;
    target.mFilterEffect = source.mFilterEffect;
}

Reanimation& Arms(Reanimation& carrier, float attackProgress)
{
    Cache& cache = Images();
    if (!cache.arms)
    {
        cache.arms = std::make_unique<Reanimation>();
        cache.arms->ReanimationInitializeType(0, 0, REANIM_ZOMBIE);
        cache.arms->AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
        cache.arms->AssignRenderGroupToTrack(kArm, RENDER_GROUP_NORMAL);
        cache.arms->AssignRenderGroupToTrack(kHand, kFingersGroup);
    }
    Reanimation& arms = *cache.arms;
    CopyAppearance(arms, carrier);
    arms.mFrameStart = carrier.mFrameStart;
    arms.mFrameCount = carrier.mFrameCount;
    arms.mAnimTime = carrier.mAnimTime;
    arms.mLoopType = carrier.mLoopType;
    for (const char* name : {kArm, kHand})
    {
        auto& target = arms.mTrackInstances[arms.FindTrackIndex(name)];
        const auto& source = carrier.mTrackInstances[carrier.FindTrackIndex(name)];
        target.mBlendTransform = source.mBlendTransform;
        target.mBlendTime = source.mBlendTime;
        target.mBlendCounter = source.mBlendCounter;
        target.mShakeX = source.mShakeX;
        target.mShakeY = source.mShakeY;
        target.mImageOverride = source.mImageOverride;
    }
    // Rotate the entire original carrying arm, closed fingers and held torch
    // together. The attachment never slides independently through the hand.
    if (attackProgress > 0.0f)
    {
        SexyTransform2D shoulder;
        arms.GetTrackMatrix(arms.FindTrackIndex(kArm), shoulder);
        const float x = shoulder.m02 - shoulder.m00 * 7.0f - shoulder.m01 * 13.0f;
        const float y = shoulder.m12 - shoulder.m10 * 7.0f - shoulder.m11 * 13.0f;
        const float reach = std::sin(std::clamp(attackProgress, 0.0f, 1.0f) * 3.14159265f);
        const float angle = -0.28f * reach;
        SexyMatrix3 turn;
        turn.LoadIdentity();
        turn.m00 = turn.m11 = std::cos(angle);
        turn.m01 = -std::sin(angle); turn.m10 = std::sin(angle);
        turn.m02 = x - turn.m00 * x - turn.m01 * y - reach * 3.0f;
        turn.m12 = y - turn.m10 * x - turn.m11 * y;
        arms.mOverlayMatrix = turn * arms.mOverlayMatrix;
    }
    return arms;
}

Reanimation& Flame()
{
    Cache& cache = Images();
    if (!cache.flame)
    {
        cache.flame = std::make_unique<Reanimation>();
        cache.flame->ReanimationInitializeType(0, 0, REANIM_TORCHWOOD);
        cache.flame->SetFramesForLayer("anim_idle");
        cache.flame->AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
        cache.flame->AssignRenderGroupToPrefix("Torchwood_fire", RENDER_GROUP_NORMAL);
    }
    return *cache.flame;
}
}

void PrepareRig(Reanimation& carrier)
{
    if (carrier.mReanimationType != REANIM_ZOMBIE || !carrier.mDefinition || !carrier.mTrackInstances) return;
    if (!carrier.TrackExists(kHand) || !carrier.TrackExists(kArm)) return;
    carrier.AssignRenderGroupToPrefix("anim_innerarm", RENDER_GROUP_HIDDEN);
    carrier.AssignRenderGroupToTrack(kArm, RENDER_GROUP_HIDDEN);
    carrier.AssignRenderGroupToTrack(kHand, RENDER_GROUP_HIDDEN);
}

void Initialize(Zombie& zombie)
{
    if (zombie.mZombieType != ZOMBIE_TORCHBEARER || !zombie.mApp) return;
    if (auto* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID)) PrepareRig(*carrier);
}

void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, bool lit, float animationTime,
    bool hasArm, bool hasObject, float attackProgress)
{
    if (carrier.mReanimationType != REANIM_ZOMBIE || !carrier.mDefinition || !carrier.mTrackInstances ||
        !carrier.TrackExists(kHand) || !carrier.TrackExists(kArm)) return;
    // mHasArm describes the stock OUTER arm. The inner carrying hand survives
    // that native limb loss and continues to hold its torch.
    (void)hasArm;
    Reanimation& arms = Arms(carrier, attackProgress);
    arms.DrawRenderGroup(graphics, RENDER_GROUP_NORMAL);
    if (!hasObject)
    {
        arms.DrawRenderGroup(graphics, kFingersGroup);
        return;
    }
    Sexy::MemoryImage* shaft = Shaft();
    if (!shaft) { arms.DrawRenderGroup(graphics, kFingersGroup); return; }
    SexyTransform2D hand;
    arms.GetTrackMatrix(arms.FindTrackIndex(kHand), hand);
    // DrawTrack has no GetTrackMatrix attachment half-pixel bias. Native hand
    // pixels(9,12) enclose opaque shaft pixel(10,88) in the original86x110
    // pole canvas. Its upper transparent margin is part of that native image.
    SexyMatrix3Translation(hand, 0.5f, 0.5f);
    SexyMatrix3 local;
    local.LoadIdentity(); local.m00 = local.m11 = 0.90f;
    local.m02 = -0.5f - local.m00 * (10.0f - shaft->GetWidth() * 0.5f);
    local.m12 = -0.5f - local.m11 * (88.0f - shaft->GetHeight() * 0.5f);
    SexyMatrix3 pole = hand * local;
    SexyMatrix3 drawPole = pole;
    SexyMatrix3Translation(drawPole, graphics->mTransX, graphics->mTransY);
    Sexy::Color color = carrier.mColorOverride;
    if (!lit)
    {
        color.mRed = color.mRed * 120 / 255;
        color.mGreen = color.mGreen * 110 / 255;
        color.mBlue = color.mBlue * 100 / 255;
    }
    if (graphics->GetColorizeImages()) color = ColorsMultiply(color, graphics->GetColor());
    carrier.ReanimBltMatrix(graphics, shaft, drawPole, graphics->mClipRect, color,
        graphics->GetDrawMode(), Sexy::Rect(0, 0, shaft->GetWidth(), shaft->GetHeight()));
    if (lit)
    {
        Reanimation& flame = Flame();
        SexyMatrix3 flameLocal;
        flameLocal.LoadIdentity();
        flameLocal.m00 = 0.42f; flameLocal.m11 = 0.48f;
        flameLocal.m02 = (26.0f - shaft->GetWidth() * 0.5f) - flameLocal.m00 * 45.0f;
        flameLocal.m12 = (38.0f - shaft->GetHeight() * 0.5f) - flameLocal.m11 * 40.0f;
        flame.mOverlayMatrix = pole * flameLocal;
        flame.mAnimTime = animationTime - std::floor(animationTime);
        flame.mColorOverride = Sexy::Color(255, 255, 255, carrier.mColorOverride.mAlpha);
        flame.mEnableExtraAdditiveDraw = false;
        flame.mEnableExtraOverlayDraw = false;
        flame.Draw(graphics);
    }
    // The original closed fingers are always the final foreground layer.
    arms.DrawRenderGroup(graphics, kFingersGroup);
}

void Draw(Zombie& zombie, Sexy::Graphics* graphics, const ZombieDrawPosition&)
{
    if (zombie.mZombieType != ZOMBIE_TORCHBEARER || !zombie.mApp || zombie.mDead ||
        zombie.mZombiePhase == PHASE_ZOMBIE_MOWERED || zombie.mMoweredReanimID != REANIMATIONID_NULL) return;
    auto* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    if (!carrier) return;
    const bool holding = zombie.mHasHead && zombie.mZombiePhase == PHASE_ZOMBIE_NORMAL;
    const float progress = zombie.mSummonCounter > 0 ?
        1.0f - zombie.mSummonCounter / static_cast<float>(TorchbearerZombie::kBurnWindupTicks) : 0.0f;
    DrawRig(graphics, *carrier, zombie.mHasObject, carrier->mAnimTime * 2.0f,
        zombie.mHasArm, holding, progress);
}

void DisposeImage()
{
    Cache& cache = Images(); cache.arms.reset(); cache.flame.reset(); cache.shaft.reset();
}
}
