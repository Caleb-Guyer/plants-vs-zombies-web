// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// Original native plant rigs composed inside the existing Bonus card window.
namespace GarlicRunPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
