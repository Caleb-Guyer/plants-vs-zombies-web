// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
class Zombie;
class ZombieDrawPosition;
class Reanimation;
namespace Sexy { class Graphics; }

namespace TorchbearerPresentation
{
void Initialize(Zombie& zombie);
void PrepareRig(Reanimation& carrier);
void Draw(Zombie& zombie, Sexy::Graphics* graphics, const ZombieDrawPosition& position);
void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, bool lit = true,
    float animationTime = 0.0f, bool hasArm = true, bool hasObject = true,
    float attackProgress = 0.0f);
void DisposeImage();
}
