// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
namespace Sexy { class Image; }
namespace FireDrillPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
