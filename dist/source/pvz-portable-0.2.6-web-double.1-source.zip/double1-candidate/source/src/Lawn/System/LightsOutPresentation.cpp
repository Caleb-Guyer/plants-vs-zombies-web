// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LightsOutPresentation.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace LightsOutPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("DelayLoad_Background2") || !PvzpLoadResources("DelayLoad_Background4") ||
        !Sexy::IMAGE_BACKGROUND2 || !Sexy::IMAGE_FOG_SOFTWARE)
        return nullptr;

    auto portrait = Blank(180, 180);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    Reanimation plantern;
    plantern.ReanimationInitializeType(40.0f, 35.0f, REANIM_PLANTERN);
    plantern.SetFramesForLayer("anim_idle");
    plantern.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND2, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));

    // Two original mist cels frame the light. They remain behind the native
    // plant so the complete Plantern silhouette and face stay readable.
    Sexy::Image* fog = Sexy::IMAGE_FOG_SOFTWARE;
    const Sexy::Rect fogCel(0, 0, fog->GetCelWidth(), fog->GetCelHeight());
    picture.SetColorizeImages(true);
    picture.SetColor(Sexy::Color(255, 255, 255, 150));
    const float fogScale = 0.6f;
    const int fogWidth = static_cast<int>(fogCel.mWidth * fogScale);
    const int fogHeight = static_cast<int>(fogCel.mHeight * fogScale);
    picture.DrawImage(fog, Sexy::Rect(-26, -14, fogWidth, fogHeight), fogCel);
    picture.DrawImage(fog, Sexy::Rect(58, -9, fogWidth, fogHeight), fogCel);
    picture.SetColorizeImages(false);

    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
