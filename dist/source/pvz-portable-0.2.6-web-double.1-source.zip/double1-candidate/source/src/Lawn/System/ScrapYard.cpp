// SPDX-License-Identifier: LGPL-3.0-or-later
#include "ScrapYard.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Coin.h"
#include "../Plant.h"
#include "../SeedPacket.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include <algorithm>
#include <climits>

namespace ScrapYard
{
void PreloadResources()
{
    Plant::PreloadPlantResources(SEED_PEASHOOTER);
    for (SeedType seed : kSeeds) Plant::PreloadPlantResources(seed);
    constexpr ZombieType types[] = {ZOMBIE_PAIL,ZOMBIE_DOOR,ZOMBIE_FOOTBALL,
        ZOMBIE_LADDER,ZOMBIE_POGO,ZOMBIE_JACK_IN_THE_BOX};
    for (ZombieType type : types) Zombie::PreloadZombieResources(type);
}

void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    challenge.mChallengeScore = 0;
    challenge.mChallengeGridY = kRulesVersion;
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = kStartingSun;
    board.mShowShovel = true;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (const StartingPlant& plant : kStartingPlants)
        board.AddPlant(plant.mCol,plant.mRow,plant.mSeed,SEED_NONE);
}

bool CanRewardPull(const Plant& plant)
{
    Board* board = plant.mBoard;
    return board && board->mApp && IsMode(board->mApp->mGameMode) && board->mChallenge &&
        board->mChallenge->mChallengeState == kActive && board->mChallenge->mChallengeGridY == kRulesVersion &&
        board->mApp->mGameScene == SCENE_PLAYING && !board->mPaused && board->mTimeStopCounter == 0 &&
        !board->mLevelComplete && !board->HasLevelAwardDropped() && plant.mSeedType == SEED_MAGNETSHROOM &&
        plant.mIsOnBoard && !plant.mDead && !plant.mSquished && !plant.mIsAsleep && plant.mPlantHealth > 0;
}

bool CanRewardPull(const Plant& plant, Zombie& zombie)
{
    if (!CanRewardPull(plant) || zombie.mBoard != plant.mBoard || zombie.mDead ||
        !zombie.mHasHead || zombie.mMindControlled || zombie.IsDeadOrDying()) return false;
    // Snapshot the native source before its removal. The source's saved flags
    // are cleared by the original pull, so neither a second attempt nor Continue
    // can pay again for an already removed item.
    return ((zombie.mHelmType == HELMTYPE_PAIL || zombie.mHelmType == HELMTYPE_FOOTBALL) && zombie.mHelmHealth > 0) ||
        ((zombie.mShieldType == SHIELDTYPE_DOOR || zombie.mShieldType == SHIELDTYPE_LADDER) && zombie.mShieldHealth > 0) ||
        (zombie.mZombieType == ZOMBIE_POGO && zombie.mHasObject) ||
        zombie.mZombiePhase == PHASE_JACK_IN_THE_BOX_RUNNING ||
        (zombie.mZombieType == ZOMBIE_DIGGER && zombie.mHasObject);
}

void RewardPull(Plant& plant)
{
    if (!CanRewardPull(plant)) return;
    Board& board = *plant.mBoard;
    if (board.mChallenge->mChallengeScore < INT_MAX) ++board.mChallenge->mChallengeScore;
    for (int i = 0; i < kCoinsPerPull; ++i)
        board.AddCoin(plant.mX + 8 + i*20,plant.mY,COIN_SUN,COIN_MOTION_FROM_PLANT);
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) || challenge.mChallengeState != kActive ||
        board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.mTimeStopCounter > 0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = true;
    const int next = std::clamp(challenge.mSurvivalStage,0,kWaveCount);
    if (next < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        // Removing armor is income, not a cleared formation. Keep the full
        // interval so successful recycling never accelerates the next assault.
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter != 0) return;
        board.NextWaveComing();
        for (const Spawn& spawn : kFormations[next])
        {
            if (spawn.mType == ZOMBIE_INVALID) continue;
            Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,next);
            zombie->mPosX = static_cast<float>(spawn.mX);
            zombie->mX = spawn.mX;
            zombie->UpdateReanim();
        }
        challenge.mSurvivalStage = next + 1;
        board.mCurrentWave = board.mTotalSpawnedWaves = next + 1;
        board.mZombieHealthWaveStart = board.TotalZombiesHealthInWave(next);
        board.mZombieHealthToNextWave = -1;
        challenge.mChallengeStateCounter = kFormationInterval;
        board.mZombieCountDown = board.mZombieCountDownStart = kFormationInterval;
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(4,2);
}
}
