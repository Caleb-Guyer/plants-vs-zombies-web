// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>
#include <string_view>

class Board;
class SeedBank;

// Separate from finite Pool Panic. All progress uses existing saved counters;
// native plants, packets, zombies, mowers and effects retain their own states.
namespace PoolPanicEndless
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_POOL_PANIC_ENDLESS;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(127);
inline constexpr ChallengeState kBetween = static_cast<ChallengeState>(128);
inline constexpr ChallengeState kHugeWave = static_cast<ChallengeState>(129);
inline constexpr int kRulesVersion = 3;
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestFormation = 48;
inline constexpr int kLivingActorSoftCap = 128;
inline constexpr int kBankSize = 10;
inline constexpr int kOpeningPackets = 6;
inline constexpr int kPacketQuota = 48;
inline constexpr int kSupplyInterval = 400;
inline constexpr int kOpeningDelay = 1800;
inline constexpr int kBetweenDelay = 600;
inline constexpr int kResumeDelay = 200;
inline constexpr int kHugeWaveDelay = 750;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kBetween || state == kHugeWave); }
inline constexpr std::array<SeedType,10> kSupplySeeds = {
    SEED_REPEATER, SEED_THREEPEATER, SEED_TALLNUT, SEED_TORCHWOOD, SEED_SPIKEWEED,
    SEED_LILYPAD, SEED_SQUASH, SEED_TANGLEKELP, SEED_CHERRYBOMB, SEED_JALAPENO
};
inline constexpr std::array<SeedType,kOpeningPackets> kOpeningSeeds = {
    SEED_REPEATER, SEED_THREEPEATER, SEED_TALLNUT, SEED_REPEATER, SEED_LILYPAD, SEED_TORCHWOOD
};
constexpr int SupplyInterval(int waiting)
{ return waiting > 8 ? 1000 : waiting > 6 ? 500 : waiting > 4 ? 425 : 400; }
constexpr int FormationInterval(int flags)
{
    if (flags < 6) return flags >= 3 ? 1700 - (flags-3)*100 : 2200 - (flags > 0 ? flags : 0)*200;
    return flags >= 26 ? 600 : 1400-(flags-6)*40;
}
constexpr int EscalationAge(int flags) { return flags >= 86 ? 80 : flags > 6 ? flags-6 : 0; }
constexpr int HeavyPercent(int flags)
{ const int value = 4+EscalationAge(flags)*2; return value > 80 ? 80 : value; }
constexpr int RedeyePercent(int flags)
{ return flags < 9 ? 0 : flags >= 78 ? 70 : flags-8; }
struct Cell { int mCol; int mRow; };
inline constexpr std::array<Cell,8> kLilyPads = {{{0,2},{1,2},{2,2},{3,2},{0,3},{1,3},{2,3},{3,3}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
// Independently authored opening flags. N normal, C cone, B bucket, S screen
// door, R football, H snorkel and F dolphin; digits are canonical native rows.
inline constexpr std::array<std::array<std::string_view,kWaveCount>,3> kOpeningFlags = {{
    {{"N0 N2","N5 C3","C0 N1 N2","N4 C5 C3","C0 C1 N2 C3","C4 C5 C2 N3",
      "B0 N1 C2 C3","N4 B5 C2 C3","C0 C1 N2 C3 F3","N4 C5 C2 F2 B3"}},
    {{"C0 N5 N2","N1 C4 C3","B0 C1 C2 N3","C4 B5 N2 C3","S0 C1 C2 H3 N5",
      "C0 S4 C5 H2 C3","B0 N1 C2 F2 B3","C4 B5 B2 F3 C3","R0 C1 C4 C2 H2 F3","C1 C4 R5 F2 B3 H3"}},
    {{"B0 N5 C2 H3","C1 B4 H2 N3","S0 C1 C2 F2 B3","C4 S5 B2 H3 F3","B0 R1 C5 C2 B3 H3",
      "C0 R4 B5 H2 C3 F3","S0 B1 N4 B2 F2 H3","N1 B4 S5 H2 B3 F3","R0 C1 B4 S5 C2 H2 F3","C0 S1 C4 R5 F2 B3 H3"}}
}};
constexpr ZombieType TypeFor(char type)
{
    switch (type)
    {
    case 'N': return ZOMBIE_NORMAL;
    case 'C': return ZOMBIE_TRAFFIC_CONE;
    case 'B': return ZOMBIE_PAIL;
    case 'S': return ZOMBIE_DOOR;
    case 'R': return ZOMBIE_FOOTBALL;
    case 'H': return ZOMBIE_SNORKEL;
    case 'F': return ZOMBIE_DOLPHIN_RIDER;
    default: return ZOMBIE_INVALID;
    }
}
constexpr Formation ParseWave(std::string_view text)
{
    Formation result{};
    int count = 0;
    for (std::size_t i = 0; i + 1 < text.size() && count < kLargestFormation; i += 3)
    {
        result[count] = {TypeFor(text[i]),text[i+1]-'0',800+(count%3)*40};
        ++count;
    }
    return result;
}
constexpr int ZombieCount(const Formation& formation)
{
    int count = 0;
    for (const Spawn& spawn : formation) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
constexpr int TransformRow(int row, int flags, int variation, int wave)
{
    if (row == 2 || row == 3) return 2 + (row-2 + variation/4 + flags%2 + wave) % 2;
    constexpr int land[4] = {0,1,4,5};
    const int index = row < 2 ? row : row-2;
    return land[(index + variation%4 + flags%4) % 4];
}
constexpr Formation WaveFor(int flags, int wave, int variation)
{
    Formation result{};
    if (flags < 0 || wave < 0 || wave >= kWaveCount || variation < 0 || variation >= 8) return result;
    if (flags < 3) result = ParseWave(kOpeningFlags[flags][wave]);
    else if (flags < 6)
    {
        // Vary land/water pressure and introduce original counter mechanics.
        // Density is bounded; no zombie's native statistics are changed.
        const int growth = flags >= 11 ? 4 : (flags-3)/2;
        const int requested = ZombieCount(ParseWave(kOpeningFlags[0][wave])) + 3 + growth;
        const int limit = wave == kWaveCount-1 ? kLargestFormation-1 : kLargestFormation;
        const int count = requested < limit ? requested : limit;
        constexpr int land[4] = {0,1,4,5};
        for (int i = 0; i < count; ++i)
        {
            const int key = (flags%19 + wave*3 + i*5) % 19;
            const int theme = flags%3;
            const bool water = theme == 0 ? i%2 == 1 : theme == 1 ? i%4 == 3 : i%3 != 0;
            result[i] = {ZOMBIE_NORMAL, water ? 2+(wave+i)%2 : land[(wave+i)%4],800+(i%3)*40};
            if (water)
            {
                constexpr ZombieType types[5] = {ZOMBIE_NORMAL,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,ZOMBIE_SNORKEL,ZOMBIE_DOLPHIN_RIDER};
                result[i].mType = types[(key+flags%5)%5];
            }
            else
            {
                constexpr ZombieType types[6] = {ZOMBIE_NORMAL,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,ZOMBIE_DOOR,ZOMBIE_FOOTBALL,ZOMBIE_NEWSPAPER};
                result[i].mType = types[key%6];
                if (flags >= 3 && i == 0 && wave == 4) result[i].mType = ZOMBIE_JACK_IN_THE_BOX;
                if (flags >= 3 && i == 0 && wave == 7) result[i].mType = ZOMBIE_LADDER;
                if (flags >= 4 && i == 0 && wave == 5) result[i].mType = ZOMBIE_ZAMBONI;
                if (flags >= 5 && i == 0 && wave == 8) result[i].mType = ZOMBIE_GARGANTUAR;
            }
        }
    }
    else
    {
        // The first six flags remain the published opening. Thereafter native
        // density, overlap and the heavy mix keep growing on separate curves.
        // Physical ceilings protect the native arrays; these are not uncapped.
        const int growth = flags >= 47 ? 46 : flags-1;
        const int requested = ZombieCount(ParseWave(kOpeningFlags[0][wave]))+growth;
        const int limit = wave == kWaveCount-1 ? kLargestFormation-1 : kLargestFormation;
        const int count = requested < limit ? requested : limit;
        const int age = EscalationAge(flags);
        const int theme = (flags-6)%6;
        const int heavy = HeavyPercent(flags);
        const int redeye = RedeyePercent(flags);
        const int requestedSpecial = 16+age/2;
        const int special = requestedSpecial < 100-heavy ? requestedSpecial : 100-heavy;
        constexpr int land[4] = {0,1,4,5};
        constexpr ZombieType specialists[6][5] = {
            {ZOMBIE_DOOR,ZOMBIE_FOOTBALL,ZOMBIE_POGO,ZOMBIE_LADDER,ZOMBIE_JACK_IN_THE_BOX},
            {ZOMBIE_LADDER,ZOMBIE_POGO,ZOMBIE_LADDER,ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_FOOTBALL},
            {ZOMBIE_ZAMBONI,ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_ZAMBONI,ZOMBIE_LADDER,ZOMBIE_JACK_IN_THE_BOX},
            {ZOMBIE_DANCER,ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_DANCER,ZOMBIE_POGO,ZOMBIE_LADDER},
            {ZOMBIE_LADDER,ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_ZAMBONI,ZOMBIE_FOOTBALL,ZOMBIE_DOOR},
            {ZOMBIE_DANCER,ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_LADDER,ZOMBIE_POGO,ZOMBIE_ZAMBONI}
        };
        int landCount = 0, dancers = 0, vehicles = 0;
        for (int i = 0; i < count; ++i)
        {
            const int key = (flags%97*13+wave*11+i*7)%101;
            const bool water = theme == 5 ? i%3 != 0 : theme == 1 || theme == 4 ? i%4 == 3 : i%3 == 2;
            result[i] = {ZOMBIE_NORMAL,water ? 2+(wave+i)%2 : land[(wave+landCount)%4],800+(i%4)*40};
            if (water)
            {
                constexpr ZombieType types[5] = {ZOMBIE_PAIL,ZOMBIE_SNORKEL,ZOMBIE_DOLPHIN_RIDER,ZOMBIE_PAIL,ZOMBIE_TRAFFIC_CONE};
                result[i].mType = types[(key+wave)%5];
                if (age >= 6 && result[i].mType == ZOMBIE_TRAFFIC_CONE) result[i].mType = ZOMBIE_SNORKEL;
                continue;
            }
            if (key < redeye || (flags >= 9 && wave == kWaveCount-1 && landCount == 0))
                result[i].mType = ZOMBIE_REDEYE_GARGANTUAR;
            else if (key < heavy) result[i].mType = ZOMBIE_GARGANTUAR;
            else if (key < heavy+special)
            {
                ZombieType type = specialists[theme][(key+wave+flags%5)%5];
                // Native summons and vehicles have wider runtime cost and
                // replacement demand than an ordinary walking zombie.
                if (type == ZOMBIE_DANCER && dancers >= 2) type = ZOMBIE_LADDER;
                if (type == ZOMBIE_ZAMBONI && vehicles >= (age >= 10 ? 2 : 1)) type = ZOMBIE_JACK_IN_THE_BOX;
                result[i].mType = type;
                dancers += type == ZOMBIE_DANCER;
                vehicles += type == ZOMBIE_ZAMBONI;
            }
            else
            {
                constexpr ZombieType types[5] = {ZOMBIE_PAIL,ZOMBIE_DOOR,ZOMBIE_FOOTBALL,ZOMBIE_NEWSPAPER,ZOMBIE_TRAFFIC_CONE};
                result[i].mType = types[(key+wave)%5];
                if (age >= 6 && result[i].mType == ZOMBIE_TRAFFIC_CONE) result[i].mType = ZOMBIE_FOOTBALL;
            }
            ++landCount;
        }
    }
    if (wave == kWaveCount-1)
    {
        const int count = ZombieCount(result);
        result[count] = {ZOMBIE_FLAG,0,800+(count%3)*40};
    }
    for (Spawn& spawn : result) if (spawn.mType != ZOMBIE_INVALID)
        spawn.mRow = TransformRow(spawn.mRow,flags,variation,wave);
    return result;
}
constexpr int ZombiesPerFlag(int flags)
{
    int count = 0;
    for (int wave = 0; wave < kWaveCount; ++wave) count += ZombieCount(WaveFor(flags,wave,0));
    return count;
}

// Fire Drill completion opts into the new enemy. Keep the published opening,
// population counts, heavy attackers and water lanes unchanged.
constexpr Formation WithTorchbearers(Formation formation,int flags,int wave,bool unlocked)
{
    if(!unlocked || flags<9 || (wave!=2 && wave!=6 && wave!=8)) return formation;
    int remaining=wave==8 ? 2 : 1;
    const int count=ZombieCount(formation);
    for(int step=0;step<count && remaining>0;++step)
    {
        Spawn& spawn=formation[(step+flags+wave)%count];
        if(spawn.mRow==2 || spawn.mRow==3) continue;
        if(spawn.mType!=ZOMBIE_NORMAL && spawn.mType!=ZOMBIE_TRAFFIC_CONE &&
           spawn.mType!=ZOMBIE_PAIL && spawn.mType!=ZOMBIE_NEWSPAPER) continue;
        spawn.mType=ZOMBIE_TORCHBEARER;
        --remaining;
    }
    return formation;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
    {
        const Formation formation = WaveFor(0,wave,0);
        for (int i = 0; i < ZombieCount(formation); ++i) output[wave][i] = formation[i].mType;
    }
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOLPHIN_RIDER));
    for (auto& allowed : output) allowed = false;
    for (int wave = 0; wave < kWaveCount; ++wave) for (const Spawn& spawn : WaveFor(0,wave,0))
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank) { bank.mNumPackets = kBankSize; }
bool CanAcceptSupply(const SeedBank& bank);
int SupplyWeight(Board& board, SeedType seed);
void MigrateLegacy(Board& board);
void PreloadResources();
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode) == 87);
static_assert(ZombiesPerFlag(0)==37 && ZombiesPerFlag(1)==47 && ZombiesPerFlag(2)==57 && ZombiesPerFlag(3)==67);
static_assert(ZombiesPerFlag(5)==77 && ZombiesPerFlag(6)==87 && ZombiesPerFlag(7)==97 && ZombiesPerFlag(11)==137);
static_assert(ZombiesPerFlag(19)==217 && ZombiesPerFlag(39)==417 && ZombiesPerFlag(79)==480);
}
