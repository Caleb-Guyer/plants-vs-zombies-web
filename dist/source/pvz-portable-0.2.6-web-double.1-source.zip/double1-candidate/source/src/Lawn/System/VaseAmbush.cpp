// SPDX-License-Identifier: LGPL-3.0-or-later
#include "VaseAmbush.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../GridItem.h"
#include "../Coin.h"
#include "../SeedPacket.h"
#include "../Projectile.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/Reanimator.h"
#include <algorithm>

namespace VaseAmbush
{
namespace
{
void ClearMallet(Board& board)
{
    Challenge& challenge=*board.mChallenge;
    if(Reanimation* hammer=board.mApp->ReanimationTryToGet(challenge.mReanimChallenge))hammer->ReanimationDie();
    challenge.mReanimChallenge=REANIMATIONID_NULL;
    challenge.mChallengeGridX=challenge.mChallengeGridY=0;
}
}
void PreloadResources()
{
    ReanimatorEnsureDefinitionLoaded(REANIM_HAMMER,true);
    for(const Puzzle& puzzle:kBoards)
    {
        for(const Defender& plant:puzzle.mPlants)if(plant.mSeed!=SEED_NONE)Plant::PreloadPlantResources(plant.mSeed);
        for(const Vase& vase:puzzle.mVases)if(vase.mType!=ZOMBIE_INVALID)Zombie::PreloadZombieResources(vase.mType);
    }
}
void Populate(Board& board)
{
    Challenge& challenge=*board.mChallenge;
    const int stage=std::clamp(challenge.mSurvivalStage,0,kBoardCount-1);
    ClearMallet(board);
    challenge.mSurvivalStage=stage;
    challenge.mChallengeState=kActive;
    challenge.mChallengeStateCounter=challenge.mChallengeScore=0;
    challenge.mScaryPotterPots=VaseCount(stage);
    board.mSunMoney=0;
    board.mCurrentWave=board.mTotalSpawnedWaves=0;
    board.mProgressMeterWidth=0;
    board.mZombieCountDown=board.mZombieCountDownStart=100000;
    board.mNextSurvivalStageCounter=0;
    board.mShowShovel=false;
    board.mBonusLawnMowersRemaining=0;
    board.ClearCursor();
    board.mSeedBank->mNumPackets=0;
    for(int row=0;row<5;++row)
    {
        GridItem* brain=board.mGridItems.DataArrayAlloc();
        brain->mGridItemType=GRIDITEM_IZOMBIE_BRAIN;
        brain->mGridX=0;brain->mGridY=row;
        brain->mRenderOrder=Board::MakeRenderOrder(RENDER_LAYER_PLANT,row,0);
        brain->mGridItemCounter=70;
        brain->mPosX=board.GridToPixelX(0,row)-40;
        brain->mPosY=board.GridToPixelY(0,row)+40;
    }
    for(const Defender& defender:kBoards[stage].mPlants)
    {
        if(defender.mSeed==SEED_NONE)continue;
        Plant* plant=board.NewPlant(defender.mCol,defender.mRow,defender.mSeed,SEED_NONE);
        plant->SetSleeping(false);
        challenge.IZombieSetupPlant(plant);
    }
    for(const Vase& entry:kBoards[stage].mVases)
    {
        if(entry.mType==ZOMBIE_INVALID)continue;
        GridItem* vase=board.mGridItems.DataArrayAlloc();
        vase->mGridItemType=GRIDITEM_SCARY_POT;
        vase->mGridItemState=GRIDITEM_STATE_SCARY_POT_ZOMBIE;
        vase->mGridX=entry.mCol;vase->mGridY=entry.mRow;
        vase->mScaryPotType=SCARYPOT_ZOMBIE;
        vase->mZombieType=entry.mType;
        vase->mRenderOrder=Board::MakeRenderOrder(RENDER_LAYER_PLANT,entry.mRow,1);
        // Use the original Plantern window and cached zombie, not extra labels.
        vase->mTransparentCounter=50;
    }
}
void ResetStage(Board& board,int stage)
{
    ClearMallet(board);
    for(Zombie* zombie:board.mZombies)if(!zombie->mDead)zombie->DieNoLoot();
    for(Plant* plant:board.mPlants)if(!plant->mDead)plant->Die();
    for(Coin* coin:board.mCoins)if(!coin->mDead)coin->Die();
    for(GridItem* item:board.mGridItems)if(!item->mDead)item->GridItemDie();
    for(Projectile* projectile:board.mProjectiles)if(!projectile->mDead)projectile->Die();
    board.mChallenge->mSurvivalStage=std::clamp(stage,0,kBoardCount-1);
    board.mLevelAwardSpawned=false;
    Populate(board);
}
bool CanBreak(Board& board)
{
    return board.mApp && board.mChallenge && IsMode(board.mApp->mGameMode) &&
        board.mChallenge->mChallengeState==kActive && !board.mPaused &&
        board.mApp->mGameScene==SCENE_PLAYING && !board.mLevelComplete &&
        !board.HasLevelAwardDropped() && board.mApp->GetDialog(DIALOG_GAME_OVER)==nullptr &&
        board.mApp->GetDialog(DIALOG_CONTINUE)==nullptr &&
        board.mChallenge->mReanimChallenge==REANIMATIONID_NULL;
}
void MalletPot(Board& board,GridItem* pot)
{
    if(!CanBreak(board) || !pot || pot->mDead || pot->mBoard!=&board || pot->mGridItemType!=GRIDITEM_SCARY_POT)return;
    // Native hammer, target coordinates, animation rate, sound and shatter.
    board.mChallenge->ScaryPotterMalletPot(pot);
    board.mChallenge->mChallengeState=kActive;
}
void OnBrainsCleared(Board& board,int row)
{
    Challenge& challenge=*board.mChallenge;
    if(challenge.mChallengeState!=kActive || board.HasLevelAwardDropped())return;
    ClearMallet(board);
    board.ClearCursor();
    board.ClearAdviceImmediately();
    if(challenge.mSurvivalStage==kBoardCount-1)
    {
        challenge.mChallengeState=kFinished;
        challenge.SpawnLevelAward(0,row);
    }
    else
    {
        challenge.mChallengeState=kTransition;
        challenge.mChallengeStateCounter=kTransitionTicks;
    }
}
void Update(Board& board)
{
    Challenge& challenge=*board.mChallenge;
    if(!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) || board.mPaused ||
        board.mTimeStopCounter>0 || board.mApp->mGameScene!=SCENE_PLAYING ||
        board.mLevelComplete || board.HasLevelAwardDropped())return;
    board.mShowShovel=false;
    if(challenge.mChallengeState==kTransition)
    {
        if(--challenge.mChallengeStateCounter>0)return;
        ClearMallet(board);
        challenge.PuzzleNextStageClear();
        for(Coin* coin:board.mCoins)if(!coin->mDead)coin->Die();
        for(Projectile* projectile:board.mProjectiles)if(!projectile->mDead)projectile->Die();
        Populate(board);
        return;
    }
    if(challenge.mChallengeState!=kActive)return;
    // Native mallet animation is serialized through the existing saved ID.
    if(Reanimation* hammer=board.mApp->ReanimationTryToGet(challenge.mReanimChallenge))
    {
        if(hammer->mLoopCount>0)
        {
            GridItem* vase=board.GetGridItemAt(GRIDITEM_SCARY_POT,challenge.mChallengeGridX,challenge.mChallengeGridY);
            if(vase && !vase->mDead)challenge.ScaryPotterOpenPot(vase);
            ClearMallet(board);
        }
    }
    else if(challenge.mReanimChallenge!=REANIMATIONID_NULL)ClearMallet(board);
    challenge.mScaryPotterPots=challenge.ScaryPotterCountPots();
    // Native I, Zombie handles idle-walker speed and the settled loss timing,
    // including Chomper/Squash and mine effects. Unopened army vases gate that
    // original defeat check, so thinking time cannot spend the player's army.
    challenge.IZombieUpdate();
}
}
