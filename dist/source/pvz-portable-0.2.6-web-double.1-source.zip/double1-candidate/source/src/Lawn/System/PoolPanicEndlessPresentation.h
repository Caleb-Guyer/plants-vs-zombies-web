// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include <cstdint>
#include <string_view>

namespace Sexy { class Image; class Graphics; }

// The complete original Dolphin Rider assembly in the native Bonus thumbnail.
namespace PoolPanicEndlessPresentation
{
Sexy::Image* GetBonusImage();
// A compact original-font record stamp leaves the portrait's upper 47 rows clear.
bool DrawFittedBestRecord(Sexy::Graphics* graphics, uint32_t record, std::string_view nativeText, int x, int y);
void DisposeImage();
}
