// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Plant;

namespace LightsOut
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_LIGHTS_OUT;
inline constexpr ChallengeState kState = static_cast<ChallengeState>(114);
inline constexpr int kRows = 5;
inline constexpr int kRailCol = 2;
inline constexpr int kLightRadius = 2;
inline constexpr int kMoveCooldown = 75;
inline constexpr int kOpeningDelay = 1800;
inline constexpr int kWaveCount = 8;
inline constexpr int kLargestWave = 6;
inline constexpr int kFogOpacity = 132;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kState; }
constexpr bool IsCellLit(int lampCol, int lampRow, int col, int row)
{
    const int dx = lampCol > col ? lampCol - col : col - lampCol;
    const int dy = lampRow > row ? lampRow - row : row - lampRow;
    return col >= 0 && col < 9 && row >= 0 && row < kRows && dx + dy <= kLightRadius;
}
struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
inline constexpr std::array<StartingPlant, 16> kStartingPlants = {{
    {SEED_SNOWPEA,0,0}, {SEED_REPEATER,1,0}, {SEED_WALLNUT,4,0},
    {SEED_SNOWPEA,0,1}, {SEED_REPEATER,1,1}, {SEED_WALLNUT,4,1},
    {SEED_SNOWPEA,0,2}, {SEED_REPEATER,1,2}, {SEED_WALLNUT,4,2},
    {SEED_SNOWPEA,0,3}, {SEED_REPEATER,1,3}, {SEED_WALLNUT,4,3},
    {SEED_SNOWPEA,0,4}, {SEED_REPEATER,1,4}, {SEED_WALLNUT,4,4},
    {SEED_PLANTERN,kRailCol,2}
}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; };
using Wave = std::array<Spawn,kLargestWave>;
// The first lone walker teaches the bright center lane; the next pair asks for
// the first relocation. Later simultaneous lanes make the lamp a shared resource.
inline constexpr std::array<Wave,kWaveCount> kWaves = {{
    {{{ZOMBIE_NORMAL,2}}},
    {{{ZOMBIE_NORMAL,4},{ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_NORMAL,0},{ZOMBIE_TRAFFIC_CONE,0},{ZOMBIE_NORMAL,1}}},
    {{{ZOMBIE_TRAFFIC_CONE,4},{ZOMBIE_NORMAL,3},{ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_TRAFFIC_CONE,1},{ZOMBIE_NORMAL,3},{ZOMBIE_TRAFFIC_CONE,3}}},
    {{{ZOMBIE_TRAFFIC_CONE,4},{ZOMBIE_NORMAL,0},{ZOMBIE_TRAFFIC_CONE,0},{ZOMBIE_NORMAL,2}}},
    {{{ZOMBIE_TRAFFIC_CONE,0},{ZOMBIE_TRAFFIC_CONE,4},{ZOMBIE_NORMAL,1},{ZOMBIE_TRAFFIC_CONE,3}}},
    {{{ZOMBIE_FLAG,2},{ZOMBIE_TRAFFIC_CONE,0},{ZOMBIE_NORMAL,0},{ZOMBIE_TRAFFIC_CONE,4},{ZOMBIE_NORMAL,4},{ZOMBIE_NORMAL,2}}}
}};
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count=0;
    for (const auto& spawn:kWaves[wave]) if (spawn.mType!=ZOMBIE_INVALID) ++count;
    return count;
}
constexpr int RowForSpawn(int wave,int ordinal)
{
    return wave>=0 && wave<kWaveCount && ordinal>=0 && ordinal<ZombieCount(wave) ? kWaves[wave][ordinal].mRow : -1;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves>=kWaveCount && Slots>kLargestWave);
    for (auto& wave:output) for (auto& zombie:wave) zombie=ZOMBIE_INVALID;
    for (int wave=0;wave<kWaveCount;++wave)
        for (int ordinal=0;ordinal<ZombieCount(wave);++ordinal) output[wave][ordinal]=kWaves[wave][ordinal].mType;
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count>static_cast<std::size_t>(ZOMBIE_DOOR));
    for (auto& allowed:output) allowed=false;
    for (const auto& wave:kWaves) for (const auto& spawn:wave)
        if (spawn.mType!=ZOMBIE_INVALID) output[spawn.mType]=true;
}
Plant* GetPlantern(Board& board);
const Plant* GetPlantern(const Board& board);
bool IsLit(const Board& board,int col,int row);
bool CanAttack(const Plant& plant);
void Populate(Board& board);
void Update(Board& board);
bool MovePlantern(Board& board,Plant* plant,int col,int row);
static_assert(static_cast<int>(kMode)==82);
}
