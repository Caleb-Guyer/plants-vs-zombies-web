// SPDX-License-Identifier: LGPL-3.0-or-later
#include "BungeeBusinessPresentation.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace BungeeBusinessPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1) return nullptr;

    auto portrait = Blank(220, 220);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);

    // Preserve the original carrying geometry, pose and occlusion. Native
    // UpdateReanim places a Bungee body at (-3,-8) relative to its cell origin;
    // DrawBungeeReanim draws the carried plant at (0,30), then its forearms.
    constexpr float originX = 70.0f, originY = 25.0f;
    constexpr int arms = 2;
    Reanimation body;
    body.ReanimationInitializeType(originX - 3.0f, originY - 8.0f, REANIM_BUNGEE);
    body.SetFramesForLayer("anim_raise");
    body.mLoopType = REANIM_PLAY_ONCE_AND_HOLD;
    body.mAnimTime = 1.0f;
    body.SetTruncateDisappearingFrames(nullptr, false);
    for (const char* prefix : {"Zombie_bungi_rightarm_lower2", "Zombie_bungi_rightarm_hand2",
            "Zombie_bungi_leftarm_lower2", "Zombie_bungi_leftarm_hand2"})
        body.AssignRenderGroupToPrefix(prefix, arms);
    body.Draw(&native);

    Reanimation flower;
    flower.ReanimationInitializeType(originX, originY + 30.0f, REANIM_SUNFLOWER);
    flower.SetFramesForLayer("anim_idle");
    flower.Draw(&native);
    body.DrawRenderGroup(&native, arms);

    // The protection leaf is a small supporting figure. The held plant stays
    // registered to the Bungee and is never independently fitted into its grip.
    Reanimation umbrella;
    umbrella.ReanimationInitializeType(145.0f, 115.0f, REANIM_UMBRELLALEAF);
    umbrella.SetFramesForLayer("anim_idle");
    umbrella.OverrideScale(0.5f, 0.5f);
    umbrella.Draw(&native);

    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
