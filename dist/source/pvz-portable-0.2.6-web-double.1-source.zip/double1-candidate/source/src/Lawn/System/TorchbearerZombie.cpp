// SPDX-License-Identifier: LGPL-3.0-or-later
#include "TorchbearerZombie.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/PvzpFoley.h"
#include "../../PvzpLib/PvzpParticle.h"
#include <algorithm>

namespace TorchbearerZombie
{
namespace
{
bool CanCarry(const Zombie& zombie)
{
    // The torch is held in the native flag carrier's INNER hand. Losing the
    // ordinary OUTER arm does not remove that grip or provide a second counter.
    return !zombie.mDead && zombie.mBodyHealth > 0 && zombie.mHasHead &&
        !zombie.mMindControlled && !zombie.mBlowingAway && !zombie.mInPool &&
        zombie.mZombiePhase == PHASE_ZOMBIE_NORMAL && zombie.mZombieHeight == HEIGHT_ZOMBIE_NORMAL;
}

bool IsBurnable(const Plant& plant)
{
    if (plant.mDead || plant.mPlantHealth <= 0 ||
        plant.mSeedType == SEED_SPIKEWEED || plant.mSeedType == SEED_SPIKEROCK) return false;
    // Preserve the original bite protections: an armed mine and an awake
    // instant-use plant get their normal opportunity to activate.
    if (plant.mState == STATE_FLOWERPOT_INVULNERABLE || plant.mState == STATE_LILYPAD_INVULNERABLE ||
        plant.mState == STATE_SQUASH_LOOK || plant.mState == STATE_SQUASH_PRE_LAUNCH) return false;
    if (plant.mSeedType == SEED_POTATOMINE && plant.mState != STATE_NOTREADY) return false;
    if (!plant.mIsAsleep)
    {
        switch (plant.mSeedType)
        {
        case SEED_JALAPENO: case SEED_CHERRYBOMB: case SEED_DOOMSHROOM:
        case SEED_ICESHROOM: case SEED_HYPNOSHROOM: case SEED_BLOVER:
            return false;
        default: break;
        }
    }
    return true;
}

void CancelWindup(Zombie& zombie)
{
    const bool attacking = IsAttacking(zombie);
    zombie.mSummonCounter = 0;
    zombie.mTargetPlantID = PLANTID_NULL;
    if (attacking && !zombie.mDead && zombie.mHasHead && zombie.mBodyHealth > 0 &&
        zombie.mZombiePhase == PHASE_ZOMBIE_NORMAL) zombie.StopEating();
}
}

bool IsZombie(const Zombie& zombie) { return zombie.mZombieType == kType; }
bool IsLit(const Zombie& zombie) { return IsZombie(zombie) && zombie.mHasObject; }
bool IsAttacking(const Zombie& zombie)
{
    return IsLit(zombie) && zombie.mSummonCounter > 0;
}
float AttackProgress(const Zombie& zombie)
{
    return IsAttacking(zombie) ?
        1.0f - std::clamp(zombie.mSummonCounter, 0, kBurnWindupTicks) / float(kBurnWindupTicks) : 0.0f;
}

void Extinguish(Zombie& zombie)
{
    if (!IsZombie(zombie)) return;
    CancelWindup(zombie);
    zombie.mHasObject = false;
}

void ValidateState(Zombie& zombie)
{
    if (!IsZombie(zombie)) return;
    if (!CanCarry(zombie) || zombie.mChilledCounter > 0 || zombie.mIceTrapCounter > 0)
        Extinguish(zombie);
}

bool TryStartBurn(Zombie& zombie, Plant& plant)
{
    if (!IsLit(zombie) || !CanCarry(zombie) || !zombie.mBoard || !IsBurnable(plant) ||
        zombie.IsImmobilizied() || zombie.mChilledCounter > 0 ||
        zombie.FindPlantTarget(ATTACKTYPE_CHEW) != &plant) return false;
    if (!IsAttacking(zombie))
    {
        zombie.mTargetPlantID = static_cast<PlantID>(zombie.mBoard->mPlants.DataArrayGetID(&plant));
        zombie.mSummonCounter = kBurnWindupTicks;
        zombie.StartEating();
    }
    return true;
}

void Update(Zombie& zombie)
{
    if (!IsZombie(zombie)) return;
    ValidateState(zombie);
    if (!IsAttacking(zombie) || zombie.IsImmobilizied() || !zombie.mBoard) return;

    Plant* target = zombie.mBoard->mPlants.DataArrayTryToGet(static_cast<unsigned int>(zombie.mTargetPlantID));
    // A shoveled bait, replaced layer or moving target cannot redirect a strike
    // into a different plant. The still-lit torch can be aimed again normally.
    if (!target || !IsBurnable(*target) || zombie.FindPlantTarget(ATTACKTYPE_CHEW) != target)
    {
        CancelWindup(zombie);
        return;
    }
    if (--zombie.mSummonCounter > 0) return;

    zombie.mHasObject = false;
    zombie.mTargetPlantID = PLANTID_NULL;
    // Reuse the original finite fireball burst at a single-plant scale. It
    // contains the native flame/smoke artwork and deals no area damage.
    if (PvzpParticleSystem* burst = zombie.mApp->AddPvzpParticle(target->mX + 40.0f,
        target->mY + 45.0f, zombie.mRenderOrder + 1, PARTICLE_FIREBALL_DEATH))
        burst->OverrideScale(nullptr, 0.32f);
    zombie.mApp->PlayFoley(FOLEY_FIREPEA);
    target->mPlantHealth = 0;
    ++zombie.mBoard->mPlantsEaten;
    target->Die();
    zombie.mBoard->mChallenge->ZombieAtePlant(target);
    zombie.StopEating();
}
}
