// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Plant;
class Zombie;

// Native metal removal funds a finite night defense. All progress, packets,
// pulled items and loose sun use the existing native saved object fields.
namespace ScrapYard
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_SCRAP_YARD;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(130);
inline constexpr ChallengeState kState = kActive;
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(131);
inline constexpr int kRulesVersion = 1;
inline constexpr int kStartingSun = 800;
inline constexpr int kWaveCount = 6;
inline constexpr int kLargestFormation = 8;
inline constexpr int kOpeningDelay = 1800;
// Leave room for two native recycling cycles and deliberate explosive timing.
inline constexpr int kFormationInterval = 3500;
inline constexpr int kCoinsPerPull = 2;
inline constexpr int kSunPerPull = 50;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kFinished); }
inline constexpr std::array<SeedType,5> kSeeds = {
    SEED_MAGNETSHROOM, SEED_WALLNUT, SEED_CHERRYBOMB, SEED_JALAPENO, SEED_SQUASH
};
struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
// Alternating lanes finish stripped bodies. The two unsupported lanes can
// share a central Cherry Bomb while the player manages their recycling tools.
inline constexpr std::array<StartingPlant,13> kStartingPlants = {{{SEED_PEASHOOTER,1,0},
    {SEED_PEASHOOTER,1,2},{SEED_PEASHOOTER,1,4},{SEED_MAGNETSHROOM,3,0},
    {SEED_MAGNETSHROOM,3,1},{SEED_MAGNETSHROOM,3,2},{SEED_MAGNETSHROOM,3,3},
    {SEED_MAGNETSHROOM,3,4},{SEED_WALLNUT,5,0},{SEED_WALLNUT,5,1},
    {SEED_WALLNUT,5,2},{SEED_WALLNUT,5,3},{SEED_WALLNUT,5,4}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
// Slow, valuable metal comes first. Later tools create distinct native threats:
// fast helmets, climbable ladders, pogo sticks and boxes that can be disarmed.
inline constexpr std::array<Formation,kWaveCount> kFormations = {{
    {{{ZOMBIE_PAIL,0,800},{ZOMBIE_PAIL,1,800},{ZOMBIE_PAIL,2,840},{ZOMBIE_PAIL,3,800},{ZOMBIE_PAIL,4,800}}},
    {{{ZOMBIE_DOOR,0,800},{ZOMBIE_DOOR,1,840},{ZOMBIE_DOOR,2,800},{ZOMBIE_DOOR,3,840},{ZOMBIE_DOOR,4,800}}},
    {{{ZOMBIE_PAIL,0,800},{ZOMBIE_LADDER,1,840},{ZOMBIE_DOOR,2,800},{ZOMBIE_DOOR,2,880},{ZOMBIE_LADDER,3,840},{ZOMBIE_PAIL,4,800}}},
    {{{ZOMBIE_PAIL,0,840},{ZOMBIE_PAIL,1,800},{ZOMBIE_POGO,1,880},{ZOMBIE_DOOR,2,800},
       {ZOMBIE_PAIL,3,800},{ZOMBIE_DOOR,3,880},{ZOMBIE_FOOTBALL,4,840}}},
    {{{ZOMBIE_LADDER,0,800},{ZOMBIE_JACK_IN_THE_BOX,1,840},{ZOMBIE_PAIL,2,800},{ZOMBIE_DOOR,2,880},
       {ZOMBIE_DOOR,3,840},{ZOMBIE_LADDER,4,800},{ZOMBIE_PAIL,4,880}}},
    {{{ZOMBIE_FOOTBALL,0,840},{ZOMBIE_LADDER,1,800},{ZOMBIE_POGO,1,880},{ZOMBIE_JACK_IN_THE_BOX,2,800},
       {ZOMBIE_DOOR,2,880},{ZOMBIE_LADDER,3,800},{ZOMBIE_PAIL,3,880},{ZOMBIE_DOOR,4,840}}}
}};
constexpr int ZombieCount(int formation)
{
    if (formation < 0 || formation >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kFormations[formation]) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
        for (int i = 0; i < ZombieCount(wave); ++i) output[wave][i] = kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_LADDER));
    for (auto& allowed : output) allowed = false;
    for (const Formation& formation : kFormations) for (const Spawn& spawn : formation)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}
void PreloadResources();
void Populate(Board& board);
void Update(Board& board);
bool CanRewardPull(const Plant& plant);
bool CanRewardPull(const Plant& plant, Zombie& zombie);
void RewardPull(Plant& plant);
static_assert(static_cast<int>(kMode) == 88);
static_assert(ZombieCount(0)+ZombieCount(1)+ZombieCount(2)+ZombieCount(3)+ZombieCount(4)+ZombieCount(5)==38);
}
