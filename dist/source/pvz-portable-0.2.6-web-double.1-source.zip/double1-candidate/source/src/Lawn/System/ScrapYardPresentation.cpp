// SPDX-License-Identifier: LGPL-3.0-or-later
#include "ScrapYardPresentation.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace ScrapYardPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("LoadingImages") || !PvzpLoadResources("DelayLoad_Background2") ||
        !Sexy::IMAGE_BACKGROUND2) return nullptr;
    ReanimatorEnsureDefinitionLoaded(REANIM_ZOMBIE, true);
    ReanimatorEnsureDefinitionLoaded(REANIM_LADDER, true);
    if (!Sexy::IMAGE_REANIM_ZOMBIE_BUCKET1 || !Sexy::IMAGE_REANIM_ZOMBIE_LADDER_1) return nullptr;

    // Fit the complete original plant alone so secondary metal does not
    // shrink its silhouette compared with neighboring native plant cards.
    auto portrait = Blank(240, 180);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    Reanimation magnet;
    magnet.ReanimationInitializeType(72.0f, 43.0f, REANIM_MAGNETSHROOM);
    magnet.SetFramesForLayer("anim_idle");
    magnet.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND2, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    // Secondary recovered metal stays behind the dominant native plant.
    // Preserve the original pixel proportions in the final card coordinates.
    Sexy::Image* ladder = Sexy::IMAGE_REANIM_ZOMBIE_LADDER_1;
    const float ladderScale = 30.0f / ladder->GetHeight();
    PvzpDrawImageScaledF(&picture, ladder, 62.0f, 29.0f, ladderScale, ladderScale);
    Sexy::Image* bucket = Sexy::IMAGE_REANIM_ZOMBIE_BUCKET1;
    const float bucketScale = 14.0f / bucket->GetWidth();
    PvzpDrawImageScaledF(&picture, bucket, 7.0f, 44.0f, bucketScale, bucketScale);
    const float scale = std::min(58.0f / bounds.mWidth, 54.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        33.0f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
