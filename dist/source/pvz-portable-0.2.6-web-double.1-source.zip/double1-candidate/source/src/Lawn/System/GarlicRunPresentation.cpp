// SPDX-License-Identifier: LGPL-3.0-or-later
#include "GarlicRunPresentation.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace GarlicRunPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}

void DrawPlant(Sexy::Graphics& graphics, ReanimationType type, const char* layer,
    const Sexy::Rect& destination)
{
    auto sprite = Blank(180, 180);
    Sexy::Graphics native(sprite.get());
    native.SetLinearBlend(true);
    Reanimation plant;
    plant.ReanimationInitializeType(40.0f, 35.0f, type);
    plant.SetFramesForLayer(layer);
    plant.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*sprite);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return;
    const float scale = std::min(static_cast<float>(destination.mWidth) / bounds.mWidth,
        static_cast<float>(destination.mHeight) / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, sprite.get(),
        destination.mX + (destination.mWidth - bounds.mWidth * scale) * 0.5f - bounds.mX * scale,
        destination.mY + (destination.mHeight - bounds.mHeight * scale) * 0.5f - bounds.mY * scale,
        scale, scale);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1) return nullptr;

    // The complete Garlic remains the centered hero. The original ground
    // traps form a small route below it, without inventing new artwork.
    auto portrait = Blank(180, 150);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    DrawPlant(native, REANIM_SPIKEWEED, "anim_idle", Sexy::Rect(30, 98, 120, 26));
    DrawPlant(native, REANIM_POTATOMINE, "anim_armed", Sexy::Rect(118, 85, 32, 30));
    DrawPlant(native, REANIM_GARLIC, "anim_idle", Sexy::Rect(50, 10, 80, 90));
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
