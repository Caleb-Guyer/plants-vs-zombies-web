// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;

// One finite artillery battle. Existing saved Challenge counters hold the
// next formation and its remaining delay; all actors retain native mechanics.
namespace CobCannonCommand
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_COB_CANNON_COMMAND;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(123);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(124);
inline constexpr int kWaveCount = 8;
inline constexpr int kOpeningDelay = 1200;
inline constexpr int kFormationInterval = 1200;
inline constexpr int kLargestFormation = 6;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kFinished); }
struct Cell { int mCol; int mRow; };
inline constexpr std::array<Cell,6> kCannons = {{{0,0},{0,1},{0,2},{0,3},{0,4},{2,2}}};
inline constexpr std::array<Cell,5> kWalls = {{{4,0},{4,1},{4,2},{4,3},{4,4}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
inline constexpr std::array<Formation,kWaveCount> kFormations = {{
    {{{ZOMBIE_NORMAL,2,760},{ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_NORMAL,2,840}}},
    {{{ZOMBIE_NORMAL,0,760},{ZOMBIE_TRAFFIC_CONE,0,800},{ZOMBIE_NORMAL,1,760},{ZOMBIE_TRAFFIC_CONE,1,800}}},
    {{{ZOMBIE_NORMAL,3,760},{ZOMBIE_TRAFFIC_CONE,3,800},{ZOMBIE_NORMAL,4,760},{ZOMBIE_TRAFFIC_CONE,4,800}}},
    {{{ZOMBIE_TRAFFIC_CONE,0,760},{ZOMBIE_PAIL,0,800},{ZOMBIE_TRAFFIC_CONE,4,760},{ZOMBIE_PAIL,4,800}}},
    {{{ZOMBIE_DOOR,1,760},{ZOMBIE_NORMAL,1,800},{ZOMBIE_DOOR,2,760},{ZOMBIE_NORMAL,2,800},{ZOMBIE_DOOR,3,760},{ZOMBIE_NORMAL,3,800}}},
    {{{ZOMBIE_FOOTBALL,0,800},{ZOMBIE_FOOTBALL,1,800},{ZOMBIE_FOOTBALL,3,800},{ZOMBIE_FOOTBALL,4,800}}},
    {{{ZOMBIE_GARGANTUAR,1,800},{ZOMBIE_TRAFFIC_CONE,0,760},{ZOMBIE_NORMAL,2,800},{ZOMBIE_PAIL,3,760},{ZOMBIE_NORMAL,4,800}}},
    {{{ZOMBIE_GARGANTUAR,3,800},{ZOMBIE_PAIL,0,760},{ZOMBIE_NORMAL,1,800},{ZOMBIE_TRAFFIC_CONE,2,760},{ZOMBIE_NORMAL,4,760},{ZOMBIE_TRAFFIC_CONE,4,800}}}
}};
constexpr int ZombieCount(int formation)
{
    if (formation < 0 || formation >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kFormations[formation]) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
        for (int i = 0; i < ZombieCount(wave); ++i) output[wave][i] = kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for (auto& allowed : output) allowed = false;
    for (const Formation& formation : kFormations) for (const Spawn& spawn : formation)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode) == 85);
static_assert(ZombieCount(0)+ZombieCount(1)+ZombieCount(2)+ZombieCount(3)+ZombieCount(4)+ZombieCount(5)+ZombieCount(6)+ZombieCount(7)==36);
}
