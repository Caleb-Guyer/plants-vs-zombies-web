// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// Native Plantern and fog artwork composed inside the standard Bonus window.
namespace LightsOutPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
