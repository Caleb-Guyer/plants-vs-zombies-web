// SPDX-License-Identifier: LGPL-3.0-or-later
#include "FireDrillPresentation.h"
#include "TorchbearerPresentation.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace FireDrillPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;
std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}
Sexy::Rect Bounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y) for (int x = 0; x < image.GetWidth(); ++x)
        if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
        {left = std::min(left, x); top = std::min(top, y); right = std::max(right, x); bottom = std::max(bottom, y);}
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right-left+1, bottom-top+1);
}
void Fit(Sexy::Graphics& graphics, Sexy::MemoryImage& image, float centerX, float baseline,
    float maxWidth, float maxHeight)
{
    const Sexy::Rect bounds = Bounds(image);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return;
    const float scale = std::min(maxWidth / bounds.mWidth, maxHeight / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, &image, centerX - (bounds.mX + bounds.mWidth * .5f) * scale,
        baseline - (bounds.mY + bounds.mHeight) * scale, scale, scale);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1) return nullptr;
    auto zombie = Blank(240, 230);
    Sexy::Graphics zombieGraphics(zombie.get()); zombieGraphics.SetLinearBlend(true);
    Reanimation carrier;
    carrier.ReanimationInitializeType(95, 45, REANIM_ZOMBIE);
    carrier.SetFramesForLayer("anim_idle");
    Zombie::SetupReanimLayers(&carrier, ZOMBIE_TORCHBEARER);
    TorchbearerPresentation::PrepareRig(carrier);
    carrier.Draw(&zombieGraphics);
    TorchbearerPresentation::DrawRig(&zombieGraphics, carrier, true, .25f);
    auto snowpea = Blank(160, 150);
    Sexy::Graphics plantGraphics(snowpea.get()); plantGraphics.SetLinearBlend(true);
    Reanimation plant;
    plant.ReanimationInitializeType(30, 35, REANIM_SNOWPEA);
    plant.SetFramesForLayer("anim_idle");
    plant.Draw(&plantGraphics);
    plant.SetFramesForLayer("anim_head_idle");
    plant.Draw(&plantGraphics);
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get()); picture.SetLinearBlend(true);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0,0,80,65), Sexy::Rect(400,140,480,390));
    Fit(picture, *zombie, 29, 61, 46, 57);
    Fit(picture, *snowpea, 62, 61, 32, 35);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
