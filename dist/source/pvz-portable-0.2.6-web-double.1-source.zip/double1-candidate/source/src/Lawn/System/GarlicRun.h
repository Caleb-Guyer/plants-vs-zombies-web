// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>
#include <string>

class Board;
class Plant;
class Zombie;

// A finite routing puzzle using the original Garlic, Spikeweed and Potato Mine
// mechanics. Existing native board/actor fields carry every saved state.
namespace GarlicRun
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_GARLIC_RUN;
inline constexpr ChallengeState kPlanning = static_cast<ChallengeState>(115);
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(116);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(117);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(118);
inline constexpr int kBoardCount = 5;
inline constexpr int kTransitionTicks = 180;
inline constexpr int kMoveCooldown = 75;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{
    return IsMode(mode) && state >= kPlanning && state <= kFinished;
}
constexpr bool IsPlanning(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kPlanning; }
constexpr bool CanMoveInState(ChallengeState state) { return state == kPlanning || state == kActive; }

struct Cell { int mCol = -1; int mRow = -1; };
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
struct Puzzle { std::array<Cell, 2> mGarlic; std::array<Spawn, 6> mZombies; };
// Never use the top lawn row: native zombie heads remain below the header.
// Interior diversions keep their native random direction; BOTH destinations
// have a trap corridor, while the bottom edge has only one legal diversion.
inline constexpr std::array<Puzzle, kBoardCount> kBoards = {{
    {{{{6,2}, {-1,-1}}}, {{{ZOMBIE_NORMAL,4,620}, {ZOMBIE_TRAFFIC_CONE,4,940}}}},
    {{{{6,4}, {-1,-1}}}, {{{ZOMBIE_NORMAL,2,620}, {ZOMBIE_TRAFFIC_CONE,2,940}}}},
    {{{{6,2}, {-1,-1}}}, {{{ZOMBIE_NORMAL,2,620}, {ZOMBIE_NORMAL,4,900}, {ZOMBIE_TRAFFIC_CONE,2,1180}}}},
    {{{{6,1}, {6,3}}}, {{{ZOMBIE_NORMAL,2,620}, {ZOMBIE_NORMAL,4,620},
        {ZOMBIE_NORMAL,2,940}, {ZOMBIE_TRAFFIC_CONE,4,940}}}},
    {{{{6,1}, {6,3}}}, {{{ZOMBIE_TRAFFIC_CONE,2,620}, {ZOMBIE_NORMAL,4,620},
        {ZOMBIE_NORMAL,2,900}, {ZOMBIE_NORMAL,4,900}, {ZOMBIE_NORMAL,2,1180}, {ZOMBIE_NORMAL,4,1180}}}}
}};
constexpr int ZombieCount(int stage)
{
    if (stage < 0 || stage >= kBoardCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kBoards[stage].mZombies) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kBoardCount);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    return kBoardCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for (auto& allowed : output) allowed = false;
    for (const Puzzle& puzzle : kBoards) for (const Spawn& spawn : puzzle.mZombies)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
bool IsPlanning(const Board& board);
bool CanMove(const Plant& plant);
bool HoldsZombie(Zombie& zombie);
void Populate(Board& board);
void ResetStage(Board& board, int stage);
void RestoreButton(Board& board);
void Commit(Board& board);
void Update(Board& board);
bool MoveGarlic(Board& board, Plant* plant, int col, int row);
std::string LevelLabel(int stage);
static_assert(static_cast<int>(kMode) == 83);
}
