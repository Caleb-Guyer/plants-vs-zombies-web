// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanicPresentation.h"
#include "../../GameConstants.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace PoolPanicPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("LoadingImages") || !PvzpLoadResources("DelayLoad_Background3") ||
        !Sexy::IMAGE_BACKGROUND3 || !Sexy::IMAGE_POOL) return nullptr;

    // Original plant rigs retain their complete parts and native proportions.
    // Kelp uses its original packet/Almanac aquarium pose so its face and arms
    // are recognizable beside a Squash resting on the native Lily Pad.
    auto portrait = Blank(240, 180);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    Reanimation pad;
    pad.ReanimationInitializeType(40.0f, 70.0f, REANIM_LILYPAD);
    pad.SetFramesForLayer("anim_idle");
    pad.Draw(&native);
    Reanimation squash;
    squash.ReanimationInitializeType(40.0f, 45.0f, REANIM_SQUASH);
    squash.SetFramesForLayer("anim_idle");
    squash.Draw(&native);
    Reanimation kelp;
    kelp.ReanimationInitializeType(115.0f, 45.0f, REANIM_TANGLEKELP);
    kelp.SetFramesForLayer("anim_idle_aquarium");
    kelp.AssignRenderGroupToTrack("anim_waterline", RENDER_GROUP_HIDDEN);
    kelp.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    // The backdrop has a white pool opening. Match the original software pool
    // composition before cropping: PoolEffect draws water at (34,278), while
    // Board::DrawBackdrop places the background at (-BOARD_OFFSET,0).
    auto landscape = Blank(Sexy::IMAGE_BACKGROUND3->GetWidth(), Sexy::IMAGE_BACKGROUND3->GetHeight());
    Sexy::Graphics ground(landscape.get());
    ground.DrawImage(Sexy::IMAGE_BACKGROUND3, 0, 0);
    ground.DrawImage(Sexy::IMAGE_POOL, 34 + BOARD_OFFSET, 278);
    picture.DrawImage(landscape.get(), Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 225, 480, 240));
    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
