// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// The complete original loaded Cob Cannon in the native Bonus thumbnail.
namespace CobCannonCommandPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
