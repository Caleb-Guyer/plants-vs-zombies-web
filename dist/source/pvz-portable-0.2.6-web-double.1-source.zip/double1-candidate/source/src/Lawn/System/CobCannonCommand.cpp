// SPDX-License-Identifier: LGPL-3.0-or-later
#include "CobCannonCommand.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include <algorithm>

namespace CobCannonCommand
{
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    board.mCurrentWave = 0;
    board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = 0;
    board.mShowShovel = false;
    board.mSeedBank->mNumPackets = 0;
    board.ClearCursor();
    // New native Cobs begin with their original 500-tick arming delay. Later
    // firing, 3000-tick reload and charge animations are entirely native.
    for (const Cell& cell : kCannons) board.AddPlant(cell.mCol,cell.mRow,SEED_COBCANNON,SEED_NONE);
    for (const Cell& cell : kWalls) board.AddPlant(cell.mCol,cell.mRow,SEED_WALLNUT,SEED_NONE);
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) ||
        challenge.mChallengeState != kActive || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mPaused || board.mTimeStopCounter > 0 || board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    const int next = std::clamp(challenge.mSurvivalStage,0,kWaveCount);
    if (next < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            for (const Spawn& spawn : kFormations[next])
            {
                if (spawn.mType == ZOMBIE_INVALID) continue;
                Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,next);
                zombie->mPosX = static_cast<float>(spawn.mX);
                zombie->mX = spawn.mX;
                zombie->UpdateReanim();
            }
            challenge.mSurvivalStage = next + 1;
            board.mCurrentWave = next + 1;
            board.mTotalSpawnedWaves = next + 1;
            challenge.mChallengeStateCounter = kFormationInterval;
            board.mZombieCountDown = board.mZombieCountDownStart = kFormationInterval;
        }
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(4,2);
}
}
