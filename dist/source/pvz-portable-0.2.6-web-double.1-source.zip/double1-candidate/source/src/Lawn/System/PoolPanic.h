// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;

// A finite native pool conveyor battle. Existing Challenge counters persist
// formation/delivery progress; the original bank owns every waiting packet.
namespace PoolPanic
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_POOL_PANIC;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(125);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(126);
inline constexpr int kWaveCount = 8;
inline constexpr int kOpeningDelay = 1600;
inline constexpr int kFormationInterval = 1200;
inline constexpr int kLargestFormation = 8;
inline constexpr int kBankSize = 10;
inline constexpr int kOpeningPackets = 4;
inline constexpr int kPacketCount = 56;
inline constexpr int kSupplyInterval = 200;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kFinished); }
inline constexpr std::array<SeedType,8> kSupplyCycle = {
    SEED_SQUASH, SEED_TANGLEKELP, SEED_CHERRYBOMB, SEED_TANGLEKELP,
    SEED_SQUASH, SEED_JALAPENO, SEED_CHERRYBOMB, SEED_TANGLEKELP
};
constexpr SeedType SeedForSupply(int ordinal)
{
    return ordinal >= 0 && ordinal < kPacketCount ? kSupplyCycle[ordinal % kSupplyCycle.size()] : SEED_NONE;
}
struct Cell { int mCol; int mRow; };
inline constexpr std::array<Cell,8> kLilyPads = {{{0,2},{1,2},{2,2},{3,2},{0,3},{1,3},{2,3},{3,3}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
inline constexpr std::array<Formation,kWaveCount> kFormations = {{
    {{{ZOMBIE_NORMAL,0,800},{ZOMBIE_NORMAL,5,800},{ZOMBIE_NORMAL,2,800},{ZOMBIE_NORMAL,3,800}}},
    {{{ZOMBIE_TRAFFIC_CONE,1,800},{ZOMBIE_TRAFFIC_CONE,4,800},{ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_TRAFFIC_CONE,3,800}}},
    {{{ZOMBIE_NORMAL,0,800},{ZOMBIE_TRAFFIC_CONE,0,840},{ZOMBIE_NORMAL,1,800},{ZOMBIE_TRAFFIC_CONE,1,840},{ZOMBIE_NORMAL,2,800},{ZOMBIE_NORMAL,3,800}}},
    {{{ZOMBIE_NORMAL,4,800},{ZOMBIE_TRAFFIC_CONE,4,840},{ZOMBIE_NORMAL,5,800},{ZOMBIE_TRAFFIC_CONE,5,840},{ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_TRAFFIC_CONE,3,800}}},
    {{{ZOMBIE_PAIL,0,800},{ZOMBIE_NORMAL,1,800},{ZOMBIE_PAIL,4,800},{ZOMBIE_NORMAL,5,800},{ZOMBIE_PAIL,2,800},{ZOMBIE_PAIL,3,800}}},
    {{{ZOMBIE_TRAFFIC_CONE,0,800},{ZOMBIE_TRAFFIC_CONE,1,800},{ZOMBIE_TRAFFIC_CONE,4,800},{ZOMBIE_TRAFFIC_CONE,5,800},{ZOMBIE_DOLPHIN_RIDER,2,800},{ZOMBIE_DOLPHIN_RIDER,3,800}}},
    {{{ZOMBIE_DOOR,0,800},{ZOMBIE_PAIL,1,840},{ZOMBIE_DOOR,4,800},{ZOMBIE_PAIL,5,840},{ZOMBIE_NORMAL,2,800},{ZOMBIE_TRAFFIC_CONE,2,840},{ZOMBIE_NORMAL,3,800},{ZOMBIE_TRAFFIC_CONE,3,840}}},
    {{{ZOMBIE_FOOTBALL,0,800},{ZOMBIE_TRAFFIC_CONE,1,840},{ZOMBIE_FOOTBALL,4,800},{ZOMBIE_TRAFFIC_CONE,5,840},{ZOMBIE_PAIL,2,800},{ZOMBIE_DOLPHIN_RIDER,2,880},{ZOMBIE_PAIL,3,800},{ZOMBIE_DOLPHIN_RIDER,3,880}}}
}};
constexpr int ZombieCount(int formation)
{
    if (formation < 0 || formation >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kFormations[formation]) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
constexpr int WaterZombieCount()
{
    int count = 0;
    for (const Formation& formation : kFormations) for (const Spawn& spawn : formation)
        count += spawn.mType != ZOMBIE_INVALID && (spawn.mRow == 2 || spawn.mRow == 3);
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
        for (int i = 0; i < ZombieCount(wave); ++i) output[wave][i] = kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOLPHIN_RIDER));
    for (auto& allowed : output) allowed = false;
    for (const Formation& formation : kFormations) for (const Spawn& spawn : formation)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank) { bank.mNumPackets = kBankSize; }
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode) == 86);
static_assert(ZombieCount(0)+ZombieCount(1)+ZombieCount(2)+ZombieCount(3)+ZombieCount(4)+ZombieCount(5)+ZombieCount(6)+ZombieCount(7)==48);
static_assert(WaterZombieCount()==20);
}
