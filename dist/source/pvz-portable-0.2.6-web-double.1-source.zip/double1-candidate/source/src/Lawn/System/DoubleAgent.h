// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Plant;

// Both sides use stock combat. Only the finite resources, authored assault and
// phase routing belong to this mode. Every checkpoint uses existing save fields.
namespace DoubleAgent
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_DOUBLE_AGENT;
inline constexpr int kProfileIndex = 90;
inline constexpr int kRulesVersion = 1;
inline constexpr ChallengeState kPlanning = static_cast<ChallengeState>(138);
inline constexpr ChallengeState kDefense = static_cast<ChallengeState>(139);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(140);
inline constexpr ChallengeState kOffense = static_cast<ChallengeState>(141);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(142);
inline constexpr ChallengeState kFailed = static_cast<ChallengeState>(143);
inline constexpr int kStartingSun = 1500;
inline constexpr int kOffenseSun = 1000;
inline constexpr int kGardenColumns = 5;
inline constexpr int kDeploymentColumn = 5;
inline constexpr int kWaveCount = 2;
inline constexpr int kOpeningDelay = 200;
inline constexpr int kFormationInterval = 1200;
inline constexpr int kTransitionTicks = 120;
inline constexpr std::array<SeedType, 7> kSeeds = {SEED_PEASHOOTER,
    SEED_SNOWPEA, SEED_REPEATER, SEED_WALLNUT, SEED_CHOMPER,
    SEED_POTATOMINE, SEED_SPIKEWEED};
inline constexpr std::array<SeedType, 6> kArmySeeds = {SEED_ZOMBIE_NORMAL,
    SEED_ZOMBIE_TRAFFIC_CONE, SEED_ZOMBIE_PAIL, SEED_ZOMBIE_SCREEN_DOOR,
    SEED_ZOMBIE_POLEVAULTER, SEED_ZOMBIE_FOOTBALL};
struct Spawn { ZombieType mType; int mRow; int mX; };
using Formation = std::array<Spawn, 5>;
inline constexpr std::array<Formation, kWaveCount> kFormations = {{
    {{{ZOMBIE_NORMAL,0,800},{ZOMBIE_NORMAL,1,800},{ZOMBIE_NORMAL,2,800},
      {ZOMBIE_NORMAL,3,800},{ZOMBIE_NORMAL,4,800}}},
    {{{ZOMBIE_TRAFFIC_CONE,0,800},{ZOMBIE_TRAFFIC_CONE,1,800},
      {ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_TRAFFIC_CONE,3,800},
      {ZOMBIE_TRAFFIC_CONE,4,800}}}
}};
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && state >= kPlanning && state <= kFailed; }
constexpr bool IsOffense(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kOffense || state == kFinished); }
constexpr bool IsGardenSeed(SeedType seed)
{ for (SeedType allowed : kSeeds) if (seed == allowed) return true; return false; }
constexpr bool IsArmySeed(SeedType seed)
{ for (SeedType allowed : kArmySeeds) if (seed == allowed) return true; return false; }
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > 5);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
        for (int i = 0; i < 5; ++i) output[wave][i] = kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count> void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_TRAFFIC_CONE));
    for (auto& allowed : output) allowed = false;
    output[ZOMBIE_NORMAL] = output[ZOMBIE_TRAFFIC_CONE] = true;
}
template<class Bank> void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}
bool IsPlanning(const Board& board);
bool IsOffense(const Board& board);
bool CanPlantAt(const Board& board, int col, int row, SeedType seed);
bool Validate(const Board& board);
void PreloadResources();
void Populate(Board& board);
void RestoreButton(Board& board);
void Commit(Board& board);
void Update(Board& board);
void OnBrainsCleared(Board& board, int row);
static_assert(static_cast<int>(kMode) == 91 && kProfileIndex < 100);
}
