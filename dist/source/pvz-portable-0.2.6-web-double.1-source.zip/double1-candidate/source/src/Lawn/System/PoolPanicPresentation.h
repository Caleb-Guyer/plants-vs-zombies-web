// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// Original Squash, Tangle Kelp and Lily Pad rigs in the native Bonus thumbnail.
namespace PoolPanicPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
