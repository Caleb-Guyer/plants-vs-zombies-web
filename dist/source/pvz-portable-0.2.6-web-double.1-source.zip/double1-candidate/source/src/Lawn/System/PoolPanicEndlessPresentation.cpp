// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanicEndlessPresentation.h"
#include "../../GameConstants.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/PvzpStringFile.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/Font.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <string>
#include <vector>

namespace PoolPanicEndlessPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;
std::unique_ptr<Sexy::MemoryImage> sBestLabel;
uint32_t sBestRecord = 0;
std::string sBestText;
std::string sBestNativeText;
const Sexy::_Font* sBestFront = nullptr;

std::string BestRecordText(uint32_t record)
{
    if (record < 1000) return "Best: " + std::to_string(record);
    constexpr uint64_t divisors[] = {1000, 1000000, 1000000000};
    constexpr char suffixes[] = {'k', 'm', 'b'};
    const uint64_t value = record;
    int unit = record >= 1000000000 ? 2 : record >= 1000000 ? 1 : 0;
    if (unit < 2 && (value + divisors[unit] / 2) / divisors[unit] >= 1000) ++unit;
    const uint64_t divisor = divisors[unit];
    std::string count;
    if (value < 10 * divisor)
    {
        const uint64_t tenths = (value * 10 + divisor / 2) / divisor;
        count = std::to_string(tenths / 10);
        if (tenths % 10) count += "." + std::to_string(tenths % 10);
    }
    else count = std::to_string((value + divisor / 2) / divisor);
    count += suffixes[unit];
    return "Best: " + count;
}

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("LoadingImages") || !PvzpLoadResources("DelayLoad_Background3") ||
        !Sexy::IMAGE_BACKGROUND3 || !Sexy::IMAGE_POOL) return nullptr;

    // Keep the original riding zombie and dolphin in their complete native
    // assembly. No independently moved limbs, redrawn parts or extra badges.
    auto portrait = Blank(300, 220);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    Reanimation rider;
    rider.ReanimationInitializeType(60.0f, 35.0f, REANIM_ZOMBIE_DOLPHINRIDER);
    rider.SetFramesForLayer("anim_ride");
    rider.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    // The backdrop has a white pool opening. Match the original software pool
    // composition before cropping: PoolEffect draws water at (34,278), while
    // Board::DrawBackdrop places the background at (-BOARD_OFFSET,0).
    auto landscape = Blank(Sexy::IMAGE_BACKGROUND3->GetWidth(), Sexy::IMAGE_BACKGROUND3->GetHeight());
    Sexy::Graphics ground(landscape.get());
    ground.DrawImage(Sexy::IMAGE_BACKGROUND3, 0, 0);
    ground.DrawImage(Sexy::IMAGE_POOL, 34 + BOARD_OFFSET, 278);
    picture.DrawImage(landscape.get(), Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 225, 480, 240));
    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

bool DrawFittedBestRecord(Sexy::Graphics* graphics, uint32_t record, std::string_view nativeText, int x, int y)
{
    Sexy::_Font* front = Sexy::FONT_BRIANNETOD12;
    if (!record || !front) return false;
    if (sBestLabel && record == sBestRecord && nativeText == sBestNativeText && front == sBestFront)
    {
        graphics->DrawImage(sBestLabel.get(), x + 13, y + 51);
        return true;
    }
    // Keep the recognizable hero above a single small native-font stamp.
    // Counts are abbreviated instead of shrinking original glyphs to fit.
    auto label = Blank(80, 18);
    Sexy::Graphics ink(label.get());
    ink.SetLinearBlend(true);
    const std::string text = BestRecordText(record);
    PvzpDrawString(&ink, text, 41, 15, front, Sexy::Color(42, 42, 90), DS_ALIGN_CENTER);
    PvzpDrawString(&ink, text, 40, 14, front, Sexy::Color(253, 245, 173), DS_ALIGN_CENTER);
    sBestLabel = std::move(label);
    sBestRecord = record;
    sBestText = text;
    sBestNativeText = nativeText;
    sBestFront = front;
    graphics->DrawImage(sBestLabel.get(), x + 13, y + 51);
    return true;
}

void DisposeImage()
{
    sCard.reset();
    sBestLabel.reset();
    sBestRecord = 0;
    sBestText.clear();
    sBestNativeText.clear();
    sBestFront = nullptr;
}
}
