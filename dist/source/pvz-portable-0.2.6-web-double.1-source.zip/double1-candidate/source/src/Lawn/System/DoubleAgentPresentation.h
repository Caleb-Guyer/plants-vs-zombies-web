// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include <string>
namespace Sexy { class Image; }
namespace DoubleAgentPresentation
{
Sexy::Image* GetBonusImage();
std::string LevelLabel(int phase);
void DisposeImage();
}
