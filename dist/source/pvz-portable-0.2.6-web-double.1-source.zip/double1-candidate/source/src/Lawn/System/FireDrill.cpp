// SPDX-License-Identifier: LGPL-3.0-or-later
#include "FireDrill.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../SeedPacket.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include <algorithm>
#include "PlayerInfo.h"

namespace FireDrill
{
bool IsUnlocked(const LawnApp* app)
{ return app && app->mPlayerInfo && app->mPlayerInfo->mChallengeRecords[kProfileIndex]>0; }

void PreloadResources()
{
    for(SeedType seed:kSeeds) Plant::PreloadPlantResources(seed);
    for(const Formation& wave:kFormations) for(const Spawn& spawn:wave)
        if(spawn.mType!=ZOMBIE_INVALID) Zombie::PreloadZombieResources(spawn.mType);
}

void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    challenge.mChallengeScore = 0;
    challenge.mChallengeGridY = kRulesVersion;
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = kStartingSun;
    board.mShowShovel = true;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (const StartingPlant& plant : kStartingPlants)
        board.AddPlant(plant.mCol,plant.mRow,plant.mSeed,SEED_NONE);
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) || challenge.mChallengeState != kActive ||
        board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.mTimeStopCounter > 0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = true;
    const int next = std::clamp(challenge.mSurvivalStage,0,kWaveCount);
    if (next < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        // Keep deliberate recovery time between authored formations.
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter != 0) return;
        board.NextWaveComing();
        for (const Spawn& spawn : kFormations[next])
        {
            if (spawn.mType == ZOMBIE_INVALID) continue;
            Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,next);
            zombie->mPosX = static_cast<float>(spawn.mX);
            zombie->mX = spawn.mX;
            zombie->UpdateReanim();
        }
        challenge.mSurvivalStage = next + 1;
        board.mCurrentWave = board.mTotalSpawnedWaves = next + 1;
        board.mZombieHealthWaveStart = board.TotalZombiesHealthInWave(next);
        board.mZombieHealthToNextWave = -1;
        challenge.mChallengeStateCounter = kFormationInterval;
        board.mZombieCountDown = board.mZombieCountDownStart = kFormationInterval;
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(4,2);
}
}
