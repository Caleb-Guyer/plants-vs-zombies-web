// SPDX-License-Identifier: LGPL-3.0-or-later
#include "GarlicRun.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../CursorObject.h"
#include "../Coin.h"
#include "../GridItem.h"
#include "../Widget/GameButton.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpParticle.h"
#include <algorithm>
#include <format>

namespace GarlicRun
{
bool IsPlanning(const Board& board)
{
    return board.mApp && board.mChallenge && IsPlanning(board.mApp->mGameMode, board.mChallenge->mChallengeState);
}
bool CanMove(const Plant& plant)
{
    return plant.mBoard && plant.mSeedType == SEED_GARLIC && plant.mIsOnBoard &&
        !plant.mDead && !plant.mSquished && plant.mPlantHealth > 0 && plant.mOnBungeeState == NOT_ON_BUNGEE;
}
bool HoldsZombie(Zombie& zombie)
{
    return zombie.mBoard && IsPlanning(*zombie.mBoard) && zombie.IsOnBoard() && !zombie.IsDeadOrDying();
}
std::string LevelLabel(int stage)
{
    return std::format("Garlic Run - {}/{}", std::clamp(stage + 1, 1, kBoardCount), kBoardCount);
}
void RestoreButton(Board& board)
{
    if (!board.mStoreButton) return;
    GameButton* button = board.mStoreButton.get();
    const bool planning = IsPlanning(board);
    button->mParentWidget = &board;
    button->mBtnNoDraw = !planning;
    button->mDisabled = !planning;
    button->SetLabel("[LETS_ROCK_BUTTON]");
    button->Resize(224, 12, 210, 46);
}
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    const int stage = std::clamp(challenge.mSurvivalStage, 0, kBoardCount - 1);
    challenge.mSurvivalStage = stage;
    challenge.mChallengeState = kPlanning;
    challenge.mChallengeStateCounter = 0;
    board.mCurrentWave = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = 100000;
    board.mShowShovel = false;
    board.mSunMoney = 0;
    board.mSeedBank->mNumPackets = 0;
    board.ClearCursor();
    for (int row : {1, 3})
    {
        for (int col : {2, 3, 4}) board.AddPlant(col, row, SEED_SPIKEWEED, SEED_NONE);
        // Keep the native unarmed pose and 1500-tick fuse. Only preparation
        // pauses that fuse; Let's Rock starts ordinary mine behavior.
        board.AddPlant(1, row, SEED_POTATOMINE, SEED_NONE);
    }
    for (const Cell& cell : kBoards[stage].mGarlic)
        if (cell.mCol >= 0) board.AddPlant(cell.mCol, cell.mRow, SEED_GARLIC, SEED_NONE);
    for (const Spawn& spawn : kBoards[stage].mZombies)
    {
        if (spawn.mType == ZOMBIE_INVALID) continue;
        Zombie* zombie = board.AddZombieInRow(spawn.mType, spawn.mRow, 0);
        zombie->mPosX = static_cast<float>(spawn.mX);
        zombie->mX = spawn.mX;
        if (Reanimation* body = board.mApp->ReanimationTryToGet(zombie->mBodyReanimID))
        {
            if (body->TrackExists("anim_idle")) zombie->PlayZombieReanim("anim_idle", REANIM_LOOP, 0, 12.0f);
            else body->mAnimRate = 0.0f;
        }
        zombie->UpdateReanim();
    }
    // Native intro camera finishes before the preparation control is shown.
    board.mStoreButton->mBtnNoDraw = true;
    board.mStoreButton->mDisabled = true;
}
void ResetStage(Board& board, int stage)
{
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) zombie->DieNoLoot();
    for (Plant* plant : board.mPlants) if (!plant->mDead) plant->Die();
    for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
    for (GridItem* item : board.mGridItems) if (!item->mDead) item->GridItemDie();
    board.mChallenge->mSurvivalStage = std::clamp(stage, 0, kBoardCount - 1);
    Populate(board);
}
void Commit(Board& board)
{
    if (!IsPlanning(board) || board.mApp->mGameScene != SCENE_PLAYING || board.mPaused ||
        board.mTimeStopCounter > 0 || board.HasLevelAwardDropped()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    board.mChallenge->mChallengeState = kActive;
    board.mStoreButton->mBtnNoDraw = true;
    board.mStoreButton->mDisabled = true;
    for (Zombie* zombie : board.mZombies)
        if (!zombie->mDead && !zombie->IsDeadOrDying()) zombie->StartWalkAnim(0);
}
void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState)) return;
    Plant* selected = board.mPlants.DataArrayTryToGet(board.mCursorObject->mGlovePlantID);
    if (board.mCursorObject->mGlovePlantID != PLANTID_NULL &&
        (!selected || !CanMove(*selected) || !CanMoveInState(challenge.mChallengeState) ||
            board.mLevelComplete || board.HasLevelAwardDropped()))
    {
        board.ClearCursor();
        selected = nullptr;
    }
    if (board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.mTimeStopCounter > 0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    if (CanMoveInState(challenge.mChallengeState) && challenge.mChallengeStateCounter > 0)
        --challenge.mChallengeStateCounter;
    if (selected) selected->mHighlighted = true;
    if (challenge.mChallengeState == kPlanning)
    {
        if (board.mStoreButton->mBtnNoDraw) RestoreButton(board);
        return;
    }
    if (challenge.mChallengeState == kTransition)
    {
        if (--challenge.mChallengeStateCounter > 0) return;
        challenge.PuzzleNextStageClear();
        for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
        Populate(board);
        return;
    }
    if (challenge.mChallengeState != kActive || board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    if (challenge.mSurvivalStage == kBoardCount - 1)
    {
        challenge.mChallengeState = kFinished;
        challenge.SpawnLevelAward(4, 2);
    }
    else
    {
        challenge.mChallengeState = kTransition;
        challenge.mChallengeStateCounter = kTransitionTicks;
    }
}
bool MoveGarlic(Board& board, Plant* plant, int col, int row)
{
    if (!board.mChallenge || !IsCurrentRules(board.mApp->mGameMode, board.mChallenge->mChallengeState) ||
        !CanMoveInState(board.mChallenge->mChallengeState) || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mPaused || board.mTimeStopCounter > 0 || board.mLevelComplete || board.HasLevelAwardDropped() ||
        board.mChallenge->mChallengeStateCounter > 0 || !plant || plant->mBoard != &board || !CanMove(*plant) ||
        col < 0 || col >= 9 || row < 0 || row >= 5 || (plant->mPlantCol == col && plant->mRow == row) ||
        board.GetTopPlantAt(col, row, TOPPLANT_ANY) || board.CanPlantAt(col, row, SEED_GARLIC) != PLANTING_OK) return false;
    const int oldX = plant->mX, oldY = plant->mY;
    plant->mX = board.GridToPixelX(col, row);
    plant->mY = board.GridToPixelY(col, row);
    plant->mPlantCol = col;
    plant->mRow = plant->mStartRow = row;
    plant->mRenderOrder = plant->CalcRenderOrder();
    if (PvzpParticleSystem* particle = board.mApp->ParticleTryToGet(plant->mParticleID))
        if (particle->mEmitterList.mSize)
        {
            PvzpParticleEmitter* emitter = particle->mParticleHolder->mEmitters.DataArrayGet(
                static_cast<unsigned int>(particle->mEmitterList.GetHead()->mValue));
            particle->SystemMove(emitter->mSystemCenter.x + plant->mX - oldX, emitter->mSystemCenter.y + plant->mY - oldY);
        }
    board.mChallenge->mChallengeStateCounter = kMoveCooldown;
    board.DoPlantingEffects(col, row, plant);
    return true;
}
}
