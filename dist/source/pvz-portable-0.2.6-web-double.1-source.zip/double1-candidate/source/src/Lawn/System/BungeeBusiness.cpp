// SPDX-License-Identifier: LGPL-3.0-or-later
#include "BungeeBusiness.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../Coin.h"
#include "../GridItem.h"
#include "../Projectile.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include <algorithm>
#include <format>

namespace BungeeBusiness
{
namespace
{
int TargetBit(const Board& board, int col, int row)
{
    const int stage = std::clamp(board.mChallenge->mSurvivalStage, 0, kBoardCount - 1);
    int index = 0;
    for (const Defender& defender : kBoards[stage].mPlants)
    {
        if (defender.mSeed != SEED_SUNFLOWER) continue;
        if (defender.mCol == col && defender.mRow == row) return 1 << index;
        ++index;
    }
    return 0;
}
void Fail(Board& board)
{
    board.mChallenge->mChallengeState = kFailed;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    board.ZombiesWon(nullptr);
}
}

std::string LevelLabel(int stage)
{
    return std::format("Bungee Business - {}/{}", std::clamp(stage + 1, 1, kBoardCount), kBoardCount);
}

void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    const int stage = std::clamp(challenge.mSurvivalStage, 0, kBoardCount - 1);
    challenge.mSurvivalStage = stage;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = 0;
    challenge.mChallengeScore = 0;
    // This existing saved field is the unique authored-target completion mask.
    challenge.mScaryPotterPots = 0;
    board.mSunMoney = kBoards[stage].mSun;
    board.mCurrentWave = 0;
    board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = 100000;
    board.mNextSurvivalStageCounter = 0;
    board.mShowShovel = false;
    board.mBonusLawnMowersRemaining = 0;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (const Defender& defender : kBoards[stage].mPlants)
    {
        if (defender.mSeed == SEED_NONE) continue;
        Plant* plant = board.NewPlant(defender.mCol, defender.mRow, defender.mSeed, SEED_NONE);
        board.mChallenge->IZombieSetupPlant(plant);
    }
}

void ResetStage(Board& board, int stage)
{
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) zombie->DieNoLoot();
    for (Plant* plant : board.mPlants) if (!plant->mDead) plant->Die();
    for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
    for (GridItem* item : board.mGridItems) if (!item->mDead) item->GridItemDie();
    for (Projectile* projectile : board.mProjectiles) if (!projectile->mDead) projectile->Die();
    board.mChallenge->mSurvivalStage = std::clamp(stage, 0, kBoardCount - 1);
    board.mLevelAwardSpawned = false;
    Populate(board);
}

bool CanDeploy(Board& board, int col, int row, SeedType seed)
{
    if (!board.mChallenge || board.mChallenge->mChallengeState != kActive ||
        board.mLevelComplete || board.HasLevelAwardDropped() ||
        col < 0 || col >= 9 || row < 0 || row >= 5 ||
        std::find(kSeeds.begin(), kSeeds.end(), seed) == kSeeds.end()) return false;
    if (seed != SEED_ZOMBIE_BUNGEE) return col >= kDeploymentColumn;
    if (col >= kDeploymentColumn || board.BungeeIsTargetingCell(col, row)) return false;
    Plant* plant = board.GetTopPlantAt(col, row, TOPPLANT_BUNGEE_ORDER);
    return plant && !plant->mDead && !plant->NotOnGround();
}

void OnBungeeExit(Zombie& zombie)
{
    Board* board = zombie.mBoard;
    if (!board || !board->mChallenge || !IsMode(board->mApp->mGameMode) ||
        board->mChallenge->mChallengeState != kActive || zombie.mDead || zombie.IsDeadOrDying() ||
        zombie.mZombieType != ZOMBIE_BUNGEE || zombie.mZombiePhase != PHASE_BUNGEE_RISING ||
        zombie.mAltitude < 600.0f || zombie.mRelatedZombieID != ZOMBIEID_NULL) return;
    Plant* plant = board->mPlants.DataArrayTryToGet(zombie.mTargetPlantID);
    if (!plant || plant->mDead || plant->mSquished || plant->mPlantHealth <= 0 || plant->mSeedType != SEED_SUNFLOWER ||
        plant->mPlantCol != zombie.mTargetCol || plant->mRow != zombie.mRow ||
        plant->mOnBungeeState != RISING_WITH_BUNGEE) return;
    const int bit = TargetBit(*board, plant->mPlantCol, plant->mRow);
    if (bit == 0 || (board->mChallenge->mScaryPotterPots & bit) != 0) return;
    board->mChallenge->mScaryPotterPots |= bit;
    ++board->mChallenge->mChallengeScore;
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) || board.mPaused ||
        board.mApp->mGameScene != SCENE_PLAYING || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    if (challenge.mChallengeState == kTransition)
    {
        if (--challenge.mChallengeStateCounter > 0) return;
        challenge.PuzzleNextStageClear();
        for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
        for (Projectile* projectile : board.mProjectiles) if (!projectile->mDead) projectile->Die();
        Populate(board);
        return;
    }
    if (challenge.mChallengeState != kActive) return;
    const int stage = std::clamp(challenge.mSurvivalStage, 0, kBoardCount - 1);
    int remaining = 0;
    for (const Defender& target : kBoards[stage].mPlants)
    {
        if (target.mSeed != SEED_SUNFLOWER) continue;
        const int bit = TargetBit(board, target.mCol, target.mRow);
        if ((challenge.mScaryPotterPots & bit) != 0) continue;
        bool present = false;
        // A rising plant is still a live target until its carrier leaves.
        for (Plant* plant : board.mPlants)
            if (!plant->mDead && !plant->mSquished && plant->mPlantHealth > 0 && plant->mSeedType == SEED_SUNFLOWER &&
                plant->mPlantCol == target.mCol && plant->mRow == target.mRow) present = true;
        if (!present) { Fail(board); return; }
        ++remaining;
    }
    if (remaining == 0 && challenge.mChallengeScore == TargetCount(stage))
    {
        board.ClearCursor();
        board.ClearAdviceImmediately();
        if (stage == kBoardCount - 1)
        {
            challenge.mChallengeState = kFinished;
            challenge.SpawnLevelAward(2, 2);
        }
        else
        {
            challenge.mChallengeState = kTransition;
            challenge.mChallengeStateCounter = kTransitionTicks;
        }
        return;
    }
    if (board.mSunMoney + board.CountSunBeingCollected() >= kBungeeCost) return;
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) return;
    Fail(board);
}
}
