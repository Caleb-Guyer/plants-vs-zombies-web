// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>

class Board;
class GridItem;

// A finite I, Zombie army, released through the original Vasebreaker hammer.
// All progress uses existing saved Challenge and GridItem fields.
namespace VaseAmbush
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_VASE_AMBUSH;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(132);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(133);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(134);
inline constexpr ChallengeState kFailed = static_cast<ChallengeState>(135);
inline constexpr int kBoardCount = 5;
inline constexpr int kTransitionTicks = 120;
inline constexpr int kMaxPlants = 15;
inline constexpr int kMaxVases = 15;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && state >= kActive && state <= kFailed; }
struct Defender { SeedType mSeed=SEED_NONE; int mCol=0; int mRow=0; };
struct Vase { ZombieType mType=ZOMBIE_INVALID; int mCol=0; int mRow=0; };
struct Puzzle { std::array<Defender,kMaxPlants> mPlants; std::array<Vase,kMaxVases> mVases; };

inline constexpr std::array<Puzzle,kBoardCount> kBoards = {{
    // A protected advance: far-back cones can walk ahead of the nearer walkers.
    {{{{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,1,1},{SEED_PEASHOOTER,1,2},{SEED_PEASHOOTER,1,3},{SEED_PEASHOOTER,1,4}}},
     {{{ZOMBIE_TRAFFIC_CONE,8,0},{ZOMBIE_TRAFFIC_CONE,8,1},{ZOMBIE_TRAFFIC_CONE,8,2},{ZOMBIE_TRAFFIC_CONE,8,3},{ZOMBIE_TRAFFIC_CONE,8,4},{ZOMBIE_NORMAL,6,0},{ZOMBIE_NORMAL,6,1},{ZOMBIE_NORMAL,6,2},{ZOMBIE_NORMAL,6,3},{ZOMBIE_NORMAL,6,4}}}},
    // Cold rows flank an easier center; the outside lanes need a shorter protected push.
    {{{{SEED_REPEATER,1,1},{SEED_REPEATER,1,3},{SEED_SNOWPEA,2,1},{SEED_SNOWPEA,2,2},{SEED_SNOWPEA,2,3},{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,1,2},{SEED_PEASHOOTER,1,4},{SEED_PEASHOOTER,3,0},{SEED_PEASHOOTER,3,1},{SEED_PEASHOOTER,3,3},{SEED_PEASHOOTER,3,4}}},
     {{{ZOMBIE_PAIL,8,0},{ZOMBIE_PAIL,8,1},{ZOMBIE_PAIL,8,2},{ZOMBIE_PAIL,8,3},{ZOMBIE_PAIL,8,4},{ZOMBIE_NORMAL,7,0},{ZOMBIE_TRAFFIC_CONE,7,1},{ZOMBIE_TRAFFIC_CONE,7,2},{ZOMBIE_TRAFFIC_CONE,7,3},{ZOMBIE_NORMAL,7,4},{ZOMBIE_NORMAL,6,0},{ZOMBIE_DOOR,6,1},{ZOMBIE_NORMAL,6,2},{ZOMBIE_DOOR,6,3},{ZOMBIE_NORMAL,6,4}}}},
    // Three Chompers need bait; two awake Fume-shrooms cover the intervening lanes.
    {{{{SEED_REPEATER,1,0},{SEED_REPEATER,1,2},{SEED_REPEATER,1,4},{SEED_SPIKEWEED,2,0},{SEED_SPIKEWEED,2,2},{SEED_SPIKEWEED,2,4},{SEED_CHOMPER,3,0},{SEED_CHOMPER,3,2},{SEED_CHOMPER,3,4},{SEED_PEASHOOTER,1,1},{SEED_PEASHOOTER,1,3},{SEED_FUMESHROOM,3,1},{SEED_FUMESHROOM,3,3}}},
     {{{ZOMBIE_PAIL,8,0},{ZOMBIE_PAIL,8,2},{ZOMBIE_PAIL,8,4},{ZOMBIE_PAIL,8,1},{ZOMBIE_PAIL,8,3},{ZOMBIE_TRAFFIC_CONE,7,0},{ZOMBIE_TRAFFIC_CONE,7,2},{ZOMBIE_TRAFFIC_CONE,7,4},{ZOMBIE_TRAFFIC_CONE,6,0},{ZOMBIE_NORMAL,6,1},{ZOMBIE_TRAFFIC_CONE,6,2},{ZOMBIE_NORMAL,6,3},{ZOMBIE_TRAFFIC_CONE,6,4}}}},
    // Two mines and two magnets ask which valuable armor the front doors should spend.
    {{{{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,1,2},{SEED_PEASHOOTER,1,4},{SEED_POTATOMINE,3,1},{SEED_POTATOMINE,3,3},{SEED_SNOWPEA,2,1},{SEED_SNOWPEA,2,3},{SEED_MAGNETSHROOM,3,0},{SEED_MAGNETSHROOM,3,4},{SEED_SPIKEWEED,3,2}}},
     {{{ZOMBIE_PAIL,8,0},{ZOMBIE_PAIL,8,1},{ZOMBIE_PAIL,8,2},{ZOMBIE_PAIL,8,3},{ZOMBIE_PAIL,8,4},{ZOMBIE_TRAFFIC_CONE,7,0},{ZOMBIE_TRAFFIC_CONE,7,1},{ZOMBIE_TRAFFIC_CONE,7,2},{ZOMBIE_TRAFFIC_CONE,7,3},{ZOMBIE_TRAFFIC_CONE,7,4},{ZOMBIE_DOOR,6,0},{ZOMBIE_DOOR,6,1},{ZOMBIE_DOOR,6,2},{ZOMBIE_DOOR,6,3},{ZOMBIE_DOOR,6,4}}}},
    // Shared Threepeater fire, magnets and a Chomper combine the earlier ideas.
    {{{{SEED_PEASHOOTER,1,0},{SEED_THREEPEATER,1,1},{SEED_MAGNETSHROOM,3,1},{SEED_CHOMPER,3,2},{SEED_PEASHOOTER,1,3},{SEED_MAGNETSHROOM,3,3},{SEED_PEASHOOTER,1,4},{SEED_PEASHOOTER,2,4}}},
     {{{ZOMBIE_TRAFFIC_CONE,8,0},{ZOMBIE_TRAFFIC_CONE,8,1},{ZOMBIE_TRAFFIC_CONE,8,2},{ZOMBIE_TRAFFIC_CONE,8,3},{ZOMBIE_TRAFFIC_CONE,8,4},{ZOMBIE_TRAFFIC_CONE,7,0},{ZOMBIE_DOOR,7,1},{ZOMBIE_TRAFFIC_CONE,7,2},{ZOMBIE_DOOR,7,3},{ZOMBIE_TRAFFIC_CONE,7,4},{ZOMBIE_TRAFFIC_CONE,6,0},{ZOMBIE_TRAFFIC_CONE,6,1},{ZOMBIE_TRAFFIC_CONE,6,2},{ZOMBIE_TRAFFIC_CONE,6,3},{ZOMBIE_TRAFFIC_CONE,6,4}}}}
}};
constexpr int PlantCount(int stage)
{
    if(stage<0 || stage>=kBoardCount) return 0;
    int count=0;for(const Defender& entry:kBoards[stage].mPlants) count+=entry.mSeed!=SEED_NONE;
    return count;
}
constexpr int VaseCount(int stage)
{
    if(stage<0 || stage>=kBoardCount) return 0;
    int count=0;for(const Vase& entry:kBoards[stage].mVases) count+=entry.mType!=ZOMBIE_INVALID;
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    for(auto& wave:output)for(auto& zombie:wave)zombie=ZOMBIE_INVALID;
    return kBoardCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for(auto& allowed:output)allowed=false;
    for(ZombieType type:{ZOMBIE_NORMAL,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,ZOMBIE_DOOR})output[type]=true;
}
void PreloadResources();
void Populate(Board& board);
void ResetStage(Board& board,int stage);
void Update(Board& board);
bool CanBreak(Board& board);
void MalletPot(Board& board,GridItem* pot);
void OnBrainsCleared(Board& board,int row);
static_assert(static_cast<int>(kMode)==89 && VaseCount(0)==10 && VaseCount(4)==15);
}
