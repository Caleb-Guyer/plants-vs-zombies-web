// SPDX-License-Identifier: LGPL-3.0-or-later
#include "DoubleAgentPresentation.h"
#include "DoubleAgent.h"
#include "ReanimationLawn.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <memory>
#include <vector>

namespace DoubleAgentPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}

bool Fit(Sexy::Graphics& graphics, Sexy::MemoryImage& image, float centerX,
    float baseline, float maxWidth, float maxHeight)
{
    const Sexy::Rect bounds = VisibleBounds(image);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return false;
    const float scale = std::min(maxWidth / bounds.mWidth, maxHeight / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, &image,
        centerX - (bounds.mX + bounds.mWidth * .5f) * scale,
        baseline - (bounds.mY + bounds.mHeight) * scale, scale, scale);
    return true;
}
}

std::string LevelLabel(int phase)
{
    // These are the mode's existing serialized ChallengeState values. They
    // change the original footer text rather than introducing another panel.
    switch (static_cast<ChallengeState>(phase))
    {
    case DoubleAgent::kPlanning: return "Double Agent - Prepare";
    case DoubleAgent::kDefense: return "Double Agent - Defend";
    case DoubleAgent::kTransition: return "Double Agent - Switch Sides";
    case DoubleAgent::kOffense: return "Double Agent - I, Zombie";
    default: return "Double Agent";
    }
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!gLawnApp || !gLawnApp->mReanimatorCache || !PvzpLoadResources("LoadingImages") ||
        !PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1 || !Sexy::IMAGE_BRAIN)
        return nullptr;

    // The native cache renders the complete original plant, including its
    // separate head layer, and the complete stock zombie. No replacement art.
    auto plant = gLawnApp->mReanimatorCache->MakeCachedPlantFrame(SEED_PEASHOOTER, VARIATION_NORMAL);
    auto zombie = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_NORMAL);
    auto sun = Blank(160, 160);
    Sexy::Graphics sunlight(sun.get());
    sunlight.SetLinearBlend(true);
    Reanimation nativeSun;
    nativeSun.ReanimationInitializeType(80, 80, REANIM_SUN);
    nativeSun.Draw(&sunlight);
    auto* brain = dynamic_cast<Sexy::MemoryImage*>(Sexy::IMAGE_BRAIN);
    if (!plant || !zombie || !brain) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    // Sun and brains identify the two native roles. The two full silhouettes
    // stay distinct, with their feet on the same lawn and no caption or tips.
    if (!Fit(picture, *plant, 22, 61, 36, 35) ||
        !Fit(picture, *zombie, 60, 61, 34, 56) ||
        !Fit(picture, *sun, 12, 18, 14, 14) ||
        !Fit(picture, *brain, 32, 19, 16, 13)) return nullptr;
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
