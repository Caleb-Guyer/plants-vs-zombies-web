// SPDX-License-Identifier: LGPL-3.0-or-later
#include "DoubleAgent.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../GridItem.h"
#include "../Coin.h"
#include "../Projectile.h"
#include "../SeedPacket.h"
#include "../Widget/GameButton.h"
#include "../../LawnApp.h"
#include <algorithm>
#include <cstring>

namespace DoubleAgent
{
bool IsPlanning(const Board& board)
{ return board.mApp && board.mChallenge && IsMode(board.mApp->mGameMode) && board.mChallenge->mChallengeState == kPlanning; }
bool IsOffense(const Board& board)
{
    if (!board.mApp || !board.mChallenge || !IsMode(board.mApp->mGameMode)) return false;
    const Challenge& challenge = *board.mChallenge;
    return IsOffense(board.mApp->mGameMode, challenge.mChallengeState) ||
        (challenge.mChallengeState == kFailed && challenge.mChallengeGridX == 1);
}
bool CanPlantAt(const Board& board, int col, int row, SeedType seed)
{
    if (row < 0 || row >= 5 || col < 0 || col >= 9 || !board.mChallenge) return false;
    if (IsPlanning(board)) return col < kGardenColumns && IsGardenSeed(seed);
    return board.mChallenge->mChallengeState == kOffense && col >= kDeploymentColumn && IsArmySeed(seed);
}
bool Validate(const Board& board)
{
    if (!board.mChallenge || !board.mSeedBank || !board.mApp || !IsMode(board.mApp->mGameMode)) return false;
    const Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) ||
        challenge.mChallengeGridY != kRulesVersion || challenge.mChallengeGridX < 0 || challenge.mChallengeGridX > 1 ||
        challenge.mSurvivalStage < 0 || challenge.mSurvivalStage > kWaveCount ||
        challenge.mChallengeScore < 0 || challenge.mChallengeScore > 5 ||
        challenge.mChallengeStateCounter < 0 || challenge.mChallengeStateCounter > kFormationInterval) return false;
    for (int col = 0; col < 9; ++col) for (int row = 0; row < 6; ++row)
    {
        const int value = challenge.mBeghouledEated[col][row];
        if (value == 0) continue;
        if (value < 0 || col >= kGardenColumns || row >= 5 || !IsGardenSeed(static_cast<SeedType>(value - 1))) return false;
    }
    if (challenge.mChallengeState == kPlanning && challenge.mChallengeGridX != 0) return false;
    if ((challenge.mChallengeState == kDefense || challenge.mChallengeState == kTransition) && challenge.mChallengeGridX != 0) return false;
    if ((challenge.mChallengeState == kOffense || challenge.mChallengeState == kFinished) && challenge.mChallengeGridX != 1) return false;
    const int packets = IsPlanning(board) ? static_cast<int>(kSeeds.size()) :
        IsOffense(board) ? static_cast<int>(kArmySeeds.size()) : 0;
    if (board.mSeedBank->mNumPackets != packets || board.mSunMoney < 0 ||
        board.mSunMoney > (IsPlanning(board) ? kStartingSun : IsOffense(board) ? kOffenseSun : 0)) return false;
    for (int i = 0; i < packets; ++i)
        if (board.mSeedBank->mSeedPackets[i].mPacketType != (IsPlanning(board) ? kSeeds[i] : kArmySeeds[i])) return false;
    return true;
}
void RestoreButton(Board& board)
{
    if (!board.mStoreButton) return;
    GameButton& button = *board.mStoreButton;
    const bool planning = IsPlanning(board);
    button.mParentWidget = &board;
    button.mBtnNoDraw = button.mDisabled = !planning;
    button.SetLabel("[LETS_ROCK_BUTTON]");
    button.Resize(300, 550, 210, 46);
}
void PreloadResources()
{
    for (SeedType seed : kSeeds) Plant::PreloadPlantResources(seed);
    for (SeedType seed : kArmySeeds) Zombie::PreloadZombieResources(Challenge::IZombieSeedTypeToZombieType(seed));
}
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kPlanning;
    challenge.mChallengeStateCounter = challenge.mChallengeScore = challenge.mSurvivalStage = 0;
    challenge.mChallengeGridX = 0;
    challenge.mChallengeGridY = kRulesVersion;
    std::memset(challenge.mBeghouledEated, 0, sizeof(challenge.mBeghouledEated));
    board.mCurrentWave = board.mTotalSpawnedWaves = board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = 100000;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = kStartingSun;
    board.mShowShovel = true;
    board.mBonusLawnMowersRemaining = 0;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    board.mSeedBank->UpdateWidth();
    // The normal level intro finishes before this preparation control appears.
    board.mStoreButton->mBtnNoDraw = board.mStoreButton->mDisabled = true;
}
void Commit(Board& board)
{
    if (!IsPlanning(board) || board.mApp->mGameScene != SCENE_PLAYING || board.mPaused ||
        board.mTimeStopCounter > 0 || board.mLevelComplete || board.HasLevelAwardDropped()) return;
    Challenge& challenge = *board.mChallenge;
    std::memset(challenge.mBeghouledEated, 0, sizeof(challenge.mBeghouledEated));
    for (Plant* plant : board.mPlants)
    {
        if (plant->mDead) continue;
        if (!CanPlantAt(board, plant->mPlantCol, plant->mRow, plant->mSeedType)) return;
        challenge.mBeghouledEated[plant->mPlantCol][plant->mRow] = static_cast<int>(plant->mSeedType) + 1;
    }
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kDefense;
    challenge.mChallengeStateCounter = kOpeningDelay;
    // Native hit testing visits every fixed bank slot. Retire the preparation
    // packets as well as hiding them, so no old seventh slot can catch a click
    // at the right edge of the smaller six-packet I, Zombie bank.
    for (SeedPacket& packet : board.mSeedBank->mSeedPackets) packet.mPacketType = SEED_NONE;
    board.mSeedBank->mNumPackets = 0;
    board.mSeedBank->UpdateWidth();
    board.mSunMoney = 0;
    board.mShowShovel = false;
    RestoreButton(board);
}
namespace
{
void SwitchSides(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    board.ClearCursor();
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) zombie->DieNoLoot();
    for (Plant* plant : board.mPlants) if (!plant->mDead) plant->Die();
    for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
    for (Projectile* projectile : board.mProjectiles) if (!projectile->mDead) projectile->Die();
    for (GridItem* item : board.mGridItems) if (!item->mDead) item->GridItemDie();
    // The original native I, Zombie renderer/brains become active together.
    challenge.mChallengeState = kOffense;
    challenge.mChallengeStateCounter = challenge.mChallengeScore = 0;
    challenge.mChallengeGridX = 1;
    board.mSunMoney = kOffenseSun;
    board.mShowShovel = false;
    board.mCurrentWave = board.mTotalSpawnedWaves = board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = 100000;
    board.mSeedBank->mNumPackets = static_cast<int>(kArmySeeds.size());
    for (int i = 0; i < board.mSeedBank->mNumPackets; ++i)
        board.mSeedBank->mSeedPackets[i].SetPacketType(kArmySeeds[i]);
    board.mSeedBank->UpdateWidth();
    for (int col = 0; col < kGardenColumns; ++col) for (int row = 0; row < 5; ++row)
    {
        const int stored = challenge.mBeghouledEated[col][row];
        if (stored == 0) continue;
        Plant* plant = board.NewPlant(col, row, static_cast<SeedType>(stored - 1), SEED_NONE);
        plant->SetSleeping(false);
        challenge.IZombieSetupPlant(plant);
    }
    for (int row = 0; row < 5; ++row)
    {
        GridItem* brain = board.mGridItems.DataArrayAlloc();
        brain->mGridItemType = GRIDITEM_IZOMBIE_BRAIN;
        brain->mGridX = 0; brain->mGridY = row;
        brain->mRenderOrder = Board::MakeRenderOrder(RENDER_LAYER_PLANT, row, 0);
        brain->mGridItemCounter = 70;
        brain->mPosX = board.GridToPixelX(0, row) - 40;
        brain->mPosY = board.GridToPixelY(0, row) + 40;
    }
    board.ClearAdviceImmediately();
    board.DisplayAdvice("[ADVICE_I_ZOMBIE_EAT_ALL_BRAINS]", MESSAGE_STYLE_HINT_FAST, ADVICE_I_ZOMBIE_EAT_ALL_BRAINS);
}
}
void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) || board.mPaused ||
        board.mTimeStopCounter > 0 || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = IsPlanning(board);
    if (challenge.mChallengeState == kPlanning) { RestoreButton(board); return; }
    if (challenge.mChallengeState == kTransition)
    {
        if (--challenge.mChallengeStateCounter <= 0) SwitchSides(board);
        return;
    }
    if (challenge.mChallengeState == kOffense) { challenge.IZombieUpdate(); return; }
    if (challenge.mChallengeState != kDefense) return;
    if (challenge.mSurvivalStage < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter != 0) return;
        const int wave = challenge.mSurvivalStage;
        board.NextWaveComing();
        for (const Spawn& spawn : kFormations[wave])
        {
            Zombie* zombie = board.AddZombieInRow(spawn.mType, spawn.mRow, wave);
            zombie->mPosX = static_cast<float>(spawn.mX);
            zombie->mX = spawn.mX;
            zombie->UpdateReanim();
        }
        ++challenge.mSurvivalStage;
        board.mCurrentWave = board.mTotalSpawnedWaves = challenge.mSurvivalStage;
        board.mZombieHealthToNextWave = -1;
        challenge.mChallengeStateCounter = kFormationInterval;
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    board.mApp->AddPvzpParticle(400, 300, RENDER_LAYER_TOP, PARTICLE_SCREEN_FLASH);
    board.DisplayAdvice("SWITCH SIDES!", MESSAGE_STYLE_BIG_MIDDLE, ADVICE_NONE);
    challenge.mChallengeState = kTransition;
    challenge.mChallengeStateCounter = kTransitionTicks;
}
void OnBrainsCleared(Board& board, int row)
{
    Challenge& challenge = *board.mChallenge;
    if (challenge.mChallengeState != kOffense || board.HasLevelAwardDropped()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(0, row);
}
}
