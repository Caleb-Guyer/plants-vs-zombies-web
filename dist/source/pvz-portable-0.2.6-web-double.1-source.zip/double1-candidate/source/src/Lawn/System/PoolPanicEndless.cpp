// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanicEndless.h"
#include "FireDrill.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../LawnCommon.h"
#include "PlayerInfo.h"
#include "../../LawnApp.h"
#include "../../GameConstants.h"
#include "../../PvzpLib/PvzpStringFile.h"
#include "Common.h"
#include "misc/MTRand.h"
#include <algorithm>
#include <climits>
#include <cstdint>
#include <cstring>
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#endif

namespace PoolPanicEndless
{
namespace
{
int WaitingPackets(const SeedBank& bank)
{
    int count = 0;
    for (int i = 0; i < bank.mNumPackets; ++i)
        count += bank.mSeedPackets[i].mPacketType != SEED_NONE;
    return count;
}
std::uint32_t SeedBits(std::int32_t saved)
{
    std::uint32_t bits;
    std::memcpy(&bits,&saved,sizeof(bits));
    return bits;
}
void StoreSeed(Challenge& challenge, std::uint32_t seed)
{ std::memcpy(&challenge.mSlotMachineRollCount,&seed,sizeof(seed)); }
void RestoreEmptyPads(Board& board)
{
    for (const Cell& cell : kLilyPads)
        if (!board.GetTopPlantAt(cell.mCol,cell.mRow,TOPPLANT_ANY))
            board.AddPlant(cell.mCol,cell.mRow,SEED_LILYPAD,SEED_NONE);
}
bool CanAdmitFormation(Board& board, const Formation& formation)
{
    int living = 0;
    for (Zombie* zombie : board.mZombies)
        living += !zombie->mDead && !zombie->IsDeadOrDying();
    return living+ZombieCount(formation) <= kLivingActorSoftCap;
}
void UpdateSupply(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    board.mSeedBank->UpdateConveyorBelt();
    if (challenge.mChallengeScore >= kPacketQuota ||
        WaitingPackets(*board.mSeedBank) >= board.mSeedBank->mNumPackets) return;
    if (challenge.mConveyorBeltCounter > 0) --challenge.mConveyorBeltCounter;
    if (challenge.mConveyorBeltCounter != 0 || !CanAcceptSupply(*board.mSeedBank)) return;
    std::array<int,kSupplySeeds.size()> weights{};
    int total = 0;
    for (std::size_t i = 0; i < kSupplySeeds.size(); ++i)
        total += weights[i] = SupplyWeight(board,kSupplySeeds[i]);
    if (total == 0) return;
    // The saved seed belongs only to this mode. Advancing a native MTRand
    // seed chain preserves future deliveries through Continue without altering
    // the global combat RNG or the serialized Challenge layout.
    Sexy::MTRand random(SeedBits(challenge.mSlotMachineRollCount));
    int pick = static_cast<int>(random.Next(static_cast<unsigned long>(total)));
    std::size_t index = 0;
    while (index+1 < weights.size() && pick >= weights[index]) pick -= weights[index++];
    // One cold counter per flag arrives before the new late-game torch roster.
    // The normal quota, bank capacity, saved seed and delivery cadence apply.
    const bool coldSupply = FireDrill::IsUnlocked(board.mApp) &&
        challenge.mSurvivalStage >= 8 && challenge.mChallengeScore == 0;
    const SeedType seed = coldSupply ? SEED_SNOWPEA : kSupplySeeds[index];
    board.mSeedBank->AddSeed(seed);
    StoreSeed(challenge,static_cast<std::uint32_t>(random.Next()));
    challenge.mLastConveyorSeedType = seed;
    ++challenge.mChallengeScore;
    challenge.mConveyorBeltCounter = SupplyInterval(WaitingPackets(*board.mSeedBank));
}
void CompleteFlag(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    if (challenge.mSurvivalStage < INT_MAX) ++challenge.mSurvivalStage;
    challenge.mChallengeState = kBetween;
    challenge.mChallengeStateCounter = kBetweenDelay;
    // Accepted native packets carry unchanged. Only this completed flag's
    // unissued quota expires; the next flag starts a new delivery allowance.
    challenge.mChallengeScore = 0;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    board.mCurrentWave = 0;
    board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kBetweenDelay;
    board.mZombieHealthToNextWave = -1;
    RestoreEmptyPads(board);
    board.SurvivalSaveScore();
    const std::string flags = board.mApp->Pluralize(challenge.mSurvivalStage,"[ONE_FLAG]","[COUNT_FLAGS]");
    board.DisplayAdvice(PvzpReplaceString("[SUCCESSFULLY_DEFENDED]","{FLAGS}",flags),
        MESSAGE_STYLE_BIG_MIDDLE_FAST,ADVICE_NONE);
    board.SaveGame(GetSavedGameName(kMode,board.mApp->mPlayerInfo->mId));
#ifdef __EMSCRIPTEN__
    // Use the existing serialized browser persistence queue after BOTH native
    // files were written. Its helper owns promise/error handling; Node lacks it.
    EM_ASM({
        if (typeof globalThis.syncSavesInBackground === 'function')
            globalThis.syncSavesInBackground();
    });
#endif
}
}
bool CanAcceptSupply(const SeedBank& bank)
{
    const int waiting = WaitingPackets(bank);
    if (waiting >= bank.mNumPackets) return false;
    // Native AddSeed's fallback adds 40px to the previous offset. Admission
    // must wait until that fallback cannot push a new packet off the entry.
    const int entry = 515-(SEED_PACKET_WIDTH+1)*waiting;
    return waiting == 0 || bank.mSeedPackets[waiting-1].mOffsetX <= entry;
}
int SupplyWeight(Board& board, SeedType seed)
{
    int base = 0, waitingLimit = 2, boardLimit = 54;
    switch (seed)
    {
    case SEED_REPEATER: base=26; waitingLimit=3; boardLimit=16; break;
    case SEED_THREEPEATER: base=20; waitingLimit=3; boardLimit=10; break;
    case SEED_TALLNUT: base=13; boardLimit=10; break;
    case SEED_TORCHWOOD: base=10; waitingLimit=1; break;
    case SEED_SPIKEWEED: base=8; boardLimit=8; break;
    case SEED_LILYPAD: base=4; waitingLimit=1; boardLimit=14; break;
    case SEED_SQUASH: base=6; boardLimit=4; break;
    case SEED_TANGLEKELP: base=4; waitingLimit=1; boardLimit=4; break;
    case SEED_CHERRYBOMB: base=7; break;
    case SEED_JALAPENO: base=5; break;
    default: return 0;
    }
    if (board.mChallenge->mSurvivalStage >= 6)
    {
        // Preserve the six-flag opening, then make room for native repairs
        // and area counters instead of accumulating six spare pea shooters.
        switch (seed)
        {
        case SEED_REPEATER: base=18; waitingLimit=1; break;
        case SEED_THREEPEATER: base=14; waitingLimit=1; break;
        case SEED_TALLNUT: base=20; break;
        case SEED_SPIKEWEED: base=16; break;
        case SEED_SQUASH: base=12; break;
        case SEED_TANGLEKELP: base=10; break;
        case SEED_CHERRYBOMB: base=16; break;
        case SEED_JALAPENO: base=14; break;
        default: break;
        }
    }
    int waiting = 0, planted = 0;
    std::array<bool,6> torchwoodRows{};
    for (const SeedPacket& packet : board.mSeedBank->mSeedPackets)
        waiting += packet.mPacketType == seed;
    for (const Plant* plant : board.mPlants)
    {
        planted += !plant->mDead && plant->mSeedType == seed;
        if (!plant->mDead && plant->mSeedType == SEED_TORCHWOOD && plant->mRow >= 0 && plant->mRow < 6)
            torchwoodRows[plant->mRow] = true;
    }
    if (waiting >= waitingLimit || planted >= boardLimit) return 0;
    bool legal = false;
    if (seed == SEED_TORCHWOOD)
    {
        // Fire peas do not gain another multiplier from a second Torchwood.
        // Reserve pending packets against genuinely unserved, plantable lanes.
        int demand = 0;
        for (int row = 0; row < 6; ++row)
        {
            if (torchwoodRows[row]) continue;
            for (int col = 0; col < 9; ++col)
                if (board.CanPlantAt(col,row,seed) == PLANTING_OK) { ++demand; break; }
        }
        if (waiting >= demand) return 0;
        legal = true;
    }
    for (int row = 0; row < 6 && !legal; ++row)
        for (int col = 0; col < 9 && !legal; ++col)
            legal = board.CanPlantAt(col,row,seed) == PLANTING_OK;
    if (!legal) return 0;
    int weight = std::max(1,base/(1+planted/3));
    if (waiting > 0) weight = std::max(1,weight/(waiting+1));
    if (board.mChallenge->mLastConveyorSeedType == seed) weight = std::max(1,weight/2);
    return weight;
}
void MigrateLegacy(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsMode(board.mApp->mGameMode)) return;
    if (challenge.mChallengeGridY == kRulesVersion) return;
    if (challenge.mChallengeGridY >= 2)
    {
        // .2 already has admitted native packets and the saved local RNG.
        // Changing the schedule must not reroll future supply or move cards.
        challenge.mChallengeGridY = kRulesVersion;
        return;
    }
    const int waiting = WaitingPackets(*board.mSeedBank);
    bool outsideEntry = false;
    const int entryX = board.mSeedBank->mSeedPackets[0].mX+515;
    for (int i = 0; i < waiting; ++i)
    {
        const SeedPacket& packet = board.mSeedBank->mSeedPackets[i];
        outsideEntry |= packet.mX+packet.mOffsetX > entryX;
    }
    // Repair only the legacy over-spaced backlog. Every accepted type and
    // order stays intact, as do all board actors, health, mowers and records.
    if (outsideEntry)
        for (int i = 0; i < waiting; ++i) board.mSeedBank->mSeedPackets[i].mOffsetX = 0;
    const std::uint32_t legacySeed = SeedBits(board.mBoardRandSeed) ^
        static_cast<std::uint32_t>(challenge.mSurvivalStage)*0x9e3779b9u ^
        static_cast<std::uint32_t>(challenge.mChallengeScore)*0x85ebca6bu;
    Sexy::MTRand random(legacySeed);
    StoreSeed(challenge,static_cast<std::uint32_t>(random.Next()));
    challenge.mChallengeGridY = kRulesVersion;
    if (board.mCurrentWave > 0 && board.mZombieHealthToNextWave < 0)
    {
        board.mZombieHealthWaveStart = board.TotalZombiesHealthInWave(board.mCurrentWave-1);
        board.mZombieHealthToNextWave = static_cast<int>(board.mZombieHealthWaveStart*0.55f);
    }
}
void PreloadResources()
{
    for (SeedType seed : kSupplySeeds) Plant::PreloadPlantResources(seed);
    Plant::PreloadPlantResources(SEED_SNOWPEA);
    Zombie::PreloadZombieResources(ZOMBIE_TORCHBEARER);
    constexpr ZombieType types[] = {ZOMBIE_NORMAL,ZOMBIE_FLAG,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,
        ZOMBIE_DOOR,ZOMBIE_FOOTBALL,ZOMBIE_NEWSPAPER,ZOMBIE_SNORKEL,ZOMBIE_DOLPHIN_RIDER,
        ZOMBIE_JACK_IN_THE_BOX,ZOMBIE_LADDER,ZOMBIE_ZAMBONI,ZOMBIE_GARGANTUAR,ZOMBIE_IMP,
        ZOMBIE_POGO,ZOMBIE_DANCER,ZOMBIE_BACKUP_DANCER,ZOMBIE_REDEYE_GARGANTUAR};
    for (ZombieType type : types) Zombie::PreloadZombieResources(type);
}
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    challenge.mChallengeScore = 0;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    challenge.mChallengeGridX = Sexy::Rand(8);
    challenge.mChallengeGridY = kRulesVersion;
    StoreSeed(challenge,static_cast<std::uint32_t>(Sexy::Rand()));
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = 0;
    board.mShowShovel = false;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (SeedType seed : kOpeningSeeds)
    {
        board.mSeedBank->AddSeed(seed,true);
        challenge.mLastConveyorSeedType = seed;
        ++challenge.mChallengeScore;
    }
    RestoreEmptyPads(board);
}
void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) ||
        board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.mTimeStopCounter > 0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    MigrateLegacy(board);
    board.mShowShovel = true;
    UpdateSupply(board);
    if (challenge.mChallengeState == kBetween)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            challenge.mChallengeState = kActive;
            challenge.mChallengeStateCounter = kResumeDelay;
            board.mZombieCountDown = board.mZombieCountDownStart = kResumeDelay;
        }
        return;
    }
    const int wave = std::clamp(board.mCurrentWave,0,kWaveCount);
    if (wave < kWaveCount)
    {
        bool warningFinished = false;
        if (challenge.mChallengeState == kHugeWave)
        {
            challenge.mChallengeStateCounter = board.mHugeWaveCountDown;
            board.mZombieCountDown = challenge.mChallengeStateCounter;
            if (board.mHugeWaveCountDown > 0) return;
            warningFinished = true;
        }
        else
        {
            if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
            if (wave > 0 && challenge.mChallengeStateCounter > 200 &&
                board.mZombieCountDownStart-challenge.mChallengeStateCounter > 400 &&
                board.TotalZombiesHealthInWave(wave-1) <= board.mZombieHealthToNextWave)
                challenge.mChallengeStateCounter = 200;
        }
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            const Formation formation = WithTorchbearers(
                WaveFor(challenge.mSurvivalStage,wave,challenge.mChallengeGridX),
                challenge.mSurvivalStage,wave,FireDrill::IsUnlocked(board.mApp));
            if (wave == kWaveCount-1 && !warningFinished)
            {
                board.ClearAdviceImmediately();
                board.DisplayAdviceAgain("[ADVICE_HUGE_WAVE]",MESSAGE_STYLE_HUGE_WAVE,ADVICE_HUGE_WAVE);
                board.mHugeWaveCountDown = kHugeWaveDelay;
                board.mZombieCountDown = board.mZombieCountDownStart = kHugeWaveDelay;
                challenge.mChallengeState = kHugeWave;
                challenge.mChallengeStateCounter = kHugeWaveDelay;
                return;
            }
            // Native warning/music/siren ran once. Keep the warning state at
            // zero until admission is safe, without restarting its advice.
            if (!CanAdmitFormation(board,formation)) return;
            if (warningFinished) challenge.mChallengeState = kActive;
            if (wave != kWaveCount-1) board.NextWaveComing();
            for (const Spawn& spawn : formation)
            {
                if (spawn.mType == ZOMBIE_INVALID) continue;
                Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,wave);
                zombie->mPosX = static_cast<float>(spawn.mX);
                zombie->mX = spawn.mX;
                zombie->UpdateReanim();
            }
            board.mCurrentWave = wave + 1;
            if (board.mTotalSpawnedWaves < INT_MAX) ++board.mTotalSpawnedWaves;
            if (wave == kWaveCount-1) board.mFlagRaiseCounter = 100;
            board.mZombieHealthWaveStart = board.TotalZombiesHealthInWave(wave);
            board.mZombieHealthToNextWave = static_cast<int>(board.mZombieHealthWaveStart*0.55f);
            challenge.mChallengeStateCounter = FormationInterval(challenge.mSurvivalStage);
            board.mZombieCountDown = board.mZombieCountDownStart = challenge.mChallengeStateCounter;
        }
        return;
    }
    if (!board.AreEnemyZombiesOnScreen()) CompleteFlag(board);
}
}
