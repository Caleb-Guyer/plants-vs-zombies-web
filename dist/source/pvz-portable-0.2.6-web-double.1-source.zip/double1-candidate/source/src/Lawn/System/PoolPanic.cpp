// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanic.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include <algorithm>

namespace PoolPanic
{
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    challenge.mChallengeScore = 0;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = 0;
    board.mShowShovel = false;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (int i = 0; i < kOpeningPackets; ++i)
    {
        const SeedType seed = SeedForSupply(challenge.mChallengeScore);
        board.mSeedBank->AddSeed(seed,true);
        challenge.mLastConveyorSeedType = seed;
        ++challenge.mChallengeScore;
    }
    for (const Cell& cell : kLilyPads) board.AddPlant(cell.mCol,cell.mRow,SEED_LILYPAD,SEED_NONE);
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) ||
        challenge.mChallengeState != kActive || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mPaused || board.mTimeStopCounter > 0 || board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    // Movement remains native at capacity. An unaccepted delivery never spends
    // its saved ordinal or delay, so a full bank cannot silently lose supplies.
    board.mSeedBank->UpdateConveyorBelt();
    if (challenge.mChallengeScore < kPacketCount &&
        board.mSeedBank->GetNumSeedsOnConveyorBelt() < board.mSeedBank->mNumPackets)
    {
        if (challenge.mConveyorBeltCounter > 0) --challenge.mConveyorBeltCounter;
        if (challenge.mConveyorBeltCounter == 0)
        {
            const SeedType seed = SeedForSupply(challenge.mChallengeScore);
            board.mSeedBank->AddSeed(seed);
            challenge.mLastConveyorSeedType = seed;
            ++challenge.mChallengeScore;
            challenge.mConveyorBeltCounter = kSupplyInterval;
        }
    }
    const int next = std::clamp(challenge.mSurvivalStage,0,kWaveCount);
    if (next < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            for (const Spawn& spawn : kFormations[next])
            {
                if (spawn.mType == ZOMBIE_INVALID) continue;
                Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,next);
                zombie->mPosX = static_cast<float>(spawn.mX);
                zombie->mX = spawn.mX;
                zombie->UpdateReanim();
            }
            challenge.mSurvivalStage = next + 1;
            board.mCurrentWave = board.mTotalSpawnedWaves = next + 1;
            challenge.mChallengeStateCounter = kFormationInterval;
            board.mZombieCountDown = board.mZombieCountDownStart = kFormationInterval;
        }
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(4,2);
}
}
