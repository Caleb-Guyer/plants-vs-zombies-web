// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>

class Board;
class LawnApp;

namespace FireDrill
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_FIRE_DRILL;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(136);
inline constexpr ChallengeState kState = kActive;
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(137);
inline constexpr int kRulesVersion = 1;
inline constexpr int kStartingSun = 425;
inline constexpr int kWaveCount = 6;
inline constexpr int kLargestFormation = 10;
inline constexpr int kOpeningDelay = 1000;
inline constexpr int kFormationInterval = 2400;
inline constexpr int kProfileIndex = 89;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kFinished); }
inline constexpr std::array<SeedType,7> kSeeds = {SEED_SUNFLOWER,SEED_PEASHOOTER,
    SEED_SNOWPEA,SEED_WALLNUT,SEED_POTATOMINE,SEED_CHERRYBOMB,SEED_SQUASH};
struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
inline constexpr std::array<StartingPlant,8> kStartingPlants = {{{SEED_SUNFLOWER,0,0},
    {SEED_SUNFLOWER,0,1},{SEED_SUNFLOWER,0,2},{SEED_SUNFLOWER,0,3},{SEED_SUNFLOWER,0,4},
    {SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,1,2},{SEED_PEASHOOTER,1,4}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
// Exposed torches, shielded escorts and pairs exercise ice, bait and recovery.
// Every attacker uses its normal statistics and original combat behavior.
inline constexpr std::array<Formation,kWaveCount> kFormations = {{
    {{{ZOMBIE_TORCHBEARER,1,800},{ZOMBIE_NORMAL,2,840},{ZOMBIE_TORCHBEARER,3,800}}},
    {{{ZOMBIE_TRAFFIC_CONE,0,800},{ZOMBIE_TORCHBEARER,0,870},{ZOMBIE_TORCHBEARER,2,800},
      {ZOMBIE_TRAFFIC_CONE,4,800},{ZOMBIE_TORCHBEARER,4,870}}},
    {{{ZOMBIE_DOOR,1,800},{ZOMBIE_TORCHBEARER,1,870},{ZOMBIE_DOOR,3,800},
      {ZOMBIE_TORCHBEARER,3,870},{ZOMBIE_NORMAL,2,800},{ZOMBIE_TORCHBEARER,2,920}}},
    {{{ZOMBIE_TORCHBEARER,0,800},{ZOMBIE_TORCHBEARER,0,880},{ZOMBIE_TORCHBEARER,2,800},
      {ZOMBIE_TORCHBEARER,2,880},{ZOMBIE_TORCHBEARER,4,800},{ZOMBIE_TORCHBEARER,4,880},
      {ZOMBIE_PAIL,1,800},{ZOMBIE_PAIL,3,800}}},
    {{{ZOMBIE_DOOR,0,800},{ZOMBIE_TORCHBEARER,0,870},{ZOMBIE_FOOTBALL,1,880},
      {ZOMBIE_DOOR,2,800},{ZOMBIE_TORCHBEARER,2,870},{ZOMBIE_FOOTBALL,3,880},
      {ZOMBIE_DOOR,4,800},{ZOMBIE_TORCHBEARER,4,870}}},
    {{{ZOMBIE_TORCHBEARER,0,800},{ZOMBIE_TORCHBEARER,1,800},{ZOMBIE_TORCHBEARER,2,800},
      {ZOMBIE_TORCHBEARER,3,800},{ZOMBIE_TORCHBEARER,4,800},{ZOMBIE_TRAFFIC_CONE,0,870},
      {ZOMBIE_PAIL,1,870},{ZOMBIE_DOOR,2,870},{ZOMBIE_PAIL,3,870},{ZOMBIE_TRAFFIC_CONE,4,870}}}
}};
constexpr int ZombieCount(int wave)
{
    if(wave<0 || wave>=kWaveCount) return 0;
    int count=0;for(const Spawn& spawn:kFormations[wave]) count+=spawn.mType!=ZOMBIE_INVALID;
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves>=kWaveCount && Slots>kLargestFormation);
    for(auto& wave:output)for(auto& zombie:wave)zombie=ZOMBIE_INVALID;
    for(int wave=0;wave<kWaveCount;++wave)
        for(int i=0;i<ZombieCount(wave);++i)output[wave][i]=kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count>static_cast<std::size_t>(ZOMBIE_TORCHBEARER));
    for(auto& allowed:output)allowed=false;
    for(const Formation& wave:kFormations)for(const Spawn& spawn:wave)
        if(spawn.mType!=ZOMBIE_INVALID)output[spawn.mType]=true;
}
template<class Bank> void FillSeedBank(Bank& bank)
{
    bank.mNumPackets=static_cast<int>(kSeeds.size());
    for(int i=0;i<bank.mNumPackets;++i)bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}
bool IsUnlocked(const LawnApp* app);
void PreloadResources();
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode)==90 && ZombieCount(0)==3 && ZombieCount(5)==10);
}
