// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"

class Plant;
class Zombie;

// One torch, one ordinary eating target. The existing native saved fields hold
// the flame (mHasObject), windup (mSummonCounter) and exact target (mTargetPlantID).
// No actor, board or profile serialization layout changes are required.
namespace TorchbearerZombie
{
inline constexpr ZombieType kType = ZOMBIE_TORCHBEARER;
inline constexpr int kBodyHealth = 270;
inline constexpr int kBurnWindupTicks = 35;
inline constexpr int kZombieValue = 3;

bool IsZombie(const Zombie& zombie);
bool IsLit(const Zombie& zombie);
bool IsAttacking(const Zombie& zombie);
float AttackProgress(const Zombie& zombie);
bool TryStartBurn(Zombie& zombie, Plant& plant);
void ValidateState(Zombie& zombie);
void Update(Zombie& zombie);
void Extinguish(Zombie& zombie);

static_assert(static_cast<int>(kType) == 34);
static_assert(static_cast<int>(GAMEMODE_CHALLENGE_FIRE_DRILL) == 90);
}
