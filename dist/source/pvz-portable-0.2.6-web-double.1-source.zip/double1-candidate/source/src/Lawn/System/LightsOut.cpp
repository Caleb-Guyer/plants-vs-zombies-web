// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LightsOut.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../CursorObject.h"
#include "../../LawnApp.h"
#include "PvzpLib/PvzpParticle.h"

namespace LightsOut
{
Plant* GetPlantern(Board& board)
{
    for (Plant* plant:board.mPlants)
        if (plant->mSeedType==SEED_PLANTERN && plant->mIsOnBoard && !plant->mDead &&
            !plant->mSquished && plant->mPlantHealth>0 &&
            plant->mOnBungeeState==NOT_ON_BUNGEE) return plant;
    return nullptr;
}
const Plant* GetPlantern(const Board& board) { return GetPlantern(const_cast<Board&>(board)); }
bool IsLit(const Board& board,int col,int row)
{
    const Plant* lamp=GetPlantern(board);
    return lamp && IsCellLit(lamp->mPlantCol,lamp->mRow,col,row);
}
bool CanAttack(const Plant& plant)
{
    if (!plant.mApp || !IsMode(plant.mApp->mGameMode) || !plant.mBoard || !plant.mIsOnBoard) return true;
    if (plant.mSeedType==SEED_PLANTERN || plant.mSeedType==SEED_WALLNUT) return true;
    return IsLit(*plant.mBoard,plant.mPlantCol,plant.mRow);
}
void Populate(Board& board)
{
    for (const auto& entry:kStartingPlants) board.AddPlant(entry.mCol,entry.mRow,entry.mSeed,SEED_NONE);
    board.mShowShovel=false;
    board.mFogOffset=0;
    board.mFogBlownCountDown=0;
    for (auto& column:board.mGridCelFog) for (int& fog:column) fog=kFogOpacity;
    board.UpdateFog();
}
void Update(Board& board)
{
    if (!board.mChallenge || !IsCurrentRules(board.mApp->mGameMode,board.mChallenge->mChallengeState)) return;
    Plant* selected=board.mPlants.DataArrayTryToGet(board.mCursorObject->mGlovePlantID);
    if (board.mCursorObject->mGlovePlantID!=PLANTID_NULL &&
        (!selected || selected!=GetPlantern(board) || board.mLevelComplete || board.HasLevelAwardDropped()))
    {
        board.ClearCursor();
        selected=nullptr;
    }
    if (board.mApp->mGameScene!=SCENE_PLAYING || board.mPaused || board.mTimeStopCounter>0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    if (board.mChallenge->mChallengeStateCounter>0) --board.mChallenge->mChallengeStateCounter;
    if (selected) selected->mHighlighted=true;
}
bool MovePlantern(Board& board,Plant* plant,int col,int row)
{
    if (!board.mChallenge || !IsCurrentRules(board.mApp->mGameMode,board.mChallenge->mChallengeState) ||
        board.mApp->mGameScene!=SCENE_PLAYING || board.mPaused || board.mTimeStopCounter>0 ||
        board.mLevelComplete || board.HasLevelAwardDropped() || board.mChallenge->mChallengeStateCounter>0 ||
        !plant || plant!=GetPlantern(board) || col!=kRailCol || row<0 || row>=kRows ||
        (plant->mPlantCol==col && plant->mRow==row) || board.GetTopPlantAt(col,row,TOPPLANT_ANY) ||
        board.CanPlantAt(col,row,SEED_PLANTERN)!=PLANTING_OK) return false;
    const int oldX=plant->mX,oldY=plant->mY;
    plant->mX=board.GridToPixelX(col,row);
    plant->mY=board.GridToPixelY(col,row);
    plant->mPlantCol=col;plant->mRow=row;plant->mStartRow=row;
    plant->mRenderOrder=plant->CalcRenderOrder();
    if (PvzpParticleSystem* particle=board.mApp->ParticleTryToGet(plant->mParticleID))
        if (particle->mEmitterList.mSize)
        {
            PvzpParticleEmitter* emitter=particle->mParticleHolder->mEmitters.DataArrayGet(
                static_cast<unsigned int>(particle->mEmitterList.GetHead()->mValue));
            particle->SystemMove(emitter->mSystemCenter.x+plant->mX-oldX,emitter->mSystemCenter.y+plant->mY-oldY);
        }
    board.mChallenge->mChallengeStateCounter=kMoveCooldown;
    board.DoPlantingEffects(col,row,plant);
    board.UpdateFog();
    return true;
}
}
