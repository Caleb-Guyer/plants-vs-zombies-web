// SPDX-License-Identifier: LGPL-3.0-or-later
#include "VaseAmbushPresentation.h"
#include "VaseAmbush.h"
#include "ReanimationLawn.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <format>
#include <memory>
#include <vector>

namespace VaseAmbushPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

std::string LevelLabel(int stage)
{
    return std::format("Vase Ambush - {}/{}", std::clamp(stage + 1, 1, VaseAmbush::kBoardCount), VaseAmbush::kBoardCount);
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!gLawnApp || !gLawnApp->mReanimatorCache || !PvzpLoadResources("LoadingImages") ||
        !PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1 ||
        !Sexy::IMAGE_SCARY_POT || !Sexy::IMAGE_BRAIN) return nullptr;

    // Reuse the original Plantern-revealed zombie vase composition. Its back,
    // cached zombie and translucent front have the native DrawScaryPot offsets.
    // The vase remains the dominant silhouette inside the original 80x65 card.
    auto portrait = Blank(80, 105);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    native.DrawImageCel(Sexy::IMAGE_SCARY_POT, 0, 0, 2, 0);
    Sexy::Graphics inside(native);
    inside.mScaleX = 0.4f;
    inside.mScaleY = 0.4f;
    gLawnApp->mReanimatorCache->DrawCachedZombie(&inside, 6.0f, 19.0f, ZOMBIE_TRAFFIC_CONE);
    native.SetColorizeImages(true);
    native.SetColor(Sexy::Color(255, 255, 255, 58));
    native.DrawImageCel(Sexy::IMAGE_SCARY_POT, 0, 0, 2, 1);
    native.SetColorizeImages(false);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto* brain = dynamic_cast<Sexy::MemoryImage*>(Sexy::IMAGE_BRAIN);
    const Sexy::Rect brainBounds = brain ? VisibleBounds(*brain) :
        Sexy::Rect(0, 0, Sexy::IMAGE_BRAIN->GetWidth(), Sexy::IMAGE_BRAIN->GetHeight());
    if (brainBounds.mWidth <= 0 || brainBounds.mHeight <= 0) return nullptr;
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    const float scale = std::min(47.0f / bounds.mWidth, 56.0f / bounds.mHeight);
    const float brainScale = std::min(20.0f / brainBounds.mWidth, 18.0f / brainBounds.mHeight);
    const float brainWidth = brainBounds.mWidth * brainScale;
    const float left = 40.0f - (brainWidth + 3.0f + bounds.mWidth * scale) * 0.5f;
    PvzpDrawImageScaledF(&picture, portrait.get(),
        left + brainWidth + 3.0f - bounds.mX * scale,
        32.0f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    PvzpDrawImageScaledF(&picture, Sexy::IMAGE_BRAIN,
        left - brainBounds.mX * brainScale,
        60.0f - (brainBounds.mY + brainBounds.mHeight) * brainScale, brainScale, brainScale);
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImage() { sCard.reset(); }
}
