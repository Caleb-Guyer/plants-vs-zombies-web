// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// Original Bungee, Sunflower and Umbrella-leaf rigs in the native Bonus window.
namespace BungeeBusinessPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
