// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include <string>

namespace Sexy { class Image; }

namespace VaseAmbushPresentation
{
Sexy::Image* GetBonusImage();
std::string LevelLabel(int stage);
void DisposeImage();
}
