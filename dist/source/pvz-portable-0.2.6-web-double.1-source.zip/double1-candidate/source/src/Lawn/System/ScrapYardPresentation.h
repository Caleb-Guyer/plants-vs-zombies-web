// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

namespace Sexy { class Image; }

// Original Magnet-shroom and native recovered metal in the Bonus thumbnail.
namespace ScrapYardPresentation
{
Sexy::Image* GetBonusImage();
void DisposeImage();
}
