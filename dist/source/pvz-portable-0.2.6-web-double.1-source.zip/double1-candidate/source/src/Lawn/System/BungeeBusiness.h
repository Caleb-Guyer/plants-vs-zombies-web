// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>
#include <initializer_list>
#include <string>

class Board;
class Zombie;

// Native I, Zombie input and combat with a finite heist objective. All progress
// occupies existing serialized Challenge fields; original mode layouts stay exact.
namespace BungeeBusiness
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_BUNGEE_BUSINESS;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(119);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(120);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(121);
inline constexpr ChallengeState kFailed = static_cast<ChallengeState>(122);
inline constexpr int kBoardCount = 5;
inline constexpr int kSeedCount = 5;
inline constexpr int kDeploymentColumn = 5;
inline constexpr int kBungeeCost = 125;
inline constexpr int kTransitionTicks = 120;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && state >= kActive && state <= kFailed; }
inline constexpr std::array<SeedType, kSeedCount> kSeeds = {
    SEED_ZOMBIE_NORMAL, SEED_ZOMBIE_TRAFFIC_CONE, SEED_ZOMBIE_POLEVAULTER,
    SEED_ZOMBIE_PAIL, SEED_ZOMBIE_BUNGEE
};
struct Defender { SeedType mSeed = SEED_NONE; int mCol = 0; int mRow = 0; };
struct Puzzle { int mSun; std::array<Defender, 9> mPlants; };
// Ground crews work in lanes separate from the Sunflowers. Clear the native
// Umbrella-leaf coverage, then spend the remaining budget on targeted Bungees.
inline constexpr std::array<Puzzle, kBoardCount> kBoards = {{
    {225, {{{SEED_SUNFLOWER,0,1}, {SEED_UMBRELLA,1,2}}}},
    {375, {{{SEED_SUNFLOWER,0,1}, {SEED_SUNFLOWER,0,3},
            {SEED_UMBRELLA,1,2}, {SEED_PEASHOOTER,0,2}}}},
    {450, {{{SEED_SUNFLOWER,0,1}, {SEED_SUNFLOWER,0,3},
            {SEED_UMBRELLA,1,0}, {SEED_UMBRELLA,1,4},
            {SEED_PEASHOOTER,0,0}, {SEED_PEASHOOTER,0,4}}}},
    {375, {{{SEED_SUNFLOWER,0,1}, {SEED_SUNFLOWER,0,3},
            {SEED_UMBRELLA,1,2}, {SEED_WALLNUT,3,2}, {SEED_PEASHOOTER,0,2}}}},
    {625, {{{SEED_SUNFLOWER,0,1}, {SEED_SUNFLOWER,3,1}, {SEED_SUNFLOWER,0,3},
            {SEED_UMBRELLA,1,0}, {SEED_UMBRELLA,3,2}, {SEED_UMBRELLA,1,4},
            {SEED_PEASHOOTER,0,0}, {SEED_PEASHOOTER,0,2}, {SEED_PEASHOOTER,0,4}}}}
}};
constexpr int PlantCount(int stage)
{
    if (stage < 0 || stage >= kBoardCount) return 0;
    int count = 0;
    for (const Defender& plant : kBoards[stage].mPlants) count += plant.mSeed != SEED_NONE;
    return count;
}
constexpr int TargetCount(int stage)
{
    if (stage < 0 || stage >= kBoardCount) return 0;
    int count = 0;
    for (const Defender& plant : kBoards[stage].mPlants) count += plant.mSeed == SEED_SUNFLOWER;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kBoardCount);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    return kBoardCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for (auto& allowed : output) allowed = false;
    for (ZombieType type : {ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL, ZOMBIE_BUNGEE}) output[type] = true;
}
template<class Bank> void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = kSeedCount;
    for (int i = 0; i < kSeedCount; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
    bank.RefreshAllPackets();
}
void Populate(Board& board);
void ResetStage(Board& board, int stage);
void Update(Board& board);
bool CanDeploy(Board& board, int col, int row, SeedType seed);
void OnBungeeExit(Zombie& zombie);
std::string LevelLabel(int stage);
static_assert(static_cast<int>(kMode) == 84);
static_assert(TargetCount(0) + TargetCount(1) + TargetCount(2) + TargetCount(3) + TargetCount(4) == 10);
}
