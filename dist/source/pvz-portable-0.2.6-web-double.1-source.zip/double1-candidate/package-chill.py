"""Stage the Pool Panic Endless binaries, source and provenance after tests.

Reads this candidate and the authenticated release baselines. Writes only one
fresh staging directory. No build, game, browser, audio or network is started.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tempfile
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
VERSION = "0.2.6-web-endless.3"
ENDLESS3_LATE_EVIDENCE_READY = True  # TODO: freeze lateGame report/log selection with its contract.
ENDLESS3_CONTRACT_SHA = "5d4bc2feddbaddb64354cadb718f6bbdebf717b7a2ca5306318103915dce005d"
BASE_ENDLESS_CONTRACT_SHA = "58e2d59fdcf9ad2c0cae93cbfb3781a79c8924419a8d2611676c8348ff94df2e"
DEVELOPMENT_ONLY_TEST_FILES = {'endless3-late-build.json', 'endless3-late-engine.wasm', 'endless3-late-engine.js', 'endless3-late-harness.generated.cpp', 'endless3-late-fragment.snapshot.cpp'}
UPSTREAM_SHA = "40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556"
PARENT_SHA = "b9095c65547c3d013917ae4188e284f18eabb71a98020ca3d53f71f7365f9566"
PARENT_REFERENCE_SHA = "a27ddd48212673c4224730f7b0053a35dcece19fabdf926688fa2844f9c14d32"
MIGRATION_FIXTURE_FILES = ('endless2-migration-metadata.json', 'endless2-migration-early.v4', 'endless2-migration-early.graph.txt', 'endless2-migration-early-profile.dat', 'endless2-migration-backlog.v4', 'endless2-migration-backlog.graph.txt', 'endless2-migration-backlog-profile.dat')
FLAGS = {"CMAKE_BUILD_TYPE": "Release", "DO_FIX_BUGS": "OFF",
         "PVZ_DEBUG": "OFF", "LOW_MEMORY": "OFF"}
SOURCE_NAME = f"pvz-portable-{VERSION}-source.zip"
FULL_PATCH = "web-endless.3.patch"
DELTA_PATCH = "endless2-to-endless3.patch"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {"bytes": len(data), "sha256": digest(data),
            "crc32": f"{zlib.crc32(data) & 0xffffffff:08x}"}


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe_name(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts
            and "\\" not in name and ":" not in name, "Unsafe source path: " + name)
    return name


def source_tree(folder):
    result = {}
    for path in sorted(folder.rglob("*")):
        require(not path.is_symlink(), "Source symlinks are not supported")
        if path.is_file():
            name = safe_name(path.relative_to(folder).as_posix())
            require(not any(p in {".git", "__pycache__", "node_modules"}
                            for p in PurePosixPath(name).parts), "Private source input: " + name)
            result[name] = path.read_bytes()
    return result


def archive_source(path, expected_sha, prefix, count):
    raw = path.read_bytes()
    require(digest(raw) == expected_sha, "Wrong baseline archive: " + path.name)
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), "Duplicate baseline member")
        require(archive.testzip() is None, "Invalid baseline archive CRC")
        files = {safe_name(name[len(prefix):]): archive.read(name)
                 for name in archive.namelist()
                 if name.startswith(prefix) and not name.endswith("/")}
    require(len(files) == count, "Unexpected source count: " + path.name)
    return files


def make_patch(before, after):
    changed = [{"path": name, "beforeSha256": digest(before.get(name, b"")),
                "afterSha256": digest(after.get(name, b""))}
               for name in sorted(set(before) | set(after))
               if before.get(name) != after.get(name)]
    # Generate an ordinary Git patch, including binary image sources and files
    # without a trailing newline. This isolated index preserves exact input bytes;
    # project/global attributes must not normalize line endings or invoke filters.
    with tempfile.TemporaryDirectory(prefix="mender-diff-", dir=ROOT) as temporary:
        folder = Path(temporary).resolve()
        require(folder.is_relative_to(ROOT) and folder != ROOT, "Unsafe temporary directory")
        tree = folder / "source"
        tree.mkdir()
        for name, data in before.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        checked(["git", "init", "--quiet", tree])
        (tree / ".git/info/attributes").write_text(
            "* -text -filter -ident -working-tree-encoding\n", encoding="utf-8", newline="\n")
        command = ["git", "-C", tree, "-c", "core.autocrlf=false", "-c", "core.filemode=false"]
        checked(command + ["add", "--force", "--all", "--", "."])
        original_tree = checked(command + ["write-tree"]).stdout.strip()
        for name in set(before) - set(after):
            (tree / safe_name(name)).unlink()
        for name, data in after.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        checked(command + ["add", "--force", "--all", "--", "."])
        patch = checked(command + ["diff", "--cached", "--binary", "--full-index",
                                   "--no-ext-diff", "--no-textconv", "--no-renames",
                                   "--src-prefix=a/", "--dst-prefix=b/", original_tree, "--"],
                        binary=True).stdout
    return patch, changed


def checked(command, cwd=None, *, binary=False):
    options = {} if binary else {"text": True, "encoding": "utf-8", "errors": "replace"}
    result = subprocess.run(list(map(str, command)), cwd=cwd, capture_output=True, **options)
    error = result.stderr.decode("utf-8", errors="replace") if binary else result.stderr
    require(result.returncode == 0,
            "Local check failed: " + str(command[0]) + "\n" + error[-3000:])
    return result


def reconstruct(before, patch, expected):
    # This is our newly created temporary directory only; old candidates stay untouched.
    with tempfile.TemporaryDirectory(prefix="qol-patch-", dir=ROOT) as temporary:
        folder = Path(temporary).resolve()
        require(folder.is_relative_to(ROOT) and folder != ROOT, "Unsafe temporary directory")
        tree = folder / "source"
        tree.mkdir()
        for name, data in before.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        patch_path = folder / "change.patch"
        patch_path.write_bytes(patch)
        checked(["git", "init", "--quiet", tree])
        command = ["git", "-C", tree, "-c", "core.autocrlf=false", "apply"]
        checked(command + ["--check", patch_path])
        checked(command + [patch_path])
        actual = {p.relative_to(tree).as_posix(): p.read_bytes()
                  for p in tree.rglob("*") if p.is_file()
                  and ".git" not in p.relative_to(tree).parts}
        require(actual == expected, "Patch did not reconstruct all current source bytes")
    return {"gitApplyCheck": "PASS", "gitApply": "PASS",
            "everySourceByteMatches": True, "sourceFiles": len(expected)}



def historical_comparison_inputs(release):
    """Authenticate the separate .2 comparator without relabeling it .3 proof."""
    archive = release/'dist/source/pvz-portable-0.2.6-web-endless.2-source.zip'
    require(archive.is_file() and archive.stat().st_size == 40424282 and
            digest(archive.read_bytes()) == PARENT_SHA, 'Historical comparator parent ZIP differs')
    with zipfile.ZipFile(archive) as parent:
        require(len(parent.infolist()) == 1076 and parent.testzip() is None,
                'Historical comparator parent archive inventory differs')
        prefix = 'endless2-candidate/'
        base = parent.read(prefix+'tests/pool-panic-endless-harness.cpp')
        normal = parent.read(prefix+'logs/build-result.json')
        parent_build_bytes = parent.read(prefix+'tests/pool-panic-endless-build.json')
        old_build = json.loads(parent_build_bytes)
        old_source = {'source/'+name[len(prefix+'source/'):]:digest(parent.read(name))
            for name in parent.namelist() if name.startswith(prefix+'source/') and not name.endswith('/')}
        old_policy = parent.read(prefix+'tests/pool-panic-endless-ordinary-policy.h')
    require(len(old_source) == 852 and len(old_build['productionObjectSha256']) == 134 and
            digest(normal) == 'c73cb555c339c00e51378b88f23f6e648c9a9f677df0fc3edc4d0d4ed315094a',
            'Historical comparator parent production graph differs')
    reference_path = ROOT/'tests/endless3-parent-reference.json'
    require(reference_path.stat().st_size == 138131 and digest(reference_path.read_bytes()) == PARENT_REFERENCE_SHA,
            'Portable historical parent reference fixture changed')
    reference = read_json(reference_path)
    require(reference['schema'] == 1 and reference['parentEngineId'] == '0.2.6-web-endless.2' and
            reference['parentArchiveSha256'] == PARENT_SHA and reference['parentArchiveBytes'] == 40424282 and
            reference['parentArchiveEntries'] == 1076 and reference['parentArchivePrefix'] == 'endless2-candidate/' and
            reference['productionBuildReceipt'] == json.loads(normal) and
            reference['productionBuildReceiptSha256'] == digest(normal) and
            reference['sourceSha256'] == old_source and
            reference['productionObjectSha256'] == old_build['productionObjectSha256'] and
            reference['productionSourceFiles'] == 852 and reference['productionObjectCount'] == 134 and
            reference['parentBaseHarnessSha256'] == digest(base) and reference['ordinaryPolicySha256'] == digest(old_policy) and
            reference['publishedBackendReceiptSha256'] == digest(parent_build_bytes) and
            reference['publishedBackendArtifactSha256'] == old_build['testArtifactSha256'] and
            reference['publishedBackendBuilderSha256'] == old_build['builderSha256'] and
            reference['publishedBackendTestInputSha256'] == old_build['testInputSha256'],
            'Portable parent reference must be independently authenticated to the actual published .2 archive')
    base_snapshot = ROOT/'tests/endless3-parent-base-harness.snapshot.cpp'
    policy_snapshot = ROOT/'tests/endless3-parent-ordinary-policy.snapshot.h'
    require(reference['parentBaseHarnessSnapshot'] == base_snapshot.name and base_snapshot.read_bytes() == base and
            reference['ordinaryPolicySnapshot'] == policy_snapshot.name and policy_snapshot.read_bytes() == old_policy,
            'Portable parent base scaffold/policy snapshots differ from actual published bytes')
    receipt = ROOT/'tests/endless3-parent-build.json'
    build = read_json(receipt)
    require(build.get('execution') == 'complete-production-engine' and
            build.get('parentEngine') is True and build.get('optimization') == 'O2' and
            build.get('productionObjectCount') == 134 and
            build.get('productionBuildReceiptSha256') == digest(normal) and
            build.get('sourceSha256') == old_source and
            build.get('productionObjectSha256') == old_build['productionObjectSha256'],
            'Historical comparator must use exactly the frozen published .2 headers/objects')
    fragment = ROOT/'tests/endless3-parent-fragment.snapshot.cpp'
    driver = ROOT/'tests/endless3-parent-harness.generated.cpp'
    builder = ROOT/'tests/build-endless3-late.py'
    require(build.get('parentBaseHarnessSha256') == digest(base) and
            build.get('fragmentSnapshotSha256') == digest(fragment.read_bytes()) and
            build.get('generatedHarnessSha256') == digest(driver.read_bytes()) and
            build.get('builderSha256') == digest(builder.read_bytes()),
            'Historical comparator recipe/driver snapshot changed')
    base_prefix = base.decode('utf-8').replace('\r\n','\n').rsplit('int main(int argc',1)[0]
    require(driver.read_text(encoding='utf-8') == base_prefix+fragment.read_text(encoding='utf-8'),
            'Historical comparator did not retain the exact published .2 base harness')
    parent_inputs = ('pool-panic-endless-ordinary-policy.h','endless3-late-policy.h','endless3-late-actions.h',
        'endless3-early-equivalence.h','endless3-parent-migration-factory.h','endless3-migration-controls.h',
        'endless3-parent-reference.json','endless3-parent-base-harness.snapshot.cpp',
        'endless3-parent-ordinary-policy.snapshot.h','endless3-established-layout.json')
    late_contract = read_json(ROOT/'tests/endless3-verification-contract.json')
    require(build.get('parentReferenceSha256') == PARENT_REFERENCE_SHA and
            build.get('testInputSha256') == {name:digest((ROOT/'tests'/name).read_bytes()) for name in parent_inputs} ==
                late_contract['parentTestInputs'] and
            (ROOT/'tests/pool-panic-endless-ordinary-policy.h').read_bytes() == old_policy,
            'Historical comparator frozen test inputs or ordinary-player policy changed')
    artifacts = [ROOT/'tests'/('endless3-parent-engine'+suffix) for suffix in ('.js','.wasm')]
    require(set(build.get('testArtifactSha256',{})) == {p.name for p in artifacts} and
            all(p.is_file() and digest(p.read_bytes()) == build['testArtifactSha256'][p.name] for p in artifacts),
            'Historical comparator artifact changed')
    return artifacts, {'scope':'Authenticated published Endless.2 historical comparison only; excluded from current .3 backend/object counts.',
        'parentSourceArchiveSha256':PARENT_SHA,'productionBuildReceiptSha256':digest(normal),
        'productionSourceFiles':852,'productionObjectCount':134,
        'receipt':{'path':receipt.relative_to(ROOT).as_posix(),**record(receipt.read_bytes())},
        'portableReference':{'path':reference_path.relative_to(ROOT).as_posix(),**record(reference_path.read_bytes())},
        'baseHarnessSnapshot':{'path':base_snapshot.relative_to(ROOT).as_posix(),**record(base_snapshot.read_bytes())},
        'ordinaryPolicySnapshot':{'path':policy_snapshot.relative_to(ROOT).as_posix(),**record(policy_snapshot.read_bytes())},
        'artifacts':[{'path':p.relative_to(ROOT).as_posix(),**record(p.read_bytes())} for p in artifacts]}



def late_evidence_inputs(endless):
    """Select only the frozen .3 evidence, preserving the independent .2 base."""
    contract_path=ROOT/'tests/endless3-verification-contract.json'
    require(digest(contract_path.read_bytes()) == ENDLESS3_CONTRACT_SHA, 'Late verification contract changed')
    contract=read_json(contract_path);late=endless['lateGame']
    require(late['status']=='PASS' and late['contractSha256']==ENDLESS3_CONTRACT_SHA and
            late['nativeArtInputs']==contract['nativeArtInputs']==746 and
            late['nativeArtFixtureSha256']=='292841afb14e16416ea5cbd4b3749fd6ec7faa858cafb3612fe47b22d3fe79d8' and
            late['fixtureSha256']==contract['fixtureSha256'], 'Late .3 proof/art/fixture identity differs')
    selected=[]
    require(len(contract['fixtureSha256'])==120, 'Frozen late fixture inventory changed')
    for name,pin in contract['fixtureSha256'].items():
        path=ROOT/'tests'/safe_name(name)
        require(path.is_file() and digest(path.read_bytes())==pin, 'Late documentary/migration fixture changed: '+name)
        selected.append(path)
    groups=(('earnedRuns','earned',4),('syntheticWindows','windows',16),('parentWindows','parentWindows',4),
            ('narrowControls','narrow',2),('migrationControls','migration',2))
    rows=[]
    for field,matrix,count in groups:
        cases=late[field]
        require(len(cases)==count and {(r['name'],r['speed'],r['seed']) for r in cases}==
            {tuple(item) for item in contract['matrices'][matrix]}, 'Late case identity changed: '+field)
        rows+=cases
    require(len(rows)==28 and late['checks']==852+134+504+sum(r['checks'] for r in rows) and
            late['earnedFlagCount']==48 and late['syntheticEarnedFlagCount']==0 and
            endless['nativePrefixFlags']==92, 'Base/late native accounting changed')
    def log(row,name):
        path=ROOT/'tests/endless3-late-logs'/safe_name(name)
        require(path.is_file() and digest(path.read_bytes())==row['logSha256'], 'Late native log changed: '+name)
        text=path.read_text(encoding='utf-8')
        records=[json.loads(line.removeprefix('POOL_PANIC_ENDLESS_RESULT ')) for line in text.splitlines()
            if line.startswith('POOL_PANIC_ENDLESS_RESULT ')]
        clean={k:v for k,v in row.items() if k not in ('boundarySyncs','boundarySyncCount','logSha256','resourceCapacityWarnings')}
        require(len(records)==1 and records[0]==clean, 'Late row differs from complete raw stdout: '+name)
        sync=[json.loads(line.removeprefix('ENDLESS_BOUNDARY_SYNC_RESULT ')) for line in text.splitlines()
            if line.startswith('ENDLESS_BOUNDARY_SYNC_RESULT ')]
        require(sync==row['boundarySyncs'] and row['boundarySyncCount']==len(sync) and
            row['resourceCapacityWarnings']==sum(text.count(t) for t in
                ('Too many particle emitters','Too many particle systems','Too many particles'))==0,
            'Late raw native callback/capacity ledger differs: '+name)
        selected.append(path)
    for row in rows:log(row,f"{row['name']}-{row['speed']}x-{row['seed']}.log")
    log(late['migrationFactory'],'parent-migration-factory-1x-1729.log')
    log(late['earlyEquivalence']['parentProbe'],'parent-early-equivalence-1x-1729.log')
    log(late['earlyEquivalence']['currentProbe'],'current-early-equivalence-1x-1729.log')
    exports=late['exports']
    require(len(exports)==4 and {(r['name'],r['speed'],r['seed']) for r in exports}==
        {tuple(item) for item in contract['matrices']['earned']}, 'Earned checkpoint export identity changed')
    for entry in exports:
        require(entry['actualEarnedFlags']==8 and entry['syntheticStartingFixture'] is False and
            set(entry['files'])=={'earned-flag-8.v4','earned-flag-8-profile.dat','earned-flag-8-metadata.json'},
            'Actual earned8 export scope changed')
        folder=ROOT/'tests/endless3-earned-checkpoints'/f"late-earned-{entry['speed']}x-{entry['seed']}"
        for name,pin in entry['files'].items():
            path=folder/safe_name(name)
            require(path.is_file() and path.stat().st_size==pin['bytes'] and digest(path.read_bytes())==pin['sha256'],
                'Actual earned8 native checkpoint changed: '+str(path))
            selected.append(path)
    reproduction=late['migrationFactoryReproduction']
    board_names={'endless2-migration-early.v4','endless2-migration-backlog.v4'}
    require(reproduction['excludedBoardFields']==[89,90] and set(reproduction['files'])==board_names and
        set(reproduction['exactCompanionFilesSha256'])==set(MIGRATION_FIXTURE_FILES)-board_names,
        'Native factory reproduction must scope exactly two typed diagnostics and all seven files')
    canonical={'endless2-migration-early.v4':'821e15db2191551598d244ed35293c23ca37f02ce1fa36fcc94b3de2653638fe',
        'endless2-migration-backlog.v4':'4c3b5edfb89bb5250d7c85e3a5d615fd8bbbe86b1ace118189d4df3298590a05'}
    for name,pin in reproduction['files'].items():
        path=ROOT/'tests/endless3-factory-reproduction'/safe_name(name)
        require(path.is_file() and path.stat().st_size==pin['bytes'] and digest(path.read_bytes())==pin['sha256'] and
            pin['normalizedSha256']==canonical[name], 'Fresh native factory board reproduction changed: '+name)
        selected.append(path)
    for name,pin in reproduction['exactCompanionFilesSha256'].items():
        path=ROOT/'tests/endless3-factory-reproduction'/safe_name(name)
        require(path.is_file() and digest(path.read_bytes())==pin and path.read_bytes()==(ROOT/'tests'/name).read_bytes(),
            'Fresh native factory companion must remain byte exact: '+name)
        selected.append(path)
    require(len([p for p in selected if p.parent.name=='endless3-late-logs'])==31,
        'Exactly28 late cases plus factory and dual native probes must ship')
    return sorted(set(selected)), late['checks']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path,
                        default=ROOT.parents[1] / "plants-vs-zombies-web-release")
    parser.add_argument("--build-result", type=Path, default=ROOT / "logs/build-result.json")
    parser.add_argument("--test-result", type=Path, default=ROOT / "tests/game-speed-results.json")
    parser.add_argument("--parent-manifest", type=Path, default=ROOT / "parent-engine-provenance.json",
                        help="Frozen Endless.2 engine manifest")
    parser.add_argument("--output", type=Path, default=ROOT / "staging")
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(ROOT) and output != ROOT and not output.exists(),
            "Output must be a NEW directory inside this candidate")
    release = args.release_root.resolve()
    build_result = args.build_result.resolve()
    test_result = args.test_result.resolve()
    require(build_result.is_relative_to(ROOT) and test_result.is_relative_to(ROOT / "tests"),
            "Build/test receipts must belong to this candidate")
    build = read_json(build_result)
    test_paths = [ROOT / 'tests' / (name + '-results.json') for name in
                  ['game-speed', 'qol-controls', 'decks-cooldowns', 'bonus-challenge', 'bonus-completion', 'night-shift', 'lantern-shroom', 'garden-shuffle', 'seed-swap', 'mender-bloom', 'intensive-care', 'native-layout', 'care-fatigue', 'care-full-run', 'chain-reaction', 'rally-zombie', 'rally-raid', 'lights-out', 'garlic-run', 'bungee-business', 'cob-cannon-command', 'pool-panic', 'pool-panic-endless']]
    test_reports = [read_json(path) for path in test_paths]
    tests = {'status': 'PASS focused native production tests',
             'failures': sum(report['failures'] for report in test_reports),
             'checks': sum(report['checks'] for report in test_reports),
             'sourceSha256': {key: value for report in test_reports for key, value in report['sourceSha256'].items()},
             'scope': 'Extracted production tests plus complete linked-engine Care, Chain Reaction, Rally Point, Rally Raid, Lights Out, Garlic Run, Bungee Business, Cob Cannon Command, Pool Panic and Pool Panic Endless scenarios; ordinary-player recovery, identifiable streamed supplies, real generated-phase play, native active/boundary/warning checkpoints, persistent best records and genuine hands-off defeats; original finite conveyor packets, six-row land/water placement and native single-use activations; actual native aiming, shell flight, explosions, full reload cycles and eight moving formations; actual native protection clearing, finite budgets, unique Bungee thefts, target-loss failure and native heist saves/replays; twenty actual five-board Garlic Run completions, four no-route losses and four isolated control cases; actual light-gated attacks, natural native fog edges at five lamp positions, glove tooltip hover/raster bounds, glove-over-fog composition, legal Plantern moves, active-combat save/Continue, native awards, failure/retry, slow-play balance, UI bounds and speed parity. Original regressions remain active. Audio output is disabled.'}
    require(all(str(report['status']).startswith('PASS') and report['failures'] == 0 and
                report['exitCode'] == 0 and report['checks'] > 0 for report in test_reports),
            'All twenty-three native suites must pass')
    reports_by_name = {path.name.removesuffix('-results.json'): report for path,report in zip(test_paths,test_reports)}
    raid = reports_by_name['rally-raid']
    scenarios = raid.get("scenarios", [])
    require(len(scenarios) == 32 and len(raid.get("speedParity", [])) == 16 and
            all(pair.get("sameNativeOutcome") is True for pair in raid["speedParity"]),
            "The full 32-scenario Raid matrix and 16 speed pairs must pass")
    require(sum(case.get("outcome") == "win" for case in scenarios) == 24 and
            sum(case.get("name") == "hud-controls" and case.get("syntheticUIControls") is True
                for case in scenarios) == 4 and
            sum(case.get("name") == "plant-animation-controls" and
                case.get("outcome") == "animation-pass" and
                case.get("syntheticAnimationControls") is True and
                case.get("animationOracle") == "native-iz-still-idle-live-attack-body"
                for case in scenarios) == 4,
            "Raid must distinguish 24 legal winning runs from both four-case control groups")
    lights = reports_by_name['lights-out']
    lights_cases = lights.get("scenarios", [])
    require(len(lights_cases) == 20 and len(lights.get("speedParity", [])) == 10 and
            all(pair.get("sameNativeOutcome") is True for pair in lights["speedParity"]),
            "The full Lights Out matrix and speed pairs must pass")
    lights_wins = [case for case in lights_cases if case.get("outcome") == "win"]
    lights_controls = [case for case in lights_cases if case.get("name") == "controls"]
    require(len(lights_controls) == 4 and all(
            all(case.get(field) is True for field in ("fogNaturalEdges", "nativeGloveTooltip", "gloveAboveFog")) and
            case.get("fogEdgeRows") == 5 and case.get("fogBranchCount") == 2 and case.get("croppedFogNegatives") == 10 and
            case.get("misplacedTooltipNegatives") == 1 and case.get("foggedGloveNegatives") == 1 and
            case.get("glovePixelSamples", 0) > 100 and case.get("gloveMismatchPixels") == 0
            for case in lights_controls), "Lights.2 must reject both reported fog/tooltip regressions using actual native pixels")
    require(lights.get("nativeArtInputs") == 14,
            "Both native fog styles must authenticate all fourteen original artwork inputs")
    require(len(lights_wins) == 12 and
            sum(case.get("outcome") == "loss" for case in lights_cases) == 4 and
            sum(case.get("outcome") == "controls-pass" for case in lights_cases) == 4 and
            all(case.get("minimumLampHealth", 0) > 0 and
                case.get("mowersRemaining", 0) > 0 and
                case.get("headroomFrozenAtAward") is True and
                case.get("nativeUnusedMowers") == case.get("mowersRemaining") and
                case.get("mowersRemaining", 0) + case.get("mowersTriggered", -1) == 5
                for case in lights_wins),
            "Lights Out wins must preserve the lamp and native unused-mower headroom before award cleanup")
    garlic = reports_by_name['garlic-run']
    garlic_cases = garlic.get('scenarios', [])
    require(garlic.get('optimization') == 'O2' and garlic.get('nativeArtInputs') == 51 and
            len(garlic_cases) == 24 and len(garlic.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in garlic['speedParity']),
            'Garlic Run requires the full O2 native 24-case/12-pair matrix')
    expected_totals = dict(primaryNativeWins=16, explicitReplayWins=4,
        nativeFiveBoardCompletions=20, nativeLossCases=4, isolatedControlCases=4)
    require(all(garlic.get(key) == value for key, value in expected_totals.items()),
            'Garlic Run must distinguish primary wins, full replays, losses and controls')
    wins = [case for case in garlic_cases if case.get('outcome') == 'win']
    require(len(wins) == 16 and sum(case.get('replayCompleted') is True for case in wins) == 4 and
            sum(case.get('outcome') == 'loss' for case in garlic_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in garlic_cases) == 4 and
            all(case.get('boardsSolved') == 5 and case.get('nativeZombies') == 17 and
                case.get('authoredEnemies') == 17 and case.get('mowerCount') == 0 and
                case.get('profileIndex') == 82 and case.get('profileCredits') == 1 and
                all(case.get(field) is True for field in ('awardCollected', 'bonusReturned',
                    'replayCardAvailable', 'planningHeld', 'garlicHealthUnmodified')) and
                all(case.get(field, 0) > 0 for field in ('legalMoves', 'nativeDiversions',
                    'nativeSpikeDamageEvents', 'nativeMineArmings', 'nativeMineExplosions'))
                for case in wins), 'Garlic Run earned clears must execute actual native routing and traps')
    bungee = reports_by_name['bungee-business']
    bungee_cases = bungee.get('scenarios', [])
    require(bungee.get('optimization') == 'O2' and bungee.get('nativeArtInputs') == 78 and
            len(bungee_cases) == 24 and len(bungee.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in bungee['speedParity']),
            'Bungee Business requires the full native O2 matrix and original artwork pins')
    require(sum(case.get('outcome') == 'win' for case in bungee_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in bungee_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in bungee_cases) == 4,
            'Bungee Business must distinguish actual wins, losses and isolated controls')
    cob = reports_by_name['cob-cannon-command']
    cob_cases = cob.get('scenarios', [])
    require(cob.get('optimization') == 'O2' and cob.get('nativeArtInputs') == 53 and
            len(cob_cases) == 24 and len(cob.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in cob['speedParity']),
            'Cob Cannon Command requires the full native O2 matrix and original art pins')
    require(sum(case.get('outcome') == 'win' for case in cob_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in cob_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in cob_cases) == 4,
            'Cob Cannon Command must distinguish earned wins, genuine losses and isolated controls')
    pool = reports_by_name['pool-panic']
    pool_cases = pool.get('scenarios', [])
    require(pool.get('optimization') == 'O2' and pool.get('productionObjectCount') == 134 and pool.get('nativeArtInputs') == 218 and
            len(pool_cases) == 24 and len(pool.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in pool['speedParity']),
            'Pool Panic requires the complete O2 native24-case/12-pair matrix')
    for field,count in dict(primaryNativeWins=16, explicitReplayWins=4,
            nativeBattleCompletions=20, nativeLossCases=4, isolatedControlCases=4).items():
        require(pool.get(field) == count, 'Pool Panic summary mismatch: '+field)
    require(sum(case.get('outcome') == 'win' for case in pool_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in pool_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in pool_cases) == 4,
            'Pool Panic must separate earned battles, genuine no-action losses and isolated controls')
    import importlib.util
    spec = importlib.util.spec_from_file_location('pool_package_validation', ROOT/'tests/test-pool-panic.py')
    validator = importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
    require({(r['name'],r['speed'],r['seed']) for r in pool_cases} == set(validator.MATRIX),
            'Pool Panic native scenario matrix changed')
    for case in pool_cases:
        validator.validate_result(case,(case['name'],case['speed'],case['seed']))
        require(case['resourceCapacityWarnings'] == 0, 'Native particle capacity warning')
    endless = reports_by_name['pool-panic-endless']
    contract_path = ROOT/'tests/endless2-verification-contract.json'
    require(digest(contract_path.read_bytes()) == BASE_ENDLESS_CONTRACT_SHA,
            'Historical base verification contract must remain unchanged')
    require(ENDLESS3_LATE_EVIDENCE_READY, 'TODO: require actual full base+late PASS before packaging')
    contract = read_json(contract_path)
    require(endless.get('optimization') == 'O2' and endless.get('productionObjectCount') == 134 and
            endless.get('nativeArtInputs') == contract['nativeArtInputs'] == 643,
            'Retained base native engine/art proof differs')
    spec = importlib.util.spec_from_file_location('endless_package_validation', ROOT/'tests/test-pool-panic-endless.py')
    endless_validator = importlib.util.module_from_spec(spec);spec.loader.exec_module(endless_validator)
    endless_validator.validate_report(endless)
    require({(r['name'],r['speed'],r['seed']) for r in endless['scenarios']} == set(endless_validator.MATRIX),
            'Endless native scenario matrix changed')
    for field,count in contract['summary'].items():
        require(endless.get(field) == count, 'Endless player-facing summary mismatch: '+field)
    for case in endless['scenarios']:
        endless_validator.validate_result(case,(case['name'],case['speed'],case['seed']))
        require(case['resourceCapacityWarnings'] == 0 and case.get('finiteVictory') is False and
                case.get('awardCollected') is False and case.get('profileCredits') == 0 and case.get('trophyCount') == 0,
                'Endless requires native progression without finite awards or particle exhaustion')
    late_inputs, late_checks = late_evidence_inputs(endless)
    tests['lateChecks'] = late_checks
    tests['totalChecksWithLate'] = tests['checks']+late_checks
    require(build.get("exitCode") == 0 and build.get("sourceUnchangedDuringBuild") is True,
            "A passing full build receipt is required")
    require(str(tests.get("status", "")).startswith("PASS") and tests.get("failures") == 0,
            "Passing focused native test results are required")
    require(isinstance(tests.get("checks"), int) and tests["checks"] > 0
            and isinstance(tests.get("sourceSha256"), dict) and tests["sourceSha256"],
            "Focused tests need nonempty checks and source pins")
    current = source_tree(ROOT / "source")
    hashes = {name: digest(data) for name, data in current.items()}
    require(read_json(ROOT / "logs/source-before.json") == hashes
            and read_json(ROOT / "logs/source-after.json") == hashes,
            "Source changed since the recorded build")
    require(VERSION.encode() in current["CMake/ProjectVersion.cmake"], "Wrong candidate version")
    cache = {}
    for line in (ROOT / "build/CMakeCache.txt").read_text(encoding="utf-8").splitlines():
        if not line.startswith(("#", "//")) and "=" in line and ":" in line.split("=", 1)[0]:
            key, value = line.split("=", 1)
            cache[key.split(":", 1)[0]] = value
    require(all(cache.get(key) == value for key, value in FLAGS.items()), "Unexpected build flags")
    require(Path(cache["CMAKE_HOME_DIRECTORY"]).resolve() == (ROOT / "source").resolve(),
            "Build used a different source directory")
    header = (ROOT / "build/ProjectVersion.h").read_bytes()
    require(VERSION.encode() in header, "Compiled version header mismatch")
    artifacts = {}
    for name in ["pvz-portable.js", "pvz-portable.wasm", "ProjectVersion.h"]:
        data = (ROOT / "build" / name).read_bytes()
        pin = record(data)
        expected = build["outputs"]["build/" + name]
        require(pin["bytes"] == expected["bytes"] and pin["sha256"] == expected["sha256"],
                "Build artifact changed: " + name)
        artifacts[name] = pin
    test_sources = [path for path in sorted((ROOT / 'tests').glob('*'))
                    if path.is_file() and path.name not in DEVELOPMENT_ONLY_TEST_FILES and (path.suffix in {'.py', '.cpp', '.h', '.json'} or path.name in {'care-full-run-engine.js', 'care-full-run-engine.wasm', 'chain-reaction-engine.js', 'chain-reaction-engine.wasm', 'rally-zombie-engine.js', 'rally-zombie-engine.wasm', 'rally-raid-engine.js', 'rally-raid-engine.wasm', 'lights-out-engine.js', 'lights-out-engine.wasm', 'garlic-run-engine.js', 'garlic-run-engine.wasm', 'bungee-business-engine.js', 'bungee-business-engine.wasm', 'cob-cannon-command-engine.js', 'cob-cannon-command-engine.wasm', 'pool-panic-engine.js', 'pool-panic-engine.wasm', 'pool-panic-endless-engine.js', 'pool-panic-endless-engine.wasm', 'endless3-parent-engine.js', 'endless3-parent-engine.wasm'})]
    for filename in MIGRATION_FIXTURE_FILES:
        fixture = ROOT/'tests'/filename
        require(fixture.is_file(), 'Actual parent-produced migration fixture absent: '+filename)
        test_sources.append(fixture)
    test_sources += late_inputs
    # Ship the exact fresh Endless execution evidence used by the independent
    # browser verifier, without including private development/failure probes.
    for case in endless['scenarios'] + endless['openingCorpus']:
        name = f"{case['name']}-{case['speed']}x-{case['seed']}.log"
        path = ROOT / 'tests/pool-panic-endless-logs' / safe_name(name)
        require(path.is_file() and digest(path.read_bytes()) == case['logSha256'],
                'Missing or stale actual Endless case log: ' + name)
        test_sources.append(path)
    for sample in endless['openingCorpusSeedScan']:
        name = f"variation-probe-1x-{sample['seed']}.log"
        path = ROOT / 'tests/pool-panic-endless-logs' / safe_name(name)
        require(path.is_file(), 'Missing native pre-game seed-scan log: ' + name)
        records = [json.loads(line.removeprefix('POOL_PANIC_ENDLESS_RESULT '))
                   for line in path.read_text(encoding='utf-8').splitlines()
                   if line.startswith('POOL_PANIC_ENDLESS_RESULT ')]
        require(len(records) == 1 and all(records[0].get(k) == v for k,v in sample.items()),
                'Native pre-game seed scan differs from its output: ' + name)
        test_sources.append(path)
    test_sources = sorted(set(test_sources))
    require(all(path in test_sources for path in test_paths), 'All native reports must be included')
    backend_artifacts = [ROOT / "tests" / (name + suffix)
                         for name in ["care-full-run-engine", "chain-reaction-engine",
                                      "rally-zombie-engine", "rally-raid-engine", "lights-out-engine", "garlic-run-engine", "bungee-business-engine", "cob-cannon-command-engine", "pool-panic-engine", "pool-panic-endless-engine"]
                         for suffix in [".js", ".wasm"]]
    require(len(backend_artifacts) == 20 and all(path.is_file() and path in test_sources
            for path in backend_artifacts), "All twenty native backend artifacts must be included")
    historical_artifacts, historical_comparison = historical_comparison_inputs(release)
    require(len(historical_artifacts) == 2 and all(path in test_sources for path in historical_artifacts),
            'Both authenticated historical comparator artifacts must be included separately')
    require(all(path.is_file() for path in test_sources), "Focused test text/runner/result missing")
    recipes = [ROOT / name for name in ["build-candidate.ps1", "build-chill.py", "package-chill.py", "README-chill-build.md", "parent-engine-provenance.json", "parent-source-pin.json"]]
    require(all(path.is_file() for path in recipes), "Build/package recipe missing")
    recipe_inputs = {path: path.read_bytes() for path in recipes}
    for name, expected in tests.get("sourceSha256", {}).items():
        key = name.removeprefix("source/")
        require(key in hashes and hashes[key] == expected, "Focused test source changed: " + name)
    for test_path, report in zip(test_paths, test_reports):
        for name, expected in report['sourceSha256'].items():
            key = name.removeprefix('source/')
            require(hashes.get(key) == expected, 'Stale focused report: ' + str(test_path))
        if report.get("execution") == "complete-production-engine":
            require(report["productionBuildReceiptSha256"] == digest(build_result.read_bytes()),
                    "Engine tests used a different production build")
            require(report["sourceSha256"] == {"source/" + key: pin for key, pin in hashes.items()},
                    "Engine test source graph differs from the normal Release")
            stem_name = test_path.name.removesuffix("-results.json")
            for recipe_key, filename in [("builderSha256", "build-" + stem_name + ".py"),
                                         ("runnerSha256", "test-" + stem_name + ".py")]:
                require(digest((ROOT / "tests" / filename).read_bytes()) == report[recipe_key],
                        "Stale native backend recipe: " + filename)
            for filename, pin in report["testArtifactSha256"].items():
                require(digest((ROOT / "tests" / filename).read_bytes()) == pin,
                        "Stale native backend artifact: " + filename)
        for filename, pin in report.get("fixturesSha256", {}).items():
            fixture = ROOT / "tests" / safe_name(filename)
            require(fixture in test_sources and digest(fixture.read_bytes()) == pin,
                    "Stale or omitted inherited fixture: " + filename)
        stem = test_path.name.removesuffix('-results.json')
        require(digest((ROOT / 'tests' / (stem + '-harness.cpp')).read_bytes()) ==
                report['generatedHarnessSha256'], 'Stale generated test harness: ' + stem)
    baseline_folder = release / "dist/source"
    upstream = archive_source(baseline_folder / "pvz-portable-0.2.6-source.zip", UPSTREAM_SHA,
                              "PvZ-Portable-0.2.6/", 753)
    parent = archive_source(baseline_folder / "pvz-portable-0.2.6-web-endless.2-source.zip", PARENT_SHA,
                            "endless2-candidate/source/", 852)
    parent_archive = baseline_folder / "pvz-portable-0.2.6-web-endless.2-source.zip"
    require(parent_archive.stat().st_size == 40424282, "Unexpected Endless.2 archive size")
    with zipfile.ZipFile(parent_archive) as parent_zip:
        require(len(parent_zip.infolist()) == 1076, "Unexpected Endless.2 archive entries")
    require(len(current) == 852 and set(current) == set(parent),
            "Endless rework preserves every production path and adds no serialized type")
    parent_manifest_path = (args.parent_manifest or release / "dist/game/engine-provenance.json").resolve()
    parent_manifest_raw = parent_manifest_path.read_bytes()
    parent_manifest = json.loads(parent_manifest_raw)
    require(parent_manifest["id"] == "0.2.6-web-endless.2", "Release parent is not Endless.2")
    require(parent_manifest["artifacts"]["sourceSha256"] == PARENT_SHA, "Parent source identity mismatch")
    full_patch, full_changes = make_patch(upstream, current)
    delta_patch, delta_changes = make_patch(parent, current)
    expected_delta = ["CMake/ProjectVersion.cmake", "src/Lawn/System/PoolPanicEndless.cpp", "src/Lawn/System/PoolPanicEndless.h"]
    require([change["path"] for change in delta_changes] == sorted(expected_delta),
            "Production changes must be only the reviewed late-game mode rules and release identity")
    patch_checks = {"upstream": reconstruct(upstream, full_patch, current),
                    "endless2": reconstruct(parent, delta_patch, current)}
    source_manifest = {"version": VERSION, "files": {name: record(data) for name, data in current.items()}}
    # All validation above completes before the exclusive final staging directory exists.
    output.mkdir()
    (output / "game").mkdir()
    (output / "source").mkdir()
    for name in ["pvz-portable.js", "pvz-portable.wasm"]:
        shutil.copyfile(ROOT / "build" / name, output / "game" / name)
    (output / "source" / FULL_PATCH).write_bytes(full_patch)
    (output / "source" / DELTA_PATCH).write_bytes(delta_patch)
    prefix = "endless3-candidate/"
    members = {prefix + "source/" + name: data for name, data in current.items()}
    for path, data in recipe_inputs.items():
        members[prefix + path.name] = data
    for path in test_sources:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for path in [build_result, ROOT / "logs/source-before.json", ROOT / "logs/source-after.json",
                 ROOT / "build/ProjectVersion.h"]:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    members[prefix + "source-manifest.json"] = json_bytes(source_manifest)
    # Full source already contains every modified byte. Publish authenticated
    # patches beside the archive without embedding duplicate sprite data twice.
    archive_path = output / "source" / SOURCE_NAME
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            safe_name(name)
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(archive_path) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), "Source ZIP invalid")
        require(all(archive.read(name) == data for name, data in members.items()), "Source ZIP byte mismatch")
    source_record = {"path": SOURCE_NAME, **record(archive_path.read_bytes()), "entries": len(members),
                     "uncompressedBytes": sum(map(len, members.values()))}
    limits = ["Pool Panic Endless extends its late-game pressure after six unchanged opening flags. Later authored formations add original Pogo Zombies, Dancing Zombies with native Backups, and Redeye Gargantuars alongside the existing specials, with bounded increases in formation density, shorter intervals and heavier rosters. Original combat statistics remain unchanged. New complete formations wait when the existing living actors plus that formation would exceed 128; native children remain native and can exceed this admission threshold after spawning. Accepted cards, developing defenses, automatic checkpoints, saved supply randomness and existing save layouts are preserved. All fifteen cards, accepted artwork, the compact native Menu/speed controls and every earlier mode remain unchanged. Full original parity and indefinite successful play remain unverified.",
              "Focused production-method tests and build checks do not replace broad game or browser validation.",
              "Earlier release results remain historical parent evidence. Any reused current-O2 opening prefix is explicitly sealed, source/artifact-equivalent and revalidated; it is not described as reexecuted. No separately image-generated challenge illustrations are active."]
    provenance = {
        "id": VERSION, "upstream": parent_manifest["upstream"], "sourceArchive": source_record,
        "artifacts": [{"path": "build/" + name, **pin} for name, pin in artifacts.items()],
        "sourceFiles": len(current), "sourceBytes": sum(map(len, current.values())),
        "sourceDeltaVsEndless2": delta_changes,
        "compiledVersionHeader": header.decode("utf-8"),
        "checks": {"fullRelease": {"exitCode": 0, "flags": FLAGS, "sourceUnchangedDuringBuild": True,
                    "receipt": {"path": build_result.relative_to(ROOT).as_posix(), **record(build_result.read_bytes())}},
                   "focusedNativeTests": {"status": tests["status"], "failures": 0,
                    "checks": tests["checks"], "lateChecks": tests["lateChecks"],
                    "totalChecksWithLate": tests["totalChecksWithLate"], "scope": tests["scope"],
                    "endlessBasePrefixReuse": endless.get("basePrefixReuse", {"performed": False}),
                    "reports": [{"path": path.relative_to(ROOT).as_posix(), **record(path.read_bytes()),
                        "checks": report["checks"]} for path, report in zip(test_paths, test_reports)]},
                   "patchReconstruction": patch_checks,
                   "historicalComparison": historical_comparison},
        "combinedPatch": {"path": FULL_PATCH, **record(full_patch), "sourcePaths": len(full_changes)},
        "incrementalPatch": {"path": DELTA_PATCH, **record(delta_patch), "sourcePaths": len(delta_changes)},
        "parent": {"id": parent_manifest["id"], "sourceArchiveSha256": PARENT_SHA,
                   "releaseManifestSha256": digest(parent_manifest_raw),
                   "scope": "Complete historical parent engine metadata is preserved in the parent property of engine-provenance.json."},
        "limits": limits}
    engine = {
        "id": VERSION, "upstream": parent_manifest["upstream"],
        "artifacts": {"jsSha256": artifacts["pvz-portable.js"]["sha256"],
                      "wasmSha256": artifacts["pvz-portable.wasm"]["sha256"],
                      "source": "../source/" + SOURCE_NAME, "sourceSha256": source_record["sha256"],
                      "patch": "../source/" + FULL_PATCH, "patchSha256": digest(full_patch)},
        "buildRecord": "../source/build-provenance.json",
        "change": "Extends Pool Panic Endless late-game roster and pressure while retaining its developing native defense, original combat statistics, automatic saves, persistent bests and saved-game compatibility. Existing mode IDs, all15 cards, accepted artwork and compact native Menu/speed presentation remain unchanged.",
        "caption": "with extended Pool Panic Endless late-game waves.",
        "gameAssetsIncluded": parent_manifest["gameAssetsIncluded"],
        "assetManifest": parent_manifest["assetManifest"], "assetBundleId": parent_manifest["assetBundleId"],
        "parent": parent_manifest, "parentScope": "Historical Endless.2 release metadata only; current native and browser results are recorded separately.",
        "limits": limits}
    (output / "source/build-provenance.json").write_bytes(json_bytes(provenance))
    (output / "game/engine-provenance.json").write_bytes(json_bytes(engine))
    require(source_tree(ROOT / "source") == current, "Source changed during packaging")
    require(all(path.read_bytes() == data for path, data in recipe_inputs.items()),
            "Build/package recipe changed during packaging")
    print(json.dumps({"status": "PASS staged Pool Panic Endless artifacts/source/provenance",
                      "staging": str(output), "sourceArchive": source_record,
                      "sourceFiles": len(current), "changedSourcePaths": [x["path"] for x in delta_changes],
                      "patchChecks": patch_checks, "engine": engine["artifacts"]}, indent=2))


if __name__ == "__main__":
    main()
