"""Pack exact linked native CLI artifacts using a shared lossless dictionary."""
from pathlib import Path
import hashlib,json,lzma
root=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
def pack(tests):
 files=sorted([*tests.glob('*-engine.js'),*tests.glob('*-engine.wasm')])
 assert files
 raw=bytearray();entries=[]
 for path in files:
  data=path.read_bytes();entries.append({'path':path.name,'offset':len(raw),'bytes':len(data),'sha256':sha(data)});raw.extend(data)
 packed=lzma.compress(bytes(raw),format=lzma.FORMAT_XZ,check=lzma.CHECK_CRC64,
  filters=[{'id':lzma.FILTER_LZMA2,'dict_size':16*1024*1024,'preset':6}])
 assert lzma.decompress(packed)==raw
 metadata={'format':'pvz-native-artifacts-xz-v1','files':entries,'rawBytes':len(raw),'rawSha256':sha(raw),
  'packedBytes':len(packed),'packedSha256':sha(packed)}
 return packed,(json.dumps(metadata,indent=2)+'\n').encode(),{p.name for p in files}
if __name__=='__main__':
 packed,metadata,names=pack(root/'tests')
 (root/'tests/native-artifacts.xz').write_bytes(packed)
 (root/'tests/native-artifacts.json').write_bytes(metadata)
 print(f'{len(names)} exact executable files; {len(packed):,} compressed bytes')
