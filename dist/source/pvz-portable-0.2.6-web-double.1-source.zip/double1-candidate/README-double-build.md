# Double Agent native source

Double Agent is Bonus card19, game mode91 and profile record90. The native
preparation screen supplies1500sun and seven stock plants. Plant only in the
left five columns, then use the original Let's Rock button. With planting and
the shovel locked, defend against two finite assaults. There are no mowers,
rake, free sun or combat loot.

After the defense, the same committed seed/grid layout returns at full health
as native I, Zombie cardboard. Spend1000sun on six original zombie types,
deploy on the right and eat all five brains. Native stock combat and costs
apply. Retry starts the complete challenge again. Existing Challenge fields
store the snapshot and phase; saved object structure declarations are unchanged.

Build the normal Release engine with `python build-chill.py`. The existing
`build-candidate.ps1` configures the pinned local Emscripten toolchain. The
source graph contains872files and144 non-main production objects. The13
focused suites and14 complete-engine suites must all execute against that
frozen source before packaging. The original Torch recipes, fixtures, contracts
and failed observations remain authenticated historical inputs; current test
reports are recorded separately. Native automation disables audio output.

Run `python package-double.py --output <new candidate staging directory>` to
package only a passing normal build and27 passing test reports. It checks the
actual source, object maps, recipes, linked drivers and exact parent test input
snapshot, then reconstructs both the full and incremental source patches.
The included `unpack-native-artifacts.py` restores the exact test executables.

Native raster checks cover game rendering, not browser/compositor performance.
Browser observations and public deployment have separate release records.
