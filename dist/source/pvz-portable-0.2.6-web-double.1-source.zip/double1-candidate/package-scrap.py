"""Stage authenticated Scrap.1 source/binaries after all24 native suites pass.

Only a new staging directory is published. Candidate executables stay raw and
unchanged; their downloadable copies use the shared lossless artifact codec.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, shutil, sys, tempfile, zipfile

ROOT=Path(__file__).resolve().parent
VERSION='0.2.6-web-scrap.1'
PARENT_SHA='206e5e16b0c4ae7c8b88afd94e627943b4cd15c56f82113fcaf4bb1adf4c13b1'
CARE_PROOF_SHA='509b5178025153717a04ed3c58e8c1b067da88276e8828eec59f99df1eeb998e'
SOURCE_NAME=f'pvz-portable-{VERSION}-source.zip'
FULL_PATCH='web-scrap.1.patch';DELTA_PATCH='endless3-to-scrap1.patch'
FOCUSED=['game-speed','qol-controls','decks-cooldowns','bonus-challenge','bonus-completion',
 'night-shift','lantern-shroom','garden-shuffle','seed-swap','mender-bloom','intensive-care','native-layout','care-fatigue']
ENGINES=['care-full-run','chain-reaction','rally-zombie','rally-raid','lights-out','garlic-run',
 'bungee-business','cob-cannon-command','pool-panic','pool-panic-endless','scrap-yard']
ADDED={'src/Lawn/System/ScrapYard.h','src/Lawn/System/ScrapYard.cpp',
 'src/Lawn/System/ScrapYardPresentation.h','src/Lawn/System/ScrapYardPresentation.cpp'}
CHANGED={'CMake/ProjectVersion.cmake','src/ConstEnums.h','src/Lawn/Board.cpp','src/Lawn/Challenge.cpp',
 'src/Lawn/Plant.cpp','src/Lawn/Zombie.cpp','src/Lawn/System/BonusChallenge.h','src/Lawn/Widget/ChallengeScreen.cpp','src/LawnApp.cpp'}

def module(name,filename):
 spec=importlib.util.spec_from_file_location(name,ROOT/filename)
 result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result
helpers=module('scrap_packaging_helpers','package-chill.py')
require=helpers.require;digest=helpers.digest;record=helpers.record
read_json=helpers.read_json;json_bytes=helpers.json_bytes;safe_name=helpers.safe_name

def log_pins(value):
 pins=set()
 if isinstance(value,dict):
  for key,item in value.items():
   if key=='logSha256' and isinstance(item,str):pins.add(item)
   else:pins.update(log_pins(item))
 elif isinstance(value,list):
  for item in value:pins.update(log_pins(item))
 return pins

def legacy_care_default_link(normal_bytes):
 folder=ROOT/'tests/scrap1-packaging-evidence';path=folder/'legacy-care-optimization.json';data=path.read_bytes()
 require(digest(data)==CARE_PROOF_SHA,'Reviewed Care default-link provenance changed')
 proof=json.loads(data);receipt_path=ROOT/'tests/care-full-run-build.json';receipt=read_json(receipt_path)
 require(proof['schemaVersion']==1 and proof['LegacyCareMissingOptimization'] is True and
  'optimization' not in receipt and proof['originalReceiptSha256']==digest(receipt_path.read_bytes()) and
  proof['productionBuildReceiptSha256']==receipt['productionBuildReceiptSha256']==digest(normal_bytes) and
  proof['productionSourceFiles']==856 and proof['productionObjectCount']==136 and
  proof['actualBuilderInvocation']=={'script':'tests/build-care-full-run.py','arguments':[]} and
  proof['reviewedDefault']=={'quick':False,'effectiveOptimization':'O2','alternateQuickOptimization':'O1'},
  'Care inference must retain the original receipt and actual default invocation')
 builder=(ROOT/'tests/build-care-full-run.py').read_bytes();text=builder.decode('utf-8')
 require(digest(builder)==proof['builderSha256']==receipt['builderSha256'] and
  "parser.add_argument('--quick',action='store_true'" in text and "'-O1' if args.quick else '-O2'" in text,
  'Reviewed Care builder/default optimization branch changed')
 for name,pin in proof['evidence'].items():
  actual=(folder/safe_name(name)).read_bytes()
  require(len(actual)==pin['bytes'] and digest(actual)==pin['sha256'],'Actual Care invocation evidence changed')
 summary=read_json(folder/'final800alt-build-summary.json');log=(folder/'care-full-run-default-build.log').read_bytes()
 require(summary['status']=='PASS' and summary['tag']=='final800alt' and
  summary['productionBuildReceiptSha256']==digest(normal_bytes) and summary['sourceFiles']==856 and
  summary['productionObjectCount']==136,'Actual Care build summary is stale')
 entries=[item for item in summary['suites'] if item['name']=='care-full-run']
 require(len(entries)==1 and entries[0]['action']=='build' and entries[0]['status']=='PASS' and
  entries[0]['logSha256']==digest(log),'Actual Care build log is not authenticated to its orchestration summary')
 logged=json.loads(log)
 require(all(receipt.get(key)==value for key,value in logged.items()) and
  proof['testArtifactSha256']==receipt['testArtifactSha256'], 'Care inference log/artifacts differ from the executed receipt')
 return {'path':path.relative_to(ROOT).as_posix(),**record(data),
  'inferredFromActualDefaultInvocation':True,'effectiveOptimization':'O2',
  'receiptOptimizationFieldAbsent':True,'evidence':{name:{'path':(folder/name).relative_to(ROOT).as_posix(),**pin}
   for name,pin in proof['evidence'].items()}}

def validate_reports(source,normal_bytes,care_proof):
 reports={};paths=[];objects=None
 hashes={'source/'+name:digest(data) for name,data in source.items()}
 for name in FOCUSED+ENGINES:
  path=ROOT/'tests'/f'{name}-results.json';report=read_json(path)
  require(str(report.get('status','')).startswith('PASS') and report.get('failures')==0 and
   report.get('exitCode')==0 and isinstance(report.get('checks'),int) and report['checks']>0,
   'Native suite has not actually passed: '+name)
  require(report.get('sourceSha256') and all(hashes.get(key)==pin for key,pin in report['sourceSha256'].items()),
   'Native suite is stale against the current source: '+name)
  require(digest((ROOT/'tests'/f'{name}-harness.cpp').read_bytes())==report['generatedHarnessSha256'],
   'Native suite harness changed: '+name)
  for fixture,pin in report.get('fixturesSha256',{}).items():
   require(digest((ROOT/'tests'/safe_name(fixture)).read_bytes())==pin,'Native fixture changed: '+fixture)
  if name in ENGINES:
   # The original Care receipt predates the explicit optimization field. Its
   # executed default-O2 builder, complete source/object graph and artifacts
   # retain their original schema; later engines must explicitly record O2.
   optimization_ok=report.get('optimization')=='O2' or name=='care-full-run' and 'optimization' not in report and care_proof['inferredFromActualDefaultInvocation']
   require(report.get('execution')=='complete-production-engine' and optimization_ok and
    report.get('productionObjectCount')==136 and len(report['productionObjectSha256'])==136 and
    report['sourceSha256']==hashes and report['productionBuildReceiptSha256']==digest(normal_bytes),
    'Complete native engine is not bound to the856/136 normal build: '+name)
   if objects is None:objects=report['productionObjectSha256']
   require(report['productionObjectSha256']==objects,'Current native suites link different production objects')
   for field,filename in [('builderSha256',f'build-{name}.py'),('runnerSha256',f'test-{name}.py')]:
    require(digest((ROOT/'tests'/filename).read_bytes())==report[field],'Native recipe changed: '+filename)
   for filename,pin in report['testArtifactSha256'].items():
    require(digest((ROOT/'tests'/safe_name(filename)).read_bytes())==pin,'Native executable changed: '+filename)
   # These retained-only invocations authenticate the complete case matrices,
   # raw logs, native outcomes, artwork, save ledgers and unchanged policies.
   helpers.checked([sys.executable,ROOT/'tests'/f'test-{name}.py'],cwd=ROOT)
  reports[name]=report;paths.append(path)
 require(len(reports)==24,'Exactly24 current native suites are required')
 endless=reports['pool-panic-endless']
 require(not endless.get('basePrefixReuse') and endless['lateGame']['earnedFlagCount']==48 and
  endless['lateGame']['syntheticEarnedFlagCount']==0,'All retained Endless32+28 cases must execute freshly')
 require(len(endless['scenarios'])==24 and len(endless['openingCorpus'])==8,'Retained Endless32 case set missing')
 require(len(reports['scrap-yard']['scenarios'])==18,'All18 Scrap Yard cases are required')
 return reports,paths

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--release-root',type=Path,default=ROOT.parents[1]/'plants-vs-zombies-web-release')
 parser.add_argument('--output',type=Path,default=ROOT/'staging-scrap')
 args=parser.parse_args();output=args.output.resolve();release=args.release_root.resolve()
 require(output.is_relative_to(ROOT) and output!=ROOT and not output.exists(),'Output must be a NEW candidate staging directory')
 source=helpers.source_tree(ROOT/'source');require(len(source)==856,'Expected856 production source files')
 hashes={name:digest(data) for name,data in source.items()}
 normal_path=ROOT/'logs/build-result.json';normal_bytes=normal_path.read_bytes();normal=json.loads(normal_bytes)
 require(normal.get('status')=='PASS' and normal.get('exitCode')==0 and normal.get('sourceUnchangedDuringBuild') is True and
  normal.get('sourceFiles')==856,'Passing unchanged normal856-source build required')
 for name in ['source-before.json','source-after.json']:
  require(read_json(ROOT/'logs'/name)==hashes,'Normal build source snapshot differs')
 cache={}
 for line in (ROOT/'build/CMakeCache.txt').read_text(encoding='utf-8').splitlines():
  if not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
   key,value=line.split('=',1);cache[key.split(':',1)[0]]=value
 require(all(cache.get(key)==value for key,value in helpers.FLAGS.items()),'Unexpected normal Release build flags')
 require(Path(cache['CMAKE_HOME_DIRECTORY']).resolve()==(ROOT/'source').resolve(),'Foreign normal build source directory')
 artifacts={}
 for name in ['pvz-portable.js','pvz-portable.wasm','ProjectVersion.h']:
  data=(ROOT/'build'/name).read_bytes();pin=record(data);expected=normal['outputs']['build/'+name]
  require(pin['bytes']==expected['bytes'] and pin['sha256']==expected['sha256'],'Normal artifact changed: '+name)
  artifacts[name]=pin
 require(VERSION.encode() in source['CMake/ProjectVersion.cmake'] and VERSION.encode() in
  (ROOT/'build/ProjectVersion.h').read_bytes(),'Source and compiled Scrap version differ')
 care_proof=legacy_care_default_link(normal_bytes)
 reports,report_paths=validate_reports(source,normal_bytes,care_proof)
 historical_paths,historical=helpers.historical_comparison_inputs(release)
 require(len(historical_paths)==2,'Both separately authenticated .2 comparator files are required')
 parent_path=release/'dist/source/pvz-portable-0.2.6-web-endless.3-source.zip'
 parent=helpers.archive_source(parent_path,PARENT_SHA,'endless3-candidate/source/',852)
 with zipfile.ZipFile(parent_path) as archive:
  require(archive.read('endless3-candidate/tests/build-care-full-run.py')==(ROOT/'tests/build-care-full-run.py').read_bytes(),
   'Care default builder differs from the actual published parent recipe')
  historical_test_names={name.removeprefix('endless3-candidate/') for name in archive.namelist()
   if name.startswith('endless3-candidate/tests/') and not name.endswith('/')}
 require(set(parent)<set(source) and set(source)-set(parent)==ADDED,'Production source additions exceed the four reviewed mode files')
 require({name for name in parent if parent[name]!=source[name]}==CHANGED,'Production source changes exceed the nine reviewed integration paths')
 parent_raw=(ROOT/'parent-engine-provenance.json').read_bytes();parent_manifest=json.loads(parent_raw)
 require(parent_manifest['id']=='0.2.6-web-endless.3' and parent_manifest['artifacts']['sourceSha256']==PARENT_SHA,'Wrong immediate parent metadata')
 upstream=helpers.archive_source(release/'dist/source/pvz-portable-0.2.6-source.zip',helpers.UPSTREAM_SHA,'PvZ-Portable-0.2.6/',753)
 full_patch,full_changes=helpers.make_patch(upstream,source);delta_patch,delta_changes=helpers.make_patch(parent,source)
 patch_checks={'upstream':helpers.reconstruct(upstream,full_patch,source),'endless3':helpers.reconstruct(parent,delta_patch,source)}
 codec=module('scrap_native_codec','pack-native-artifacts.py')
 packed,metadata_bytes,native_names=codec.pack(ROOT/'tests');metadata=json.loads(metadata_bytes)
 expected={name+'-engine'+suffix for name in ENGINES+['endless3-parent'] for suffix in ['.js','.wasm']}
 require(native_names==expected and len(native_names)==24,'Expected22 current and2 historical executable files')
 # Select complete test evidence. Temporary compiler/cache trees and objects are
 # excluded; all fixed contracts, original failures, logs and native saves stay.
 tests={}
 accepted_log_pins=log_pins(reports)
 # Pre-game seed scans deliberately have no per-row log hash in the historical
 # report schema. Preserve only their explicitly reported, independently
 # checked raw observations as well as the hash-pinned gameplay cases.
 scan_names=set()
 for index,sample in enumerate(reports['pool-panic-endless']['openingCorpusSeedScan']):
  require(sample['seed']==100+index and sample['preGameSeedOnly'] is True,'Opening seed-scan identity changed')
  name=f"tests/pool-panic-endless-logs/variation-probe-1x-{sample['seed']}.log"
  lines=(ROOT/name).read_text(encoding='utf-8').splitlines();prefix='POOL_PANIC_ENDLESS_RESULT '
  rows=[json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]
  require(len(rows)==1 and rows[0].get('execution')=='pre-game-variation-scan' and
   all(rows[0].get(key)==value for key,value in sample.items()),'Opening seed-scan differs from raw native output')
  scan_names.add(name)
 for path in sorted((ROOT/'tests').rglob('*')):
  if not path.is_file():continue
  relative=path.relative_to(ROOT).as_posix()
  focused_retention=relative.startswith(('tests/scrap1-focused-retention/','tests/scrap1-packaging-evidence/'))
  require(path.suffix.lower()!='.pak','Private packed game assets cannot enter corresponding source')
  if any(part in {'__pycache__','node_modules'} for part in path.relative_to(ROOT/'tests').parts):continue
  # Focused suites rebuild their small harnesses. Only the complete-engine
  # executable set belongs in the prelinked pack; do not duplicate compiler
  # outputs from earlier focused/development runs in corresponding source.
  if path.name in native_names or path.suffix.lower() in {'.js','.wasm','.o','.obj','.a','.lib','.pyc','.tmp','.exe','.dll','.pdb','.so','.dylib'} or path.name.endswith('-harness-native'):continue
  if path.name in helpers.DEVELOPMENT_ONLY_TEST_FILES:continue
  # The published historical evidence remains available. Newly generated raw
  # logs must be referenced by an actual passing report; exploratory failures
  # remain private rather than being swept into the source download.
  if not focused_retention and relative not in historical_test_names and relative not in scan_names and path.suffix=='.log' and digest(path.read_bytes()) not in accepted_log_pins:continue
  if not focused_retention and relative not in historical_test_names and path.name.endswith('-build.json') and path.name not in {name+'-build.json' for name in FOCUSED+ENGINES}:continue
  require(not path.is_symlink(),'Test evidence symlinks are not supported')
  tests[relative]=path.read_bytes()
 tests['tests/native-artifacts.xz']=packed;tests['tests/native-artifacts.json']=metadata_bytes
 recipes=['build-candidate.ps1','build-chill.py','package-chill.py','package-scrap.py','pack-native-artifacts.py',
  'unpack-native-artifacts.py','README-scrap-build.md','README-chill-build.md','parent-engine-provenance.json','parent-source-pin.json']
 recipe_inputs={name:(ROOT/name).read_bytes() for name in recipes}
 members={'source/'+name:data for name,data in source.items()};members.update(tests);members.update(recipe_inputs)
 require(not any(Path(name).suffix.lower() in {'.pak','.exe','.dll','.so','.dylib'} for name in members),
  'Corresponding source contains a private game archive or host binary')
 for name in ['logs/build-result.json','logs/source-before.json','logs/source-after.json','build/ProjectVersion.h']:
  members[name]=(ROOT/name).read_bytes()
 members['source-manifest.json']=json_bytes({'version':VERSION,'files':{name:record(data) for name,data in source.items()}})
 # Validate the shipped decoder using only its staged data, then compare every
 # restored file to the untouched original candidate executable.
 with tempfile.TemporaryDirectory(prefix='scrap-codec-check-',dir=ROOT) as temporary:
  folder=Path(temporary);(folder/'tests').mkdir();(folder/'tests/native-artifacts.xz').write_bytes(packed)
  (folder/'tests/native-artifacts.json').write_bytes(metadata_bytes)
  helpers.checked([sys.executable,ROOT/'unpack-native-artifacts.py','--root',folder])
  require(all((folder/'tests'/name).read_bytes()==(ROOT/'tests'/name).read_bytes() for name in native_names),
   'Lossless native executable reconstruction differs')
 require(helpers.source_tree(ROOT/'source')==source,'Source changed during packaging validation')
 require(all((ROOT/name).read_bytes()==data for name,data in recipe_inputs.items()),'Recipe changed during packaging validation')
 # All24 suites and every validation above have passed before final output exists.
 output.mkdir();(output/'game').mkdir();(output/'source').mkdir()
 for name in ['pvz-portable.js','pvz-portable.wasm']:shutil.copyfile(ROOT/'build'/name,output/'game'/name)
 (output/'source'/FULL_PATCH).write_bytes(full_patch);(output/'source'/DELTA_PATCH).write_bytes(delta_patch)
 archive_path=output/'source'/SOURCE_NAME;prefix='scrap1-candidate/'
 with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,data in sorted(members.items()):
   safe_name(name);info=zipfile.ZipInfo(prefix+name,date_time=(2026,11,9,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
   info.create_system=3;info.external_attr=0o100644<<16;archive.writestr(info,data)
 with zipfile.ZipFile(archive_path) as archive:
  require(archive.testzip() is None and len(archive.namelist())==len(members),'Invalid corresponding-source ZIP')
  require(all(archive.read(prefix+name)==data for name,data in members.items()),'Corresponding-source archive byte mismatch')
 source_record={'path':SOURCE_NAME,**record(archive_path.read_bytes()),'entries':len(members),'uncompressedBytes':sum(map(len,members.values()))}
 packing={'format':metadata['format'],'rawFiles':24,'currentFiles':22,'historicalFiles':2,
  'metadata':{'path':'tests/native-artifacts.json',**record(metadata_bytes)},'archive':{'path':'tests/native-artifacts.xz',**record(packed)},
  'decoder':{'path':'unpack-native-artifacts.py',**record(recipe_inputs['unpack-native-artifacts.py'])},
  'rawBytes':metadata['rawBytes'],'rawSha256':metadata['rawSha256']}
 checks=sum(report['checks'] for report in reports.values());late=reports['pool-panic-endless']['lateGame']['checks']
 limits=['Scrap Yard is a finite native night defense funded by successful metal pulls. Original plant/zombie statistics, native controls, previous modes, artwork and saved object layouts are retained. Earlier Endless acceptance gates remain unchanged and execute freshly.',
  'Synthetic controls and developer checkpoints do not count as earned progress. Native raster tests are not GPU/browser parity proof. Muted browser validation and public deployment are recorded separately. Full original-game parity remains unverified.']
 provenance={'id':VERSION,'upstream':parent_manifest['upstream'],'sourceArchive':source_record,
  'artifacts':[{'path':'build/'+name,**pin} for name,pin in artifacts.items()],
  'sourceFiles':856,'sourceBytes':sum(map(len,source.values())),'sourceDeltaVsEndless3':delta_changes,
  'compiledVersionHeader':(ROOT/'build/ProjectVersion.h').read_text(encoding='utf-8'),'nativeArtifactPacking':packing,
  'checks':{'LegacyCareMissingOptimization':care_proof,'fullRelease':{'exitCode':0,'flags':helpers.FLAGS,'sourceUnchangedDuringBuild':True,
    'receipt':{'path':'logs/build-result.json',**record(normal_bytes)}},
   'focusedNativeTests':{'status':'PASS24 native suites','failures':0,'checks':checks,'lateChecks':late,'totalChecksWithLate':checks+late,
    'scope':'13 focused native production suites and11 current complete-engine suites; all retained32base+28late Endless cases freshly executed; audio output disabled.',
    'endlessBasePrefixReuse':{'performed':False},'reports':[{'path':p.relative_to(ROOT).as_posix(),**record(p.read_bytes()),'checks':reports[p.name.removesuffix('-results.json')]['checks']} for p in report_paths]},
   'patchReconstruction':patch_checks,'historicalComparison':historical},
  'combinedPatch':{'path':FULL_PATCH,**record(full_patch),'sourcePaths':len(full_changes)},
  'incrementalPatch':{'path':DELTA_PATCH,**record(delta_patch),'sourcePaths':len(delta_changes)},
  'parent':{'id':parent_manifest['id'],'sourceArchiveSha256':PARENT_SHA,'releaseManifestSha256':digest(parent_raw)},'limits':limits}
 engine={'id':VERSION,'upstream':parent_manifest['upstream'],'artifacts':{'jsSha256':artifacts['pvz-portable.js']['sha256'],
  'wasmSha256':artifacts['pvz-portable.wasm']['sha256'],'source':'../source/'+SOURCE_NAME,'sourceSha256':source_record['sha256'],
  'patch':'../source/'+FULL_PATCH,'patchSha256':digest(full_patch)},'buildRecord':'../source/build-provenance.json',
  'change':'Adds Scrap Yard: a finite night defense where native metal pulls fund original explosive plants. Existing modes, statistics, artwork and saved layouts remain intact.',
  'caption':'with Scrap Yard metal-recycling defense.','gameAssetsIncluded':parent_manifest['gameAssetsIncluded'],
  'assetManifest':parent_manifest['assetManifest'],'assetBundleId':parent_manifest['assetBundleId'],
  'parent':parent_manifest,'parentScope':'Historical Endless.3 release metadata; current results are recorded separately.','limits':limits}
 (output/'source/build-provenance.json').write_bytes(json_bytes(provenance));(output/'game/engine-provenance.json').write_bytes(json_bytes(engine))
 require(helpers.source_tree(ROOT/'source')==source,'Source changed while writing staged artifacts')
 print(json.dumps({'status':'PASS staged Scrap.1 source/binaries/provenance','staging':str(output),'sourceArchive':source_record,
  'sourceFiles':856,'nativeSuites':24,'nativeArtifactPacking':packing,'changedSourcePaths':[x['path'] for x in delta_changes]},indent=2))

if __name__=='__main__':main()
