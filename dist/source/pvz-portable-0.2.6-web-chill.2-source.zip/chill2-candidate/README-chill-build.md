# Chill.2 original-art revision

Uses original hand-drawn game resources for Chill-shroom and all three centered
Bonus portraits. No generated artwork is used by the current renderer. Gameplay,
attacks, saved phases, internal IDs and serialized layouts stay compatible.

Run with the existing Emscripten toolchain:

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Runners accept --native for host C++20 and initialize no full game or audio device.
Release flags: DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF. Configure SDK paths
in build-candidate.ps1 when using a different workspace/toolchain.

The native renderer composes original resource sprites on CPU MemoryImages once,
fits visible hero bounds uniformly and centers the actual subject in80x65 cards.
No PNG/base64 artwork headers or external custom artwork requests are needed.
Corresponding source, test/build receipts and recipes are included. Authenticated
Chill.1/upstream source and full/delta patch reconstruction establish byte identity.
