// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LanternShroom.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../SexyAppFramework/graphics/MemoryImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <vector>

namespace LanternShroom
{
namespace
{
struct SpriteCache
{
    std::unique_ptr<Sexy::MemoryImage> preview;
    std::array<std::unique_ptr<Sexy::MemoryImage>, 3> bonus;
};
SpriteCache& CachedSprite()
{
    static SpriteCache cache;
    return cache;
}

std::unique_ptr<Sexy::MemoryImage> MakeBlankImage(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect GetVisibleBounds(Sexy::MemoryImage& image)
{
    const int width = image.GetWidth(), height = image.GetHeight();
    const uint32_t* bits = image.GetBits();
    int left = width, top = height, right = -1, bottom = -1;
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
            if ((bits[y * width + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left || bottom < top ? Sexy::Rect(0, 0, 0, 0) :
        Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}

struct PortraitPlacement
{
    float x = 0.0f;
    float y = 0.0f;
    float scale = 0.0f;
};
PortraitPlacement GetPortraitPlacement(const Sexy::Rect& bounds)
{
    PortraitPlacement placement;
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return placement;
    placement.scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    placement.x = 40.0f - (bounds.mX + bounds.mWidth * 0.5f) * placement.scale;
    placement.y = 32.5f - (bounds.mY + bounds.mHeight * 0.5f) * placement.scale;
    return placement;
}

void DrawCenteredPortrait(Sexy::Graphics& graphics, Sexy::MemoryImage& image)
{
    const PortraitPlacement placement = GetPortraitPlacement(GetVisibleBounds(image));
    if (placement.scale > 0.0f)
        PvzpDrawImageScaledF(&graphics, &image, placement.x, placement.y, placement.scale, placement.scale);
}

std::unique_ptr<Sexy::MemoryImage> MakeNativePortrait(GameMode mode)
{
    const bool cone = mode == GAMEMODE_CHALLENGE_CONE_ZONE;
    auto image = MakeBlankImage(cone ? 200 : 120, cone ? 210 : 120);
    Sexy::Graphics graphics(image.get());
    graphics.SetLinearBlend(true);
    Reanimation native;
    native.ReanimationInitializeType(cone ? 40.0f : 20.0f, cone ? 40.0f : 20.0f,
        cone ? REANIM_ZOMBIE : mode == GAMEMODE_CHALLENGE_NIGHT_SHIFT ? REANIM_PUFFSHROOM : REANIM_ICESHROOM);
    native.SetFramesForLayer("anim_idle");
    if (cone)
    {
        Zombie::SetupReanimLayers(&native, ZOMBIE_TRAFFIC_CONE);
        native.AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
        native.AssignRenderGroupToPrefix("anim_head", RENDER_GROUP_NORMAL);
        native.AssignRenderGroupToPrefix("anim_cone", RENDER_GROUP_NORMAL);
    }
    else if (mode == GAMEMODE_CHALLENGE_LANTERN_GLOW)
    {
        BindCap(native);
    }
    native.Draw(&graphics);
    return image;
}
}

void DisposeImage()
{
    SpriteCache& cache = CachedSprite();
    for (auto& image : cache.bonus) image.reset();
    cache.preview.reset();
}

void BindCap(Reanimation& reanimation, int glow)
{
    (void)glow;
    if (!reanimation.TrackExists("IceShroom_head")) return;
    if (reanimation.GetImageOverride("IceShroom_head"))
        reanimation.SetImageOverride("IceShroom_head", nullptr);
}

void ConfigureAttackAnimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body) return;
    const bool winding = !plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE &&
        GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown) == AttackPhase::Windup;
    const char* layer = plant.mIsAsleep || winding ? "anim_sleep" : "anim_idle";
    if (!body->IsAnimPlaying(layer)) body->PlayReanim(layer, REANIM_LOOP, 6, 12.0f);
    if (winding)
    {
        plant.EndBlink();
        plant.mBlinkCountdown = std::max(plant.mBlinkCountdown, kWindupTicks + 1);
    }
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (body && body->mReanimationType != REANIM_ICESHROOM)
    {
        // Upgrade the previous muzzle-bearing carrier, retaining the same plant.
        plant.EndBlink();
        plant.mApp->RemoveReanimation(plant.mBodyReanimID);
        plant.mBodyReanimID = REANIMATIONID_NULL;
        body = nullptr;
    }
    if (!body)
    {
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, plant.mSeedType, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0.0f, offsetY, plant.mRenderOrder + 1, REANIM_ICESHROOM);
        body->SetFramesForLayer(plant.mIsAsleep ? "anim_sleep" : "anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mAnimRate = 12.0f;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
        if (plant.mBlinkCountdown <= 0) plant.mBlinkCountdown = 400;
        if (!plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE)
        {
            const AttackPose pose = GetAttackPose(plant.mStateCountdown, plant.mDoSpecialCountdown);
            body->SetPosition(pose.offsetX, offsetY + pose.offsetY);
            body->OverrideScale(pose.scaleX, pose.scaleY);
        }
    }
    BindCap(*body);
    ConfigureAttackAnimation(plant);
}

Sexy::Image* GetImage()
{
    SpriteCache& cache = CachedSprite();
    if (cache.preview) return cache.preview.get();
    cache.preview = MakeNativePortrait(GAMEMODE_CHALLENGE_LANTERN_GLOW);
    return cache.preview.get();
}

Sexy::Image* GetBonusImage(GameMode mode)
{
    const int index = mode == GAMEMODE_CHALLENGE_CONE_ZONE ? 0 : mode == GAMEMODE_CHALLENGE_NIGHT_SHIFT ? 1 :
        mode == GAMEMODE_CHALLENGE_LANTERN_GLOW ? 2 : -1;
    if (index < 0) return nullptr;
    SpriteCache& cache = CachedSprite();
    if (!cache.bonus[index])
    {
        if (!PvzpLoadResources(index == 0 ? "DelayLoad_Background1" : "DelayLoad_Background2")) return nullptr;
        Sexy::Image* background = index == 0 ? Sexy::IMAGE_BACKGROUND1 : Sexy::IMAGE_BACKGROUND2;
        if (!background) return nullptr;
        auto picture = MakeBlankImage(80, 65);
        Sexy::Graphics graphics(picture.get());
        graphics.SetLinearBlend(true);
        graphics.DrawImage(background, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
        auto portrait = MakeNativePortrait(mode);
        DrawCenteredPortrait(graphics, *portrait);
        cache.bonus[index] = std::move(picture);
    }
    return cache.bonus[index].get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* preview = GetImage())
        PvzpDrawImageScaledF(graphics, preview, x - 20.0f * scaleX, y - 20.0f * scaleY, scaleX, scaleY);
}

void DrawAttackPulse(Sexy::Graphics* graphics, const Plant& plant, float offsetY)
{
    if (plant.mDead || plant.mPlantHealth < 0 || plant.mSquished || plant.mIsAsleep || plant.mOnBungeeState != NOT_ON_BUNGEE) return;
    const AttackPhase phase = GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown);
    if (phase == AttackPhase::Idle) return;
    Sexy::Graphics frost(*graphics);
    // Keep transient frost on the lawn, clear of the seed bank and menu.
    frost.ClipRect(-plant.mX, 80 - plant.mY, 800, 520);
    frost.SetColorizeImages(true);
    struct Direction { float x; float y; };
    static constexpr Direction directions[12] = {
        {1,0},{0.8660254f,0.5f},{0.5f,0.8660254f},{0,1},{-0.5f,0.8660254f},{-0.8660254f,0.5f},
        {-1,0},{-0.8660254f,-0.5f},{-0.5f,-0.8660254f},{0,-1},{0.5f,-0.8660254f},{0.8660254f,-0.5f}
    };
    if (phase == AttackPhase::Windup)
    {
        const float progress = (kWindupTicks - plant.mStateCountdown) / static_cast<float>(kWindupTicks);
        const float radius = 20.0f - 14.0f * progress;
        frost.SetColor(Sexy::Color(210, 240, 255, 80 + static_cast<int>(progress * 100.0f)));
        if (Sexy::IMAGE_SNOWFLAKES)
            for (int i = 0; i < 12; i += 3)
                PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWFLAKES, 40.0f + directions[i].x * radius,
                    32.0f + offsetY + directions[i].y * radius * 0.65f, i % 3, 0.35f, 0.35f);
        return;
    }
    const float progress = 1.0f - std::clamp(plant.mDoSpecialCountdown, 0, kPulseFrames) / static_cast<float>(kPulseFrames);
    const float radius = 18.0f + (kRadius - 18.0f) * progress * (2.0f - progress);
    frost.SetColor(Sexy::Color(210, 240, 255, static_cast<int>((1.0f - progress) * 200.0f)));
    for (int i = 0; i < 12; ++i)
    {
        const float distance = radius * (0.82f + (i % 3) * 0.09f);
        if (Sexy::IMAGE_SNOWFLAKES)
            PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWFLAKES, 40.0f + directions[i].x * distance,
                40.0f + offsetY + directions[i].y * distance, i % 3, 0.45f + progress * 0.15f, 0.45f + progress * 0.15f);
        if (i % 2 == 0 && Sexy::IMAGE_SNOWPEA_PUFF)
            PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWPEA_PUFF, 40.0f + directions[i].x * radius * 0.7f,
                40.0f + offsetY + directions[i].y * radius * 0.7f, std::min(5, static_cast<int>(progress * 6)),
                0.60f + progress * 0.25f, 0.60f + progress * 0.25f);
    }
}
}
