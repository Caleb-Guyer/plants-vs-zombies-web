# Chill.9 native bonus variety revision

This candidate starts from the exact published Chill.8 source archive (SHA-256
04bd204805f83ce8322952fbba81a9e5a2d73bdf1eeafaf95b4a5c7ccf33d367).
It expands Cone Zone with functioning cone-armored variants and native giant
bowling nuts, and Night Shift with graveyard control. Original IDs, serialized
layouts, accepted plant artwork, Cold Front and its earned unlock are retained.

Run build-chill.py with the retained local Release Emscripten toolchain. Run all
seven tests/test-*.py production-method suites, then package-chill.py. Packaging
verifies coherent build/test source pins, reconstructs the full upstream and
exact parent patches, and stages source, binaries and provenance. No installed
game executable or private player data is a distribution input. Browser testing
uses ?testing=1 and generated save fixtures only.
