# Scrap Yard: corresponding source and native verification

This candidate is `0.2.6-web-scrap.1`, based on the published Endless.3 source
archive SHA-256 `206e5e16b0c4ae7c8b88afd94e627943b4cd15c56f82113fcaf4bb1adf4c13b1`.
The archive root is `scrap1-candidate/`. Its 856 production files and 136
non-main production objects retain the existing saved object layouts.

Scrap Yard owns mode88/profile record87. Its five ordinary seed packets are
Magnet-shroom, Wall-nut, Cherry Bomb, Jalapeno and Squash. Successful native
Magnet-shroom metal removals produce two original25-sun coins. Native costs,
recharge, enemy statistics, metal-pull animations and collectible-sun behavior
are retained. The starting sun gives an emergency reserve. Five Magnet-shrooms
and five Wall-nuts start on the lawn, with three original Peashooters supporting
alternating lanes. The two unsupported lanes share the player's explosive
coverage. Six authored night formations contain38 metal-bearing zombies.
Their35-second spacing does not accelerate when a successful pull removes armor.
There is no sky sun or free sunflower income. The original shovel, enemy
breach, finite award and save/Continue paths remain native. A saved pull ledger
does not repay already removed metal; loose sun and held items are native saved
objects. The previous fifteen cards and all earlier modes retain their identities.

Build the normal Release using `python build-chill.py`. Packaging requires all
24 actual native suites to pass against that unchanged normal build. Eleven
current complete-engine CLI backends link its136 non-main objects. A separate
historical comparator retains the authenticated published Endless.2 headers and
134 old objects; it is never described as current-game proof. Every retained
Endless32-base and28-late case executes freshly. The original acceptance
contract remains unchanged; `tests/scrap1-endless-retention.json` records only
the current source/object accounting and two Python runner-envelope adaptations.
Original published runner snapshots remain included.

Care's older build receipt omits an optimization field. The actual default-O2
invocation, reviewed builder branch and matching build log are retained in
`tests/scrap1-packaging-evidence/`; the original receipt remains unchanged.

The source download losslessly packs the24 prelinked JS/WASM files together.
Restore their exact pinned bytes before running retained authentication or
headless scenarios:

```
python unpack-native-artifacts.py
python tests/test-scrap-yard.py
python tests/test-pool-panic-endless.py
python tests/test-scrap-yard.py --native --asset-root PATH_TO_GAME_ASSETS --jobs 2
python tests/test-pool-panic-endless.py --native --asset-root PATH_TO_GAME_ASSETS --jobs 2
```

These runners disable audio output. No installed SDK is required to execute
the restored prelinked artifacts; rebuilding uses the configured Emscripten SDK.
The original asset bundle remains a separately supplied runtime input. Native
case logs, source/build/object maps, policies, metadata, artwork pins, migration
files and actual earned checkpoints are included. Synthetic controls never
count as earned game progress. Native raster fixtures establish their stated
layout properties, not GPU or broad original-game parity. Muted browser testing
and publication evidence are recorded separately by the website release.

`package-scrap.py` writes a fresh staging directory only after all gates pass.
It verifies both the complete upstream patch and the Endless.3 incremental patch
reconstruct every current production byte. The candidate's raw executables
remain unchanged when the downloadable archive is packed.
