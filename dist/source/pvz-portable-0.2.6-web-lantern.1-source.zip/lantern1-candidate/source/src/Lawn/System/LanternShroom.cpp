// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LanternShroom.h"
#include "LanternShroomSprite.h"
#include "../../LawnApp.h"
#include "../../SexyAppFramework/graphics/GLImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include <png.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <memory>
#include <vector>

namespace LanternShroom
{
namespace
{
struct SpriteCache
{
    std::unique_ptr<Sexy::GLImage> image;
    bool attempted = false;
};
SpriteCache& CachedSprite()
{
    static SpriteCache cache;
    return cache;
}
}

void DisposeImage()
{
    // Called before LawnApp/base graphics destruction on native app shutdown.
    SpriteCache& cache = CachedSprite();
    cache.image.reset();
    cache.attempted = false;
}

// Decode and downsample once, outside every frame/pulse/save loop. The original
// PNG is embedded exactly in the corresponding source and WebAssembly binary.
Sexy::Image* GetImage()
{
    SpriteCache& cache = CachedSprite();
    auto& sprite = cache.image;
    auto& attempted = cache.attempted;
    if (attempted) return sprite.get();
    attempted = true;
    png_image input{};
    input.version = PNG_IMAGE_VERSION;
    if (!png_image_begin_read_from_memory(&input, LanternShroomArt::kPng, LanternShroomArt::kPngSize))
        return nullptr;
    input.format = PNG_FORMAT_RGBA;
    std::vector<unsigned char> rgba(PNG_IMAGE_SIZE(input));
    if (!png_image_finish_read(&input, nullptr, rgba.data(), 0, nullptr))
    {
        png_image_free(&input);
        return nullptr;
    }
    const int width = static_cast<int>(input.width), height = static_cast<int>(input.height);
    int left = width, top = height, right = -1, bottom = -1;
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
            if (rgba[(y * width + x) * 4 + 3] > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    if (right < left || bottom < top)
    {
        png_image_free(&input);
        return nullptr;
    }
    const float sourceWidth = static_cast<float>(right - left + 1);
    const float sourceHeight = static_cast<float>(bottom - top + 1);
    const float scale = std::min(76.0f / sourceWidth, 78.0f / sourceHeight);
    const float drawWidth = sourceWidth * scale, drawHeight = sourceHeight * scale;
    const float drawX = 40.0f - drawWidth * 0.5f, drawY = 78.0f - drawHeight;
    std::vector<uint32_t> pixels(80 * 80, 0);
    for (int y = 0; y < 80; ++y)
        for (int x = 0; x < 80; ++x)
        {
            unsigned int alpha = 0, red = 0, green = 0, blue = 0;
            for (int sy = 0; sy < 4; ++sy)
                for (int sx = 0; sx < 4; ++sx)
                {
                    const float px = x + (sx + 0.5f) * 0.25f, py = y + (sy + 0.5f) * 0.25f;
                    if (px < drawX || px >= drawX + drawWidth || py < drawY || py >= drawY + drawHeight)
                        continue;
                    const int sourceX = std::clamp(left + static_cast<int>((px - drawX) / scale), 0, width - 1);
                    const int sourceY = std::clamp(top + static_cast<int>((py - drawY) / scale), 0, height - 1);
                    const auto* sample = &rgba[(sourceY * width + sourceX) * 4];
                    const unsigned int a = sample[3];
                    alpha += a; red += sample[0] * a; green += sample[1] * a; blue += sample[2] * a;
                }
            if (alpha)
                pixels[y * 80 + x] = ((alpha / 16) << 24) | ((red / alpha) << 16) | ((green / alpha) << 8) | (blue / alpha);
        }
    png_image_free(&input);
    sprite = std::make_unique<Sexy::GLImage>(gLawnApp->mGLInterface.get());
    sprite->SetBits(pixels.data(), 80, 80);
    sprite->mNumCols = 1;
    sprite->mNumRows = 1;
    return sprite.get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* sprite = GetImage())
        PvzpDrawImageScaledF(graphics, sprite, x, y, scaleX, scaleY);
}

void DrawPulse(Sexy::Graphics* graphics, float x, float y, int glow)
{
    if (glow <= 0) return;
    Sexy::Graphics pulse(*graphics);
    const float progress = 1.0f - std::clamp(glow, 0, kPulseFrames) / static_cast<float>(kPulseFrames);
    const float radius = 18.0f + (kRadius - 18.0f) * progress;
    pulse.SetColor(Sexy::Color(255, 220, 132, static_cast<int>((1.0f - progress) * 68.0f)));
    constexpr int segments = 40;
    constexpr float tau = 6.283185307179586f;
    for (int i = 0; i < segments; ++i)
    {
        const float a = i * tau / segments, b = (i + 1) * tau / segments;
        pulse.DrawLineAA(static_cast<int>(x + cos(a) * radius), static_cast<int>(y + sin(a) * radius * 0.68f),
                         static_cast<int>(x + cos(b) * radius), static_cast<int>(y + sin(b) * radius * 0.68f));
    }
}
}
