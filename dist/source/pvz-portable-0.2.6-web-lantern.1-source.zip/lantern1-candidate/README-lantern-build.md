# Lantern-shroom native build

Lantern.1 appends Lantern-shroom and its Lantern Glow Bonus challenge to Night.1.
Existing modes, plants, save layouts, controls and background save worker remain.

Build with the existing local Emscripten toolchain:

    python build-lantern.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-lantern.py

Test runners accept --native for host C++20 and initialize no game or audio.
Release flags: DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF. The recipe expects
work/toolchain; configure SDK paths on another machine. Packaging checks current
source/binary/test pins and reconstructs full-upstream and incremental Night.1
patches to compare every source byte. Each --output is a new candidate directory.
The authenticated patches are separate downloads beside the complete source;
the archive avoids duplicating the embedded sprite in two patch copies.

LanternShroomSprite.h embeds exact generated PNG bytes; the game decodes and
scales the image once at runtime. Public dist/content/lantern-shroom.png and
lantern-shroom-art.json retain the original image and generation prompt. Existing
original game resources are unchanged and remain separately bundled. No private
saves, credentials or compiled test executables belong in the source archive.
