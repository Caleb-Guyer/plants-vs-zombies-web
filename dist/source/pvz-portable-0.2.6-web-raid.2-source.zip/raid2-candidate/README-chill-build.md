# Native I, Zombie UI restoration: corresponding source and tests

Exact published Raid.1 parent source SHA-256:
50e122044bb767eb9c78cf8c38c9cd48de022f8b3f966b69b3bd29a7bbafdb8c.
The parent archive has 23,958,264 bytes, 916 entries and 828 production files
under raid1-candidate/source/. Current recipes and source use raid2-candidate/.

Raid.2 restores the original I, Zombie bank/Menu layers and native packet-pick
and ready-flash layers. Only CMake/ProjectVersion.cmake, Board.cpp and
SeedPacket.cpp differ from Raid.1. Geometry, artwork, authored boards, budgets,
combat, IDs and saved layouts are unchanged.

Build the normal Release browser engine with build-chill.py. Separate muted
Care, Chain Reaction, Rally Zombie and Rally Raid CLI drivers link those same
production objects with test-only entry points. All seventeen native reports
and eight backend JS/WASM artifacts remain release gates. Native routing is
compared with authenticated original I, Zombie methods; foreground bank
occlusion is a regression negative. Native test hardware never opens audio.

package-chill.py authenticates source/build/test receipts and exact upstream
and Raid.1 patch reconstruction before staging matching source/binaries.
Patches are web-raid.2.patch and raid1-to-raid2.patch.
