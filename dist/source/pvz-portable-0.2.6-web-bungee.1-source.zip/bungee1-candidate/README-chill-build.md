# Bungee Business: source and native tests

Exact published Garlic.1 parent source SHA-256:
389c3ab2ca51747139b34f2162d9dd8b81a973919222974cce4e8431e495749c.
Parent:29,234,821bytes,948entries,836production files undergarlic1-candidate/source/.
Current archive prefix:bungee1-candidate/. Current source:840files.

Bungee Business appends mode84, profile record83 and the twelfth Bonus card.
Five finite-budget heists use original I,Zombie input, costs, protection,
combat and Bungee grabbing/raising animations. Ground crews clear native
Umbrella-leaf coverage; only completed native departures with live unique
Sunflower targets count as thefts. Destroying/eating a target fails the board.
Duplicate/empty Bungee targets reject before spending. Only this mode disables
Sunflower payouts and incidental loot, keeping the authored budget finite.
No serialized fields, sprites or persistent challenge tips are added.

Build normal Release with build-chill.py. All twenty native suites remain
release gates. Seven silent complete-engine drivers link the same128normal
production objects exceptmain. The new24case/12pair matrix uses two seeds and
both1x/2x speeds. Earned battles execute actual packet/lawn/Continue/Retry/award
inputs with native stats, coverage, abductions and budgets. Full fresh replays
have independent observations. Separate synthetic lifecycle/UI controls do not
award completion credit. Seventy-eight original image/font/rig inputs are
authenticated. Selected-field checkpoint comparisons cover observed actors
and animation clocks; offscreen MemoryImage exports do not claim browser/GPU
equivalence. Muted browser inspection is separate; normal audio remains usable.

package-chill.py verifies exact source/build/test receipts. web-bungee.1.patch
and garlic1-to-bungee1.patch reconstruct all840production files byte-for-byte
from upstream and the exact published immediate parent. Every prior native
regression and accepted bitmap remains a release gate.
