/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
#pragma once

#include "MemoryImage.h"

namespace Sexy
{

// Opaque RGB888 CPU screen destination. Offscreen MemoryImages retain their
// distinct native MemoryImage composition. This emulates the audited nonvolatile
// DD32 software kernels, without DirectDraw surface-driver or16-bit fallbacks.
class SoftwareScreenImage final : public MemoryImage
{
    static uint32_t CompositePixel(uint32_t source, uint32_t destination,
        const Color& color, int drawMode, bool stretch, bool sourceHasAlpha, bool sourceHasTrans);

public:
    explicit SoftwareScreenImage(SexyAppBase* app);
    void Create(int width, int height) override;
    void Blt(Image* image, int x, int y, const Rect& sourceRect, const Color& color,
        int drawMode, bool linearFilter = true) override;
    void StretchBlt(Image* image, const Rect& destinationRect, const Rect& sourceRect,
        const Rect& clipRect, const Color& color, int drawMode, bool fastStretch) override;
};

}
