$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$taskTools = Join-Path (Split-Path -Parent (Split-Path -Parent $taskRoot)) 'toolchain'
$taskSdk = Join-Path $taskTools 'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
$env:EM_CONFIG = Join-Path $taskSdk '.emscripten'
$env:EM_CACHE = Join-Path $taskTools 'em-cache'
$env:EMCC_TEMP_DIR = Join-Path $taskRoot 'presenter-tests/temp'
$env:PYTHONNOUSERSITE = '1'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
& (Join-Path $taskSdk 'python/3.13.3_64bit/python.exe') (Join-Path $PSScriptRoot 'prepare-presenter-test.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& (Join-Path $taskSdk 'python/3.13.3_64bit/python.exe') (Join-Path $taskSdk 'upstream/emscripten/em++.py') (Join-Path $PSScriptRoot 'presenter-harness.cpp') -std=c++20 -O1 -fexceptions -sENVIRONMENT=node -sALLOW_MEMORY_GROWTH=1 -o (Join-Path $PSScriptRoot 'presenter-harness.js')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (Select-String -LiteralPath (Join-Path $PSScriptRoot 'presenter-harness.js') -Pattern 'AudioContext' -Quiet) { throw 'Unexpected audio initialization' }
& (Join-Path $taskSdk 'node/24.19.0_64bit/node.exe') (Join-Path $PSScriptRoot 'presenter-harness.js')
exit $LASTEXITCODE
