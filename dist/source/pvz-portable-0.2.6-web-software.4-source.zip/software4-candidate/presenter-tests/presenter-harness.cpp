// SPDX-License-Identifier: MIT
// Actual extracted presenter and shared batcher; mock GL/SDL, no game or audio.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <memory>
#include <new>
#include <set>
#include <vector>
#include <cstdio>
using GLuint = unsigned;
using GLenum = unsigned;
using GLint = int;
using GLsizei = int;
constexpr GLenum GL_SRC_ALPHA=1, GL_ONE_MINUS_SRC_ALPHA=2, GL_ONE=3, GL_ZERO=4;
constexpr GLenum GL_NEAREST=5, GL_LINEAR=6, GL_TEXTURE_2D=7, GL_TEXTURE0=8;
constexpr GLenum GL_TEXTURE_MIN_FILTER=9, GL_TEXTURE_MAG_FILTER=10;
constexpr GLenum GL_TEXTURE_WRAP_S=11, GL_TEXTURE_WRAP_T=12, GL_CLAMP_TO_EDGE=13;
constexpr GLenum GL_UNPACK_ALIGNMENT=14, GL_RGBA=15, GL_UNSIGNED_BYTE=16;
constexpr GLenum GL_NO_ERROR=0, GL_FRAMEBUFFER=17, GL_SCISSOR_TEST=18;
constexpr GLenum GL_COLOR_BUFFER_BIT=19, GL_TRIANGLE_STRIP=20;
constexpr GLenum GL_ARRAY_BUFFER=21, GL_DYNAMIC_DRAW=22;
struct GLVertex { float sx,sy,sz; uint32_t color; float tu,tv; };
struct Rect { int mX,mY,mWidth,mHeight; };
struct SDL_Window {};
struct FakeApp { void* mWindow=nullptr; };
static bool failAllocation=false;
struct RenderData {};
struct MemoryImage {
    int mWidth=0,mHeight=0;
    bool mPurgeBits=false,mHasTrans=false,mHasAlpha=false;
    RenderData* mRenderData=nullptr;
    std::vector<uint32_t> bits;
    explicit MemoryImage(FakeApp*) {}
    virtual ~MemoryImage()=default;
    void Create(int w,int h) { if(failAllocation) throw std::bad_alloc(); mWidth=w;mHeight=h;bits.resize(size_t(w)*h); }
    uint32_t* GetBits() { return bits.data(); }
    void BitsChanged() {}
    void SetImageMode(bool t,bool a) {mHasTrans=t;mHasAlpha=a;}
};
struct SoftwareScreenImage:MemoryImage { using MemoryImage::MemoryImage; };
struct GLImage:MemoryImage { explicit GLImage(FakeApp* a):MemoryImage(a){} };
struct Stats {
    int gen=0,deleted=0,allocate=0,upload=0,draw=0,swap=0,clear=0;
    GLuint boundTexture=0,program=0;
    GLenum src=0,dst=0;
    Rect viewport{};
    std::array<float,4> clearColor{};
    std::vector<uint32_t> pixels;
    std::vector<GLVertex> vertices;
    int width=0,height=0;
    bool failGen=false;
    GLenum error=GL_NO_ERROR;
} st;
static GLuint nextTexture=100;
static GLenum activeTexture=0;
static void glGenTextures(int,GLuint* p){++st.gen;*p=st.failGen?0:nextTexture++;}
static void glDeleteTextures(int,const GLuint*){++st.deleted;}
static void glActiveTexture(GLenum e){activeTexture=e;}
static void glBindTexture(GLenum,GLuint p){st.boundTexture=p;}
static void glTexParameteri(GLenum,GLenum,GLint){}
static void glPixelStorei(GLenum e,int a){assert(e==GL_UNPACK_ALIGNMENT&&a==4);}
static void glTexImage2D(GLenum,int,GLint,int w,int h,int,GLenum,GLenum,const void* p){++st.allocate;st.width=w;st.height=h;assert(!p);}
static GLenum glGetError(){auto e=st.error;st.error=0;return e;}
static void glTexSubImage2D(GLenum,int,int x,int y,int w,int h,GLenum format,GLenum type,const void* p){
    ++st.upload;assert(x==0&&y==0&&format==GL_RGBA&&type==GL_UNSIGNED_BYTE);
    st.width=w;st.height=h;auto b=static_cast<const uint32_t*>(p);st.pixels.assign(b,b+size_t(w)*h);
}
static void glBindFramebuffer(GLenum,GLuint id){assert(id==0);}
static void glUseProgram(GLuint p){st.program=p;}
static void glDisable(GLenum e){assert(e==GL_SCISSOR_TEST);}
static void glClearColor(float r,float g,float b,float a){st.clearColor={r,g,b,a};}
static void glClear(GLenum e){assert(e==GL_COLOR_BUFFER_BIT);++st.clear;}
static void glViewport(int x,int y,int w,int h){st.viewport={x,y,w,h};}
static void glBlendFunc(GLenum a,GLenum b){st.src=a;st.dst=b;}
static void glUniform1i(GLint,int){}
static void glUniform4fv(GLint,int,const float*){}
static void glBindBuffer(GLenum,GLuint){}
static void glBufferData(GLenum,size_t n,const void* p,GLenum){auto v=static_cast<const GLVertex*>(p);st.vertices.assign(v,v+n/sizeof(GLVertex));}
static void glDrawArrays(GLenum mode,GLint first,GLsizei count){assert(mode==GL_TRIANGLE_STRIP&&first==0&&count==4);++st.draw;}
static void SDL_GL_SwapWindow(SDL_Window*){++st.swap;}
static uint32_t ToLE32(uint32_t v){return v;}
static bool gLinearFilter=false;
static std::vector<GLVertex> gVertices(16384);
static int gNumVertices=0,gPrimitiveStart=0;
static GLenum gVertexMode=GLenum(-1);
static GLuint gProgram=7,gVbo=9;
static GLint gUfUseTexture=1,gUfMixedBlend=2,gUfClampUvEnabled=3,gUfUvBounds=4;
static int MAX_TEXTURE_SIZE=2048;
constexpr int MAX_VERTICES=16384;
static constexpr float kDefaultUvBounds[4]={0,0,1,1};
#include "presenter-state.inc"
class GLInterface {
public:
    FakeApp* mApp;
    int mWidth=800,mHeight=600;
    Rect mPresentationRect{8,16,400,300};
    std::unique_ptr<GLImage> mScreenImage;
    std::unique_ptr<MemoryImage> mSoftwareScreenImage;
    std::vector<uint32_t> mSoftwareFramePixels;
    GLuint mSoftwareTexture=0;
    bool mSoftwareRendering=false;
    std::set<MemoryImage*> mImageSet;
    explicit GLInterface(FakeApp* a):mApp(a),mScreenImage(std::make_unique<GLImage>(a)){}
    ~GLInterface();
    MemoryImage* GetScreenImage();
    bool IsSoftwareRendering()const;
    bool SetSoftwareRendering(bool);
    bool PresentSoftwareFrame();
    bool PreDraw();
    bool Redraw(Rect*);
    void Flush();
};
#include "presenter-actual.inc"
static void Reset(){st={};gDrawCommands.clear();gNumVertices=0;gVertexMode=GLenum(-1);gAppliedStateValid=true;gAppliedTextureValid=true;}
int main(){
    FakeApp app;
    {
        GLInterface gl(&app); auto hw=gl.GetScreenImage();
        gProgram=0;assert(!gl.SetSoftwareRendering(true)&&gl.GetScreenImage()==hw&&!gl.IsSoftwareRendering());gProgram=7;
        failAllocation=true;assert(!gl.SetSoftwareRendering(true)&&gl.GetScreenImage()==hw);failAllocation=false;
        st.failGen=true;assert(!gl.SetSoftwareRendering(true)&&gl.GetScreenImage()==hw);st.failGen=false;
        st.error=999;int dead=st.deleted;assert(!gl.SetSoftwareRendering(true)&&gl.GetScreenImage()==hw&&st.deleted==dead+1);
        Reset();assert(gl.SetSoftwareRendering(true));
        assert(gl.IsSoftwareRendering()&&gl.GetScreenImage()!=hw&&st.allocate==1);
        assert(!gAppliedStateValid&&!gAppliedTextureValid);
        auto cpu=gl.GetScreenImage();assert(!cpu->mHasAlpha&&!cpu->mHasTrans&&!cpu->mPurgeBits);
        assert(cpu->bits.front()==0xff000000&&cpu->bits.back()==0xff000000);
        cpu->bits[0]=0x00112233;cpu->bits[1]=0x80445566;cpu->bits[800]=0xff778899;cpu->bits[801]=0xffaabbcc;
        Reset();assert(gl.Redraw(nullptr));
        assert(st.upload==1&&st.draw==1&&st.swap==1&&st.allocate==0&&st.clear==1);
        assert(st.width==800&&st.height==600&&st.program==gProgram&&activeTexture==GL_TEXTURE0);
        assert(st.pixels[0]==0xff332211&&st.pixels[1]==0xff665544&&st.pixels[800]==0xff998877&&st.pixels[801]==0xffccbbaa);
        assert(st.src==GL_ONE&&st.dst==GL_ZERO);
        assert((st.clearColor==std::array<float,4>{0,0,0,1}));
        assert(st.viewport.mX==8&&st.viewport.mY==16&&st.viewport.mWidth==400&&st.viewport.mHeight==300);
        assert(gAppliedStateValid&&gAppliedTextureValid&&gDrawState.filter==GL_NEAREST&&gDrawState.clampUv==0&&gDrawState.mixedBlend==0);
        assert(st.vertices.size()==4&&st.vertices[0].sy==0&&st.vertices[0].tv==0&&st.vertices[1].sy==600&&st.vertices[1].tv==1);
        assert(st.vertices[3].sx==800&&st.vertices[3].sy==600&&st.vertices[3].tu==1&&st.vertices[3].tv==1);
        for(auto v:st.vertices)assert(v.color==0xffffffff&&v.sz==0);
        assert(gl.SetSoftwareRendering(false)&&gl.GetScreenImage()==hw&&!gl.IsSoftwareRendering());
        Reset();assert(gl.PreDraw());
        assert(gDrawState.blendSrc==GL_SRC_ALPHA&&gDrawState.blendDst==GL_ONE_MINUS_SRC_ALPHA&&gDrawState.mixedBlend==0);
        GLVertex hwQuad[4]={{0,0,0,0xffffffffu,0,0},{0,10,0,0xffffffffu,0,1},{10,0,0,0xffffffffu,1,0},{10,10,0,0xffffffffu,1,1}};
        GfxBindTexture(999);GfxBegin(GL_TRIANGLE_STRIP);GfxAddVertices(hwQuad,4);GfxEnd();
        assert(gl.Redraw(nullptr)&&st.upload==0&&st.swap==1&&st.draw==1);
        assert(st.src==GL_SRC_ALPHA&&st.dst==GL_ONE_MINUS_SRC_ALPHA&&st.boundTexture==999);
        assert(gl.SetSoftwareRendering(true)&&gl.GetScreenImage()==cpu&&st.allocate==0);
        Reset();gl.mSoftwareTexture=0;assert(!gl.Redraw(nullptr)&&st.swap==0&&gl.IsSoftwareRendering());
        gl.mSoftwareTexture=123;Reset();
    }
    assert(st.deleted==1);
    std::puts("PASS actual presenter/batcher: setup rollback, opaque CPU target, ARGB/RGBA orientation, one upload/quad/swap, viewport/black bars/state restoration, hardware return and texture cleanup.");
}
