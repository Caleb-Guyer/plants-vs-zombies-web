# SPDX-License-Identifier: MIT
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
p=root/'source/src/SexyAppFramework/graphics/GLInterface.cpp'
s=p.read_text(encoding='utf-8')
out=root/'presenter-tests'
def function(signature):
    start=s.index(signature)
    begin=s.index('{',start)
    depth=1
    i=begin+1
    while depth:
        if s[i]=='{':depth+=1
        elif s[i]=='}':depth-=1
        i+=1
    return s[start:i]+'\n'
state=s[s.index('struct GfxDrawState'):s.index('static void GfxBegin')]
(out/'presenter-state.inc').write_text(state,encoding='utf-8')
signatures=[
 'static inline uint32_t ArgbToRgba(',
 'static void GfxBegin(', 'static void SetBlendFunc(', 'static void SetMixedBlendMode(',
 'static void GfxApplyState(', 'static void GfxSubmit(', 'static void GfxEnd(',
 'static void GfxFlush(', 'static void GfxEnsureSpace(',
 'static void GfxAddVertices(const GLVertex *', 'static void SetLinearFilter(',
 'static void GfxBindTexture(', 'GLInterface::~GLInterface()',
 'MemoryImage* GLInterface::GetScreenImage()', 'bool GLInterface::IsSoftwareRendering()',
 'bool GLInterface::SetSoftwareRendering(', 'bool GLInterface::PresentSoftwareFrame()',
 'bool GLInterface::Redraw(', 'bool GLInterface::PreDraw()', 'void GLInterface::Flush()']
# Forward declarations preserve the source's helper ordering in the extracted unit.
parts=['static void GfxEnd();\nstatic void GfxSubmit();\n']+[function(x) for x in signatures]
(out/'presenter-actual.inc').write_text('\n'.join(parts),encoding='utf-8')
(out/'extraction.json').write_text(json.dumps({'source':str(p),'signatures':signatures,'scope':'Actual presenter/shared-batcher source; fake GL/SDL/MemoryImage dependencies, no engine runtime or browser pass.'},indent=2)+'\n')
print('Prepared actual presenter/shared-batcher extraction.')
