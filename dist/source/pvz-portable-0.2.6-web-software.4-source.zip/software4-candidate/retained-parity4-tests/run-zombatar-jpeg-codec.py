#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Compile baseline/patched actual ImageLib; inspect synthetic JPEG bytes only."""
from pathlib import Path
import hashlib
import json
import os
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT.parent / 'toolchain'
SDK = TOOLS / 'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
OUT = ROOT / 'codec-test/zombatar'
OUT.mkdir(parents=True, exist_ok=True)
EXPECTED = json.loads((ROOT / 'tests/zombatar-jpeg-expected.json').read_text())
env = dict(os.environ, EM_CONFIG=str(SDK / '.emscripten'),
           EM_CACHE=str(TOOLS / 'em-cache'), EMCC_TEMP_DIR=str(ROOT / 'codec-temp'),
           PYTHONNOUSERSITE='1')
ZIGZAG = [0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,
          12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,
          35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,
          58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63]

def inspect(data):
    assert data[:2] == b'\xff\xd8'
    p, tables, huffman, frame = 2, {}, {}, None
    while p < len(data):
        assert data[p] == 255
        marker = data[p+1]
        p += 2
        if marker == 0xd9:
            break
        length = int.from_bytes(data[p:p+2], 'big')
        payload = data[p+2:p+length]
        p += length
        if marker == 0xda:
            break
        if marker == 0xdb:
            q = 0
            while q < len(payload):
                flags = payload[q]
                q += 1
                assert flags >> 4 == 0, 'Expected 8-bit baseline quantizers'
                natural = [0] * 64
                for target, value in zip(ZIGZAG, payload[q:q+64]):
                    natural[target] = value
                tables[flags & 15] = natural
                q += 64
        elif marker == 0xc4:
            q = 0
            while q < len(payload):
                key = payload[q]
                counts = list(payload[q+1:q+17])
                size = sum(counts)
                values = list(payload[q+17:q+17+size])
                huffman[key] = {'counts': counts, 'values': values}
                q += 17 + size
        elif marker in (0xc0, 0xc1, 0xc2):
            precision, height, width, count = struct.unpack('>BHHB', payload[:6])
            frame = {'marker': marker, 'precision': precision,
                     'width': width, 'height': height,
                     'components': [list(payload[6+i*3:9+i*3]) for i in range(count)]}
    assert frame == {'marker': 192, 'precision': 8, 'width': 180, 'height': 180,
                     'components': [[1, 34, 0], [2, 17, 1], [3, 17, 1]]}
    return {'quantizers': tables, 'huffman': huffman, 'frame': frame}

def run_variant(variant):
    source = ROOT / f'{variant}-source/src'
    target = OUT / f'{variant}.js'
    cmd = [str(SDK / 'python/3.13.3_64bit/python.exe'),
           str(SDK / 'upstream/emscripten/em++.py'),
           str(ROOT / 'tests/zombatar-jpeg-codec.cpp'),
           str(source / 'SexyAppFramework/imagelib/ImageLib.cpp'),
           '-I' + str(source / 'SexyAppFramework'), '-I' + str(source),
           '-std=c++20', '-O2', '-fexceptions', '-sUSE_SDL=2', '-sUSE_ZLIB=1',
           '-sUSE_LIBPNG=1', '-sUSE_LIBJPEG=1', '-sENVIRONMENT=node',
           '-sFORCE_FILESYSTEM=1', '-o', str(target)]
    if variant == 'patched':
        cmd.append('-DTEST_ZOMBATAR_ENCODER')
    result = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    assert 'AudioContext' not in target.read_text(), 'Unexpected audio initialization'
    result = subprocess.run([str(SDK / 'node/24.19.0_64bit/node.exe'), str(target)],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-1000:] + result.stderr)
    files = {}
    for line in result.stdout.splitlines():
        if line.startswith('JPEG '):
            _, name, encoded = line.split(' ', 2)
            files[name] = bytes.fromhex(encoded)
    assert len(files) == (4 if variant == 'patched' else 2)
    for name, data in files.items():
        (OUT / f'{variant}-{name[1:]}').write_bytes(data)
        inspect(data)
    print(f'PASS {variant}: actual ImageLib compiled; codec decode/orientation/dimensions/failure checks; no audio initialization.')
    return files

baseline = run_variant('baseline')
patched = run_variant('patched')
results = []
for kind in ('quadrants', 'texture'):
    generic = f'/generic-{kind}.jpg'
    portrait = f'/zombatar-{kind}.jpg'
    assert baseline[generic] == patched[generic], 'General JPEG writer output changed'
    old = inspect(baseline[generic])
    new = inspect(patched[portrait])
    assert new['quantizers'] == {0: EXPECTED['Y'], 1: EXPECTED['CbCr']}
    assert new['quantizers'] != old['quantizers']
    assert new['huffman'] != old['huffman'], 'Expected actual optimized Huffman tables'
    if kind == 'quadrants':
        assert len(new['huffman'][16]['values']) < len(old['huffman'][16]['values'])
    results.append({'fixture': kind, 'general_writer_identical': True,
                    'general_sha256': hashlib.sha256(patched[generic]).hexdigest(),
                    'zombatar_sha256': hashlib.sha256(patched[portrait]).hexdigest(),
                    'zombatar_bytes': len(patched[portrait]), 'dimensions': [180,180],
                    'sampling': 'Y2x2,Cb1x1,Cr1x1', 'exact_original_static_DQT': True,
                    'optimized_DHT_differs_from_general': True,
                    'luma_ac_symbols': len(new['huffman'][16]['values'])})
report = {'scope': 'Actual compiled codec with synthetic pixels; no original runtime JPEG/pixel comparison.',
          'expected_parameter_evidence': EXPECTED['evidence'], 'results': results}
(OUT / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS original static DQT, baseline4:2:0, optimized DHT, and byte-identical general writer for both fixtures.')
