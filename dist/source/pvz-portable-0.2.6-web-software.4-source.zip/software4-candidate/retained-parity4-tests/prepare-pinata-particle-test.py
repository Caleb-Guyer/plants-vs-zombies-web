"""Extract actual production C++ slices and helpers; never initialize game/audio."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
out = root / 'tests/generated-pinata'
out.mkdir(exist_ok=True)


def braced(source, start):
    brace = source.index('{', start)
    depth = 0
    for end in range(brace, len(source)):
        depth += (source[end] == '{') - (source[end] == '}')
        if depth == 0:
            return source[start:end + 1]
    raise AssertionError('Unclosed source block')


def function(source, signature):
    assert source.count(signature) == 1, signature
    return braced(source, source.index(signature))


preamble = r'''
#include <cassert>
#include <cstdio>
#include <cstring>
#include <strings.h>
enum class ParticleEffect { PARTICLE_ZOMBIE_HEAD=6, PARTICLE_ZOMBIE_PINATA=96 };
enum class ZombiePhase { PHASE_ZOMBIE_NORMAL=0, PHASE_ZOMBIE_MOWERED=3 };
enum class ParticleEmitterID : unsigned { FIRST=0, SECOND=1 };
template<class T> struct PvzpListNode { T mValue; PvzpListNode* mNext; };
struct ParticleEmitterDefinition { const char* mName; };
struct PvzpParticleEmitter { ParticleEmitterDefinition* mEmitterDef; float mScaleOverride=1.0f; };
struct EmitterBank {
    ParticleEmitterDefinition definitions[2]{{"first"},{"second"}};
    PvzpParticleEmitter emitters[2]{{&definitions[0]},{&definitions[1]}};
    int accesses=0;
    PvzpParticleEmitter* DataArrayGet(unsigned id) { assert(id<2); ++accesses; return &emitters[id]; }
};
struct ParticleHolder { EmitterBank mEmitters; };
struct PvzpParticleSystem {
    ParticleHolder holder;
    ParticleHolder* mParticleHolder=&holder;
    PvzpListNode<ParticleEmitterID> second{ParticleEmitterID::SECOND,nullptr};
    PvzpListNode<ParticleEmitterID> first{ParticleEmitterID::FIRST,&second};
    struct { PvzpListNode<ParticleEmitterID>* mHead; } mEmitterList{&first};
    void OverrideScale(const char*,float);
};
struct Board { bool mPinataMode=true; };
struct App {
    PvzpParticleSystem head,pinata;
    bool nullHead=false,nullPinata=false;
    int headCreates=0,pinataCreates=0;
    PvzpParticleSystem* AddPvzpParticle(float x,float y,int order,ParticleEffect effect) {
        assert(x==12.0f && y==34.0f && order==56);
        if(effect==ParticleEffect::PARTICLE_ZOMBIE_HEAD) { ++headCreates; return nullHead?nullptr:&head; }
        assert(effect==ParticleEffect::PARTICLE_ZOMBIE_PINATA);
        ++pinataCreates; return nullPinata?nullptr:&pinata;
    }
};
struct Zombie {
    App app; Board board;
    App* mApp=&app; Board* mBoard=&board;
    ZombiePhase mZombiePhase=ZombiePhase::PHASE_ZOMBIE_NORMAL;
    float mScaleZombie=1.0f;
    void OverrideParticleScale(PvzpParticleSystem*);
    void OverrideParticleColor(PvzpParticleSystem*) {} // unrelated production color helper
    void ExtractedDropHeadSlice();
};
'''

cases = r'''
int failures=0;
void check(bool condition,const char* scenario,const char* property) {
    if(!condition) { std::printf("FAIL %s: %s\n",scenario,property); ++failures; }
}
void scenario(const char* name,float scale,bool enabled,bool mowed,bool nullPinata,bool nullHead=false) {
    Zombie z; z.mScaleZombie=scale; z.board.mPinataMode=enabled;
    z.mZombiePhase=mowed?ZombiePhase::PHASE_ZOMBIE_MOWERED:ZombiePhase::PHASE_ZOMBIE_NORMAL;
    z.app.nullPinata=nullPinata; z.app.nullHead=nullHead;
    assert(&z.app.head!=&z.app.pinata); // allocator gives genuinely distinct objects
    z.ExtractedDropHeadSlice();
    const bool created=enabled&&!mowed;
    check(z.app.headCreates==1,name,"head spawn unchanged");
    check(z.app.pinataCreates==(created?1:0),name,"pinata spawning conditions unchanged");
    check(z.app.head.holder.mEmitters.accesses==(nullHead?0:2),name,"head scaled exactly once");
    check(z.app.pinata.holder.mEmitters.accesses==((created&&!nullPinata)?2:0),name,"new pinata alone receives its scale");
    for(int i=0;i<2;++i) {
        check(z.app.head.holder.mEmitters.emitters[i].mScaleOverride==(nullHead?1.0f:scale),name,"head scale preserved");
        check(z.app.pinata.holder.mEmitters.emitters[i].mScaleOverride==((created&&!nullPinata)?scale:1.0f),name,"pinata emitter scale matches zombie");
    }
}
int main() {
    scenario("mini",0.5f,true,false,false);
    scenario("normal",1.0f,true,false,false);
    scenario("null new particle",0.5f,true,false,true);
    scenario("null head particle",0.5f,true,false,false,true);
    scenario("disabled mini",0.5f,false,false,false);
    scenario("disabled normal",1.0f,false,false,false);
    scenario("mowed mini",0.5f,true,true,false);
    scenario("mowed normal",1.0f,true,true,false);
    scenario("disabled and mowed",0.5f,false,true,false);
    if(failures) { std::printf("%d failed checks\n",failures); return 1; }
    std::puts("PASS 9 scenarios: distinct head/pinata objects, mini0.5/normal1, null creation, disabled/mowed guards; actual extracted C++ block and both scale helpers; no game/audio initialization.");
    return 0;
}
'''

manifest = {}
for variant, folder in [('before', 'baseline-source'), ('after', 'patched-source')]:
    zombie_path = root / folder / 'src/Lawn/Zombie.cpp'
    particle_path = root / folder / 'src/PvzpLib/PvzpParticle.cpp'
    zombie = zombie_path.read_text(encoding='utf-8')
    particle = particle_path.read_text(encoding='utf-8')
    drop = function(zombie, 'void Zombie::DropHead(unsigned int theDamageFlags)')
    head_start = drop.index('\n\tPvzpParticleSystem* aParticle =')
    head = drop[head_start:drop.index('\n\tif (aParticle)', head_start)]
    assert head.count('OverrideParticleScale(aParticle);') == 1
    branch_signature = 'if (mBoard->mPinataMode && mZombiePhase != ZombiePhase::PHASE_ZOMBIE_MOWERED)'
    assert drop.count(branch_signature) == 1
    branch = braced(drop, drop.index(branch_signature))
    scale = function(zombie, 'void Zombie::OverrideParticleScale(PvzpParticleSystem* aParticle)')
    particle_scale = function(particle, 'void PvzpParticleSystem::OverrideScale(const char* theEmitterName, float theScale)')
    body = '\nvoid Zombie::ExtractedDropHeadSlice() {\nfloat aPosX=12.0f,aPosY=34.0f; int aRenderOrder=56;\nParticleEffect aEffect=ParticleEffect::PARTICLE_ZOMBIE_HEAD;\n' + head + '\n' + branch + '\n}\n'
    generated = preamble + '\n' + particle_scale + '\n' + scale + body + cases
    target = out / f'pinata-{variant}.cpp'
    target.write_text(generated, encoding='utf-8')
    manifest[variant] = {
        'zombieSource': str(zombie_path),
        'zombieSha256': hashlib.sha256(zombie_path.read_bytes()).hexdigest(),
        'extractedBlockSha256': hashlib.sha256(branch.encode()).hexdigest(),
        'generatedSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    }
(out / 'extraction.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print('Prepared baseline/current production slices and scale helpers under tests/generated-pinata.')
