// SPDX-License-Identifier: MIT
// Synthetic codec check only: no game resources, SDL/audio initialization, or
// host filesystem mount. Emscripten writes /fixture.jpg in its own MEMFS.
#include "imagelib/ImageLib.h"
#include <cassert>
#include <cstddef>
#include <cstdio>
#include <memory>
#include <vector>
extern "C" {
#include <jpeglib.h>
}

int main()
{
    ImageLib::Image image;
    image.mWidth = 180;
    image.mHeight = 180;
    image.mBits = std::make_unique<uint32_t[]>(180 * 180);
    for (int y = 0; y < 180; ++y)
        for (int x = 0; x < 180; ++x)
            image.mBits[y * 180 + x] = y >= 90 ? 0xff0000ffu : x < 90 ? 0xffff0000u : 0xff00ff00u;
    assert(ImageLib::WriteJPEGImage("/fixture.jpg", &image));

    FILE* file = std::fopen("/fixture.jpg", "rb");
    assert(file);
    jpeg_decompress_struct decoder{};
    jpeg_error_mgr errors{};
    decoder.err = jpeg_std_error(&errors);
    jpeg_create_decompress(&decoder);
    jpeg_stdio_src(&decoder, file);
    assert(jpeg_read_header(&decoder, TRUE) == JPEG_HEADER_OK);
    jpeg_start_decompress(&decoder);
    assert(decoder.output_width == 180 && decoder.output_height == 180 && decoder.output_components == 3);
    std::vector<unsigned char> rgb(180 * 180 * 3);
    while (decoder.output_scanline < decoder.output_height) {
        JSAMPROW row = rgb.data() + decoder.output_scanline * 180 * 3;
        jpeg_read_scanlines(&decoder, &row, 1);
    }
    jpeg_finish_decompress(&decoder);
    jpeg_destroy_decompress(&decoder);
    std::fclose(file);
    auto channel = [&](int x, int y, int c) { return rgb[(y * 180 + x) * 3 + c]; };
    assert(channel(25, 25, 0) > 220 && channel(25, 25, 1) < 30 && channel(25, 25, 2) < 30);
    assert(channel(140, 25, 0) < 30 && channel(140, 25, 1) > 220 && channel(140, 25, 2) < 30);
    assert(channel(25, 140, 0) < 30 && channel(25, 140, 1) < 30 && channel(25, 140, 2) > 220);
    std::puts("PASS existing JPEG writer:180x180, ARGB-to-RGB channels, top-to-bottom orientation and decodable output.");
    return 0;
}
