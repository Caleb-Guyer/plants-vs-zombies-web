// SPDX-License-Identifier: MIT
// Actual ImageLib codec, synthetic pixels, MEMFS only; no game resources/audio.
#include "imagelib/ImageLib.h"
#include <cassert>
#include <cstdio>
#include <memory>
#include <vector>
extern "C" {
#include <jpeglib.h>
}

static void DumpFile(const char* path)
{
    FILE* file = std::fopen(path, "rb");
    assert(file);
    std::printf("JPEG %s ", path);
    for (int byte; (byte = std::fgetc(file)) != EOF;)
        std::printf("%02x", byte);
    std::puts("");
    std::fclose(file);
}

static void CheckDecodedOrientation(const char* path)
{
    FILE* file = std::fopen(path, "rb");
    assert(file);
    jpeg_decompress_struct decoder{};
    jpeg_error_mgr errors{};
    decoder.err = jpeg_std_error(&errors);
    jpeg_create_decompress(&decoder);
    jpeg_stdio_src(&decoder, file);
    assert(jpeg_read_header(&decoder, TRUE) == JPEG_HEADER_OK);
    assert(decoder.image_width == 180 && decoder.image_height == 180);
    assert(decoder.num_components == 3 && decoder.jpeg_color_space == JCS_YCbCr);
    assert(!decoder.progressive_mode);
    assert(decoder.comp_info[0].h_samp_factor == 2 && decoder.comp_info[0].v_samp_factor == 2);
    assert(decoder.comp_info[1].h_samp_factor == 1 && decoder.comp_info[1].v_samp_factor == 1);
    assert(decoder.comp_info[2].h_samp_factor == 1 && decoder.comp_info[2].v_samp_factor == 1);
    jpeg_start_decompress(&decoder);
    assert(decoder.output_components == 3);
    std::vector<unsigned char> rgb(180 * 180 * 3);
    while (decoder.output_scanline < decoder.output_height) {
        JSAMPROW row = rgb.data() + decoder.output_scanline * 180 * 3;
        jpeg_read_scanlines(&decoder, &row, 1);
    }
    jpeg_finish_decompress(&decoder);
    jpeg_destroy_decompress(&decoder);
    std::fclose(file);
    auto at = [&](int x, int y, int channel) { return rgb[(y * 180 + x) * 3 + channel]; };
    assert(at(25, 25, 0) > 220 && at(25, 25, 1) < 30 && at(25, 25, 2) < 30);
    assert(at(140, 25, 0) < 30 && at(140, 25, 1) > 220 && at(140, 25, 2) < 30);
    assert(at(25, 140, 0) < 30 && at(25, 140, 1) < 30 && at(25, 140, 2) > 220);
}

int main()
{
    ImageLib::Image image;
    image.mWidth = image.mHeight = 180;
    image.mBits = std::make_unique<uint32_t[]>(180 * 180);
    for (int fixture = 0; fixture < 2; ++fixture) {
        for (int y = 0; y < 180; ++y) {
            for (int x = 0; x < 180; ++x) {
                uint32_t pixel;
                if (fixture == 0)
                    pixel = y >= 90 ? 0xff0000ffu : x < 90 ? 0xffff0000u : 0xff00ff00u;
                else {
                    unsigned r = (x * 37 + y * 19 + (x ^ y) * 11) & 255;
                    unsigned g = (x * 7 + y * 31 + (x * y) % 251) & 255;
                    unsigned b = (x * 17 + y * 13 + (x ^ y) * 23) & 255;
                    pixel = 0xff000000u | (r << 16) | (g << 8) | b;
                }
                image.mBits[y * 180 + x] = pixel;
            }
        }
        const char* generic = fixture == 0 ? "/generic-quadrants.jpg" : "/generic-texture.jpg";
        assert(ImageLib::WriteJPEGImage(generic, &image));
        if (fixture == 0) CheckDecodedOrientation(generic);
        DumpFile(generic);
#ifdef TEST_ZOMBATAR_ENCODER
        const char* portrait = fixture == 0 ? "/zombatar-quadrants.jpg" : "/zombatar-texture.jpg";
        assert(ImageLib::WriteZombatarJPEGImage(portrait, &image));
        if (fixture == 0) CheckDecodedOrientation(portrait);
        DumpFile(portrait);
#endif
    }
    assert(!ImageLib::WriteJPEGImage("/missing-directory/output.jpg", &image));
#ifdef TEST_ZOMBATAR_ENCODER
    assert(!ImageLib::WriteZombatarJPEGImage("/missing-directory/output.jpg", &image));
#endif
    std::puts("PASS actual codec: 180x180 dimensions, baseline4:2:0, RGB order/orientation and failed-open handling.");
}
