// SPDX-License-Identifier: MIT
// Exercise the actual EM_ASM download body with a synthetic FS and DOM.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source = fs.readFileSync(new URL('../patched-source/src/Lawn/Widget/ZombatarWidget.cpp', import.meta.url), 'utf8');
const begin = source.indexOf('return EM_ASM_INT({');
const end = source.indexOf('}, thePath.c_str()) != 0;', begin);
assert(begin > 0 && end > begin);
const body = source.slice(begin + 'return EM_ASM_INT({'.length, end);
function harness({ clickFails = false, readFails = false, persistFails = false } = {}) {
  const events = [], warnings = [], timers = [], blobs = [];
  const bytes = new Uint8Array([255, 216, 255, 224, 0, 16, 74, 70, 73, 70]);
  const path = '/saves/userdata/zombatars/user900001/Zombatar_7.jpg';
  let anchor;
  const context = vm.createContext({
    $0: 1234, Uint8Array, Blob,
    UTF8ToString(pointer) { assert.equal(pointer, 1234); events.push('path'); return path; },
    FS: {
      readFile(target) { assert.equal(target, path); events.push('read'); if (readFails) throw new Error('read failed'); return bytes; },
      syncfs(populate, callback) { assert.equal(populate, false); events.push('sync'); callback(persistFails ? new Error('persist failed') : null); },
    },
    document: {
      createElement(tag) {
        assert.equal(tag, 'a');
        anchor = { click() { events.push('click'); if (clickFails) throw new Error('click failed'); }, remove() { events.push('remove'); } };
        return anchor;
      },
      body: { appendChild(value) { assert.equal(value, anchor); events.push('append'); } },
    },
    URL: {
      createObjectURL(blob) { blobs.push(blob); return 'blob:synthetic-portrait'; },
      revokeObjectURL(url) { assert.equal(url, 'blob:synthetic-portrait'); events.push('revoke'); },
    },
    setTimeout(fn, delay) { timers.push({ fn, delay }); },
    console: { warn: (...args) => warnings.push(args) },
    AudioContext() { throw new Error('Audio must never be initialized by an image download'); },
  });
  const request = vm.runInContext('(function(){' + body + '})', context);
  return { request, events, warnings, timers, blobs, bytes, anchor: () => anchor };
}

const success = harness(); assert.equal(success.request(), 1);
assert.deepEqual(success.events, ['path', 'read', 'append', 'click', 'remove', 'sync']);
assert.equal(success.anchor().download, 'Zombatar_7.jpg'); assert.equal(success.anchor().hidden, true);
assert.equal(success.blobs[0].type, 'image/jpeg');
const expected = [...success.bytes]; success.bytes.fill(0);
assert.deepEqual([...new Uint8Array(await success.blobs[0].arrayBuffer())], expected, 'Blob owns copied bytes before later FS changes');
assert.equal(success.timers[0].delay, 60000); assert(!success.events.includes('revoke'));
success.timers[0].fn(); assert.equal(success.events.at(-1), 'revoke');
console.log('PASS actual bridge copies exact bytes, preserves filename/MIME, requests download before async sync, and delays URL cleanup.');

const blocked = harness({ clickFails: true }); assert.equal(blocked.request(), 0);
assert(blocked.events.includes('remove')); assert.equal(blocked.timers.length, 1); assert(blocked.events.includes('sync'));
assert(blocked.warnings.some(w => String(w[0]).includes('download request failed')));
const missing = harness({ readFails: true }); assert.equal(missing.request(), 0);
assert.equal(missing.blobs.length, 0); assert.equal(missing.timers.length, 0); assert(missing.events.includes('sync'));
const storage = harness({ persistFails: true }); assert.equal(storage.request(), 1);
assert(storage.warnings.some(w => String(w[0]).includes('persist failed')));
assert.equal(storage.blobs.length, 1);
console.log('PASS failed read/click reports failure without a fake success; persistence failure does not cancel an already requested image download.');

const repeat = harness(); assert.equal(repeat.request(), 1); assert.equal(repeat.request(), 1);
assert.equal(repeat.blobs.length, 2); assert.equal(repeat.events.filter(e => e === 'read').length, 2);
assert.equal(repeat.anchor().download, 'Zombatar_7.jpg');
console.log('PASS download retry can read the same stored portrait again without regenerating a profile record or initializing audio.');
