$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
$taskTools=Join-Path (Split-Path -Parent $taskRoot) 'toolchain'
$taskSdk=Join-Path $taskTools 'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
$env:EM_CONFIG=Join-Path $taskSdk '.emscripten'
$env:EM_CACHE=Join-Path $taskTools 'em-cache'
$env:EMCC_TEMP_DIR=Join-Path $taskRoot 'pinata-test-temp'
$env:PYTHONNOUSERSITE='1'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
$python=Join-Path $taskSdk 'python\3.13.3_64bit\python.exe'
$node=Join-Path $taskSdk 'node\24.19.0_64bit\node.exe'
& $python (Join-Path $PSScriptRoot 'prepare-pinata-particle-test.py')
if($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
foreach($variant in @('before','after')) {
    $prefix=Join-Path $PSScriptRoot ('generated-pinata\pinata-'+$variant)
    & $python (Join-Path $taskSdk 'upstream\emscripten\em++.py') ($prefix+'.cpp') -std=c++20 -O1 -sENVIRONMENT=node -o ($prefix+'.js')
    if($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    if(Select-String -LiteralPath ($prefix+'.js') -Pattern 'AudioContext' -Quiet) { throw 'Unexpected audio initialization in isolated test' }
    & $node ($prefix+'.js')
    $observedExit=$LASTEXITCODE
    if($variant -eq 'before') {
        if($observedExit -ne 1) { throw 'Baseline must fail its behavioral assertions with exit1' }
        'EXPECTED FAILURE: unmodified baseline reproduces wrong pinata/head destination.'
    } elseif($observedExit -ne 0) { throw 'Patched actual source did not pass' }
}
'PASS: baseline fails; patched production block passes all9 scenarios. No full engine build, game or audio initialization.'
exit 0
