"""Run retained production-code regressions on isolated parity.4 source/output paths."""
from pathlib import Path
import hashlib, json, os, subprocess

ROOT=Path(__file__).resolve().parent.parent
SOURCE=Path(os.environ.get('PVZ_PARITY4_SOURCE_ROOT',ROOT/'matte-candidate/source')).resolve()
OUT=ROOT/'matte-candidate/retained-tests';OUT.mkdir(parents=True,exist_ok=True)
TOOLS=ROOT.parent/'toolchain';SDK=TOOLS/'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
PY=SDK/'python/3.13.3_64bit/python.exe';NODE=SDK/'node/24.19.0_64bit/node.exe'
env=dict(os.environ,EM_CONFIG=str(SDK/'.emscripten'),EM_CACHE=str(TOOLS/'em-cache'),EMCC_TEMP_DIR=str(OUT/'temp'),PYTHONNOUSERSITE='1')
(OUT/'temp').mkdir(exist_ok=True)
records=[]

def run(name,cmd,expected=0):
    result=subprocess.run([str(x) for x in cmd],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (OUT/(name+'.log')).write_text(result.stdout)
    assert result.returncode==expected,(name,result.returncode,result.stdout[-1800:])
    records.append({'name':name,'exit_code':result.returncode,'expected_exit_code':expected,'command':[str(x) for x in cmd],'log':str(OUT/(name+'.log'))})
    print('PASS '+name+': expected exit'+str(expected))

def adapt(name,replacements):
    text=(ROOT/'tests'/name).read_text()
    for old,new in replacements:
        assert old in text,(name,old)
        text=text.replace(old,new)
    path=OUT/name;path.write_text(text);return path

def compile_node(name,cpp,expected=0):
    target=cpp.with_suffix('.js')
    run(name+'-compile',[PY,SDK/'upstream/emscripten/em++.py',cpp,'-std=c++20','-O1','-sENVIRONMENT=node','-o',target])
    assert 'AudioContext' not in target.read_text()
    run(name,[NODE,target],expected)

root_line='root = Path(__file__).resolve().parent.parent'
prep=adapt('prepare-fullscreen-state-test.py',[(root_line,'root = Path('+repr(str(ROOT))+')'),("root / 'patched-source/src/LawnApp.cpp'","Path("+repr(str(SOURCE/'src/LawnApp.cpp'))+")"),("root / 'patched-source/src/SexyAppFramework/platform/emscripten/Window.cpp'","Path("+repr(str(SOURCE/'src/SexyAppFramework/platform/emscripten/Window.cpp'))+")"),("root / 'codec-test/fullscreen-state.cpp'","Path("+repr(str(OUT/'fullscreen-state.cpp'))+")")])
run('fullscreen-prepare',[PY,prep]);compile_node('fullscreen',OUT/'fullscreen-state.cpp')

prep=adapt('prepare-pinata-particle-test.py',[(root_line,'root = Path('+repr(str(ROOT))+')'),("root / 'tests/generated-pinata'","Path("+repr(str(OUT/'generated-pinata'))+")"),("('after', 'patched-source')","('after', "+repr(str(SOURCE))+")")])
run('pinata-prepare',[PY,prep]);compile_node('pinata-baseline',OUT/'generated-pinata/pinata-before.cpp',1);compile_node('pinata-candidate',OUT/'generated-pinata/pinata-after.cpp')

codec=adapt('run-zombatar-jpeg-codec.py',[("ROOT = Path(__file__).resolve().parents[1]",'ROOT = Path('+repr(str(ROOT))+')'),("OUT = ROOT / 'codec-test/zombatar'",'OUT = Path('+repr(str(OUT/'codec'))+')'),("source = ROOT / f'{variant}-source/src'","source = (Path("+repr(str(SOURCE))+") if variant == 'patched' else ROOT / 'baseline-source') / 'src'"),("str(ROOT / 'codec-temp')",'str(OUT / "temp")')])
(OUT/'codec/temp').mkdir(parents=True,exist_ok=True);run('codec',[PY,codec])

bridge=adapt('download-bridge.mjs',[("new URL('../patched-source/src/Lawn/Widget/ZombatarWidget.cpp', import.meta.url)",json.dumps(str(SOURCE/'src/Lawn/Widget/ZombatarWidget.cpp')))])
run('bridge',[NODE,bridge])
inputs={name:hashlib.sha256((ROOT/'tests'/name).read_bytes()).hexdigest() for name in ['prepare-fullscreen-state-test.py','prepare-pinata-particle-test.py','run-zombatar-jpeg-codec.py','zombatar-jpeg-codec.cpp','zombatar-jpeg-expected.json','download-bridge.mjs']}
(OUT/'results.json').write_text(json.dumps({'status':'PASS','source':str(SOURCE),'path_adaptations_only':True,'test_inputs_sha256':inputs,'tests':records},indent=2)+'\n')
print('PASS retained fullscreen/Pinata/codec/bridge actual-code suites on isolated parity.4 source; path adaptations only, assertions unchanged.')
