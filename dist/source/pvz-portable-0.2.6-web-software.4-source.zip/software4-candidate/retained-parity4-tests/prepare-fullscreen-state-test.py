"""Build an isolated harness from the actual fullscreen C++ implementation."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
app = (root / 'patched-source/src/LawnApp.cpp').read_text()
window = (root / 'patched-source/src/SexyAppFramework/platform/emscripten/Window.cpp').read_text()

def function(source, signature):
    assert source.count(signature) == 1
    start = source.index(signature)
    brace = source.index('{', start)
    depth = 0
    for end in range(brace, len(source)):
        depth += (source[end] == '{') - (source[end] == '}')
        if depth == 0:
            return source[start:end + 1]
    raise AssertionError('Unclosed function')

sync = function(app, 'static void SyncBrowserFullscreen(')
callback = function(app, 'static EM_BOOL BrowserFullscreenChanged(')
make = function(window, 'void SexyAppBase::MakeWindow()')
request = make[make.index('\n\tif (mWindow)'):make.index('\n\telse\n\t{')]
query = make[make.index('\n\t// A request can be pending'):make.index('\n\tif (mGLInterface')]
assert app.count('SyncBrowserFullscreen(') == 3, 'Only callback and initialization may synchronize staged UI'
assert 'emscripten_set_fullscreenchange_callback(EMSCRIPTEN_EVENT_TARGET_DOCUMENT, nullptr, EM_FALSE, nullptr);' in function(app, 'LawnApp::~LawnApp()')
switch = function(app, 'void LawnApp::SwitchScreenMode(bool wantWindowed, bool is3d, bool force)')
assert '#ifdef __EMSCRIPTEN__\n\t\taNewOptionsDialog->mFullscreenCheckbox->SetChecked(!mIsWindowed, false);' in switch
kill = function(app, 'bool LawnApp::KillNewOptionsDialog()')
registration_start = app.index('#ifdef __EMSCRIPTEN__\n\temscripten_set_fullscreenchange_callback(EMSCRIPTEN_EVENT_TARGET_DOCUMENT, this,')
registration = app[registration_start:app.index('#endif', registration_start) + len('#endif')]
destructor = function(app, 'LawnApp::~LawnApp()')
unregistration = destructor[destructor.index('#ifdef __EMSCRIPTEN__'):destructor.index('#endif') + len('#endif')]

harness = r'''
#include <cassert>
#include <cstdio>
#include <cstring>
using EM_BOOL = int;
using EMSCRIPTEN_RESULT = int;
constexpr int EM_FALSE = 0;
constexpr int EMSCRIPTEN_RESULT_SUCCESS = 0;
constexpr int EMSCRIPTEN_RESULT_NOT_SUPPORTED = -1;
constexpr const char* EMSCRIPTEN_EVENT_TARGET_DOCUMENT = "#document";
struct EmscriptenFullscreenChangeEvent {
    bool isFullscreen = false; const char* nodeName = ""; const char* id = "";
};
using FullscreenCallback = EM_BOOL(*)(int, const EmscriptenFullscreenChangeEvent*, void*);
bool registered = false, unregistered = false;
void* registeredApp = nullptr;
EMSCRIPTEN_RESULT emscripten_set_fullscreenchange_callback(const char* target, void* data, EM_BOOL capture, FullscreenCallback callback) {
    assert(std::strcmp(target, "#document") == 0 && capture == EM_FALSE);
    if (callback) { registered = true; registeredApp = data; }
    else { assert(data == nullptr); unregistered = true; registered = false; }
    return EMSCRIPTEN_RESULT_SUCCESS;
}
struct Checkbox {
    bool checked = false; int listenerCalls = 0;
    void SetChecked(bool value, bool tellListener = true) { checked = value; if (tellListener) ++listenerCalls; }
    bool IsChecked() const { return checked; }
};
struct NewOptionsDialog {
    Checkbox box, hardwareBox;
    Checkbox* mFullscreenCheckbox = &box;
    Checkbox* mHardwareAccelerationCheckbox = &hardwareBox;
};
namespace Dialogs { enum { DIALOG_NEWOPTIONS = 1 }; }
namespace Sexy {
    struct SexyAppBase {
        bool mIsWindowed = true; bool requestedWindowed = true; int switchCalls = 0;
        void SwitchScreenMode(bool windowed, bool, bool) { requestedWindowed = windowed; ++switchCalls; }
    };
    template<class... T> void LogInfoLn(const char*, T...) {}
}
using Sexy::SexyAppBase;
struct LawnApp : SexyAppBase {
    bool hasDialog = true; NewOptionsDialog dialog; int clearBacklogs = 0;
    void* GetDialog(int) { return hasDialog ? &dialog : nullptr; }
    void KillDialog(int) { hasDialog = false; }
    void ClearUpdateBacklog() { ++clearBacklogs; }
    void SwitchScreenMode(bool, bool, bool);
    bool KillNewOptionsDialog();
    void InitializeBrowserFullscreen();
    void UnregisterBrowserFullscreen();
};
bool actualFullscreen = false;
int statusResult = 0, requestResult = 0, requests = 0, exits = 0;
bool completeRequestSynchronously = false;
EMSCRIPTEN_RESULT emscripten_get_fullscreen_status(EmscriptenFullscreenChangeEvent* event) {
    event->isFullscreen = actualFullscreen; return statusResult;
}
EMSCRIPTEN_RESULT emscripten_request_fullscreen(const char* target, EM_BOOL defer) {
    assert(std::strcmp(target, "#canvas-container") == 0); assert(defer == EM_FALSE); ++requests;
    if (completeRequestSynchronously && requestResult == 0) actualFullscreen = true;
    return requestResult;
}
EMSCRIPTEN_RESULT emscripten_exit_fullscreen() {
    ++exits;
    if (completeRequestSynchronously && requestResult == 0) actualFullscreen = false;
    return requestResult;
}
'''
harness += sync + '\n' + callback
harness += '\n' + switch + '\n' + kill
harness += '\nvoid LawnApp::InitializeBrowserFullscreen() {\n' + registration + '\n}\n'
harness += '\nvoid LawnApp::UnregisterBrowserFullscreen() {\n' + unregistration + '\n}\n'
harness += '\nstruct WindowHarness { void* mWindow = this; bool mIsWindowed = true; void MakeWindow() {' + request + query + '\n} };\n'
harness += r'''
int main() {
    LawnApp app;
    app.InitializeBrowserFullscreen();
    assert(registered && registeredApp == &app);
    assert(app.mIsWindowed && !app.dialog.box.checked);
    EmscriptenFullscreenChangeEvent event{true, "BODY", ""};
    assert(BrowserFullscreenChanged(0, &event, &app) == EM_FALSE);
    assert(!app.mIsWindowed && app.dialog.box.checked && app.dialog.box.listenerCalls == 0);
    event.nodeName = "DIV"; event.id = "canvas-container";
    BrowserFullscreenChanged(0, &event, &app);
    assert(!app.mIsWindowed && app.dialog.box.checked && app.dialog.box.listenerCalls == 0);
    event.isFullscreen = false;
    BrowserFullscreenChanged(0, &event, &app);
    assert(app.mIsWindowed && !app.dialog.box.checked && app.dialog.box.listenerCalls == 0);
    app.hasDialog = false;
    event.isFullscreen = true;
    BrowserFullscreenChanged(0, &event, &app);
    assert(!app.mIsWindowed);
    app.hasDialog = true;
    SyncBrowserFullscreen(&app, false);
    app.dialog.box.SetChecked(true); // ordinary staged native checkbox click
    assert(app.mIsWindowed && app.dialog.box.checked && app.dialog.box.listenerCalls == 1);
    app.KillNewOptionsDialog(); // real implementation must pass the staged choice to SwitchScreenMode
    assert(app.switchCalls == 1 && !app.requestedWindowed && !app.hasDialog && app.clearBacklogs == 1);
    assert(app.dialog.box.listenerCalls == 1); // synchronization did not re-enter the checkbox listener
    app.UnregisterBrowserFullscreen();
    assert(unregistered && !registered);

    WindowHarness window;
    requestResult = -2; actualFullscreen = false; window.mIsWindowed = false;
    window.MakeWindow();
    assert(window.mIsWindowed && requests == 1); // rejected entry
    requestResult = 0; window.mIsWindowed = false;
    window.MakeWindow();
    assert(window.mIsWindowed && requests == 2); // pending entry remains actually windowed
    actualFullscreen = true; window.mIsWindowed = false;
    window.MakeWindow();
    assert(!window.mIsWindowed); // initial or actual fullscreen wins
    window.mIsWindowed = true;
    window.MakeWindow();
    assert(!window.mIsWindowed && exits == 1); // pending exit remains actually fullscreen
    completeRequestSynchronously = true;
    window.mIsWindowed = true; window.MakeWindow();
    assert(window.mIsWindowed && !actualFullscreen);
    window.mIsWindowed = false; window.MakeWindow();
    assert(!window.mIsWindowed && actualFullscreen);
    statusResult = EMSCRIPTEN_RESULT_NOT_SUPPORTED;
    window.mIsWindowed = false; window.MakeWindow();
    assert(window.mIsWindowed); // unavailable fullscreen cannot be reported checked
    statusResult = 0; window.mWindow = nullptr; actualFullscreen = true;
    window.MakeWindow(); assert(!window.mIsWindowed); // initial query; no request
    std::puts("PASS actual extracted C++ fullscreen logic: BODY/container entry, external exit, pending/rejected/unsupported status, staged Options application, no listener recursion, registration/unregistration; no audio initialized.");
}
'''
target = root / 'codec-test/fullscreen-state.cpp'
target.write_text(harness)
print(target)
