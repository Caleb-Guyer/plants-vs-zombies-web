$ErrorActionPreference='Stop'
$candidateRoot=Split-Path -Parent $PSScriptRoot
$taskWork=Split-Path -Parent (Split-Path -Parent $candidateRoot)
$env:PVZ_WORK_ROOT=$taskWork
$env:PVZ_TOOLCHAIN_ROOT=Join-Path $taskWork 'toolchain'
$env:PVZ_MATTE_TEST_OUT=Join-Path $PSScriptRoot 'results'
$env:PVZ_MATTE_BASELINE_ROOT=Join-Path $PSScriptRoot 'baseline'
$env:PVZ_MATTE_SOURCE_ROOT=Join-Path $candidateRoot 'source'
$env:PYTHONNOUSERSITE='1'
& (Join-Path $env:PVZ_TOOLCHAIN_ROOT 'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154\python\3.13.3_64bit\python.exe') (Join-Path $PSScriptRoot 'test-matte-compositor.py')
exit $LASTEXITCODE
