"""Compile actual parity.3/candidate export setup, compositor and blitter on synthetic pixels."""
from pathlib import Path
import hashlib, json, os, subprocess, zipfile

WORK=Path(os.environ.get('PVZ_WORK_ROOT',Path(__file__).resolve().parents[2]))
BUILD=WORK/'portable-build'
OUT=Path(os.environ.get('PVZ_MATTE_TEST_OUT',BUILD/'matte-candidate/tests'))
OUT.mkdir(parents=True,exist_ok=True)
SDK=Path(os.environ.get('PVZ_TOOLCHAIN_ROOT',WORK/'toolchain'))/'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
ARCHIVE=BUILD/'pvz-portable-0.2.6-web-parity.3-source.zip'
PREFIX='PvZ-Portable-0.2.6-web-parity.3/'
BASELINE=Path(os.environ['PVZ_MATTE_BASELINE_ROOT']) if 'PVZ_MATTE_BASELINE_ROOT' in os.environ else None
CANDIDATE=Path(os.environ.get('PVZ_MATTE_SOURCE_ROOT',BUILD/'matte-candidate/source'))
if BASELINE is None:
    assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()=='d12c29eec4885dfd9419cba57b17980a6506812aa634dd9de85cf63eed260230'
    z=zipfile.ZipFile(ARCHIVE)
else:
    expected=json.loads((BASELINE/'manifest.json').read_text())
    for name,digest in expected['files'].items():assert hashlib.sha256((BASELINE/name).read_bytes()).hexdigest()==digest,name

def baseline(name):return z.read(PREFIX+name).decode() if BASELINE is None else (BASELINE/name).read_text()

def source(name,variant):
    if variant in ('parity3','control-zero-only','control-alpha-only'):
        text=baseline(name)
        if name.endswith('/ZombatarWidget.cpp'):
            if variant=='control-zero-only':text=text.replace('std::fill_n(aPixels, aPixelCount, 0xff000000u);','std::fill_n(aPixels, aPixelCount, 0u);')
            elif variant=='control-alpha-only':text=text.replace('\taPortrait.SetImageMode(false, false);','')
        return text
    return (CANDIDATE/name).read_text()

def block(text,marker):
    start=text.index(marker);brace=text.index('{',start);depth=0
    for end in range(brace,len(text)):
        if text[end]=='{':depth+=1
        elif text[end]=='}':
            depth-=1
            if depth==0:return text[start:end+1]
    raise AssertionError(marker)

STUBS=r'''
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <vector>
using uchar=unsigned char;
namespace Sexy {struct Color {
 int mRed,mGreen,mBlue,mAlpha;
 constexpr Color(int r=0,int g=0,int b=0,int a=255):mRed(r),mGreen(g),mBlue(b),mAlpha(a){}
 bool operator==(const Color& x)const{return mRed==x.mRed&&mGreen==x.mGreen&&mBlue==x.mBlue&&mAlpha==x.mAlpha;}
 bool operator!=(const Color& x)const{return !(*this==x);}
 static Color White;
}; Color Color::White{255,255,255};}
using Sexy::Color;
struct Rect {int mX,mY,mWidth,mHeight;
 Rect(int x=0,int y=0,int w=0,int h=0):mX(x),mY(y),mWidth(w),mHeight(h){}
 Rect Intersection(const Rect& x)const {int l=std::max(mX,x.mX),t=std::max(mY,x.mY);return {l,t,std::max(0,std::min(mX+mWidth,x.mX+x.mWidth)-l),std::max(0,std::min(mY+mHeight,x.mY+x.mHeight)-t)};}
};
struct Image {int mWidth=0,mHeight=0;bool mDrawn=false;virtual ~Image()=default;
 int GetWidth(){return mWidth;}int GetHeight(){return mHeight;}
 virtual void Blt(Image*,int,int,const Rect&,const Color&,int,bool)=0;
};
struct MemoryImage:Image {
 bool mHasAlpha=false,mHasTrans=false,mForcedMode=false;int changes=0;
 std::unique_ptr<uint32_t[]>mBits,mColorTable;std::unique_ptr<uchar[]>mColorIndices;
 std::vector<uchar>runs;
 MemoryImage(void* unused=nullptr){}
 uint32_t* GetBits(){if(!mBits)mBits=std::make_unique<uint32_t[]>(mWidth*mHeight+1);return mBits.get();}
 uchar* GetRLAlphaData(){runs.assign(mWidth*mHeight,1);return runs.data();}
 void BitsChanged(){++changes;}
 void Create(int,int);void SetImageMode(bool,bool);void NormalBlt(Image*,int,int,const Rect&,const Color&);
 void Blt(Image* i,int x,int y,const Rect&r,const Color&c,int mode,bool filter)override{NormalBlt(i,x,y,r,c);}
};
struct Graphics {Image*mDestImage;int mScaleX=1,mScaleY=1,mTransX=0,mTransY=0,mDrawMode=0;bool mColorizeImages=false,mLinearBlend=true;Color mColor=Color::White;Rect mClipRect;
 Graphics(Image*i):mDestImage(i),mClipRect(0,0,i->mWidth,i->mHeight){}
 void SetColorizeImages(bool b){mColorizeImages=b;}void SetColor(const Color&c){mColor=c;}
 void DrawImage(Image*,int,int);
 void DrawImage(Image*,int,int,const Rect&){std::abort();}
};
'''
TEST=r'''
int failed=0;void check(bool ok,const char*label){if(!ok){++failed;printf("FAIL %s\n",label);}}
MemoryImage sprite(int w,int h,uint32_t pixel){MemoryImage a;a.Create(w,h);std::fill_n(a.GetBits(),w*h,pixel);return a;}
// White normal-blit equations transcribed from original 0x5B1ABC..0x5B1B57.
// This independent oracle is static arithmetic, never execution of original bytes.
uint32_t originalWhite(uint32_t d,uint32_t s){uint32_t a=s>>24;if(!a)return d;uint32_t da=d>>24,na=da+((255-da)*a)/255;a=255*a/na;uint32_t oma=256-a;return (na<<24)|(((((d&0xff00ff)*oma)>>8)+(((s&0xff00ff)*a)>>8))&0xff00ff)|(((((d&0xff00)*oma)>>8)+(((s&0xff00)*a)>>8))&0xff00);}
int main(){
 int fixtures=0;uint64_t rgbDifferent=0;
 for(uint32_t alpha:{0u,1u,64u,127u,128u,254u,255u}){
  MemoryImage bg=sprite(4,4,(alpha<<24)|0xc86432),blank=sprite(4,4,0);
  IMAGE_ZOMBATAR_BACKGROUND_BLANK=&bg;IMAGE_ZOMBATAR_ZOMBIE_BLANK=&blank;IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN=&blank;
  ZombatarWidget widget;widget.bg=&bg;
  Result r=widget.ExportFixture();uint32_t expected=originalWhite(0,(alpha<<24)|0xc86432);
  check(r.hasAlpha&&r.hasTrans&&!r.forced,"export destination preserves original alpha/trans/forced flags");
  for(auto pixel:r.pixels){check(pixel==expected,"actual export/compositor white-background ARGB equals original equation");rgbDifferent+=(pixel&0xffffff)!=(expected&0xffffff);}
  if(alpha==128||alpha==255)printf("sample alpha%u: actual=%08x original=%08x\n",alpha,r.pixels[0],expected);
  ++fixtures;
 }
 // Actual DrawAvatar + DrawPartImage order, offsets, skin, and two parts.
 {
  MemoryImage bg=sprite(4,4,0x80c86432),blank=sprite(4,4,0),hair=sprite(1,1,0x7f52ca64),clothes=sprite(1,1,0xff3246d2);
  IMAGE_ZOMBATAR_BACKGROUND_BLANK=&bg;IMAGE_ZOMBATAR_ZOMBIE_BLANK=&blank;IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN=&blank;
  ZombatarWidget w;w.bg=&bg;w.parts[ZOMBATAR_PAGE_HAIR]=2;w.parts[ZOMBATAR_PAGE_CLOTHES]=0;w.images[ZOMBATAR_PAGE_HAIR]=&hair;w.images[ZOMBATAR_PAGE_CLOTHES]=&clothes;
  layouts[ZOMBATAR_PAGE_HAIR]={1,1,0,0,20};layouts[ZOMBATAR_PAGE_CLOTHES]={1,1,0,0,10};
  Result r=w.ExportFixture();uint32_t base=originalWhite(0,0x80c86432),expected=originalWhite(originalWhite(base,0xff3246d2),0x7f52ca64);
  check(r.pixels[5]==expected,"actual compositor sorted overlapping white layers matches original equation");
  check(r.pixels[0]==base,"uncovered background remains original RGB");++fixtures;
 }
 // Isolate the actual include on a partial alpha source and explicit zero/opaque
 // destinations, proving which branch the flags select independently of setup.
 {
  MemoryImage src=sprite(1,1,0x80c86432),zero=sprite(1,1,0),black=sprite(1,1,0xff000000);
  black.SetImageMode(false,false);zero.NormalBlt(&src,0,0,{0,0,1,1},Color::White);black.NormalBlt(&src,0,0,{0,0,1,1},Color::White);
  check(zero.GetBits()[0]==0x80c76331,"actual general branch independently matches original zeroARGB formula");
  check(black.GetBits()[0]==0xff643219,"actual opaque branch independently demonstrates black-matte RGB");
  check((zero.GetBits()[0]&0xffffff)!=(black.GetBits()[0]&0xffffff),"alpha omitted by JPEG leaves distinct RGB");++fixtures;
 }
 printf("fixtures=%d rgb_pixels_mismatching_original=%llu failed=%d; synthetic only, no game/audio\n",fixtures,(unsigned long long)rgbDifferent,failed);
 return failed?1:0;
}
'''

def generate(variant):
    assert '#define OPTIMIZE_SOFTWARE_DRAWING' in source('src/SexyAppFramework/graphics/MemoryImage.h',variant)
    widget=source('src/Lawn/Widget/ZombatarWidget.cpp',variant)
    mi=source('src/SexyAppFramework/graphics/MemoryImage.cpp',variant)
    gfx=source('src/SexyAppFramework/graphics/Graphics.cpp',variant)
    system=source('src/Lawn/System/Zombatar.h',variant)
    inc=source('src/SexyAppFramework/graphics/inc_routines/MI_NormalBlt.inc',variant)
    # Same production include text for both variants, including optimized flag.
    (OUT/'inc_routines').mkdir(exist_ok=True)
    (OUT/'inc_routines/MI_NormalBlt.inc').write_text(inc)
    enum=block(system,'enum ZombatarPage')+';\n'+block(system,'struct ZombatarPartLayout')+';\n'
    colors=system[system.index('inline constexpr Sexy::Color gZombatarColors[]'):system.index('constexpr int ZombatarRemapAccessoryForRuntime')]
    structs=block(widget,'struct ZombatarDrawPart')+';\n'
    structs+='enum {ZOMBATAR_COLOR_MODE_SKIN,ZOMBATAR_COLOR_MODE_1,ZOMBATAR_COLOR_MODE_2,ZOMBATAR_COLOR_MODE_NONE};\n'
    structs+=block(widget,'constexpr int GetPartColorMode')+'\n'
    structs+='ZombatarPartLayout layouts[NUM_ZOMBATAR_PAGES]{};const ZombatarPartLayout*GetPartLayout(ZombatarPage p,int i){return &layouts[p];}\n'
    structs+='Image*IMAGE_ZOMBATAR_BACKGROUND_BLANK,*IMAGE_ZOMBATAR_ZOMBIE_BLANK,*IMAGE_ZOMBATAR_ZOMBIE_BLANK_SKIN;\n'
    structs+='struct Result{std::vector<uint32_t>pixels;bool hasAlpha,hasTrans,forced;};\n'
    structs+='struct ZombatarWidget{void*mApp=nullptr;Image*bg=nullptr;std::array<int,NUM_ZOMBATAR_PAGES>parts,colors;Image*images[NUM_ZOMBATAR_PAGES]{};ZombatarWidget(){parts.fill(-1);colors.fill(-1);parts[ZOMBATAR_PAGE_BACKDROPS]=0;}void DecodeRecord(const uint8_t*,int*p,int*c){std::copy(parts.begin(),parts.end(),p);std::copy(colors.begin(),colors.end(),c);}Image*GetBackgroundImage(int){return bg;}Image*GetPartImage(ZombatarPage p,int){return images[p];}Image*GetPartMaskImage(ZombatarPage,int){return nullptr;}void DrawImageColorized(Graphics*,Image*,int,int,int);void DrawPartImage(Graphics*,ZombatarPage,int,int,int,int);void DrawAvatar(Graphics*,int,int,const uint8_t*);Result ExportFixture();};\n'
    funcs='\n'.join(block(mi,name) for name in ['void MemoryImage::Create','void MemoryImage::SetImageMode','void MemoryImage::NormalBlt'])
    funcs+='\n'+block(gfx,'void Graphics::DrawImage(Sexy::Image*').replace('Sexy::Image*','Image*')
    funcs+='\n'+'\n'.join(block(widget,name) for name in ['void ZombatarWidget::DrawImageColorized','void ZombatarWidget::DrawPartImage','void ZombatarWidget::DrawAvatar'])
    start=widget.index('MemoryImage aPortrait(mApp);',widget.index('bool ZombatarWidget::WriteCurrentPortraitImage'))
    stop=widget.index('DrawAvatar(&aGraphics, 0, 0, aRecord.data());',start)+len('DrawAvatar(&aGraphics, 0, 0, aRecord.data());')
    setup=widget[start:stop]
    funcs+='\nResult ZombatarWidget::ExportFixture(){Image*aBackground=bg;std::array<uint8_t,72>aRecord{};'+setup+'\nreturn {{aPortrait.GetBits(),aPortrait.GetBits()+aPixelCount},aPortrait.mHasAlpha,aPortrait.mHasTrans,aPortrait.mForcedMode};}\n'
    cpp=OUT/(variant+'.cpp');cpp.write_text(STUBS+'\n#define OPTIMIZE_SOFTWARE_DRAWING\n'+enum+colors+structs+funcs+TEST)
    return cpp

def run(variant):
    cpp=generate(variant);target=OUT/(variant+'.js')
    env=dict(os.environ,EM_CONFIG=str(SDK/'.emscripten'),EM_CACHE=str(SDK.parent/'em-cache'),EMCC_TEMP_DIR=str(OUT/'temp'),PYTHONNOUSERSITE='1')
    (OUT/'temp').mkdir(exist_ok=True)
    cmd=[str(SDK/'python/3.13.3_64bit/python.exe'),str(SDK/'upstream/emscripten/em++.py'),str(cpp),'-std=c++20','-O1','-sENVIRONMENT=node','-o',str(target)]
    subprocess.run(cmd,env=env,check=True)
    assert 'AudioContext' not in target.read_text()
    result=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(target)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (OUT/(variant+'.log')).write_text(result.stdout)
    print(variant+': '+result.stdout.splitlines()[-1])
    return {'variant':variant,'exit_code':result.returncode,'generated_cpp_sha256':hashlib.sha256(cpp.read_bytes()).hexdigest(),'log':str(OUT/(variant+'.log')),'sample_lines':[s for s in result.stdout.splitlines() if s.startswith('sample')]}

if __name__=='__main__':
    import sys
    variants=sys.argv[1:] or ['parity3','control-zero-only','control-alpha-only','candidate']
    results=[run(v) for v in variants]
    for r in results:assert r['exit_code']==(0 if r['variant']=='candidate' else 1),r
    (OUT/'results.json').write_text(json.dumps({'results':results,'scope':'Actual extracted production export setup/compositor/normal blitter with synthetic resource interfaces. Original white-normal equations independently transcribed from static disassembly. No original executable code or pixels run; no native game/audio.'},indent=2)+'\n')
    print('PASS expected parity.3 failure/corrected candidate behavior for requested variants')
