PRIVATE CPU SCREEN CANDIDATE — 0.2.6-web-software.4

The ordinary original software screen is a DDImage with opaque RGB888 output,
not a bare MemoryImage. Software.4 adds a dedicated SoftwareScreenImage target
for the audited nonvolatile32-bit CPU kernels. It preserves all Software.3
literal offscreen MemoryImage code and its separately proven white-normal
filter/step arithmetic. Software.3 source/binaries/sourceZIP/preview are frozen;
its root UI results are NOT Software.4 runtime results. No4 browser run or public
integration/publication has occurred during this preparation.

Four source paths differ from Software.3:
 CMake/ProjectVersion.cmake — private0.2.6-web-software.4 identity.
 graphics/GLInterface.cpp — include and allocate the new CPU target type only.
 graphics/SoftwareScreenImage.h/.cpp — dedicated screen implementation.
The existing unique_ptr<MemoryImage> ownership, WidgetManager borrowed target,
safe renderer mode transition/rollback, final upload and hardware target remain.

Bounded native-supported behavior
Screen mode0/1 Blt uses native alpha cache channel P=floor(S*(A+1)/256).
White normal blends its separate destination product plus P; nonwhite combines
destination and P*tint products. Unstretched Blt has a special sourceA255 AND
tintA255 path that omits the destination product; fast stretch does not. White
no-alpha sources use the native-alpha copy/optional-transparent-zero policy.
Additive output saturates each8-bit channel. Blt rejects unknown draw modes;
the separately mapped fast stretch dispatch treats nonzero mode as additive.

Fast screen stretch clips destination/source first using the unchanged shared
helper, converts clipped source origins/steps to16.16, samples before adding,
and applies the DD32 fast equations. Slow screen stretch creates a zero-ARGB
plain MemoryImage temporary, uses the preserved native white-normal slow
kernel, then calls screen Blt with the original color/mode. Applying the tint
or additive mode inside the temporary would not match that native call chain.
These paths and the distinct original screen type/flags were independently
traced statically. Source archives include only authored equation/reference
test inputs, never installed executable bytes, disassembly or native audit files.

Verification
 dd32-tests/run-dd32-tests.py: actual new screen methods and virtual base calls
 against the independently transcribed native nonvolatileRGB888 equations and
 clip/sampler.20,893 pixel assertions cover white/tint/globalalpha,0/1 normal/
 additive, zero/partial/opaque source alpha, source flags, saturation, indexed
 palette stretch, clipping/16.16 and slow temp→DD dispatch. Seven extra tests
 verify inherited mirror helpers dispatch virtual screen methods; they do NOT
 prove native DD mirror dispatch. Total20,900, zero failures. LiteralSoftware.3
 differs7,360RGBpixels across these synthetic controls (not game scenes).
 The independent review caught and corrected a test-only palette-input issue:
 indexed storage is restored after the old control before the actual candidate.
 OffscreenMemoryImage.cpp/.h/slowinclude exact Software.3 hashes are asserted
 from software3-parent.json; this checksum input is supplied in the archive.
 tests/run-primitives.ps1:149/149 retained cases; old baseline31/149,118 expected
 failures. stretch-tests/run-native-stretch.py:20 retained literalMI3 fixtures,
 zero differences from its native-supported reference. The copied suite keeps
 historical Software.2/3 role labels because this offscreen code is identical.
 tests/run-mode-tests.ps1 and presenter-tests/run-presenter-test.ps1 pass actual
 transition/shared-batcher methods with dependency/GL/SDL doubles. The presenter
 mock only supplies the new allocation type; pixel math is tested separately.
 matte-regression/run-matte-regression.ps1 passes9 actual compositor fixtures;
 old baseline and both partial controls fail as expected.
 Complete isolated Release engine build/link exits0. JS syntax/WASM.validate
 and distinct embedded Software.4 version pass without initializing the engine.

Reproduce using existing workspace tools/cache only
 powershell -NoProfile -ExecutionPolicy Bypass -File .../build-candidate.ps1
 python .../dd32-tests/run-dd32-tests.py
Other test runners are listed above. Tools remain Emscripten6.0.13,
CMake3.31.9/Ninja1.13.2, Release, DO_FIX_BUGS=OFF/PVZ_DEBUG=OFF/LOW_MEMORY=OFF.
SourceZIP excludes Git metadata. To reproduce build/date header fields, use
the exact shallow upstream0.2.6 tag metadata (commit396f1c7fcf0507dcd1b79dc1ffad139eea2fb6ca,
count1/date2026-10-25), then overlay the complete source bytes. The private
version override runs after git collection. No differing-tool byte identity claim.

web-software.4.patch is the combined patch against RAW upstream0.2.6, whose
archive SHA25640af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556
is checked. software3-to-software4.patch is the four-path direct delta. The
additional source-changes.patch has the older PRIVATE parity.3 base and is
explicitly labeled that way in verification.json. Do not confuse these bases.
The full supplied source tree builds without applying any patch.

Limits before release
Only the successfully locked nonvolatile CPU RGB888 kernel paths are claimed
statically supported. DD16/other layouts, DirectDraw surface-driver shortcuts,
device loss, original framebuffer equality and source volatility are excluded.
Volatile inputs preserve the existing MemoryImage fallback; no game SetVolatile
call site exists in this source. Invalid rectangles are rejected defensively;
the native finite/int32 valid sampling range is the comparison scope.
Fractional/rotated/matrix/triangle/fill and native mirror screen dispatch remain
separate audits; inherited mirror tests prove routing only. Offscreen MI tint/
additive extensions still have no full original equivalence proof. The CPU
compositor still needs WebGL for one final bitmap transport. Root must conduct
Software.4's own browser start/toggle/reload/scene/keyboard/fullscreen/save and
dense-scene performance validation. No Software.3 UI credit transfers to4.
