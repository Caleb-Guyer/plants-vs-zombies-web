"""Private complete corresponding Software.4 source/tests/recipe; no original/native data."""
from pathlib import Path
import hashlib,json,zipfile,zlib

ROOT=Path(__file__).resolve().parent
assert ROOT.name=='software4-candidate'
def record(data):return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'crc32':f'{zlib.crc32(data):08x}'}
def files(folder):return {p.relative_to(folder).as_posix():p.read_bytes() for p in sorted(folder.rglob('*')) if p.is_file() and '.git' not in p.relative_to(folder).parts}
source=files(ROOT/'source');assert len(source)==755
verification=json.loads((ROOT/'verification.json').read_text())
assert verification['candidate']=='0.2.6-web-software.4'
for artifact in verification['artifacts']:
    assert record((ROOT/artifact['path']).read_bytes())['sha256']==artifact['sha256']
fingerprint=json.loads((ROOT/'software4-change-record.json').read_text())['fullSourceFingerprint']
assert {name:record(data)['sha256'] for name,data in source.items()}==fingerprint
patch_check=json.loads((ROOT/'patch-check.json').read_text())
assert patch_check['everySourceByteMatchesCandidate'] and patch_check['reconstructedFiles']==755
assert record((ROOT/'web-software.4.patch').read_bytes())['sha256']==verification['sourcePatchSha256']==patch_check['combinedPatchSha256']
assert not any(Path(name).suffix.lower() in {'.exe','.dll','.pak','.dat','.regemu'} for name in source)

entries={'software4-candidate/source/'+name:data for name,data in source.items()}
allowlist=['README.txt','build-candidate.ps1','write-provenance.py','package-candidate.py',
 'verification.json','source-changes.patch','web-software.4.patch','software3-to-software4.patch',
 'software3-parent.json','software4-change-record.json','matte-merge.json','patch-check.json',
 'tests/prepare-primitives.py','tests/run-primitives.ps1','tests/prepare-mode-tests.py','tests/run-mode-tests.ps1',
 'presenter-tests/prepare-presenter-test.py','presenter-tests/run-presenter-test.ps1','presenter-tests/presenter-harness.cpp',
 'matte-regression/test-matte-compositor.py','matte-regression/run-matte-regression.ps1',
 'stretch-tests/run-native-stretch.py','stretch-tests/fixtures.cpp','stretch-tests/results/results.json',
 'dd32-tests/run-dd32-tests.py','dd32-tests/fixtures.cpp','dd32-tests/native-dd32-reference.h','dd32-tests/results/results.json']
for name in allowlist:entries['software4-candidate/'+name]=(ROOT/name).read_bytes()
for folder in ['tests/baseline','matte-regression/baseline','stretch-tests/software2-baseline']:
    for name,data in files(ROOT/folder).items():entries['software4-candidate/'+folder+'/'+name]=data
for name in ['primitives.log','mode-transition.log','presenter.log','matte-regression.log','native-mi-stretch.log','dd32.log','build.log']:
    entries['software4-candidate/verification-logs/'+name]=(ROOT/'logs'/name).read_bytes()
entries['software4-candidate/compiled-version-header.txt']=(ROOT/'build/ProjectVersion.h').read_bytes()
prior=ROOT.parent/'software3-candidate/pvz-portable-0.2.6-web-software.3-source.zip'
assert record(prior.read_bytes())['sha256']=='f43535270212d3cb81e9d8eb26c8d60a96faf694a411b6cf3346a5c7ba1b8c09'
with zipfile.ZipFile(prior) as old:
    assert old.testzip() is None
    for name in old.namelist():
        prefix='software3-candidate/retained-parity4-tests/'
        if name.startswith(prefix):entries['software4-candidate/retained-parity4-tests/'+name[len(prefix):]]=old.read(name)
scope={'candidate':verification['candidate'],'sourceFiles':755,'sourceBytes':sum(map(len,source.values())),
 'sourceManifest':{name:record(data) for name,data in source.items()},
 'excludes':['.git','compiled engine/test binaries/build objects','original game EXE/DLL/PAK/artwork','native audit/disassembly files','installed/personal/actualQA saves/settings/backups'],
 'includedReference':'Authored independent native-equation header is test code, contains no original machine code or disassembly.',
 'upstreamFixtures':'Complete licensed source retains unchanged upstream library MP3-tag/synth/example fixtures/project icons; no installed game resources.'}
entries['software4-candidate/source-manifest.json']=(json.dumps(scope,indent=2)+'\n').encode()
path=ROOT/'pvz-portable-0.2.6-web-software.4-source.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,27,0,0,0));info.external_attr=0o100644<<16
        archive.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(entries)
    for name,data in entries.items():assert archive.read(name)==data,name
assert source==files(ROOT/'source')
frozen=ROOT.parent/'software3-candidate'
with zipfile.ZipFile(prior) as old:
    for name in old.namelist():
        prefix='software3-candidate/source/'
        if name.startswith(prefix):assert old.read(name)==(frozen/'source'/name[len(prefix):]).read_bytes()
for artifact in json.loads((frozen/'verification.json').read_text())['artifacts']:
    assert record((frozen/artifact['path']).read_bytes())['sha256']==artifact['sha256']
preview=json.loads((frozen/'preview/inventory.json').read_text())
for name,expected in preview['files'].items():assert record((frozen/'preview/dist'/name).read_bytes())==expected,name
report={'candidate':verification['candidate'],
 'sourceArchive':{'path':path.name,**record(path.read_bytes()),'entries':len(entries),'uncompressedBytes':sum(map(len,entries.values()))},
 'sourceFiles':755,'sourceBytes':scope['sourceBytes'],'crcReadAndByteCompare':'PASS every entry',
 'combinedUpstreamPatch':{'path':'web-software.4.patch',**record((ROOT/'web-software.4.patch').read_bytes()),'changedPaths':len(verification['sourceChanges']),'base':verification['base'],'applyCheck':patch_check},
 'software3IncrementalPatch':{'path':'software3-to-software4.patch',**record((ROOT/'software3-to-software4.patch').read_bytes())},
 'engineArtifacts':verification['artifacts'],'sourceDeltaVsSoftware3':json.loads((ROOT/'software4-change-record.json').read_text())['sourceChanges'],
 'software3SourceBinaryAndPreviewUnchanged':True,'publicNotWrittenByPreparation':True,'engineInitialized':False,'serverLaunched':False,
 'independentReview':'fullscreen_fix independently reviewed source/native equations/clip/dispatch and final actual-code/reference/test scope;20900=20893 equation+7 inherited-dispatch assertions; no4runtime credit.',
 'limits':verification['limits'],'archiveScope':scope['excludes']}
(ROOT/'package.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ['candidate','sourceArchive','sourceFiles','sourceBytes','crcReadAndByteCompare','combinedUpstreamPatch','software3SourceBinaryAndPreviewUnchanged']},indent=2))
