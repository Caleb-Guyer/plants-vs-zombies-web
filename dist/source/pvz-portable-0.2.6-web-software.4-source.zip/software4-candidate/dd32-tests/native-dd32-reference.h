#pragma once
// Independent static-original transcription for conditional RGB888 DD32 output.
// This is reference/test code, not an original binary or an ideal RGBA renderer.
// Scope: ordinary opaque software DDImage, successful surface lock, native-alpha
// cache path; source volatility and driver surface-Blt shortcuts are excluded.
#include <algorithm>
#include <cstdint>
#include <vector>

namespace NativeDD32Reference {
struct Tint { int r=255, g=255, b=255, a=255; };
struct SourceFlags { bool hasAlpha=true, hasTrans=true; };
inline bool White(Tint c) { return c.r==255 && c.g==255 && c.b==255 && c.a==255; }

// Original MemoryImage::GetNativeAlphaData raw0x5AF7BA..0x5AF7FE,
// palette0x5AF8B6..0x5AF8FA: RGB*(alpha+1)/256, then pack display masks.
inline int PremultipliedChannel(uint32_t pixel, int shift) {
    return int((pixel>>shift)&255) * (int(pixel>>24)+1) / 256;
}

// FAST StretchBlt: white0x596F77..0x596FEC; tinted0x597053..0x5975D7;
// additive0x598725..0x5987EC /0x598865..0x598E26.
inline uint32_t FastPixel(uint32_t source, uint32_t destination, Tint color, int mode) {
    const bool white=White(color);
    const int alpha=source>>24;
    const int a=white ? alpha : alpha*color.a/255;
    if (mode==0 && a==0) return destination | 0xff000000u;
    uint32_t result=0xff000000u;
    for (int shift=0;shift<24;shift+=8) {
        const int d=(destination>>shift)&255;
        const int p=PremultipliedChannel(source,shift);
        const int c=shift==16?color.r:shift==8?color.g:color.b;
        const int k=c*color.a/255;
        const int out=mode==0 ? (white ? d*(256-alpha)/256+p : (d*(256-a)+p*k)/256)
                             : std::min(255,d+(white?p:p*k/256));
        result |= uint32_t(out)<<shift;
    }
    return result;
}

// UNSTRETCHED DDImage::Blt dispatch0x58A4B3..0x58A5C0.
// White alpha path copy/skip0x57ED7F..0x57EE1F, partial0x57EE57..0x57EF61.
// No-alpha white copy/optional-alpha0 skip0x581CE4..0x581E7A.
// Tint special sourceA255 AND colorA255 omits destination:
// nongray0x57F474..0x57F553, gray0x57F137..0x57F1F2.
// Other tint uses combined products0x57F5DD..0x57F6B8.
// Additive0x586D3A..0x587438 uses the same saturated cache-RGB equations.
inline uint32_t BltPixel(uint32_t source, uint32_t destination, Tint color, int mode, SourceFlags flags={}) {
    const bool white=White(color);
    const int alpha=source>>24;
    if (mode==0 && white && !flags.hasAlpha) {
        if (flags.hasTrans && alpha==0) return destination | 0xff000000u;
        return 0xff000000u | uint32_t(PremultipliedChannel(source,16))<<16
                              | uint32_t(PremultipliedChannel(source,8))<<8
                              | uint32_t(PremultipliedChannel(source,0));
    }
    if (mode==0 && alpha==0) return destination | 0xff000000u;
    if (mode==0 && !white && alpha==255 && color.a==255) {
        uint32_t result=0xff000000u;
        for (int shift=0;shift<24;shift+=8) {
            const int c=shift==16?color.r:shift==8?color.g:color.b;
            result |= uint32_t(PremultipliedChannel(source,shift)*c/256)<<shift;
        }
        return result;
    }
    return FastPixel(source,destination,color,mode);
}

struct Rect { int x,y,w,h; };
struct Clipped { Rect destination; double sx,sy,sw,sh; };
// Shared original clip helper0x5B31B0..0x5B3327. Ratios from UNCLIPPED
// integer rectangles, clipped fractional source coordinates stored as doubles.
inline Clipped Clip(Rect source, Rect draw, Rect clip) {
    const int left=std::max(draw.x,clip.x), top=std::max(draw.y,clip.y);
    const int right=std::min(draw.x+draw.w,clip.x+clip.w);
    const int bottom=std::min(draw.y+draw.h,clip.y+clip.h);
    const Rect d{left,top,std::max(0,right-left),std::max(0,bottom-top)};
    const double fx=double(source.w)/draw.w, fy=double(source.h)/draw.h;
    return {d,source.x+(d.x-draw.x)*fx,source.y+(d.y-draw.y)*fy,
              source.w+(d.w-draw.w)*fx,source.h+(d.h-draw.h)*fy};
}
// Applied AFTER clipping: QY0,truncated steps0x596B0B..0x596B47;
// QX0 each row0x596EAC..0x596EBA; sample-before-add0x596EF5..0x596F2D.
// Arithmetic right shift is original sar; finite in-range positive coordinates
// use truncating conversion helper0x6C0820 (cvttsd2si0x6C0835).
inline std::vector<int> FastIndices(Clipped clipped, int sourceRowWidth) {
    std::vector<int> result;
    if (clipped.destination.w<=0 || clipped.destination.h<=0 || clipped.sw<=0 || clipped.sh<=0) return result;
    const int dx=int(clipped.sw*65536.0/clipped.destination.w);
    const int dy=int(clipped.sh*65536.0/clipped.destination.h);
    int qy=int(clipped.sy*65536.0);
    for (int y=0;y<clipped.destination.h;++y,qy+=dy) {
        int qx=int(clipped.sx*65536.0);
        for (int x=0;x<clipped.destination.w;++x,qx+=dx)
            result.push_back((qy>>16)*sourceRowWidth+(qx>>16));
    }
    return result;
}
} // namespace NativeDD32Reference
