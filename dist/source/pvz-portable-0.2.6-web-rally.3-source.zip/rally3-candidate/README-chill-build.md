# Rally Zombie hand and megaphone attachment maintenance

Exact published Rally.2 parent source SHA-256:
8d7c3d5a54bdebb57d36cd1b8a6d33f87ca68e7c0b39c905838f1a83173f8b82.
824 production inputs under rally2-candidate/source/.

This release repairs the megaphone attachment to the original hand animation.
Preserve the native arm transition blends, original sprite sources, existing
Survival wave initialization, gameplay balance, content IDs and saved layouts.

Build the normal Release browser engine with build-chill.py. Separate silent
Care, Chain Reaction and Rally Zombie drivers link those same production
objects with test-only entry points. Rerun all sixteen retained suites against
this build, including hand/megaphone placement controls across the native poses.
No audio device is opened by automated native tests.

package-chill.py authenticates current source/build/test receipts and exact
parent/upstream patch reconstruction before staging matching source/binaries.
Corresponding source, tests and executed report artifacts use rally3-candidate/.
