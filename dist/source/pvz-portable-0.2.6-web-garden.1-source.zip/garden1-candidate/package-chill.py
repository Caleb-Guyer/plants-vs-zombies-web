"""Stage Garden.1 binaries, corresponding source and provenance after build/tests.

Reads this candidate and the authenticated release baselines. Writes only one
fresh staging directory. No build, game, browser, audio or network is started.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tempfile
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
VERSION = "0.2.6-web-garden.1"
UPSTREAM_SHA = "40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556"
PARENT_SHA = "7fa3d16079cca928812a965ec7bdcd15c7f157570d14607895c31067d06e49f0"
FLAGS = {"CMAKE_BUILD_TYPE": "Release", "DO_FIX_BUGS": "OFF",
         "PVZ_DEBUG": "OFF", "LOW_MEMORY": "OFF"}
SOURCE_NAME = f"pvz-portable-{VERSION}-source.zip"
FULL_PATCH = "web-garden.1.patch"
DELTA_PATCH = "chill9-to-garden1.patch"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {"bytes": len(data), "sha256": digest(data),
            "crc32": f"{zlib.crc32(data) & 0xffffffff:08x}"}


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe_name(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts
            and "\\" not in name and ":" not in name, "Unsafe source path: " + name)
    return name


def source_tree(folder):
    result = {}
    for path in sorted(folder.rglob("*")):
        require(not path.is_symlink(), "Source symlinks are not supported")
        if path.is_file():
            name = safe_name(path.relative_to(folder).as_posix())
            require(not any(p in {".git", "__pycache__", "node_modules"}
                            for p in PurePosixPath(name).parts), "Private source input: " + name)
            result[name] = path.read_bytes()
    return result


def archive_source(path, expected_sha, prefix, count):
    raw = path.read_bytes()
    require(digest(raw) == expected_sha, "Wrong baseline archive: " + path.name)
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), "Duplicate baseline member")
        require(archive.testzip() is None, "Invalid baseline archive CRC")
        files = {safe_name(name[len(prefix):]): archive.read(name)
                 for name in archive.namelist()
                 if name.startswith(prefix) and not name.endswith("/")}
    require(len(files) == count, "Unexpected source count: " + path.name)
    return files


def make_patch(before, after):
    lines, changed = [], []
    for name in sorted(set(before) | set(after)):
        old, new = before.get(name, b""), after.get(name, b"")
        if old == new:
            continue
        require((not old or old.endswith(b"\n")) and (not new or new.endswith(b"\n")),
                "Changed source must end in newline: " + name)
        lines.extend(difflib.unified_diff(
            old.decode("utf-8").splitlines(keepends=True),
            new.decode("utf-8").splitlines(keepends=True),
            fromfile="a/" + name if name in before else "/dev/null",
            tofile="b/" + name if name in after else "/dev/null", n=3))
        changed.append({"path": name, "beforeSha256": digest(old), "afterSha256": digest(new)})
    return "".join(lines).encode(), changed


def checked(command, cwd=None):
    result = subprocess.run(list(map(str, command)), cwd=cwd,
                            capture_output=True, text=True, encoding="utf-8", errors="replace")
    require(result.returncode == 0,
            "Local check failed: " + str(command[0]) + "\n" + result.stderr[-3000:])
    return result


def reconstruct(before, patch, expected):
    # This is our newly created temporary directory only; old candidates stay untouched.
    with tempfile.TemporaryDirectory(prefix="qol-patch-", dir=ROOT) as temporary:
        folder = Path(temporary).resolve()
        require(folder.is_relative_to(ROOT) and folder != ROOT, "Unsafe temporary directory")
        tree = folder / "source"
        tree.mkdir()
        for name, data in before.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        patch_path = folder / "change.patch"
        patch_path.write_bytes(patch)
        checked(["git", "init", "--quiet", tree])
        command = ["git", "-C", tree, "-c", "core.autocrlf=false", "apply"]
        checked(command + ["--check", patch_path])
        checked(command + [patch_path])
        actual = {p.relative_to(tree).as_posix(): p.read_bytes()
                  for p in tree.rglob("*") if p.is_file()
                  and ".git" not in p.relative_to(tree).parts}
        require(actual == expected, "Patch did not reconstruct all current source bytes")
    return {"gitApplyCheck": "PASS", "gitApply": "PASS",
            "everySourceByteMatches": True, "sourceFiles": len(expected)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path,
                        default=ROOT.parents[1] / "plants-vs-zombies-web-release")
    parser.add_argument("--build-result", type=Path, default=ROOT / "logs/build-result.json")
    parser.add_argument("--test-result", type=Path, default=ROOT / "tests/game-speed-results.json")
    parser.add_argument("--parent-manifest", type=Path, default=ROOT / "parent-engine-provenance.json",
                        help="Frozen Chill.9 engine manifest")
    parser.add_argument("--output", type=Path, default=ROOT / "staging")
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(ROOT) and output != ROOT and not output.exists(),
            "Output must be a NEW directory inside this candidate")
    release = args.release_root.resolve()
    build_result = args.build_result.resolve()
    test_result = args.test_result.resolve()
    require(build_result.is_relative_to(ROOT) and test_result.is_relative_to(ROOT / "tests"),
            "Build/test receipts must belong to this candidate")
    build = read_json(build_result)
    test_paths = [ROOT / 'tests' / (name + '-results.json') for name in
                  ['game-speed', 'qol-controls', 'decks-cooldowns', 'bonus-challenge', 'bonus-completion', 'night-shift', 'lantern-shroom', 'garden-shuffle']]
    test_reports = [read_json(path) for path in test_paths]
    tests = {'status': 'PASS focused native production tests',
             'failures': sum(report['failures'] for report in test_reports),
             'checks': sum(report['checks'] for report in test_reports),
             'sourceSha256': {key: value for report in test_reports for key, value in report['sourceSha256'].items()},
             'scope': 'Actual extracted production methods and content, settings, deck and cooldown code. No audio device or full game starts.'}
    require(all(str(report['status']).startswith('PASS') and report['failures'] == 0 and
                report['exitCode'] == 0 and report['checks'] > 0 for report in test_reports),
            'All eight native suites must pass')
    require(build.get("exitCode") == 0 and build.get("sourceUnchangedDuringBuild") is True,
            "A passing full build receipt is required")
    require(str(tests.get("status", "")).startswith("PASS") and tests.get("failures") == 0,
            "A passing focused speed test result is required")
    require(isinstance(tests.get("checks"), int) and tests["checks"] > 0
            and isinstance(tests.get("sourceSha256"), dict) and tests["sourceSha256"],
            "Focused tests need nonempty checks and source pins")
    current = source_tree(ROOT / "source")
    hashes = {name: digest(data) for name, data in current.items()}
    require(read_json(ROOT / "logs/source-before.json") == hashes
            and read_json(ROOT / "logs/source-after.json") == hashes,
            "Source changed since the recorded build")
    require(VERSION.encode() in current["CMake/ProjectVersion.cmake"], "Wrong candidate version")
    cache = {}
    for line in (ROOT / "build/CMakeCache.txt").read_text(encoding="utf-8").splitlines():
        if not line.startswith(("#", "//")) and "=" in line and ":" in line.split("=", 1)[0]:
            key, value = line.split("=", 1)
            cache[key.split(":", 1)[0]] = value
    require(all(cache.get(key) == value for key, value in FLAGS.items()), "Unexpected build flags")
    require(Path(cache["CMAKE_HOME_DIRECTORY"]).resolve() == (ROOT / "source").resolve(),
            "Build used a different source directory")
    header = (ROOT / "build/ProjectVersion.h").read_bytes()
    require(VERSION.encode() in header, "Compiled version header mismatch")
    artifacts = {}
    for name in ["pvz-portable.js", "pvz-portable.wasm", "ProjectVersion.h"]:
        data = (ROOT / "build" / name).read_bytes()
        pin = record(data)
        expected = build["outputs"]["build/" + name]
        require(pin["bytes"] == expected["bytes"] and pin["sha256"] == expected["sha256"],
                "Build artifact changed: " + name)
        artifacts[name] = pin
    test_sources = [path for path in sorted((ROOT / 'tests').glob('*'))
                    if path.is_file() and path.suffix in {'.py', '.cpp', '.h', '.json'}]
    require(all(path in test_sources for path in test_paths), 'All native reports must be included')
    require(all(path.is_file() for path in test_sources), "Focused test text/runner/result missing")
    recipes = [ROOT / name for name in ["build-candidate.ps1", "build-chill.py", "package-chill.py", "README-chill-build.md", "parent-engine-provenance.json", "parent-source-pin.json"]]
    require(all(path.is_file() for path in recipes), "Build/package recipe missing")
    for name, expected in tests.get("sourceSha256", {}).items():
        key = name.removeprefix("source/")
        require(key in hashes and hashes[key] == expected, "Focused test source changed: " + name)
    for test_path, report in zip(test_paths, test_reports):
        for name, expected in report['sourceSha256'].items():
            key = name.removeprefix('source/')
            require(hashes.get(key) == expected, 'Stale focused report: ' + str(test_path))
        stem = test_path.name.removesuffix('-results.json')
        require(digest((ROOT / 'tests' / (stem + '-harness.cpp')).read_bytes()) ==
                report['generatedHarnessSha256'], 'Stale generated test harness: ' + stem)
    baseline_folder = release / "dist/source"
    upstream = archive_source(baseline_folder / "pvz-portable-0.2.6-source.zip", UPSTREAM_SHA,
                              "PvZ-Portable-0.2.6/", 753)
    parent = archive_source(baseline_folder / "pvz-portable-0.2.6-web-chill.9-source.zip", PARENT_SHA,
                            "chill9-candidate/source/", 780)
    parent_manifest_path = (args.parent_manifest or release / "dist/game/engine-provenance.json").resolve()
    parent_manifest_raw = parent_manifest_path.read_bytes()
    parent_manifest = json.loads(parent_manifest_raw)
    require(parent_manifest["id"] == "0.2.6-web-chill.9", "Release parent is not Chill.9")
    require(parent_manifest["artifacts"]["sourceSha256"] == PARENT_SHA, "Parent source identity mismatch")
    full_patch, full_changes = make_patch(upstream, current)
    delta_patch, delta_changes = make_patch(parent, current)
    patch_checks = {"upstream": reconstruct(upstream, full_patch, current),
                    "chill9": reconstruct(parent, delta_patch, current)}
    source_manifest = {"version": VERSION, "files": {name: record(data) for name, data in current.items()}}
    # All validation above completes before the exclusive final staging directory exists.
    output.mkdir()
    (output / "game").mkdir()
    (output / "source").mkdir()
    for name in ["pvz-portable.js", "pvz-portable.wasm"]:
        shutil.copyfile(ROOT / "build" / name, output / "game" / name)
    (output / "source" / FULL_PATCH).write_bytes(full_patch)
    (output / "source" / DELTA_PATCH).write_bytes(delta_patch)
    prefix = "garden1-candidate/"
    members = {prefix + "source/" + name: data for name, data in current.items()}
    for path in recipes:
        members[prefix + path.name] = path.read_bytes()
    for path in test_sources:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for path in [build_result, ROOT / "logs/source-before.json", ROOT / "logs/source-after.json",
                 ROOT / "build/ProjectVersion.h"]:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    members[prefix + "source-manifest.json"] = json_bytes(source_manifest)
    # Full source already contains every modified byte. Publish authenticated
    # patches beside the archive without embedding duplicate sprite data twice.
    archive_path = output / "source" / SOURCE_NAME
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            safe_name(name)
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(archive_path) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), "Source ZIP invalid")
        require(all(archive.read(name) == data for name, data in members.items()), "Source ZIP byte mismatch")
    source_record = {"path": SOURCE_NAME, **record(archive_path.read_bytes()), "entries": len(members),
                     "uncompressedBytes": sum(map(len, members.values()))}
    limits = ["Four native bonus minigames include Garden Shuffle; earlier checkpoints retain their historical rules. Accepted artwork, original IDs and serialized layouts remain. Full original parity remains unverified.",
              "Focused production-method tests and build checks do not replace broad game or browser validation.",
              "Earlier results remain historical parent evidence only. No separately image-generated challenge illustrations are active."]
    provenance = {
        "id": VERSION, "upstream": parent_manifest["upstream"], "sourceArchive": source_record,
        "artifacts": [{"path": "build/" + name, **pin} for name, pin in artifacts.items()],
        "sourceFiles": len(current), "sourceBytes": sum(map(len, current.values())),
        "sourceDeltaVsChill9": delta_changes,
        "compiledVersionHeader": header.decode("utf-8"),
        "checks": {"fullRelease": {"exitCode": 0, "flags": FLAGS, "sourceUnchangedDuringBuild": True,
                    "receipt": {"path": build_result.relative_to(ROOT).as_posix(), **record(build_result.read_bytes())}},
                   "focusedNativeTests": {"status": tests["status"], "failures": 0,
                    "checks": tests["checks"], "scope": tests["scope"],
                    "reports": [{"path": path.relative_to(ROOT).as_posix(), **record(path.read_bytes()),
                        "checks": report["checks"]} for path, report in zip(test_paths, test_reports)]},
                   "patchReconstruction": patch_checks},
        "combinedPatch": {"path": FULL_PATCH, **record(full_patch), "sourcePaths": len(full_changes)},
        "incrementalPatch": {"path": DELTA_PATCH, **record(delta_patch), "sourcePaths": len(delta_changes)},
        "parent": {"id": parent_manifest["id"], "sourceArchiveSha256": PARENT_SHA,
                   "releaseManifestSha256": digest(parent_manifest_raw),
                   "scope": "Complete historical parent engine metadata is preserved in the parent property of engine-provenance.json."},
        "limits": limits}
    engine = {
        "id": VERSION, "upstream": parent_manifest["upstream"],
        "artifacts": {"jsSha256": artifacts["pvz-portable.js"]["sha256"],
                      "wasmSha256": artifacts["pvz-portable.wasm"]["sha256"],
                      "source": "../source/" + SOURCE_NAME, "sourceSha256": source_record["sha256"],
                      "patch": "../source/" + FULL_PATCH, "patchSha256": digest(full_patch)},
        "buildRecord": "../source/build-provenance.json",
        "change": "Adds Garden Shuffle with a fixed garden and movable living plants, plus a fairer Night Shift grave warning. Retains the existing bonus modes, earned Chill-shroom unlock, original content and native save layouts.",
        "caption": "with Garden Shuffle and native bonus minigames.",
        "gameAssetsIncluded": parent_manifest["gameAssetsIncluded"],
        "assetManifest": parent_manifest["assetManifest"], "assetBundleId": parent_manifest["assetBundleId"],
        "parent": parent_manifest, "parentScope": "Historical Chill.9 release metadata only; not new Garden.1 runtime results.",
        "limits": limits}
    (output / "source/build-provenance.json").write_bytes(json_bytes(provenance))
    (output / "game/engine-provenance.json").write_bytes(json_bytes(engine))
    require(source_tree(ROOT / "source") == current, "Source changed during packaging")
    print(json.dumps({"status": "PASS staged Garden.1 artifacts/source/provenance",
                      "staging": str(output), "sourceArchive": source_record,
                      "sourceFiles": len(current), "changedSourcePaths": [x["path"] for x in delta_changes],
                      "patchChecks": patch_checks, "engine": engine["artifacts"]}, indent=2))


if __name__ == "__main__":
    main()
