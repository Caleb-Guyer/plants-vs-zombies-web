# Garden.1 native minigame revision

Starts from the exact published Chill.9 source archive, SHA-256
7fa3d16079cca928812a965ec7bdcd15c7f157570d14607895c31067d06e49f0.
Adds Garden Shuffle with a fixed living garden and native glove movement.
Original IDs and saved fields are retained; new mode76 owns unused record75.

Run build-chill.py using the retained local Release Emscripten toolchain, all
eight tests/test-*.py production-method suites, then package-chill.py. Packaging
verifies source-coherent receipts and reconstructs both raw-upstream and exact
parent patches. Browser tests use ?testing=1 with generated QA profiles only.
No installed original executable or private player files are release inputs.
