SOFTWARE.8 - CURRENT SOURCE AND TWO BOUNDED CORRECTIONS

The complete757-file engine starts from the authenticated Software.7 source
archive66b4cf8c473f1c9e6293a60cb2d7864b24cd91b0803745a77ef62c1669cacc3a.
Exactly four paths differ: CMake version, Challenge.cpp, and the dedicated CPU
SoftwareScreenImage.cpp/.h. Other753 engine files retain the exact parent bytes.

Challenge::ScaryPotterMalletPot now requests anim_open_pot, matching the
original lookup and shipped Hammer track. The old missing anim_pot_open name
logged a warning and fell back to track0, which is already anim_open_pot.
This fixes the lookup, without asserting a visible animation difference.

The screen's nonaxis additive-AA path matches the addressed original empty
software worker and auxiliary-cache invalidation. The gate is limited to
finite nonaxis additive lines on the dedicated forced-opaque nonvolatile
canonical raw RGB888 CPU screen. Its authoritative CPU mBits are retained;
three auxiliary caches are invalidated without changing dirty state/mDrawn.
Axis/point, normal/unknown modes, unproved states and offscreen paths retain7.
No ordinary game caller of this AA path has been proven.

New focused test (actual extracted methods; no game/audio initialization):
  python aa-tests/run-aa-tests.py
It accepts --source PATH and includes six authenticated Software.7 baseline
fragments, so no sibling7 checkout or old source archive is needed for it.
Current paired result:10,866 assertions per variant;7 has1,168 expected
failures/888 differing framebuffer words;8 has zero. Read aa-tests/README.txt
and verification.json for the exact wrapper/cache and fallback limits.
Earlier Software.7 suites and gameplay evidence are HISTORICAL evidence for
preserved source; they are not copied or relabeled as newly run8 tests.

Build the current source with the source/CMakeLists.txt Emscripten project.
The included build-candidate.ps1/build-and-record.py preserve the producer's
pinned existing SDK layout, Release, DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF,
LOW_MEMORY=OFF and --parallel4. Place this candidate below a work directory
containing the pinned toolchain to use that exact recipe; portable builds may
instead configure the complete current source with their own compatible SDK.
No old source archive is needed to compile the current source.

Producer provenance/archive regeneration requires both exact standalone
baseline archives for real patch reconstruction. These archives are named
and hashed in software7-parent.json/verification.json, not nested here:
  python write-provenance.py --parent-archive PATH --upstream-archive PATH
  python package-candidate.py --parent-archive PATH --upstream-archive PATH
The writer requires a real completed build/result and matching focused test
inputs. --preflight performs only read-only source/AA/recipe checks. The
packager uses actual git apply --check/apply on both authenticated baselines,
compares all757 reconstructed bytes, and refuses to overwrite an archive.
web-software.8.patch is the combined raw-upstream patch;
software7-to-software8.patch is only the incremental parent patch.

This source archive excludes original assets/executable/disassembly, saves,
account state, engine/test binaries and previous historical test trees.
Original resource files are a separately approved runtime asset bundle.
The full1:1 game/native-frame goal remains incomplete. Other formats,
callbacks, driver recovery, UV/float details and comprehensive gameplay
coverage remain active work. Producer static/build receipts make no new
browser/game/original-runtime/performance claim; runtime QA is separate.
Normal player audio is preserved; browser testing uses the quiet guard.
