Focused Software.8 screen additive-AA regression

Run from a workspace containing the pinned SDK/toolchain directory:
  python work/portable-build/software8-candidate/aa-tests/run-aa-tests.py
The runner accepts --source PATH for a relocated corresponding-source tree.
It includes the exact six required Software.7 baseline inputs, authenticated
against the pinned source ZIP by baseline-manifest.json. No sibling7 checkout
or binary artifact is needed. Generated CPP, WASM/Node files, logs and results
are written under aa-tests/results/. No game, audio or original code executes.

Expected: the frozen7 process exits1 with the native-empty-worker/state
counterexample;8 exits0. The Python runner succeeds only when both outcomes
match. Current run:10,866 assertions per variant;7 has1,168 expected failures
(888 differing framebuffer words);8 has0. These are synthetic method tests,
not original runtime or whole-game graphics comparisons.

Native scope established separately by private installed-executable static
analysis: ordinary software DDImage::DrawLineAA nonaxis mode1 invokes the empty
worker0x57AE10. The wrapper then discards its software mirror/cache buffers at
0x573530, without setting dirty counters or mDrawn. Native DD CommitBits does
nothing when the authoritative DD surface exists. The browser CPU target has
an authoritative mBits framebuffer, so the override retains it and uses the
unchanged production DeleteSWBuffers to invalidate the three auxiliary caches.
It preserves dirty count/flag, mDrawn, path, render state and target flags.

The correction is limited to finite nonaxis additive lines on this dedicated
forced-opaque, nonvolatile, canonical raw RGB888 CPU screen. Unforced/alpha/
transparent/volatile/indexed states, normal and unknown modes retain7 behavior.
Horizontal, vertical and point inputs still reach the existing virtual screen
FillRect. Ordinary game DrawLineAA callers were not found; this is an API
fidelity correction, not a newly observed gameplay rendering fix. Other pixel
formats, native surface locks and the native driver's storage are not emulated.

The runner extracts the actual production override, constructor/Create,
FillRect, inherited AA methods, BitsChanged/CommitBits/SetImageMode/cache
invalidation and generic AA include. Minimal app/rectangle/allocation doubles
avoid unrelated engine dependencies. The genuine lazy palette branch is
extracted from GetBits; unsupported recovery branches assert instead of
inventing pixels. Other screen methods/RAII/raster-context text and unchanged
MemoryImage/header/AA-include bytes are checked against the included baseline.
Normal/axis/fallback/offscreen comparisons preserve7; they do not establish
additional native AA arithmetic. No full engine build or browser result is
claimed by this focused suite.
