// Dependency doubles only; tested methods are extracted from pinned production.
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
using uchar=unsigned char;
#define OPTIMIZE_SOFTWARE_DRAWING
#define DBG_ASSERTE(x) assert(x)
constexpr uint32_t MEMORYCHECK_ID=0x4beefade;
struct Rect {
 int mX,mY,mWidth,mHeight;
 Rect(int x,int y,int w,int h):mX(x),mY(y),mWidth(w),mHeight(h){}
 Rect Intersection(const Rect& r)const{
  int l=std::max(mX,r.mX),t=std::max(mY,r.mY);
  return Rect(l,t,std::max(0,std::min(mX+mWidth,r.mX+r.mWidth)-l),std::max(0,std::min(mY+mHeight,r.mY+r.mHeight)-t));
 }
};
struct Color {
 int mRed,mGreen,mBlue,mAlpha;
 Color(int r,int g,int b,int a):mRed(r),mGreen(g),mBlue(b),mAlpha(a){}
 uint32_t ToInt()const{return(uint32_t(mAlpha)<<24)|(mRed<<16)|(mGreen<<8)|mBlue;}
};
struct Graphics {enum{DRAWMODE_NORMAL=0,DRAWMODE_ADDITIVE=1};};
struct SexyAppBase {};
struct Image {
 int mWidth=0,mHeight=0;bool mDrawn=false;std::string mFilePath;
 virtual ~Image()=default;
 virtual void Create(int,int)=0;
 virtual void FillRect(const Rect&,const Color&,int)=0;
 virtual void DrawLineAA(double,double,double,double,const Color&,int)=0;
};
struct MemoryImage:Image {
 std::unique_ptr<uint32_t[]> mBits,mColorTable,mNativeAlphaData;
 std::unique_ptr<uchar[]> mColorIndices,mRLAlphaData,mRLAdditiveData;
 bool mForcedMode=false,mHasTrans=false,mHasAlpha=false,mIsVolatile=false,mPurgeBits=false,mWantPal=false,mBitsChanged=false;
 int mBitsChangedCount=0;void* mRenderData=nullptr;uint32_t mRenderFlags=0;
 explicit MemoryImage(SexyAppBase*){}
 void Create(int w,int h)override{
  mWidth=w;mHeight=h;mBits=std::make_unique<uint32_t[]>(w*h+1);mBits[w*h]=MEMORYCHECK_ID;
  mColorTable.reset();mColorIndices.reset();mHasTrans=mHasAlpha=true;BitsChanged();
 }
 // The real lazy allocation/palette expansion branch, extracted by runner.
 uint32_t* GetBits();
 void FillRect(const Rect&,const Color&,int)override;
 void DrawLineAA(double,double,double,double,const Color&,int)override;
 void NormalDrawLineAA(double,double,double,double,const Color&);
 void BitsChanged();void CommitBits();void SetImageMode(bool,bool);void DeleteSWBuffers();
};
// Focused declaration mirrors actual ctor/Create/FillRect contract. The new
// virtual declaration is copied from the actual production header by runner.
struct SoftwareScreenImage final:MemoryImage {
 explicit SoftwareScreenImage(SexyAppBase*);
 void Create(int,int)override;
 void FillRect(const Rect&,const Color&,int)override;
 AA_OVERRIDE_DECLARATION
};
