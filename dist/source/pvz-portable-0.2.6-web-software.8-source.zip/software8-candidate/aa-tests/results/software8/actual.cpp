// Dependency doubles only; tested methods are extracted from pinned production.
#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <memory>
#include <string>
#include <vector>
using uchar=unsigned char;
#define OPTIMIZE_SOFTWARE_DRAWING
#define DBG_ASSERTE(x) assert(x)
constexpr uint32_t MEMORYCHECK_ID=0x4beefade;
struct Rect {
 int mX,mY,mWidth,mHeight;
 Rect(int x,int y,int w,int h):mX(x),mY(y),mWidth(w),mHeight(h){}
 Rect Intersection(const Rect& r)const{
  int l=std::max(mX,r.mX),t=std::max(mY,r.mY);
  return Rect(l,t,std::max(0,std::min(mX+mWidth,r.mX+r.mWidth)-l),std::max(0,std::min(mY+mHeight,r.mY+r.mHeight)-t));
 }
};
struct Color {
 int mRed,mGreen,mBlue,mAlpha;
 Color(int r,int g,int b,int a):mRed(r),mGreen(g),mBlue(b),mAlpha(a){}
 uint32_t ToInt()const{return(uint32_t(mAlpha)<<24)|(mRed<<16)|(mGreen<<8)|mBlue;}
};
struct Graphics {enum{DRAWMODE_NORMAL=0,DRAWMODE_ADDITIVE=1};};
struct SexyAppBase {};
struct Image {
 int mWidth=0,mHeight=0;bool mDrawn=false;std::string mFilePath;
 virtual ~Image()=default;
 virtual void Create(int,int)=0;
 virtual void FillRect(const Rect&,const Color&,int)=0;
 virtual void DrawLineAA(double,double,double,double,const Color&,int)=0;
};
struct MemoryImage:Image {
 std::unique_ptr<uint32_t[]> mBits,mColorTable,mNativeAlphaData;
 std::unique_ptr<uchar[]> mColorIndices,mRLAlphaData,mRLAdditiveData;
 bool mForcedMode=false,mHasTrans=false,mHasAlpha=false,mIsVolatile=false,mPurgeBits=false,mWantPal=false,mBitsChanged=false;
 int mBitsChangedCount=0;void* mRenderData=nullptr;uint32_t mRenderFlags=0;
 explicit MemoryImage(SexyAppBase*){}
 void Create(int w,int h)override{
  mWidth=w;mHeight=h;mBits=std::make_unique<uint32_t[]>(w*h+1);mBits[w*h]=MEMORYCHECK_ID;
  mColorTable.reset();mColorIndices.reset();mHasTrans=mHasAlpha=true;BitsChanged();
 }
 // The real lazy allocation/palette expansion branch, extracted by runner.
 uint32_t* GetBits();
 void FillRect(const Rect&,const Color&,int)override;
 void DrawLineAA(double,double,double,double,const Color&,int)override;
 void NormalDrawLineAA(double,double,double,double,const Color&);
 void BitsChanged();void CommitBits();void SetImageMode(bool,bool);void DeleteSWBuffers();
};
// Focused declaration mirrors actual ctor/Create/FillRect contract. The new
// virtual declaration is copied from the actual production header by runner.
struct SoftwareScreenImage final:MemoryImage {
 explicit SoftwareScreenImage(SexyAppBase*);
 void Create(int,int)override;
 void FillRect(const Rect&,const Color&,int)override;
 void DrawLineAA(double startX, double startY, double endX, double endY,
        const Color& color, int drawMode) override;
};

uint32_t* MemoryImage::GetBits(){if(!mBits){int aSize=mWidth*mHeight;mBits=std::make_unique<uint32_t[]>(aSize+1);mBits[aSize]=MEMORYCHECK_ID;		if (mColorTable != nullptr)
		{
			for (int i = 0; i < aSize; i++)
				mBits[i] = mColorTable[mColorIndices[i]];

			mColorIndices.reset();
			mColorTable.reset();
			mNativeAlphaData.reset();
		}else{assert(false&&"Unexercised device/native recovery");}}return mBits.get();}
void MemoryImage::BitsChanged()
{
	mBitsChanged = true;
	mBitsChangedCount++;
	mFilePath.clear();

	mNativeAlphaData.reset();
	mRLAlphaData.reset();
	mRLAdditiveData.reset();

	// Verify secret value at end to protect against overwrite
	if (mBits != nullptr)
	{
		DBG_ASSERTE(mBits[mWidth*mHeight] == MEMORYCHECK_ID);
	}
}
void MemoryImage::CommitBits()
{
	//if (gDebug)
	//	mApp->CopyToClipboard("+MemoryImage::CommitBits");

	if ((mBitsChanged) && (!mForcedMode))
	{
		// Analyze
		if (mBits != nullptr)
		{
			mHasTrans = false;
			mHasAlpha = false;

			int aSize = mWidth*mHeight;
			uint32_t* ptr = mBits.get();

			for (int i = 0; i < aSize; i++)
			{
				uchar anAlpha = (uchar) (*ptr++ >> 24);

				if (anAlpha == 0)
					mHasTrans = true;
				else if (anAlpha != 255)
					mHasAlpha = true;
			}
		}
		else if (mColorTable != nullptr)
		{
			mHasTrans = false;
			mHasAlpha = false;

			int aSize = 256;
			uint32_t* ptr = mColorTable.get();

			for (int i = 0; i < aSize; i++)
			{
				uchar anAlpha = (uchar) (*ptr++ >> 24);

				if (anAlpha == 0)
					mHasTrans = true;
				else if (anAlpha != 255)
					mHasAlpha = true;
			}
		}
		else
		{
			mHasTrans = true;
			mHasAlpha = false;
		}

		mBitsChanged = false;
	}

	//if (gDebug)
	//	mApp->CopyToClipboard("-MemoryImage::CommitBits");
}
void MemoryImage::SetImageMode(bool hasTrans, bool hasAlpha)
{
	mForcedMode = true;
	mHasTrans = hasTrans;
	mHasAlpha = hasAlpha;
}
void MemoryImage::DeleteSWBuffers()
{
	if ((mBits == nullptr) && (mColorIndices == nullptr))
		GetBits();

	mNativeAlphaData.reset();
	mRLAdditiveData.reset();
	mRLAlphaData.reset();
}
void MemoryImage::FillRect(const Rect& theRect, const Color& theColor, int theDrawMode)
{
	if (theDrawMode == Graphics::DRAWMODE_ADDITIVE)
	{
		const Rect clipped = theRect.Intersection(Rect(0, 0, mWidth, mHeight));
		uint32_t* bits = GetBits();
		const int weight = theColor.mAlpha == 255 ? 256 : theColor.mAlpha;
		for (int y = clipped.mY; y < clipped.mY + clipped.mHeight; ++y)
			for (int x = clipped.mX; x < clipped.mX + clipped.mWidth; ++x)
			{
				uint32_t& pixel = bits[y * mWidth + x];
				const int red = std::min(255, static_cast<int>((pixel >> 16) & 255) + ((theColor.mRed * weight) >> 8));
				const int green = std::min(255, static_cast<int>((pixel >> 8) & 255) + ((theColor.mGreen * weight) >> 8));
				const int blue = std::min(255, static_cast<int>(pixel & 255) + ((theColor.mBlue * weight) >> 8));
				pixel = (pixel & 0xFF000000u) | (red << 16) | (green << 8) | blue;
			}
		BitsChanged();
		return;
	}
	uint32_t src = theColor.ToInt();

	uint32_t* aBits = GetBits();

	int oldAlpha = src >> 24;

	if (oldAlpha == 0xFF)
	{
		for (int aRow = theRect.mY; aRow < theRect.mY+theRect.mHeight; aRow++)
		{
			uint32_t* aDestPixels = &aBits[aRow*mWidth+theRect.mX];

			for (int i = 0; i < theRect.mWidth; i++)
				*aDestPixels++ = src;
		}
	}
	else
	{
		for (int aRow = theRect.mY; aRow < theRect.mY+theRect.mHeight; aRow++)
		{
			uint32_t* aDestPixels = &aBits[aRow*mWidth+theRect.mX];

			for (int i = 0; i < theRect.mWidth; i++)
			{
				uint32_t dest = *aDestPixels;

				int aDestAlpha = dest >> 24;
				int aNewDestAlpha = aDestAlpha + ((255 - aDestAlpha) * oldAlpha) / 255;

				int newAlpha = (aNewDestAlpha == 0) ? 0 : 255 * oldAlpha / aNewDestAlpha; // fully transparent: color weight is moot

				int oma = 256 - newAlpha;

#ifdef OPTIMIZE_SOFTWARE_DRAWING
				*(aDestPixels++) = (aNewDestAlpha << 24) |
					((((dest & 0xFF00FF) * oma + (src & 0xFF00FF) * newAlpha) >> 8) & 0xFF00FF) |
					((((dest & 0x00FF00) * oma + (src & 0x00FF00) * newAlpha) >> 8) & 0x00FF00);
#else
				*(aDestPixels++) = (aNewDestAlpha << 24) |
					((((dest & 0x0000FF) * oma) >> 8) + (((src & 0x0000FF) * newAlpha) >> 8) & 0x0000FF) |
					((((dest & 0x00FF00) * oma) >> 8) + (((src & 0x00FF00) * newAlpha) >> 8) & 0x00FF00) |
					((((dest & 0xFF0000) * oma) >> 8) + (((src & 0xFF0000) * newAlpha) >> 8) & 0xFF0000);
#endif
			}
		}
	}

	BitsChanged();
}
void MemoryImage::NormalDrawLineAA(double theStartX, double theStartY, double theEndX, double theEndY, const Color& theColor)
{
	uint32_t* aBits = GetBits();
	uint32_t color = theColor.ToInt();

	int aX0 = (int)theStartX, aX1 = (int)theEndX;
	int aY0 = (int)theStartY, aY1 = (int)theEndY;
	int aXinc = 1;
	if (aY0 > aY1)
	{
		int aTempX = aX0, aTempY = aY0;
		aX0 = aX1; aY0 = aY1;
		aX1 = aTempX; aY1 = aTempY;
		double aTempXd = theStartX, aTempYd = theStartY;
		theStartX = theEndX; theStartY = theEndY;
		theEndX = aTempXd; theEndY = aTempYd;
	}

	int dx = aX1 - aX0;
	int dy = aY1 - aY0;
	double dxd = theEndX - theStartX;
	double dyd = theEndY - theStartY;
	if (dx < 0)
	{
		dx = -dx;
		aXinc = -1;
		dxd = -dxd;
	}

	if (theColor.mAlpha != 255)
	{
		#define PIXEL_TYPE				uint32_t
		#define CALC_WEIGHT_A(w)		(((w) * (theColor.mAlpha+1)) >> 8)
		#define BLEND_PIXEL(p) \
		{\
			int aDestAlpha = dest >> 24;\
			int aNewDestAlpha = aDestAlpha + ((255 - aDestAlpha) * a) / 255;\
			a = (aNewDestAlpha == 0) ? 0 : 255 * a / aNewDestAlpha;\
			oma = 256 - a;\
			*(p) = (aNewDestAlpha << 24) |\
					((((color & 0xFF0000) * a + (dest & 0xFF0000) * oma) >> 8) & 0xFF0000) |\
					((((color & 0x00FF00) * a + (dest & 0x00FF00) * oma) >> 8) & 0x00FF00) |\
					((((color & 0x0000FF) * a + (dest & 0x0000FF) * oma) >> 8) & 0x0000FF);\
		}
		const int STRIDE = mWidth;

		#include "inc_routines/GENERIC_DrawLineAA.inc"

		#undef PIXEL_TYPE
		#undef CALC_WEIGHT_A
		#undef BLEND_PIXEL
	}
	else
	{
		#define PIXEL_TYPE				uint32_t
		#define CALC_WEIGHT_A(w)		(w)
		#define BLEND_PIXEL(p) \
		{\
			int aDestAlpha = dest >> 24;\
			int aNewDestAlpha = aDestAlpha + ((255 - aDestAlpha) * a) / 255;\
			a = (aNewDestAlpha == 0) ? 0 : 255 * a / aNewDestAlpha;\
			oma = 256 - a;\
			*(p) = (aNewDestAlpha << 24) |\
					((((color & 0xFF0000) * a + (dest & 0xFF0000) * oma) >> 8) & 0xFF0000) |\
					((((color & 0x00FF00) * a + (dest & 0x00FF00) * oma) >> 8) & 0x00FF00) |\
					((((color & 0x0000FF) * a + (dest & 0x0000FF) * oma) >> 8) & 0x0000FF);\
		}
		const int STRIDE = mWidth;

		#include "inc_routines/GENERIC_DrawLineAA.inc"

		#undef PIXEL_TYPE
		#undef CALC_WEIGHT_A
		#undef BLEND_PIXEL
	}


	BitsChanged();
}
void MemoryImage::DrawLineAA(double theStartX, double theStartY, double theEndX, double theEndY, const Color& theColor, int theDrawMode)
{
	if (theStartY == theEndY)
	{
		int aStartX = std::min(theStartX, theEndX);
		int aEndX = std::max(theStartX, theEndX);

		FillRect(Rect(aStartX, theStartY, aEndX-aStartX+1, theEndY-theStartY+1), theColor, theDrawMode);
		return;
	}
	else if (theStartX == theEndX)
	{
		int aStartY = std::min(theStartY, theEndY);
		int aEndY = std::max(theStartY, theEndY);

		FillRect(Rect(theStartX, aStartY, theEndX-theStartX+1, aEndY-aStartY+1), theColor, theDrawMode);
		return;
	}

	NormalDrawLineAA(theStartX, theStartY, theEndX, theEndY, theColor);

	BitsChanged();
}
SoftwareScreenImage::SoftwareScreenImage(SexyAppBase* app) : MemoryImage(app)
{
    SetImageMode(false, false);
    mPurgeBits = false;
}
void SoftwareScreenImage::Create(int width, int height)
{
    MemoryImage::Create(width, height);
    SetImageMode(false, false);
    mPurgeBits = false;
}
void SoftwareScreenImage::FillRect(const Rect& rect, const Color& color, int drawMode)
{
    if (drawMode != Graphics::DRAWMODE_NORMAL && drawMode != Graphics::DRAWMODE_ADDITIVE)
        return;
    const Rect clipped = rect.Intersection(Rect(0, 0, mWidth, mHeight));
    if (clipped.mWidth <= 0 || clipped.mHeight <= 0)
        return;
    uint32_t* bits = GetBits();
    const int alpha = color.mAlpha;
    for (int y = clipped.mY; y < clipped.mY + clipped.mHeight; ++y)
        for (int x = clipped.mX; x < clipped.mX + clipped.mWidth; ++x)
        {
            uint32_t& pixel = bits[y * mWidth + x];
            uint32_t result = 0xff000000u;
            for (int shift = 0; shift < 24; shift += 8)
            {
                const uint32_t mask = 255u << shift;
                const int channel = shift == 16 ? color.mRed : shift == 8 ? color.mGreen : color.mBlue;
                uint32_t output;
                if (drawMode == Graphics::DRAWMODE_ADDITIVE)
                    output = static_cast<uint32_t>(std::min(255,
                        static_cast<int>((pixel >> shift) & 255) + channel * alpha / 255)) << shift;
                else if (alpha == 255)
                    // Native RGB32 opaque fill omits the correction term. Its
                    // positive channels therefore map to channel-1, not channel.
                    output = ((static_cast<uint32_t>(channel) * mask) >> 8) & mask;
                else
                {
                    const uint32_t weighted = static_cast<uint32_t>((channel * alpha + 127) >> 8);
                    const uint32_t mapped = ((weighted * mask + mask) >> 8) & mask;
                    output = ((((pixel & mask) * static_cast<uint32_t>(256 - alpha)) >> 8) & mask) + mapped;
                }
                result |= output;
            }
            pixel = result;
        }
    BitsChanged();
}
void SoftwareScreenImage::DrawLineAA(double startX, double startY, double endX, double endY,
    const Color& color, int drawMode)
{
    if (drawMode == Graphics::DRAWMODE_ADDITIVE && startX != endX && startY != endY &&
        std::isfinite(startX) && std::isfinite(startY) && std::isfinite(endX) && std::isfinite(endY) &&
        mForcedMode && !mHasAlpha && !mHasTrans && !mIsVolatile &&
        mBits && !mColorTable && !mColorIndices)
    {
        // Native DD32's nonaxis additive-AA worker is empty. Its wrapper
        // discards auxiliary caches without marking the surface changed.
        // Here mBits is the authoritative framebuffer, not a DD surface copy.
        DeleteSWBuffers();
        return;
    }
    MemoryImage::DrawLineAA(startX, startY, endX, endY, color, drawMode);
}
// Expected target pixels: untouched, because addressed native worker57AE10 is empty.
// Wrapper clears mirrors/caches but does not mark the authoritative surface dirty.
static unsigned checks=0,failures=0,pixelDifferences=0;
static void check(bool ok,const char* label){++checks;if(!ok){++failures;if(failures<12)std::printf("FAIL %s\n",label);}}
static void seed(MemoryImage& im,bool raw=true){
 im.Create(8,7);im.mHasAlpha=false;im.mHasTrans=false;im.mForcedMode=true;
 for(int i=0;i<56;++i)im.mBits[i]=0xff123456u+uint32_t(i*0x010307u);
 if(!raw){
  im.mColorTable=std::make_unique<uint32_t[]>(256);im.mColorIndices=std::make_unique<uchar[]>(56);
  for(int i=0;i<256;++i)im.mColorTable[i]=0xff251904u+uint32_t(i*0x010203u);
  for(int i=0;i<56;++i)im.mColorIndices[i]=uchar(i);
  im.mBits.reset();
 }
 im.mNativeAlphaData=std::make_unique<uint32_t[]>(2);im.mRLAlphaData=std::make_unique<uchar[]>(2);im.mRLAdditiveData=std::make_unique<uchar[]>(2);
 im.mBitsChanged=false;im.mBitsChangedCount=37;im.mFilePath="authored-marker";im.mDrawn=true;
 im.mRenderData=reinterpret_cast<void*>(uintptr_t(1234));im.mRenderFlags=91;im.mWantPal=false;im.mPurgeBits=false;
}
static std::vector<uint32_t> words(MemoryImage& im){return std::vector<uint32_t>(im.GetBits(),im.GetBits()+57);}
static void same(MemoryImage& a,MemoryImage& b,const char* name){
 check(words(a)==words(b),name);check(a.mBitsChanged==b.mBitsChanged,name);
 check(a.mBitsChangedCount==b.mBitsChangedCount,name);check(a.mFilePath==b.mFilePath,name);check(a.mDrawn==b.mDrawn,name);
 check(bool(a.mNativeAlphaData)==bool(b.mNativeAlphaData),name);
 check(bool(a.mRLAlphaData)==bool(b.mRLAlphaData),name);check(bool(a.mRLAdditiveData)==bool(b.mRLAdditiveData),name);
 check(a.mHasAlpha==b.mHasAlpha&&a.mHasTrans==b.mHasTrans&&a.mForcedMode==b.mForcedMode,name);
}
struct Segment {double x0,y0,x1,y1;};
int main(){
 SexyAppBase app;
 const Segment segments[]={{1,1,6,4},{6,4,1,1},{2,1,4,5},{4,5,2,1},{6,1,1,5},{1.25,1.5,6.5,4.25},{2.25,1.25,4.25,5.25}};
 for(auto s:segments)for(int alpha:{0,1,128,254,255})for(bool dirty:{false,true})for(bool drawn:{false,true}){
  SoftwareScreenImage im(&app);seed(im);im.mBitsChanged=dirty;im.mDrawn=drawn;
  auto expected=words(im);auto pointer=im.mBits.get();Image* target=&im;
  target->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(255,100,20,alpha),1);
  for(int i=0;i<57;++i){bool equal=im.mBits[i]==expected[i];pixelDifferences+=!equal;check(equal,"native-empty-worker framebuffer/guard");}
  check(im.mBits.get()==pointer,"authoritative CPU pointer retained");
  check(!im.mNativeAlphaData&&!im.mRLAlphaData&&!im.mRLAdditiveData,"native wrapper auxiliary-cache eviction");
  check(im.mBitsChanged==dirty&&im.mBitsChangedCount==37,"native wrapper does not mark dirty");
  check(im.mDrawn==drawn&&im.mFilePath=="authored-marker","native wrapper preserves draw/path state");
  check(im.mForcedMode&&!im.mHasTrans&&!im.mHasAlpha&&!im.mIsVolatile,"target flags retained");
  check(im.mRenderData==reinterpret_cast<void*>(uintptr_t(1234))&&im.mRenderFlags==91,"render context retained");
 }
 // Normal and unknown modes retain EXACT inherited7 behavior, not a new AA oracle.
 for(auto s:segments)for(int mode:{0,-1,2})for(int alpha:{0,1,128,254,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a);seed(b);
  Image* virtualTarget=&a;virtualTarget->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(90,210,255,alpha),mode);
  b.MemoryImage::DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(90,210,255,alpha),mode);
  same(a,b,"normal/unknown mode inherited behavior");
 }
 // Horizontal/vertical/point still invoke current screen virtual FillRect.
 const Segment axes[]={{1,2,6,2},{6,2,1,2},{3,1,3,5},{3,5,3,1},{3,3,3,3}};
 for(auto s:axes)for(int mode:{0,1,-1,2})for(int alpha:{0,1,128,254,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a);seed(b);Image* target=&a;
  target->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(255,20,70,alpha),mode);
  int x=int(std::min(s.x0,s.x1)),y=int(std::min(s.y0,s.y1));
  b.FillRect(Rect(x,y,int(std::max(s.x0,s.x1))-x+1,int(std::max(s.y0,s.y1))-y+1),Color(255,20,70,alpha),mode);
  same(a,b,"axis/point virtual FillRect route");
 }
 // Unproved screen states must fall through to the same inherited method.
 for(int state=0;state<6;++state)for(int alpha:{1,128,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a,state!=5);seed(b,state!=5);
  if(state==0)a.mForcedMode=b.mForcedMode=false;
  if(state==1)a.mHasTrans=b.mHasTrans=true;
  if(state==2)a.mHasAlpha=b.mHasAlpha=true;
  if(state==3)a.mIsVolatile=b.mIsVolatile=true;
  if(state==4){ // Both raw bits and stale palette: do not take canonical-raw gate.
   a.mColorTable=std::make_unique<uint32_t[]>(256);b.mColorTable=std::make_unique<uint32_t[]>(256);
   a.mColorIndices=std::make_unique<uchar[]>(56);b.mColorIndices=std::make_unique<uchar[]>(56);
  }
  if(state==5)check(!a.mBits&&a.mColorTable&&a.mColorIndices,"genuine lazy indexed input");
  Image* target=&a;target->DrawLineAA(1,1,6,4,Color(255,100,20,alpha),1);
  b.MemoryImage::DrawLineAA(1,1,6,4,Color(255,100,20,alpha),1);same(a,b,"unproved target state fallback");
 }
 // Plain offscreen MI receives no screen override, for opaque and alpha targets.
 for(bool alphaTarget:{false,true})for(int mode:{0,1}){
  MemoryImage a(&app),b(&app);seed(a);seed(b);a.mForcedMode=b.mForcedMode=false;a.mHasAlpha=b.mHasAlpha=alphaTarget;
  Image* target=&a;target->DrawLineAA(1,1,6,4,Color(20,255,80,128),mode);
  b.MemoryImage::DrawLineAA(1,1,6,4,Color(20,255,80,128),mode);same(a,b,"offscreen MI virtual route unchanged");
 }
 std::printf("{\"checks\":%u,\"failures\":%u,\"targetPixelDifferences\":%u}\n",checks,failures,pixelDifferences);
 return failures?1:0;
}
