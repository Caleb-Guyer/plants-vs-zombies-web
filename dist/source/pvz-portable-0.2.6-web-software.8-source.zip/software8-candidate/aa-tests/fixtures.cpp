// Expected target pixels: untouched, because addressed native worker57AE10 is empty.
// Wrapper clears mirrors/caches but does not mark the authoritative surface dirty.
static unsigned checks=0,failures=0,pixelDifferences=0;
static void check(bool ok,const char* label){++checks;if(!ok){++failures;if(failures<12)std::printf("FAIL %s\n",label);}}
static void seed(MemoryImage& im,bool raw=true){
 im.Create(8,7);im.mHasAlpha=false;im.mHasTrans=false;im.mForcedMode=true;
 for(int i=0;i<56;++i)im.mBits[i]=0xff123456u+uint32_t(i*0x010307u);
 if(!raw){
  im.mColorTable=std::make_unique<uint32_t[]>(256);im.mColorIndices=std::make_unique<uchar[]>(56);
  for(int i=0;i<256;++i)im.mColorTable[i]=0xff251904u+uint32_t(i*0x010203u);
  for(int i=0;i<56;++i)im.mColorIndices[i]=uchar(i);
  im.mBits.reset();
 }
 im.mNativeAlphaData=std::make_unique<uint32_t[]>(2);im.mRLAlphaData=std::make_unique<uchar[]>(2);im.mRLAdditiveData=std::make_unique<uchar[]>(2);
 im.mBitsChanged=false;im.mBitsChangedCount=37;im.mFilePath="authored-marker";im.mDrawn=true;
 im.mRenderData=reinterpret_cast<void*>(uintptr_t(1234));im.mRenderFlags=91;im.mWantPal=false;im.mPurgeBits=false;
}
static std::vector<uint32_t> words(MemoryImage& im){return std::vector<uint32_t>(im.GetBits(),im.GetBits()+57);}
static void same(MemoryImage& a,MemoryImage& b,const char* name){
 check(words(a)==words(b),name);check(a.mBitsChanged==b.mBitsChanged,name);
 check(a.mBitsChangedCount==b.mBitsChangedCount,name);check(a.mFilePath==b.mFilePath,name);check(a.mDrawn==b.mDrawn,name);
 check(bool(a.mNativeAlphaData)==bool(b.mNativeAlphaData),name);
 check(bool(a.mRLAlphaData)==bool(b.mRLAlphaData),name);check(bool(a.mRLAdditiveData)==bool(b.mRLAdditiveData),name);
 check(a.mHasAlpha==b.mHasAlpha&&a.mHasTrans==b.mHasTrans&&a.mForcedMode==b.mForcedMode,name);
}
struct Segment {double x0,y0,x1,y1;};
int main(){
 SexyAppBase app;
 const Segment segments[]={{1,1,6,4},{6,4,1,1},{2,1,4,5},{4,5,2,1},{6,1,1,5},{1.25,1.5,6.5,4.25},{2.25,1.25,4.25,5.25}};
 for(auto s:segments)for(int alpha:{0,1,128,254,255})for(bool dirty:{false,true})for(bool drawn:{false,true}){
  SoftwareScreenImage im(&app);seed(im);im.mBitsChanged=dirty;im.mDrawn=drawn;
  auto expected=words(im);auto pointer=im.mBits.get();Image* target=&im;
  target->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(255,100,20,alpha),1);
  for(int i=0;i<57;++i){bool equal=im.mBits[i]==expected[i];pixelDifferences+=!equal;check(equal,"native-empty-worker framebuffer/guard");}
  check(im.mBits.get()==pointer,"authoritative CPU pointer retained");
  check(!im.mNativeAlphaData&&!im.mRLAlphaData&&!im.mRLAdditiveData,"native wrapper auxiliary-cache eviction");
  check(im.mBitsChanged==dirty&&im.mBitsChangedCount==37,"native wrapper does not mark dirty");
  check(im.mDrawn==drawn&&im.mFilePath=="authored-marker","native wrapper preserves draw/path state");
  check(im.mForcedMode&&!im.mHasTrans&&!im.mHasAlpha&&!im.mIsVolatile,"target flags retained");
  check(im.mRenderData==reinterpret_cast<void*>(uintptr_t(1234))&&im.mRenderFlags==91,"render context retained");
 }
 // Normal and unknown modes retain EXACT inherited7 behavior, not a new AA oracle.
 for(auto s:segments)for(int mode:{0,-1,2})for(int alpha:{0,1,128,254,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a);seed(b);
  Image* virtualTarget=&a;virtualTarget->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(90,210,255,alpha),mode);
  b.MemoryImage::DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(90,210,255,alpha),mode);
  same(a,b,"normal/unknown mode inherited behavior");
 }
 // Horizontal/vertical/point still invoke current screen virtual FillRect.
 const Segment axes[]={{1,2,6,2},{6,2,1,2},{3,1,3,5},{3,5,3,1},{3,3,3,3}};
 for(auto s:axes)for(int mode:{0,1,-1,2})for(int alpha:{0,1,128,254,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a);seed(b);Image* target=&a;
  target->DrawLineAA(s.x0,s.y0,s.x1,s.y1,Color(255,20,70,alpha),mode);
  int x=int(std::min(s.x0,s.x1)),y=int(std::min(s.y0,s.y1));
  b.FillRect(Rect(x,y,int(std::max(s.x0,s.x1))-x+1,int(std::max(s.y0,s.y1))-y+1),Color(255,20,70,alpha),mode);
  same(a,b,"axis/point virtual FillRect route");
 }
 // Unproved screen states must fall through to the same inherited method.
 for(int state=0;state<6;++state)for(int alpha:{1,128,255}){
  SoftwareScreenImage a(&app),b(&app);seed(a,state!=5);seed(b,state!=5);
  if(state==0)a.mForcedMode=b.mForcedMode=false;
  if(state==1)a.mHasTrans=b.mHasTrans=true;
  if(state==2)a.mHasAlpha=b.mHasAlpha=true;
  if(state==3)a.mIsVolatile=b.mIsVolatile=true;
  if(state==4){ // Both raw bits and stale palette: do not take canonical-raw gate.
   a.mColorTable=std::make_unique<uint32_t[]>(256);b.mColorTable=std::make_unique<uint32_t[]>(256);
   a.mColorIndices=std::make_unique<uchar[]>(56);b.mColorIndices=std::make_unique<uchar[]>(56);
  }
  if(state==5)check(!a.mBits&&a.mColorTable&&a.mColorIndices,"genuine lazy indexed input");
  Image* target=&a;target->DrawLineAA(1,1,6,4,Color(255,100,20,alpha),1);
  b.MemoryImage::DrawLineAA(1,1,6,4,Color(255,100,20,alpha),1);same(a,b,"unproved target state fallback");
 }
 // Plain offscreen MI receives no screen override, for opaque and alpha targets.
 for(bool alphaTarget:{false,true})for(int mode:{0,1}){
  MemoryImage a(&app),b(&app);seed(a);seed(b);a.mForcedMode=b.mForcedMode=false;a.mHasAlpha=b.mHasAlpha=alphaTarget;
  Image* target=&a;target->DrawLineAA(1,1,6,4,Color(20,255,80,128),mode);
  b.MemoryImage::DrawLineAA(1,1,6,4,Color(20,255,80,128),mode);same(a,b,"offscreen MI virtual route unchanged");
 }
 std::printf("{\"checks\":%u,\"failures\":%u,\"targetPixelDifferences\":%u}\n",checks,failures,pixelDifferences);
 return failures?1:0;
}
