"""Actual-method paired AA diagnostic. No original execution/game/audio/init.

Both variants use the included authenticated7 baseline. --source defaults to
this candidate's source. The only expected failing process is frozen7.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess

HERE=Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--source',type=Path,default=HERE.parent/'source');args=arg.parse_args()
SOURCE=args.source.resolve();BASE=HERE/'software7-baseline'
WORK=next(p for p in HERE.parents if (p/'toolchain').is_dir())
SDK=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
OUT=HERE/'results';OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def function(t,s):
 assert t.count(s)==1,s
 start=t.index(s);brace=t.index('{',start);depth=0
 for end in range(brace,len(t)):
  depth+=(t[end]=='{')-(t[end]=='}')
  if not depth:return t[start:end+1]
 raise AssertionError(s)
manifest=json.loads((HERE/'baseline-manifest.json').read_text(encoding='utf8'))
for name,value in manifest['files'].items():assert sha((BASE/name).read_bytes())==value,name
G='src/SexyAppFramework/graphics/'
old=(BASE/'SoftwareScreenImage.cpp').read_bytes();new=(SOURCE/G/'SoftwareScreenImage.cpp').read_bytes()
oldt=old.decode('utf8');newt=new.decode('utf8')
addition=function(newt,'void SoftwareScreenImage::DrawLineAA(')
assert newt.replace('#include <cmath>\n','').replace('\n'+addition+'\n','')==oldt,'Old screen file content changed beyond AA/include'
oldh=(BASE/'SoftwareScreenImage.h').read_text(encoding='utf8')
newh=(SOURCE/G/'SoftwareScreenImage.h').read_text(encoding='utf8')
decl=re.search(r'    void DrawLineAA\([^;]+;',newh).group(0)
assert newh.replace(decl+'\n','')==oldh,'Old screen declarations changed'
for name in ['MemoryImage.cpp','MemoryImage.h','Image.h','inc_routines/GENERIC_DrawLineAA.inc']:
 assert (SOURCE/G/name).read_bytes()==(BASE/name).read_bytes(),name
preserved={}
for m in re.finditer(r'(?:void|uint32_t|bool) SoftwareScreenImage::\w+\(',oldt):
 sig=m.group(0);body=function(oldt,sig);assert function(newt,sig)==body,sig;preserved[sig]=sha(body.encode())

prefix=(HERE/'prefix.cpp').read_text(encoding='utf8');fixtures=(HERE/'fixtures.cpp').read_text(encoding='utf8')
rows={};inputs={}
for variant,root in [('software7',BASE),('software8',SOURCE/G)]:
 out=OUT/variant;out.mkdir(exist_ok=True);(out/'inc_routines').mkdir(exist_ok=True);(out/'temp').mkdir(exist_ok=True)
 memory=(root/'MemoryImage.cpp').read_text(encoding='utf8');screen=(root/'SoftwareScreenImage.cpp').read_text(encoding='utf8')
 header=(root/'SoftwareScreenImage.h').read_text(encoding='utf8')
 has_override='void DrawLineAA(' in header
 generated=prefix.replace('AA_OVERRIDE_DECLARATION',decl.strip() if has_override else '')
 # Exact production lazy-allocation/palette branch; other recovery paths are
 # outside these fixtures and intentionally fail instead of fabricating pixels.
 getbits=function(memory,'uint32_t* MemoryImage::GetBits(')
 begin=getbits.index('\t\tif (mColorTable != nullptr)');stop=getbits.index('\n\t\telse if (mNativeAlphaData != nullptr)')
 palette=getbits[begin:stop]
 generated+='\nuint32_t* MemoryImage::GetBits(){if(!mBits){int aSize=mWidth*mHeight;mBits=std::make_unique<uint32_t[]>(aSize+1);mBits[aSize]=MEMORYCHECK_ID;'+palette+'else{assert(false&&"Unexercised device/native recovery");}}return mBits.get();}\n'
 methods=['void MemoryImage::BitsChanged(','void MemoryImage::CommitBits(','void MemoryImage::SetImageMode(',
  'void MemoryImage::DeleteSWBuffers(','void MemoryImage::FillRect(','void MemoryImage::NormalDrawLineAA(','void MemoryImage::DrawLineAA(']
 generated+='\n'.join(function(memory,s) for s in methods)+'\n'
 for s in ['SoftwareScreenImage::SoftwareScreenImage(','void SoftwareScreenImage::Create(','void SoftwareScreenImage::FillRect(']:generated+=function(screen,s)+'\n'
 if has_override:generated+=function(screen,'void SoftwareScreenImage::DrawLineAA(')+'\n'
 generated+=fixtures
 cpp=out/'actual.cpp';cpp.write_text(generated,encoding='utf8',newline='\n')
 inc=root/'inc_routines/GENERIC_DrawLineAA.inc';shutil.copyfile(inc,out/'inc_routines/GENERIC_DrawLineAA.inc')
 pinned={str(p.relative_to(root)):sha(p.read_bytes()) for p in [root/'MemoryImage.cpp',root/'SoftwareScreenImage.cpp',root/'SoftwareScreenImage.h',inc]}
 env=dict(os.environ,EM_CONFIG=str(SDK/'.emscripten'),EM_CACHE=str(WORK/'toolchain/em-cache'),EMCC_TEMP_DIR=str(out/'temp'),PYTHONNOUSERSITE='1')
 command=[SDK/'python/3.13.3_64bit/python.exe',SDK/'upstream/emscripten/em++.py',cpp,'-std=c++20','-O1','-sENVIRONMENT=node','-o',out/'actual.js']
 build=subprocess.run(list(map(str,command)),env=env,capture_output=True,text=True)
 (out/'build.log').write_text(build.stdout+build.stderr,encoding='utf8',newline='\n');assert build.returncode==0,build.stderr
 run=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(out/'actual.js')],capture_output=True,text=True)
 (out/'run.log').write_text(run.stdout+run.stderr,encoding='utf8',newline='\n')
 result=json.loads(run.stdout.splitlines()[-1]);result.update(exitCode=run.returncode,generatedSha256=sha(cpp.read_bytes()),sourceInputsSha256=pinned)
 if variant=='software7':assert run.returncode==1 and result['failures']>0 and result['targetPixelDifferences']>0,result
 else:assert run.returncode==0 and result['failures']==0,result
 assert all(sha((root/n).read_bytes())==h for n,h in pinned.items())
 rows[variant]=result
receipt={'status':'PASS paired native-empty-worker/aux-cache scope','variants':rows,'preservedScreenBodiesSha256':preserved,
 'preservedOtherScreenBytes':True,'unchangedMemoryAndAAInclude':True,
 'runnerSha256':sha(Path(__file__).read_bytes()),'prefixSha256':sha((HERE/'prefix.cpp').read_bytes()),'fixturesSha256':sha((HERE/'fixtures.cpp').read_bytes()),
 'baselineManifestSha256':sha((HERE/'baseline-manifest.json').read_bytes()),
 'scope':'Actual extracted virtual screen override, MI AA/Fill/cache/bookkeeping and generic AA include; dependency allocation/app/geometry doubles. Native worker+wrapper static proof is external private audit. CPU mBits retained as authoritative framebuffer; native DD mBits mirror deletion has no direct storage equivalent. Normal/axis/fallback/offscreen are exact7 controls, not new native normal-AA proof. No original execution, ordinary game callsite proof, native framebuffer, full engine, browser or audio.'}
(OUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'status':receipt['status'],'variants':{n:{k:v for k,v in row.items() if k in ['checks','failures','targetPixelDifferences','exitCode']} for n,row in rows.items()}},indent=2))
