"""Lean corresponding-source helpers. Importing never builds or starts the game."""
from pathlib import Path, PurePosixPath
import difflib, hashlib, json, os, subprocess, zipfile, zlib

ROOT = Path(__file__).resolve().parent
VERSION = '0.2.6-web-software.8'
PARENT_SHA = '66b4cf8c473f1c9e6293a60cb2d7864b24cd91b0803745a77ef62c1669cacc3a'
PARENT_MANIFEST_SHA = '3c2067ce84d899a8dff4e8dd9458e4345027012f3d3a8dc09ae71f94f496dab1'
UPSTREAM_SHA = '40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
ALLOWED = sorted(['CMake/ProjectVersion.cmake', 'src/Lawn/Challenge.cpp',
    'src/SexyAppFramework/graphics/SoftwareScreenImage.cpp',
    'src/SexyAppFramework/graphics/SoftwareScreenImage.h'])
FLAGS = {'CMAKE_BUILD_TYPE': 'Release', 'DO_FIX_BUGS': 'OFF', 'PVZ_DEBUG': 'OFF', 'LOW_MEMORY': 'OFF'}
AA_FILES = ['README.txt', 'run-aa-tests.py', 'prefix.cpp', 'fixtures.cpp',
    'baseline-manifest.json', 'verification.json', 'results/results.json']
AA_BASE = ['Image.h', 'MemoryImage.cpp', 'MemoryImage.h', 'SoftwareScreenImage.cpp',
    'SoftwareScreenImage.h', 'inc_routines/GENERIC_DrawLineAA.inc']
AA_FILES += ['software7-baseline/' + n for n in AA_BASE]
AA_FILES += ['results/' + v + '/' + n for v in ('software7', 'software8')
    for n in ('actual.cpp', 'build.log', 'run.log')]
RECIPE_FILES = ['README.txt', 'candidate_support.py', 'build-candidate.ps1',
    'build-and-record.py', 'verify-parent-scope.py', 'write-provenance.py',
    'package-candidate.py', 'software7-parent.json', 'scaffold-preparation.json']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def record(data):
    return {'bytes': len(data), 'sha256': sha(data), 'crc32': f'{zlib.crc32(data) & 0xffffffff:08x}'}

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf8')

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def put_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(json_bytes(value))
    os.replace(tmp, path)

def safe_name(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in name, name
    return name

def source_bytes():
    out = {}
    for p in sorted((ROOT / 'source').rglob('*')):
        if p.is_file() and '.git' not in p.relative_to(ROOT / 'source').parts:
            out[p.relative_to(ROOT / 'source').as_posix()] = p.read_bytes()
    return out

def authenticated_parent():
    data = (ROOT / 'software7-parent.json').read_bytes()
    assert sha(data) == PARENT_MANIFEST_SHA, 'Initial authenticated parent manifest changed'
    parent = json.loads(data)
    assert parent['archiveSha256'] == PARENT_SHA and parent['sourceFileCount'] == 757
    return parent

def source_scope():
    parent = authenticated_parent()
    current = source_bytes()
    assert len(current) == 757 and set(current) == set(parent['sourceFiles']), 'Source file set changed'
    changed = sorted(n for n, b in current.items() if sha(b) != parent['sourceFiles'][n])
    assert changed == ALLOWED, ('Unexpected source scope', changed)
    return parent, current, changed

def archive_source(path, expected_sha, prefix, expected_count):
    path = Path(path)
    assert sha(path.read_bytes()) == expected_sha, f'Wrong baseline archive: {path}'
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive members'
        assert z.testzip() is None, 'Bad archive CRC'
        out = {safe_name(n[len(prefix):]): z.read(n) for n in names
            if n.startswith(prefix) and not n.endswith('/')}
    assert len(out) == expected_count, (prefix, len(out))
    return out

def patch_bytes(before, after):
    changes = []
    output = []
    for name in sorted(set(before) | set(after)):
        a, b = before.get(name, b''), after.get(name, b'')
        if a == b:
            continue
        assert not a or a.endswith(b'\n'), f'Unterminated original file: {name}'
        assert not b or b.endswith(b'\n'), f'Unterminated new file: {name}'
        output.extend(difflib.unified_diff(a.decode('utf8').splitlines(keepends=True),
            b.decode('utf8').splitlines(keepends=True),
            fromfile='a/' + name if name in before else '/dev/null',
            tofile='b/' + name if name in after else '/dev/null', n=3))
        changes.append({'path': name, 'beforeSha256': sha(a), 'afterSha256': sha(b)})
    return ''.join(output).encode('utf8'), changes

def tool_paths():
    work = next(p for p in ROOT.parents if (p / 'toolchain').is_dir())
    sdk = work / 'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
    return {'node': sdk / 'node/24.19.0_64bit/bin/node.exe'
        if (sdk / 'node/24.19.0_64bit/bin/node.exe').exists()
        else sdk / 'node/24.19.0_64bit/node.exe'}

def checked(command, **kwargs):
    run = subprocess.run(list(map(str, command)), capture_output=True, text=True, **kwargs)
    assert run.returncode == 0, {'command': list(map(str, command)), 'exitCode': run.returncode,
        'stdout': run.stdout[-4000:], 'stderr': run.stderr[-4000:]}
    return run

def focused_aa(current):
    results = read_json(ROOT / 'aa-tests/results/results.json')
    verification = read_json(ROOT / 'aa-tests/verification.json')
    assert results['status'].startswith('PASS') and verification['status'].startswith('PASS')
    old, new = results['variants']['software7'], results['variants']['software8']
    assert (old['checks'], old['failures'], old['targetPixelDifferences'], old['exitCode']) == (10866, 1168, 888, 1)
    assert (new['checks'], new['failures'], new['targetPixelDifferences'], new['exitCode']) == (10866, 0, 0, 0)
    for name, expected in verification['inputsSha256'].items():
        assert sha((ROOT / name).read_bytes()) == expected, name
    G = 'src/SexyAppFramework/graphics/'
    for name, expected in new['sourceInputsSha256'].items():
        name = name.replace('\\', '/')
        assert sha(current[G + name]) == expected, name
    baseline = read_json(ROOT / 'aa-tests/baseline-manifest.json')
    assert baseline['archiveSha256'] == PARENT_SHA
    for name, expected in baseline['files'].items():
        assert sha((ROOT / 'aa-tests/software7-baseline' / name).read_bytes()) == expected
    for name, key in [('run-aa-tests.py', 'runnerSha256'), ('prefix.cpp', 'prefixSha256'),
                      ('fixtures.cpp', 'fixturesSha256'), ('baseline-manifest.json', 'baselineManifestSha256')]:
        assert sha((ROOT / 'aa-tests' / name).read_bytes()) == results[key], name
    for variant in ('software7', 'software8'):
        assert sha((ROOT / 'aa-tests/results' / variant / 'actual.cpp').read_bytes()) == results['variants'][variant]['generatedSha256']
    assert results['preservedOtherScreenBytes'] and results['unchangedMemoryAndAAInclude']
    return results, verification

def file_inputs(names):
    return {n: record((ROOT / n).read_bytes()) for n in sorted(names)}

def assert_immutable_generated(path, data):
    path = Path(path)
    if path.exists():
        assert path.read_bytes() == data, f'Refusing to overwrite different generated file: {path}'
    else:
        path.write_bytes(data)

def git_reconstruct(before, patch, after, fixture):
    fixture = Path(fixture)
    assert not fixture.exists(), f'Fixture exists; choose a new audit directory: {fixture}'
    fixture.mkdir(parents=True)
    for n, data in before.items():
        p = fixture / safe_name(n)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    checked(['git', 'init', '--quiet', str(fixture)])
    command = ['git', '-C', fixture, '-c', 'core.autocrlf=false', 'apply']
    checked(command + ['--check', str(Path(patch).resolve())])
    checked(command + [str(Path(patch).resolve())])
    actual = {p.relative_to(fixture).as_posix(): p.read_bytes() for p in fixture.rglob('*')
        if p.is_file() and '.git' not in p.relative_to(fixture).parts}
    assert actual == after, 'Real git apply failed to reconstruct every source byte'
    return {'gitApplyCheckExitCode': 0, 'gitApplyExitCode': 0, 'baseFiles': len(before),
        'reconstructedFiles': len(actual), 'everySourceByteMatchesCandidate': True}
