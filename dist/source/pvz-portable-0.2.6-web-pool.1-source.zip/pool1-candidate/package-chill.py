"""Stage the Pool Panic minigame binaries, source and provenance after tests.

Reads this candidate and the authenticated release baselines. Writes only one
fresh staging directory. No build, game, browser, audio or network is started.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tempfile
import zipfile
import zlib

ROOT = Path(__file__).resolve().parent
VERSION = "0.2.6-web-pool.1"
UPSTREAM_SHA = "40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556"
PARENT_SHA = "f1882ce4c5a412d539d15d4ccfcd5412cc96d6ffc7b8ae5b4b374bf04418dee0"
FLAGS = {"CMAKE_BUILD_TYPE": "Release", "DO_FIX_BUGS": "OFF",
         "PVZ_DEBUG": "OFF", "LOW_MEMORY": "OFF"}
SOURCE_NAME = f"pvz-portable-{VERSION}-source.zip"
FULL_PATCH = "web-pool.1.patch"
DELTA_PATCH = "cob1-to-pool1.patch"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return {"bytes": len(data), "sha256": digest(data),
            "crc32": f"{zlib.crc32(data) & 0xffffffff:08x}"}


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe_name(name):
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts
            and "\\" not in name and ":" not in name, "Unsafe source path: " + name)
    return name


def source_tree(folder):
    result = {}
    for path in sorted(folder.rglob("*")):
        require(not path.is_symlink(), "Source symlinks are not supported")
        if path.is_file():
            name = safe_name(path.relative_to(folder).as_posix())
            require(not any(p in {".git", "__pycache__", "node_modules"}
                            for p in PurePosixPath(name).parts), "Private source input: " + name)
            result[name] = path.read_bytes()
    return result


def archive_source(path, expected_sha, prefix, count):
    raw = path.read_bytes()
    require(digest(raw) == expected_sha, "Wrong baseline archive: " + path.name)
    with zipfile.ZipFile(path) as archive:
        require(len(archive.namelist()) == len(set(archive.namelist())), "Duplicate baseline member")
        require(archive.testzip() is None, "Invalid baseline archive CRC")
        files = {safe_name(name[len(prefix):]): archive.read(name)
                 for name in archive.namelist()
                 if name.startswith(prefix) and not name.endswith("/")}
    require(len(files) == count, "Unexpected source count: " + path.name)
    return files


def make_patch(before, after):
    changed = [{"path": name, "beforeSha256": digest(before.get(name, b"")),
                "afterSha256": digest(after.get(name, b""))}
               for name in sorted(set(before) | set(after))
               if before.get(name) != after.get(name)]
    # Generate an ordinary Git patch, including binary image sources and files
    # without a trailing newline. This isolated index preserves exact input bytes;
    # project/global attributes must not normalize line endings or invoke filters.
    with tempfile.TemporaryDirectory(prefix="mender-diff-", dir=ROOT) as temporary:
        folder = Path(temporary).resolve()
        require(folder.is_relative_to(ROOT) and folder != ROOT, "Unsafe temporary directory")
        tree = folder / "source"
        tree.mkdir()
        for name, data in before.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        checked(["git", "init", "--quiet", tree])
        (tree / ".git/info/attributes").write_text(
            "* -text -filter -ident -working-tree-encoding\n", encoding="utf-8", newline="\n")
        command = ["git", "-C", tree, "-c", "core.autocrlf=false", "-c", "core.filemode=false"]
        checked(command + ["add", "--force", "--all", "--", "."])
        original_tree = checked(command + ["write-tree"]).stdout.strip()
        for name in set(before) - set(after):
            (tree / safe_name(name)).unlink()
        for name, data in after.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        checked(command + ["add", "--force", "--all", "--", "."])
        patch = checked(command + ["diff", "--cached", "--binary", "--full-index",
                                   "--no-ext-diff", "--no-textconv", "--no-renames",
                                   "--src-prefix=a/", "--dst-prefix=b/", original_tree, "--"],
                        binary=True).stdout
    return patch, changed


def checked(command, cwd=None, *, binary=False):
    options = {} if binary else {"text": True, "encoding": "utf-8", "errors": "replace"}
    result = subprocess.run(list(map(str, command)), cwd=cwd, capture_output=True, **options)
    error = result.stderr.decode("utf-8", errors="replace") if binary else result.stderr
    require(result.returncode == 0,
            "Local check failed: " + str(command[0]) + "\n" + error[-3000:])
    return result


def reconstruct(before, patch, expected):
    # This is our newly created temporary directory only; old candidates stay untouched.
    with tempfile.TemporaryDirectory(prefix="qol-patch-", dir=ROOT) as temporary:
        folder = Path(temporary).resolve()
        require(folder.is_relative_to(ROOT) and folder != ROOT, "Unsafe temporary directory")
        tree = folder / "source"
        tree.mkdir()
        for name, data in before.items():
            destination = tree / safe_name(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        patch_path = folder / "change.patch"
        patch_path.write_bytes(patch)
        checked(["git", "init", "--quiet", tree])
        command = ["git", "-C", tree, "-c", "core.autocrlf=false", "apply"]
        checked(command + ["--check", patch_path])
        checked(command + [patch_path])
        actual = {p.relative_to(tree).as_posix(): p.read_bytes()
                  for p in tree.rglob("*") if p.is_file()
                  and ".git" not in p.relative_to(tree).parts}
        require(actual == expected, "Patch did not reconstruct all current source bytes")
    return {"gitApplyCheck": "PASS", "gitApply": "PASS",
            "everySourceByteMatches": True, "sourceFiles": len(expected)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-root", type=Path,
                        default=ROOT.parents[1] / "plants-vs-zombies-web-release")
    parser.add_argument("--build-result", type=Path, default=ROOT / "logs/build-result.json")
    parser.add_argument("--test-result", type=Path, default=ROOT / "tests/game-speed-results.json")
    parser.add_argument("--parent-manifest", type=Path, default=ROOT / "parent-engine-provenance.json",
                        help="Frozen Cob.1 engine manifest")
    parser.add_argument("--output", type=Path, default=ROOT / "staging")
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(ROOT) and output != ROOT and not output.exists(),
            "Output must be a NEW directory inside this candidate")
    release = args.release_root.resolve()
    build_result = args.build_result.resolve()
    test_result = args.test_result.resolve()
    require(build_result.is_relative_to(ROOT) and test_result.is_relative_to(ROOT / "tests"),
            "Build/test receipts must belong to this candidate")
    build = read_json(build_result)
    test_paths = [ROOT / 'tests' / (name + '-results.json') for name in
                  ['game-speed', 'qol-controls', 'decks-cooldowns', 'bonus-challenge', 'bonus-completion', 'night-shift', 'lantern-shroom', 'garden-shuffle', 'seed-swap', 'mender-bloom', 'intensive-care', 'native-layout', 'care-fatigue', 'care-full-run', 'chain-reaction', 'rally-zombie', 'rally-raid', 'lights-out', 'garlic-run', 'bungee-business', 'cob-cannon-command', 'pool-panic']]
    test_reports = [read_json(path) for path in test_paths]
    tests = {'status': 'PASS focused native production tests',
             'failures': sum(report['failures'] for report in test_reports),
             'checks': sum(report['checks'] for report in test_reports),
             'sourceSha256': {key: value for report in test_reports for key, value in report['sourceSha256'].items()},
             'scope': 'Extracted production tests plus complete linked-engine Care, Chain Reaction, Rally Point, Rally Raid, Lights Out, Garlic Run, Bungee Business, Cob Cannon Command and Pool Panic scenarios; original finite conveyor packets, six-row land/water placement and native single-use activations; actual native aiming, shell flight, explosions, full reload cycles and eight moving formations; actual native protection clearing, finite budgets, unique Bungee thefts, target-loss failure and native heist saves/replays; twenty actual five-board Garlic Run completions, four no-route losses and four isolated control cases; actual light-gated attacks, natural native fog edges at five lamp positions, glove tooltip hover/raster bounds, glove-over-fog composition, legal Plantern moves, active-combat save/Continue, native awards, failure/retry, slow-play balance, UI bounds and speed parity. Original regressions remain active. Audio output is disabled.'}
    require(all(str(report['status']).startswith('PASS') and report['failures'] == 0 and
                report['exitCode'] == 0 and report['checks'] > 0 for report in test_reports),
            'All twenty-two native suites must pass')
    reports_by_name = {path.name.removesuffix('-results.json'): report for path,report in zip(test_paths,test_reports)}
    raid = reports_by_name['rally-raid']
    scenarios = raid.get("scenarios", [])
    require(len(scenarios) == 32 and len(raid.get("speedParity", [])) == 16 and
            all(pair.get("sameNativeOutcome") is True for pair in raid["speedParity"]),
            "The full 32-scenario Raid matrix and 16 speed pairs must pass")
    require(sum(case.get("outcome") == "win" for case in scenarios) == 24 and
            sum(case.get("name") == "hud-controls" and case.get("syntheticUIControls") is True
                for case in scenarios) == 4 and
            sum(case.get("name") == "plant-animation-controls" and
                case.get("outcome") == "animation-pass" and
                case.get("syntheticAnimationControls") is True and
                case.get("animationOracle") == "native-iz-still-idle-live-attack-body"
                for case in scenarios) == 4,
            "Raid must distinguish 24 legal winning runs from both four-case control groups")
    lights = reports_by_name['lights-out']
    lights_cases = lights.get("scenarios", [])
    require(len(lights_cases) == 20 and len(lights.get("speedParity", [])) == 10 and
            all(pair.get("sameNativeOutcome") is True for pair in lights["speedParity"]),
            "The full Lights Out matrix and speed pairs must pass")
    lights_wins = [case for case in lights_cases if case.get("outcome") == "win"]
    lights_controls = [case for case in lights_cases if case.get("name") == "controls"]
    require(len(lights_controls) == 4 and all(
            all(case.get(field) is True for field in ("fogNaturalEdges", "nativeGloveTooltip", "gloveAboveFog")) and
            case.get("fogEdgeRows") == 5 and case.get("fogBranchCount") == 2 and case.get("croppedFogNegatives") == 10 and
            case.get("misplacedTooltipNegatives") == 1 and case.get("foggedGloveNegatives") == 1 and
            case.get("glovePixelSamples", 0) > 100 and case.get("gloveMismatchPixels") == 0
            for case in lights_controls), "Lights.2 must reject both reported fog/tooltip regressions using actual native pixels")
    require(lights.get("nativeArtInputs") == 14,
            "Both native fog styles must authenticate all fourteen original artwork inputs")
    require(len(lights_wins) == 12 and
            sum(case.get("outcome") == "loss" for case in lights_cases) == 4 and
            sum(case.get("outcome") == "controls-pass" for case in lights_cases) == 4 and
            all(case.get("minimumLampHealth", 0) > 0 and
                case.get("mowersRemaining", 0) > 0 and
                case.get("headroomFrozenAtAward") is True and
                case.get("nativeUnusedMowers") == case.get("mowersRemaining") and
                case.get("mowersRemaining", 0) + case.get("mowersTriggered", -1) == 5
                for case in lights_wins),
            "Lights Out wins must preserve the lamp and native unused-mower headroom before award cleanup")
    garlic = reports_by_name['garlic-run']
    garlic_cases = garlic.get('scenarios', [])
    require(garlic.get('optimization') == 'O2' and garlic.get('nativeArtInputs') == 51 and
            len(garlic_cases) == 24 and len(garlic.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in garlic['speedParity']),
            'Garlic Run requires the full O2 native 24-case/12-pair matrix')
    expected_totals = dict(primaryNativeWins=16, explicitReplayWins=4,
        nativeFiveBoardCompletions=20, nativeLossCases=4, isolatedControlCases=4)
    require(all(garlic.get(key) == value for key, value in expected_totals.items()),
            'Garlic Run must distinguish primary wins, full replays, losses and controls')
    wins = [case for case in garlic_cases if case.get('outcome') == 'win']
    require(len(wins) == 16 and sum(case.get('replayCompleted') is True for case in wins) == 4 and
            sum(case.get('outcome') == 'loss' for case in garlic_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in garlic_cases) == 4 and
            all(case.get('boardsSolved') == 5 and case.get('nativeZombies') == 17 and
                case.get('authoredEnemies') == 17 and case.get('mowerCount') == 0 and
                case.get('profileIndex') == 82 and case.get('profileCredits') == 1 and
                all(case.get(field) is True for field in ('awardCollected', 'bonusReturned',
                    'replayCardAvailable', 'planningHeld', 'garlicHealthUnmodified')) and
                all(case.get(field, 0) > 0 for field in ('legalMoves', 'nativeDiversions',
                    'nativeSpikeDamageEvents', 'nativeMineArmings', 'nativeMineExplosions'))
                for case in wins), 'Garlic Run earned clears must execute actual native routing and traps')
    bungee = reports_by_name['bungee-business']
    bungee_cases = bungee.get('scenarios', [])
    require(bungee.get('optimization') == 'O2' and bungee.get('nativeArtInputs') == 78 and
            len(bungee_cases) == 24 and len(bungee.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in bungee['speedParity']),
            'Bungee Business requires the full native O2 matrix and original artwork pins')
    require(sum(case.get('outcome') == 'win' for case in bungee_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in bungee_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in bungee_cases) == 4,
            'Bungee Business must distinguish actual wins, losses and isolated controls')
    cob = reports_by_name['cob-cannon-command']
    cob_cases = cob.get('scenarios', [])
    require(cob.get('optimization') == 'O2' and cob.get('nativeArtInputs') == 53 and
            len(cob_cases) == 24 and len(cob.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in cob['speedParity']),
            'Cob Cannon Command requires the full native O2 matrix and original art pins')
    require(sum(case.get('outcome') == 'win' for case in cob_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in cob_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in cob_cases) == 4,
            'Cob Cannon Command must distinguish earned wins, genuine losses and isolated controls')
    pool = reports_by_name['pool-panic']
    pool_cases = pool.get('scenarios', [])
    require(pool.get('optimization') == 'O2' and pool.get('productionObjectCount') == 132 and pool.get('nativeArtInputs') == 218 and
            len(pool_cases) == 24 and len(pool.get('speedParity', [])) == 12 and
            all(pair.get('sameNativeOutcome') is True for pair in pool['speedParity']),
            'Pool Panic requires the complete O2 native24-case/12-pair matrix')
    for field,count in dict(primaryNativeWins=16, explicitReplayWins=4,
            nativeBattleCompletions=20, nativeLossCases=4, isolatedControlCases=4).items():
        require(pool.get(field) == count, 'Pool Panic summary mismatch: '+field)
    require(sum(case.get('outcome') == 'win' for case in pool_cases) == 16 and
            sum(case.get('outcome') == 'loss' for case in pool_cases) == 4 and
            sum(case.get('outcome') == 'controls-pass' for case in pool_cases) == 4,
            'Pool Panic must separate earned battles, genuine no-action losses and isolated controls')
    import importlib.util
    spec = importlib.util.spec_from_file_location('pool_package_validation', ROOT/'tests/test-pool-panic.py')
    validator = importlib.util.module_from_spec(spec);spec.loader.exec_module(validator)
    require({(r['name'],r['speed'],r['seed']) for r in pool_cases} == set(validator.MATRIX),
            'Pool Panic native scenario matrix changed')
    for case in pool_cases:
        validator.validate_result(case,(case['name'],case['speed'],case['seed']))
        require(case['resourceCapacityWarnings'] == 0, 'Native particle capacity warning')
    require(build.get("exitCode") == 0 and build.get("sourceUnchangedDuringBuild") is True,
            "A passing full build receipt is required")
    require(str(tests.get("status", "")).startswith("PASS") and tests.get("failures") == 0,
            "Passing focused native test results are required")
    require(isinstance(tests.get("checks"), int) and tests["checks"] > 0
            and isinstance(tests.get("sourceSha256"), dict) and tests["sourceSha256"],
            "Focused tests need nonempty checks and source pins")
    current = source_tree(ROOT / "source")
    hashes = {name: digest(data) for name, data in current.items()}
    require(read_json(ROOT / "logs/source-before.json") == hashes
            and read_json(ROOT / "logs/source-after.json") == hashes,
            "Source changed since the recorded build")
    require(VERSION.encode() in current["CMake/ProjectVersion.cmake"], "Wrong candidate version")
    cache = {}
    for line in (ROOT / "build/CMakeCache.txt").read_text(encoding="utf-8").splitlines():
        if not line.startswith(("#", "//")) and "=" in line and ":" in line.split("=", 1)[0]:
            key, value = line.split("=", 1)
            cache[key.split(":", 1)[0]] = value
    require(all(cache.get(key) == value for key, value in FLAGS.items()), "Unexpected build flags")
    require(Path(cache["CMAKE_HOME_DIRECTORY"]).resolve() == (ROOT / "source").resolve(),
            "Build used a different source directory")
    header = (ROOT / "build/ProjectVersion.h").read_bytes()
    require(VERSION.encode() in header, "Compiled version header mismatch")
    artifacts = {}
    for name in ["pvz-portable.js", "pvz-portable.wasm", "ProjectVersion.h"]:
        data = (ROOT / "build" / name).read_bytes()
        pin = record(data)
        expected = build["outputs"]["build/" + name]
        require(pin["bytes"] == expected["bytes"] and pin["sha256"] == expected["sha256"],
                "Build artifact changed: " + name)
        artifacts[name] = pin
    test_sources = [path for path in sorted((ROOT / 'tests').glob('*'))
                    if path.is_file() and (path.suffix in {'.py', '.cpp', '.h', '.json'} or path.name in {'care-full-run-engine.js', 'care-full-run-engine.wasm', 'chain-reaction-engine.js', 'chain-reaction-engine.wasm', 'rally-zombie-engine.js', 'rally-zombie-engine.wasm', 'rally-raid-engine.js', 'rally-raid-engine.wasm', 'lights-out-engine.js', 'lights-out-engine.wasm', 'garlic-run-engine.js', 'garlic-run-engine.wasm', 'bungee-business-engine.js', 'bungee-business-engine.wasm', 'cob-cannon-command-engine.js', 'cob-cannon-command-engine.wasm', 'pool-panic-engine.js', 'pool-panic-engine.wasm'})]
    require(all(path in test_sources for path in test_paths), 'All native reports must be included')
    backend_artifacts = [ROOT / "tests" / (name + suffix)
                         for name in ["care-full-run-engine", "chain-reaction-engine",
                                      "rally-zombie-engine", "rally-raid-engine", "lights-out-engine", "garlic-run-engine", "bungee-business-engine", "cob-cannon-command-engine", "pool-panic-engine"]
                         for suffix in [".js", ".wasm"]]
    require(len(backend_artifacts) == 18 and all(path.is_file() and path in test_sources
            for path in backend_artifacts), "All eighteen native backend artifacts must be included")
    require(all(path.is_file() for path in test_sources), "Focused test text/runner/result missing")
    recipes = [ROOT / name for name in ["build-candidate.ps1", "build-chill.py", "package-chill.py", "README-chill-build.md", "parent-engine-provenance.json", "parent-source-pin.json"]]
    require(all(path.is_file() for path in recipes), "Build/package recipe missing")
    recipe_inputs = {path: path.read_bytes() for path in recipes}
    for name, expected in tests.get("sourceSha256", {}).items():
        key = name.removeprefix("source/")
        require(key in hashes and hashes[key] == expected, "Focused test source changed: " + name)
    for test_path, report in zip(test_paths, test_reports):
        for name, expected in report['sourceSha256'].items():
            key = name.removeprefix('source/')
            require(hashes.get(key) == expected, 'Stale focused report: ' + str(test_path))
        if report.get("execution") == "complete-production-engine":
            require(report["productionBuildReceiptSha256"] == digest(build_result.read_bytes()),
                    "Engine tests used a different production build")
            require(report["sourceSha256"] == {"source/" + key: pin for key, pin in hashes.items()},
                    "Engine test source graph differs from the normal Release")
            stem_name = test_path.name.removesuffix("-results.json")
            for recipe_key, filename in [("builderSha256", "build-" + stem_name + ".py"),
                                         ("runnerSha256", "test-" + stem_name + ".py")]:
                require(digest((ROOT / "tests" / filename).read_bytes()) == report[recipe_key],
                        "Stale native backend recipe: " + filename)
            for filename, pin in report["testArtifactSha256"].items():
                require(digest((ROOT / "tests" / filename).read_bytes()) == pin,
                        "Stale native backend artifact: " + filename)
        for filename, pin in report.get("fixturesSha256", {}).items():
            fixture = ROOT / "tests" / safe_name(filename)
            require(fixture in test_sources and digest(fixture.read_bytes()) == pin,
                    "Stale or omitted inherited fixture: " + filename)
        stem = test_path.name.removesuffix('-results.json')
        require(digest((ROOT / 'tests' / (stem + '-harness.cpp')).read_bytes()) ==
                report['generatedHarnessSha256'], 'Stale generated test harness: ' + stem)
    baseline_folder = release / "dist/source"
    upstream = archive_source(baseline_folder / "pvz-portable-0.2.6-source.zip", UPSTREAM_SHA,
                              "PvZ-Portable-0.2.6/", 753)
    parent = archive_source(baseline_folder / "pvz-portable-0.2.6-web-cob.1-source.zip", PARENT_SHA,
                            "cob1-candidate/source/", 844)
    parent_archive = baseline_folder / "pvz-portable-0.2.6-web-cob.1-source.zip"
    require(parent_archive.stat().st_size == 34458383, "Unexpected Cob.1 archive size")
    with zipfile.ZipFile(parent_archive) as parent_zip:
        require(len(parent_zip.infolist()) == 977, "Unexpected Cob.1 archive entries")
    added = {"src/Lawn/System/PoolPanic.h", "src/Lawn/System/PoolPanic.cpp",
             "src/Lawn/System/PoolPanicPresentation.h", "src/Lawn/System/PoolPanicPresentation.cpp"}
    require(len(current) == 848 and set(current) == set(parent) | added,
            "Pool Panic adds exactly its four implementation/presentation files")
    parent_manifest_path = (args.parent_manifest or release / "dist/game/engine-provenance.json").resolve()
    parent_manifest_raw = parent_manifest_path.read_bytes()
    parent_manifest = json.loads(parent_manifest_raw)
    require(parent_manifest["id"] == "0.2.6-web-cob.1", "Release parent is not Cob.1")
    require(parent_manifest["artifacts"]["sourceSha256"] == PARENT_SHA, "Parent source identity mismatch")
    full_patch, full_changes = make_patch(upstream, current)
    delta_patch, delta_changes = make_patch(parent, current)
    expected_delta = ["CMake/ProjectVersion.cmake", "src/ConstEnums.h",
        "src/Lawn/Board.cpp", "src/Lawn/Challenge.cpp", "src/Lawn/System/BonusChallenge.h",
        "src/Lawn/System/PoolPanic.cpp", "src/Lawn/System/PoolPanic.h",
        "src/Lawn/System/PoolPanicPresentation.cpp", "src/Lawn/System/PoolPanicPresentation.h",
        "src/Lawn/Widget/ChallengeScreen.cpp", "src/Lawn/Zombie.cpp", "src/LawnApp.cpp"]
    require([change["path"] for change in delta_changes] == sorted(expected_delta),
            "Production changes must match the reviewed Pool Panic additions and exact mode integration")
    patch_checks = {"upstream": reconstruct(upstream, full_patch, current),
                    "cob1": reconstruct(parent, delta_patch, current)}
    source_manifest = {"version": VERSION, "files": {name: record(data) for name, data in current.items()}}
    # All validation above completes before the exclusive final staging directory exists.
    output.mkdir()
    (output / "game").mkdir()
    (output / "source").mkdir()
    for name in ["pvz-portable.js", "pvz-portable.wasm"]:
        shutil.copyfile(ROOT / "build" / name, output / "game" / name)
    (output / "source" / FULL_PATCH).write_bytes(full_patch)
    (output / "source" / DELTA_PATCH).write_bytes(delta_patch)
    prefix = "pool1-candidate/"
    members = {prefix + "source/" + name: data for name, data in current.items()}
    for path, data in recipe_inputs.items():
        members[prefix + path.name] = data
    for path in test_sources:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    for path in [build_result, ROOT / "logs/source-before.json", ROOT / "logs/source-after.json",
                 ROOT / "build/ProjectVersion.h"]:
        members[prefix + path.relative_to(ROOT).as_posix()] = path.read_bytes()
    members[prefix + "source-manifest.json"] = json_bytes(source_manifest)
    # Full source already contains every modified byte. Publish authenticated
    # patches beside the archive without embedding duplicate sprite data twice.
    archive_path = output / "source" / SOURCE_NAME
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(members.items()):
            safe_name(name)
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(archive_path) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), "Source ZIP invalid")
        require(all(archive.read(name) == data for name, data in members.items()), "Source ZIP byte mismatch")
    source_record = {"path": SOURCE_NAME, **record(archive_path.read_bytes()), "entries": len(members),
                     "uncompressedBytes": sum(map(len, members.values()))}
    limits = ["Pool Panic adds one continuous day-pool conveyor battle with eight formations and48 original zombies, eight rear LilyPads, six native mowers and56 finite native Squash, TangleKelp, CherryBomb and Jalapeno packets. Native activation, placement, conveyor, save, Retry and award rules remain intact. Earlier minigames, accepted artwork, original mode IDs, unlock rules and serialized object layouts are preserved. Full original parity remains unverified.",
              "Focused production-method tests and build checks do not replace broad game or browser validation.",
              "Earlier results remain historical parent evidence only. No separately image-generated challenge illustrations are active."]
    provenance = {
        "id": VERSION, "upstream": parent_manifest["upstream"], "sourceArchive": source_record,
        "artifacts": [{"path": "build/" + name, **pin} for name, pin in artifacts.items()],
        "sourceFiles": len(current), "sourceBytes": sum(map(len, current.values())),
        "sourceDeltaVsCob1": delta_changes,
        "compiledVersionHeader": header.decode("utf-8"),
        "checks": {"fullRelease": {"exitCode": 0, "flags": FLAGS, "sourceUnchangedDuringBuild": True,
                    "receipt": {"path": build_result.relative_to(ROOT).as_posix(), **record(build_result.read_bytes())}},
                   "focusedNativeTests": {"status": tests["status"], "failures": 0,
                    "checks": tests["checks"], "scope": tests["scope"],
                    "reports": [{"path": path.relative_to(ROOT).as_posix(), **record(path.read_bytes()),
                        "checks": report["checks"]} for path, report in zip(test_paths, test_reports)]},
                   "patchReconstruction": patch_checks},
        "combinedPatch": {"path": FULL_PATCH, **record(full_patch), "sourcePaths": len(full_changes)},
        "incrementalPatch": {"path": DELTA_PATCH, **record(delta_patch), "sourcePaths": len(delta_changes)},
        "parent": {"id": parent_manifest["id"], "sourceArchiveSha256": PARENT_SHA,
                   "releaseManifestSha256": digest(parent_manifest_raw),
                   "scope": "Complete historical parent engine metadata is preserved in the parent property of engine-provenance.json."},
        "limits": limits}
    engine = {
        "id": VERSION, "upstream": parent_manifest["upstream"],
        "artifacts": {"jsSha256": artifacts["pvz-portable.js"]["sha256"],
                      "wasmSha256": artifacts["pvz-portable.wasm"]["sha256"],
                      "source": "../source/" + SOURCE_NAME, "sourceSha256": source_record["sha256"],
                      "patch": "../source/" + FULL_PATCH, "patchSha256": digest(full_patch)},
        "buildRecord": "../source/build-provenance.json",
        "change": "Adds Pool Panic: a continuous pool conveyor minigame using original single-use Squash, Tangle Kelp, Cherry Bomb and Jalapeno against mixed land and water waves. Native effects, placement and conveyor controls remain intact, with saves, Retry and awards. Existing mode IDs, saved object layouts, previous minigames and accepted artwork are preserved.",
        "caption": "with Pool Panic.",
        "gameAssetsIncluded": parent_manifest["gameAssetsIncluded"],
        "assetManifest": parent_manifest["assetManifest"], "assetBundleId": parent_manifest["assetBundleId"],
        "parent": parent_manifest, "parentScope": "Historical Cob.1 release metadata only; current native and browser results are recorded separately.",
        "limits": limits}
    (output / "source/build-provenance.json").write_bytes(json_bytes(provenance))
    (output / "game/engine-provenance.json").write_bytes(json_bytes(engine))
    require(source_tree(ROOT / "source") == current, "Source changed during packaging")
    require(all(path.read_bytes() == data for path, data in recipe_inputs.items()),
            "Build/package recipe changed during packaging")
    print(json.dumps({"status": "PASS staged Pool Panic artifacts/source/provenance",
                      "staging": str(output), "sourceArchive": source_record,
                      "sourceFiles": len(current), "changedSourcePaths": [x["path"] for x in delta_changes],
                      "patchChecks": patch_checks, "engine": engine["artifacts"]}, indent=2))


if __name__ == "__main__":
    main()
