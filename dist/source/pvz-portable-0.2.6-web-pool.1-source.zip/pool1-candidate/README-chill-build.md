# Pool Panic: source and native tests

Published Cob.1 parent source SHA-256:
f1882ce4c5a412d539d15d4ccfcd5412cc96d6ffc7b8ae5b4b374bf04418dee0.
Parent: 34,458,383 bytes / 977 entries / 844 production files under
cob1-candidate/source/. Current prefix: pool1-candidate/; production: 848 files.

Pool Panic appends mode86, profile record85 and the fourteenth Bonus card.
One continuous native day-pool battle combines eight formations, 48 original
zombies (28 land and20 water), six native mowers and eight rear Lily Pads.
A finite native conveyor supplies Squash, Tangle Kelp, Cherry Bomb and Jalapeno.
All four plants retain their original placement, activation, damage, animation
and removal rules. No permanent attacking plant or added HUD is introduced.
Native conveyor slots, Menu, speed, pause, progress meter and footer provide
the interface. Delivery pauses at capacity without spending a packet.
Existing saved counters and the native bank retain battle/delivery progress;
serialized object layouts and prior content stay unchanged.

Build normal Release with build-chill.py. All22 native suites are release
gates. Nine silent complete-engine drivers link the exact132 production
objects except main. The24-case/12-pair Pool matrix uses real packet and tile
inputs at1x/2x across two seeds, including a slower action policy, active-effect
and moving-packet checkpoints, native Retry, genuine no-action defeats and
independent full replays. Controls remain separate from earned victories.
Native award-time mower headroom is compared with actual LastLevelStats.

All218 original artwork inputs are authenticated. Native offscreen MemoryImage
visual fixtures do not establish browser/GPU parity or earned battle results;
muted actual-browser inspection is separate. Normal game audio remains usable.
package-chill.py binds the exact production build, source, native reports,
driver artifacts and packaging recipes. web-pool.1.patch and cob1-to-pool1.patch
reconstruct all848 production files byte-for-byte. Every retained regression,
thirteen previous card records and accepted bitmap remains a release gate.
