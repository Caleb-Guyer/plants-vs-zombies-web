Plants vs. Zombies Portable 0.2.6-web-software.10 corresponding source

This private candidate has a successful complete Release compilation/link
and focused paired actual-code additive tests. Browser/runtime testing and
ordinary-scene relevance of the two new additive routes remain pending.
This is not a claim of original framebuffer, gameplay or complete1:1 parity.

Engine delta from authenticated Software.9 is exactly three paths:
  CMake/ProjectVersion.cmake: version .10.
  src/PvzpLib/PvzpDrawTriangle.inc: admit only the two scoped nearest/additive
    global-color RGB888 families and guard their original inputs.
  src/PvzpLib/PvzpNativeScreenPixel888.inc: ignore stored alpha only for the
    newly admitted opaque/global-only nearest/additive family.
TA1/MOD1/GLOB1 requires equal original vertex a/r/g/b inputs in0..0xFF0000,
retains the authentic global/256 vertex prepass and the second per-pixel
global multiplication. TA0/MOD0/GLOB1 uses alpha255 before global modulation.
Both use the addressed saturating additive equation. The existing exact
screen-buffer/pitch, complete dimension, global and per-pixel bounds remain.
Normal dispatchers and90 expanded callback bodies are byte-exact Software.9;
gradient, invalid and offscreen fallbacks are preserved in the paired cases.
Source geometry/scan/cache, modes, game rules and audio do not change here.

Contents
  source/: all757 corresponding engine files, including LICENSE/COPYING and
    upstream third-party notices. The upstream base archive has753 files.
  software9-parent.json: authenticated757-file parent map and archive pin.
  source-manifest.json: bytes/SHA256/CRC32 of every current source file.
  web-software.10.patch: complete raw upstream0.2.6 to this source.
  software9-to-software10.patch: exact three-path parent incremental patch.
  patch-check.json: actual git apply --check/apply reconstructions, all757
    source bytes compared with this candidate for both complete baselines.
  verification.json, logs/: actual full Release result/stdout, source maps
    captured before/after the build, generated-version and artifact pins.
  additive-tests/: only the new self-contained29-file paired code/text suite;
    old suites, test binaries and private native evidence are not included.

The original executable, game assets/disassembly, real/private saves/settings,
account state and compiled engine/test binaries are excluded from this code
archive. Previously approved game assets belong to the website's separate
asset distribution; this source ZIP does not contain those assets. Source
licenses remain in source/LICENSE, source/COPYING and upstream subdirectories.

Reproduction with the pinned local SDK
The recipe expects the existing work/toolchain layout: emsdk commit folder
emsdk-d7b4130688bfa348392b921ab04015aa15c4f154, bundled Python3.13.3,
Node24.19.0, CMake3.31.9 and Ninja1.13.2. Flags are Release, DO_FIX_BUGS=OFF,
PVZ_DEBUG=OFF and LOW_MEMORY=OFF. build-candidate.ps1 records the exact setup.
No dependency download, browser, game/original runtime or audio starts in the
build/provenance commands.

To rebuild while preserving the bundled historical build evidence, copy source/
and the recipes/scaffold/parent/additive-tests inputs into a fresh folder under
work/portable-build (exclude the bundled logs/ and build/ directories), then:
  python verify-source-inputs.py
  python build-and-record.py
The recorder requires fresh logs/build directories and captures the complete
source map before and after compilation. On an already built candidate:
  python write-provenance.py --preflight
  python write-provenance.py --parent-archive PATH/9-source.zip --upstream-archive PATH/upstream-source.zip
  python package-candidate.py --parent-archive PATH/9-source.zip --upstream-archive PATH/upstream-source.zip --audit-dir FRESH/AUDIT/DIRECTORY
The final two commands require the exact pinned baseline archives. They do not
build or run the engine. An existing differing generated receipt or any source
archive is never overwritten. Actual git patch reconstruction uses a fresh
audit directory without whitespace-ignore/fix or byte normalization.

Run the focused tests separately with a fresh output directory:
  python additive-tests/run-paired-tests.py --candidate-source source --output FRESH/TEST/OUTPUT
They compile authored test C++ to Node, test actual callback/screen methods
with flat-triangle/image/app doubles, require parent negative controls and
candidate positive controls, and audit all92 expanded callback bodies.

Limits: no original runtime or frame comparison, native scan/interpolation,
gradient equivalence, texture-cache reconstruction or dense performance proof
follows from compilation/conditional arithmetic tests. No ordinary scene using
either newly admitted additive route has been established. Earlier Software.9
runtime evidence remains historical; it is not relabeled Software.10 testing.
