"""Build the isolated candidate once and preserve source/artifact provenance."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / 'logs'
assert not LOGS.exists(), 'Preserve existing build receipts; use a fresh candidate for another build.'
assert not (ROOT / 'build').exists(), 'This recorder requires a fresh build directory.'
LOGS.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()

def inventory():
    return {p.relative_to(ROOT / 'source').as_posix(): sha(p.read_bytes())
            for p in sorted((ROOT / 'source').rglob('*')) if p.is_file()}

before = inventory()
assert len(before) == 757
preparation = json.loads((ROOT / 'scaffold-preparation.json').read_text(encoding='utf-8'))
for path, pin in preparation['sourcePins'].items():
    assert before[path] == pin, path
(LOGS / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
command = ['powershell', '-NoProfile', '-ExecutionPolicy', 'Bypass',
           '-File', str(ROOT / 'build-candidate.ps1')]
start = time.time()
print('Starting private Software.10 Release build; preserving logs/build.log', flush=True)
with (LOGS / 'build.log').open('wb') as log:
    run = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
after = inventory()
(LOGS / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n', encoding='utf-8')
outputs = {}
for name in ['ProjectVersion.h', 'pvz-portable.js', 'pvz-portable.wasm', 'pvz-portable.html', 'CMakeCache.txt']:
    p = ROOT / 'build' / name
    if p.is_file():
        data = p.read_bytes()
        outputs[name] = {'bytes': len(data), 'sha256': sha(data)}
version_path = ROOT / 'build' / 'ProjectVersion.h'
version = version_path.read_text(encoding='utf-8') if version_path.is_file() else ''
passed = (run.returncode == 0 and before == after and
          all(n in outputs for n in ['pvz-portable.js', 'pvz-portable.wasm', 'ProjectVersion.h']) and
          '0.2.6-web-software.10' in version)
receipt = {
    'status': 'PASS complete private Release build' if passed else 'FAIL or incomplete build; inspect log',
    'command': command, 'exitCode': run.returncode, 'elapsedSeconds': round(time.time()-start, 3),
    'sourceFiles': len(before), 'sourceUnchangedDuringBuild': before == after,
    'sourceBeforeManifestSha256': sha((LOGS / 'source-before.json').read_bytes()),
    'sourceAfterManifestSha256': sha((LOGS / 'source-after.json').read_bytes()),
    'buildRecipeSha256': sha((ROOT / 'build-candidate.ps1').read_bytes()),
    'recorderSha256': sha(Path(__file__).read_bytes()),
    'buildLogSha256': sha((LOGS / 'build.log').read_bytes()),
    'flags': {'CMAKE_BUILD_TYPE': 'Release', 'DO_FIX_BUGS': 'OFF', 'PVZ_DEBUG': 'OFF', 'LOW_MEMORY': 'OFF'},
    'outputs': outputs, 'generatedVersionHeader': version,
    'scope': 'Compilation/link only with pinned existing SDK and flags. No browser/game/original/audio execution, scene or full parity claim.'
}
(LOGS / 'build-result.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(0 if passed else (run.returncode or 1))
