"""Package immutable current corresponding source/recipes/focused test text only."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path,PurePosixPath
import argparse,json,uuid,zipfile,zlib
import candidate_support as c
p=argparse.ArgumentParser();p.add_argument('--candidate-root',type=Path);p.add_argument('--parent-archive',type=Path);p.add_argument('--upstream-archive',type=Path);p.add_argument('--audit-dir',type=Path);a=p.parse_args()
if a.candidate_root:c.ROOT=a.candidate_root.resolve()
root=c.ROOT;parent,current,changed=c.source_scope();tests=c.focused_additive(current)
verification=c.read_json(root/'verification.json');assert verification['candidate']==c.VERSION
build,artifacts,header=c.verify_build(current,validate_artifacts=False)
assert artifacts==verification['artifacts'] and verification['checks']['fullRelease']==build
manifest=c.read_json(root/'source-manifest.json');assert manifest['files']=={n:c.record(b) for n,b in sorted(current.items())}
assert c.sha((root/'source-manifest.json').read_bytes())==verification['sourceManifestSha256']
assert c.final_inputs()==verification['producerInputRecords'],'Frozen provenance input changed'
for n,pin in verification['producerInputRecords'].items():assert c.record((root/n).read_bytes())==pin,n
work=next(q for q in root.parents if (q/'toolchain').is_dir())
parent_archive=a.parent_archive or root.parent/'software9-candidate/pvz-portable-0.2.6-web-software.9-source.zip'
upstream_archive=a.upstream_archive or work/'lawn-defense/dist/source/pvz-portable-0.2.6-source.zip'
old=c.archive_source(parent_archive,c.PARENT_SHA,'software9-candidate/source/',757)
up=c.archive_source(upstream_archive,c.UPSTREAM_SHA,'PvZ-Portable-0.2.6/',753)
delta,dc=c.patch_bytes(old,current);full,fc=c.patch_bytes(up,current)
assert [n['path'] for n in dc]==c.ALLOWED
assert delta==(root/'software9-to-software10.patch').read_bytes() and full==(root/'web-software.10.patch').read_bytes()
assert c.sha(full)==verification['sourcePatchSha256']
archive=root/('pvz-portable-'+c.VERSION+'-source.zip')
assert not archive.exists(),'Source archive already exists; preserve it'
audit=a.audit_dir.resolve() if a.audit_dir else root.parent/('software10-patch-audit-'+uuid.uuid4().hex)
assert not audit.exists() and audit!=root and root not in audit.parents,'Fresh audit folder must be outside candidate'
audit.mkdir(parents=True)
apply={'upstream':c.git_reconstruct(up,root/'web-software.10.patch',current,audit/'upstream'),
       'software9':c.git_reconstruct(old,root/'software9-to-software10.patch',current,audit/'software9'),
       'scope':'Actual git apply --check/apply on authenticated complete baselines; all757 source bytes compared without whitespace-ignore/fix or normalization.'}
c.put_json(root/'patch-check.json',apply)
extra=c.RECIPE_FILES+['source-manifest.json','software10-change-record.json','verification.json','web-software.10.patch','software9-to-software10.patch','patch-check.json']+c.BUILD_INPUTS+['build/ProjectVersion.h']+['additive-tests/'+n for n in c.TEST_FILES]
assert len(extra)==len(set(extra))
prefix='software10-candidate/'
members={prefix+'source/'+n:b for n,b in current.items()}
members.update({prefix+n:(root/n).read_bytes() for n in extra})
assert len(members)==757+len(extra)
for n in members:
 c.safe_name(n)
 assert not any(x in PurePosixPath(n).parts for x in ['.git','__pycache__','tmp','temp']),n
 if not n.startswith(prefix+'source/'):
  assert not n.endswith(('.wasm','.js','.o','.exe','.dll','.pak','.dat','.zip','.mp3','.png','.jpg')),n
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):
  info=zipfile.ZipInfo(n,date_time=(2026,10,29,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  info.create_system=3;info.external_attr=0o100644<<16
  z.writestr(info,b,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 assert set(z.namelist())==set(members)
 for n,b in members.items():assert z.read(n)==b and z.getinfo(n).CRC==(zlib.crc32(b)&0xffffffff),n
 uncompressed=sum(i.file_size for i in z.infolist())
package={'candidate':c.VERSION,'scope':'Full Release engine corresponding source plus focused paired additive code/text tests; own10 browser/runtime and ordinary-scene relevance pending',
 'sourceArchive':{'path':archive.name,**c.record(archive.read_bytes()),'entries':len(members),'uncompressedBytes':uncompressed},
 'sourceFiles':757,'sourceBytes':sum(map(len,current.values())),
 'sourceDeltaVsSoftware9':c.read_json(root/'software10-change-record.json')['changedPaths'],
 'combinedUpstreamPatch':{'path':'web-software.10.patch',**c.record(full),'changedPaths':len(fc),'applyCheck':apply['upstream']},
 'software9IncrementalPatch':{'path':'software9-to-software10.patch',**c.record(delta),'changedPaths':3,'applyCheck':apply['software9']},
 'engineArtifacts':artifacts,'verification':c.record((root/'verification.json').read_bytes()),
 'sourceArchiveAllowlist':sorted(members),'allEntriesCrcAndByteCompared':True,
 'onlyNewFocusedAdditiveSuiteIncluded':True,'historicalParentEvidenceOnly':True,
 'codeArchiveExclusions':['Git metadata','compiled engine/test binaries/objects','historical old test/report trees','original EXE/PAK/game assets/disassembly/native audit bytes','real/private/native/QA saves/settings/account state'],
 'engineInitialized':False,'browserLaunched':False,'audioDeviceOpened':False,'publicOrStable9Modified':False,'limits':verification['limits']}
c.put_json(root/'package.json',package)
assert c.source_bytes()==current
print(json.dumps({'status':'PASS source archive/CRC/actual patch reconstructions','sourceArchive':package['sourceArchive'],'sourceFiles':757,'sourceBytes':package['sourceBytes'],'package':c.record((root/'package.json').read_bytes())},indent=2))
