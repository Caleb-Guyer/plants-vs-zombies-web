"""Lean Software.10 corresponding-source helpers; import never builds/runs a game."""
from pathlib import Path,PurePosixPath
import difflib,hashlib,json,os,subprocess,zipfile,zlib
ROOT=Path(__file__).resolve().parent
RECIPES=ROOT
VERSION='0.2.6-web-software.10'
PARENT_SHA='b4ca8b710fe2c61ead0ab5ee1f1a4dffbae92e7c9c705b8ac2e3c4e0f4f83fc4'
PARENT_MANIFEST_SHA='d7eddcc2a3657222a0918dd314f7b4088703eda0cc32f573db5ea489ff66bf9e'
UPSTREAM_SHA='40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
TEST_RESULT_SHA='5227f972f6f10c059776d9370790441503bb39aab4aafaeb94db60e466e6a14f'
ALLOWED=['CMake/ProjectVersion.cmake','src/PvzpLib/PvzpDrawTriangle.inc','src/PvzpLib/PvzpNativeScreenPixel888.inc']
SOURCE_PINS={ALLOWED[0]:'1aa6e327c0de35fde411958fa8bddfb3bc66f021a3357e9fd02e5b83ebc18758',ALLOWED[1]:'0e2b54f76ca23cabacbfb79dc7e3f3ed9e6b93cfc5f923bd999fc672ddbfdcdd',ALLOWED[2]:'a8f0592b0284f1cb381f75911d70e0a0f193c716d9cee6925d5ce8257d6d1553'}
FLAGS={'CMAKE_BUILD_TYPE':'Release','DO_FIX_BUGS':'OFF','PVZ_DEBUG':'OFF','LOW_MEMORY':'OFF'}
BASE_FILES=['src/PvzpLib/PvzpDrawTriangle.inc','src/PvzpLib/PvzpDrawTriangleInc.inc','src/PvzpLib/EffectSystem.h','src/PvzpLib/PvzpNativeScreenPixel888.inc','src/PvzpLib/PvzpNativeScreenTexel.inc','src/SexyAppFramework/graphics/SoftwareScreenImage.cpp','src/SexyAppFramework/graphics/SoftwareScreenImage.h','src/SexyAppFramework/graphics/SWTri.cpp','src/SexyAppFramework/graphics/SWTri/SWTri_Loop.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Pixel888.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Pixel8888.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Pixel565.inc','src/SexyAppFramework/graphics/SWTri/SWTri_Pixel555.inc','src/SexyAppFramework/graphics/SWTri/SWTri_GetTexel.inc','src/SexyAppFramework/graphics/SWTri/SWTri_TexelARGB.inc']
TEST_FILES=['README.txt','fixtures.cpp','run-paired-tests.py','native-reference.h','baseline-manifest.json','results/results.json']
TEST_FILES+=['software9-baseline/'+n for n in BASE_FILES]
TEST_FILES+=['results/'+v+'/'+n for v in ['software9','candidate'] for n in ['actual.cpp','expanded.cpp','build.log','run.log']]
RECIPE_FILES=['README.txt','candidate_support.py','build-candidate.ps1','build-and-record.py','prepare-from-software9.py','verify-source-inputs.py','write-provenance.py','package-candidate.py','software9-parent.json','scaffold-preparation.json']
BUILD_INPUTS=['logs/build-result.json','logs/build.log','logs/source-before.json','logs/source-after.json']

def sha(b):return hashlib.sha256(b).hexdigest()
def record(b):return {'bytes':len(b),'sha256':sha(b),'crc32':f'{zlib.crc32(b)&0xffffffff:08x}'}
def read_json(path):return json.loads(Path(path).read_text(encoding='utf8'))
def json_bytes(v):return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode('utf8')
def put_immutable(path,data):
 path=Path(path)
 if path.exists():assert path.read_bytes()==data,f'Refusing overwrite: {path}'
 else:path.write_bytes(data)
def put_json(path,value):put_immutable(path,json_bytes(value))
def safe_name(n):
 p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts and '\\' not in n,n
 return n
def source_bytes():
 out={}
 for p in sorted((ROOT/'source').rglob('*')):
  if p.is_file():
   n=p.relative_to(ROOT/'source').as_posix();assert '.git' not in PurePosixPath(n).parts,n
   out[safe_name(n)]=p.read_bytes()
 return out
def source_scope():
 raw=(ROOT/'software9-parent.json').read_bytes();assert sha(raw)==PARENT_MANIFEST_SHA
 parent=json.loads(raw);assert parent['archiveSha256']==PARENT_SHA and len(parent['sourceFiles'])==757
 current=source_bytes();assert len(current)==757 and set(current)==set(parent['sourceFiles'])
 changed=sorted(n for n,b in current.items() if sha(b)!=parent['sourceFiles'][n]);assert changed==ALLOWED,changed
 for n,h in SOURCE_PINS.items():assert sha(current[n])==h,n
 assert b'0.2.6-web-software.10' in current[ALLOWED[0]]
 for n in ['LICENSE','COPYING']:assert n in current and len(current[n])>100
 return parent,current,changed
def archive_source(path,pin,prefix,count):
 path=Path(path);assert sha(path.read_bytes())==pin,f'Wrong baseline ZIP: {path}'
 with zipfile.ZipFile(path) as z:
  assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
  out={safe_name(n[len(prefix):]):z.read(n) for n in z.namelist() if n.startswith(prefix) and not n.endswith('/')}
 assert len(out)==count,(prefix,len(out));return out
def patch_bytes(before,after):
 out=[];changes=[]
 for n in sorted(set(before)|set(after)):
  a,b=before.get(n,b''),after.get(n,b'')
  if a==b:continue
  assert not a or a.endswith(b'\n'),n
  assert not b or b.endswith(b'\n'),n
  out.extend(difflib.unified_diff(a.decode('utf8').splitlines(keepends=True),b.decode('utf8').splitlines(keepends=True),fromfile='a/'+n if n in before else '/dev/null',tofile='b/'+n if n in after else '/dev/null',n=3))
  changes.append({'path':n,'beforeSha256':sha(a),'afterSha256':sha(b)})
 return ''.join(out).encode('utf8'),changes
def checked(cmd,**kwargs):
 run=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,**kwargs)
 assert run.returncode==0,{'command':list(map(str,cmd)),'exitCode':run.returncode,'stdout':run.stdout[-3000:],'stderr':run.stderr[-3000:]}
 return run
def git_reconstruct(before,patch,after,folder):
 folder=Path(folder);assert not folder.exists();folder.mkdir(parents=True)
 for n,b in before.items():
  p=folder/safe_name(n);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 checked(['git','init','--quiet',folder])
 cmd=['git','-C',folder,'-c','core.autocrlf=false','apply']
 checked(cmd+['--check',Path(patch).resolve()]);checked(cmd+[Path(patch).resolve()])
 actual={p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file() and '.git' not in p.relative_to(folder).parts}
 assert actual==after,'Actual git apply did not reconstruct all757 source bytes'
 return {'gitApplyCheckExitCode':0,'gitApplyExitCode':0,'baseFiles':len(before),'reconstructedFiles':len(actual),'everySourceByteMatchesCandidate':True}
def focused_additive(current):
 folder=ROOT/'additive-tests'
 actual={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
 assert actual==set(TEST_FILES),sorted(actual^set(TEST_FILES))
 raw=(folder/'results/results.json').read_bytes();assert sha(raw)==TEST_RESULT_SHA
 result=json.loads(raw);assert result['status'].startswith('PASS paired')
 assert result['changedSourcePaths']==ALLOWED and result['unchangedSourceFiles']==754
 assert len(result['unchangedExpandedBodiesSha256'])==90 and result['expandedCallbackCount']==92
 assert result['fallbackFullRecordsBitExact'] is True
 expected=['PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0_ADDITIVE','PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0_ADDITIVE']
 assert result['changedExpandedCallbacks']==expected
 for name,key in [('fixtures.cpp','fixtureSha256'),('run-paired-tests.py','runnerSha256'),('native-reference.h','referenceSha256'),('baseline-manifest.json','baselineManifestSha256')]:assert sha((folder/name).read_bytes())==result[key],name
 baseline=read_json(folder/'baseline-manifest.json');parent=read_json(ROOT/'software9-parent.json')
 assert baseline['archiveSha256']==PARENT_SHA and baseline['sourceFiles']==parent['sourceFiles'] and len(baseline['files'])==15
 assert set(baseline['files'])==set(BASE_FILES)
 for n,h in baseline['files'].items():assert sha((folder/'software9-baseline'/n).read_bytes())==h==parent['sourceFiles'][n],n
 for tag in ['software9','candidate']:
  row=result['variants'][tag]
  assert row['normalFailures']==[0,0] and row['stateFailures']==0 and row['stateAssertions']==628406
  assert row['normalAssertions']==[458240,413568] and row['additiveAssertions']==[458368,413696]
  assert row['degenerateCalls']==8 and len(row['fallbackRecords'])==74 and row['calls']==27322
  assert row['additiveFailures']==([47270,50870] if tag=='software9' else [0,0])
  assert row['exitCode']==(1 if tag=='software9' else 0)
  for name,key in [('actual.cpp','actualCppSha256'),('expanded.cpp','expandedCppSha256')]:assert sha((folder/'results'/tag/name).read_bytes())==row[key]
 assert result['variants']['software9']['fallbackRecords']==result['variants']['candidate']['fallbackRecords']
 for n,h in result['variants']['candidate']['sourceInputsSha256'].items():assert sha(current[n])==h,n
 return result
def verify_build(current,validate_artifacts=False):
 build=read_json(ROOT/'logs/build-result.json');assert build['status'].startswith('PASS') and build['exitCode']==0 and build['flags']==FLAGS
 assert build['sourceFiles']==757 and build['sourceUnchangedDuringBuild'] is True
 pins={n:sha(b) for n,b in current.items()}
 for tag,key in [('before','sourceBeforeManifestSha256'),('after','sourceAfterManifestSha256')]:
  p=ROOT/f'logs/source-{tag}.json';assert sha(p.read_bytes())==build[key] and read_json(p)==pins
 assert sha((ROOT/'logs/build.log').read_bytes())==build['buildLogSha256']
 assert sha((ROOT/'build-candidate.ps1').read_bytes())==build['buildRecipeSha256']
 assert sha((ROOT/'build-and-record.py').read_bytes())==build['recorderSha256']
 assert Path(build['command'][-1]).resolve()==(ROOT/'build-candidate.ps1').resolve()
 cache={}
 for line in (ROOT/'build/CMakeCache.txt').read_text(encoding='utf8').splitlines():
  if not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
   k,v=line.split('=',1);cache[k.split(':',1)[0]]=v
 assert all(cache.get(k)==v for k,v in FLAGS.items()) and Path(cache['CMAKE_HOME_DIRECTORY']).resolve()==(ROOT/'source').resolve()
 header=(ROOT/'build/ProjectVersion.h').read_bytes();assert VERSION.encode() in header and (ROOT/'build/ProjectVersion.h').read_text(encoding='utf8')==build['generatedVersionHeader']
 for n,pin in build['outputs'].items():
  b=(ROOT/'build'/n).read_bytes();assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],n
 artifacts=[{'path':n,**record((ROOT/n).read_bytes())} for n in ['build/pvz-portable.html','build/pvz-portable.js','build/pvz-portable.wasm','build/ProjectVersion.h']]
 if validate_artifacts:
  work=next(p for p in ROOT.parents if (p/'toolchain').is_dir())
  node=work/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154/node/24.19.0_64bit/node.exe'
  checked([node,'--check',ROOT/'build/pvz-portable.js'])
  checked([node,'-e',"const fs=require('fs');if(!WebAssembly.validate(fs.readFileSync(process.argv[1])))process.exit(1);",ROOT/'build/pvz-portable.wasm'])
 return build,artifacts,header
def input_path(n):
 p=ROOT/n
 return p if p.exists() else RECIPES/n
def recipe_records():
 return {n:record(input_path(n).read_bytes()) for n in RECIPE_FILES}
def final_inputs():
 out=recipe_records()
 for n in BUILD_INPUTS+['additive-tests/'+n for n in TEST_FILES]:out[n]=record((ROOT/n).read_bytes())
 return out
