Focused Software.9 negative / Software.10 positive additive tests

Run from a candidate folder using the pinned SDK/toolchain described by its
README (a fresh output directory is required):
  python additive-tests/run-paired-tests.py --candidate-source source --output fresh-additive-results

This bundle contains exactly29 allowlisted text/code files: the runner,
fixtures, independent scalar references, the authenticated15-fragment frozen9
baseline and757-file parent hash manifest, and actual paired results/logs/
generated C++/expanded callback bodies. Test JS/WASM, the original executable,
original disassembly/PE data/assets, private QA reports and saves are omitted.
Rerunning the authored C++ tests regenerates their JS/WASM privately.

The two new screen families are RGB888 nearest additive TA1/MOD1/GLOB1 with
constant valid original vertex channels, and TA0/MOD0/GLOB1. Authentic combined
vertex prepass and second pixel global multiplication are retained; TA0 ignores
stored alpha. Only those two expanded additive callback bodies change;90
including normal dispatchers and the old9 additive family are byte-exact.
Full ARGB/state/canary/flattened bounds, global0..255/fractional constants,
effective239/240 boundaries, degenerate prepass, target-buffer/pitch rejection,
and bit-exact gradient/invalid/offscreen fallbacks are covered.

Results are conditional API tests, using actual production callback includes
and extracted screen RAII/query/virtual methods with simple image/app/flat4x4
geometry doubles. They do not demonstrate ordinary scene reachability, native
scan/interpolation/cache/framebuffer equivalence, gameplay or all-game parity.
No original runtime, browser, audio or full engine initializes in this suite.
