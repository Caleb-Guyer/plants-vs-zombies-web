"""Focused frozen9 negative / new additive candidate positive source tests.

Only authored C++ executes in Node. Does not execute an original EXE or build
the engine. Candidate source and the owned authenticated9 fragments are read-only.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,subprocess

HERE=Path(__file__).resolve().parent
WORK=next(p for p in HERE.parents if (p/'toolchain').is_dir())
SDK=WORK/'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
BASE=HERE/'software9-baseline'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate-source',type=Path,help='Future candidate source directory, containing src and CMake')
parser.add_argument('--output',type=Path,required=True,help='Fresh output directory; never overwritten')
args=parser.parse_args()
OUT=args.output.resolve();assert not OUT.exists(),f'Preserve completed receipts: {OUT}'
OUT.mkdir(parents=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['fixtures.cpp','native-reference.h','run-paired-tests.py','baseline-manifest.json']:
 (OUT/('input-'+name)).write_bytes((HERE/name).read_bytes())
manifest=json.loads((HERE/'baseline-manifest.json').read_text(encoding='utf8'))
assert manifest['archiveSha256']=='b4ca8b710fe2c61ead0ab5ee1f1a4dffbae92e7c9c705b8ac2e3c4e0f4f83fc4'
assert len(manifest['files'])==15 and len(manifest['sourceFiles'])==757
for name,pin in manifest['files'].items():assert sha((BASE/name).read_bytes())==pin,name
candidate=args.candidate_source.resolve() if args.candidate_source else None
def snapshot(root):return {p.relative_to(root).as_posix():sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
before=snapshot(candidate) if candidate else None
changed=[]
if candidate:
 assert set(before)==set(manifest['sourceFiles']), 'Candidate source inventory differs from frozen9'
 changed=sorted(n for n,h in before.items() if h!=manifest['sourceFiles'][n])
 assert changed==manifest['allowedCandidateChangedPaths'],changed
 for name,pin in manifest['files'].items():
  if name not in changed:assert sha((candidate/name).read_bytes())==pin,name

def fun(text,sig):
 assert text.count(sig)==1,sig
 start=text.index(sig);brace=text.index('{',start);depth=0
 for end in range(brace,len(text)):
  depth+=(text[end]=='{')-(text[end]=='}')
  if not depth:return text[start:end+1]
 raise AssertionError(sig)

variants=[('software9',BASE)]+([('candidate',candidate)] if candidate else [])
results={};bodies={}
for tag,source in variants:
 out=OUT/tag;out.mkdir();tmp=out/'tmp';tmp.mkdir()
 screen=(source/'src/SexyAppFramework/graphics/SoftwareScreenImage.cpp').read_text(encoding='utf8')
 methods=screen[screen.index('namespace\n{'):screen.index('SoftwareScreenImage::SoftwareScreenImage')]
 for sig in ['SoftwareScreenImage::SoftwareScreenImage(','void SoftwareScreenImage::Create(',
             'void SoftwareScreenImage::BltMatrix(','void SoftwareScreenImage::BltTrianglesTex(']:
  methods+=fun(screen,sig)+'\n'
 declarations='void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)override;\nvoid BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)override;'
 callback_decl='\n'.join(line for line in (source/'src/PvzpLib/EffectSystem.h').read_text(encoding='utf8').splitlines() if line.startswith('extern void PvzpDrawTriangle_'))
 generated=(HERE/'fixtures.cpp').read_text(encoding='utf8').replace('SCREEN_DECLARATIONS',declarations).replace('PRODUCTION_METHODS',methods).replace('FIXED_FLOOR',fun((source/'src/SexyAppFramework/graphics/SWTri.cpp').read_text(encoding='utf8'),'static int FixedFloor(')).replace('CALLBACK_DECLARATIONS',callback_decl)
 cpp=out/'actual.cpp';cpp.write_text(generated,encoding='utf8',newline='\n')
 env=dict(os.environ,TEMP=str(tmp),TMP=str(tmp),EMCC_TEMP_DIR=str(tmp),EMSDK_NODE=str(SDK/'node/24.19.0_64bit/node.exe'))
 cmd=[SDK/'python/3.13.3_64bit/python.exe',SDK/'upstream/emscripten/em++.py',cpp,
      '-I'+str(source/'src'),'-I'+str(source/'src/SexyAppFramework'),'-I'+str(HERE),
      '-std=c++20','-O2','-sENVIRONMENT=node','-o',out/'actual.js']
 build=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,env=env)
 (out/'build.log').write_text(build.stdout+build.stderr,encoding='utf8',newline='\n')
 assert build.returncode==0,build.stderr
 pp=subprocess.run(list(map(str,cmd[:-2]+['-E','-P'])),capture_output=True,env=env)
 assert pp.returncode==0,pp.stderr.decode()
 (out/'expanded.cpp').write_bytes(pp.stdout);text=pp.stdout.decode('utf8');expanded={}
 for match in re.finditer(r'\bvoid\s+(PvzpDrawTriangle_\w+)\([^;{}]*\)\s*\{',text):
  brace=match.end()-1;depth=0
  for end in range(brace,len(text)):
   depth+=(text[end]=='{')-(text[end]=='}')
   if not depth:break
  assert match[1] not in expanded,match[1]
  expanded[match[1]]=text[brace:end+1]
 assert len(expanded)==92,len(expanded)
 bodies[tag]=expanded
 run=subprocess.run([str(SDK/'node/24.19.0_64bit/node.exe'),str(out/'actual.js')],capture_output=True,text=True)
 (out/'run.log').write_text(run.stdout+run.stderr,encoding='utf8',newline='\n')
 assert run.stdout,run.stderr
 result=json.loads(run.stdout.splitlines()[-1]);result['exitCode']=run.returncode
 assert result['normalFailures']==[0,0] and result['stateFailures']==0,result
 assert all(n>0 for n in result['normalAssertions']+result['additiveAssertions'])
 assert result['degenerateCalls']==8 and len(result['fallbackRecords'])==74,result
 if tag=='software9':assert run.returncode==1 and all(n>0 for n in result['additiveFailures']),result
 else:assert run.returncode==0 and result['additiveFailures']==[0,0],result
 result.update(actualCppSha256=sha(cpp.read_bytes()),expandedCppSha256=sha(pp.stdout),
               sourceInputsSha256={n:sha((source/n).read_bytes()) for n in manifest['files']})
 results[tag]=result

changed_bodies=[];unchanged={}
if candidate:
 assert results['software9']['fallbackRecords']==results['candidate']['fallbackRecords'],'Fallback full storage/vertex/global records differ'
 assert set(bodies['software9'])==set(bodies['candidate'])
 for name,old in bodies['software9'].items():
  new=bodies['candidate'][name]
  if old!=new:changed_bodies.append(name)
  else:unchanged[name]=sha(old.encode('utf8'))
 expected=['PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0_ADDITIVE',
           'PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0_ADDITIVE']
 assert sorted(changed_bodies)==expected and len(unchanged)==90,changed_bodies
 assert snapshot(candidate)==before,'Candidate source mutated during test'
for name,pin in manifest['files'].items():assert sha((BASE/name).read_bytes())==pin,name
receipt={'status':'PASS paired frozen9 expected failure / candidate corrected with90 byte-exact bodies' if candidate else 'PASS frozen9 expected negative controls only; candidate not tested',
 'families':['TA1/MOD1/GLOB1 nearest additive','TA0/MOD0/GLOB1 nearest additive'],
 'variants':results,'changedSourcePaths':changed,'unchangedSourceFiles':754 if candidate else None,
 'changedExpandedCallbacks':sorted(changed_bodies),'unchangedExpandedBodiesSha256':unchanged,
 'expandedCallbackCount':92,'fallbackFullRecordsBitExact':True if candidate else None,
 'baselineManifestSha256':sha((HERE/'baseline-manifest.json').read_bytes()),
 'fixtureSha256':sha((HERE/'fixtures.cpp').read_bytes()),'referenceSha256':sha((HERE/'native-reference.h').read_bytes()),
 'runnerSha256':sha(Path(__file__).read_bytes()),
 'toolchain':{'folder':SDK.name,'emppSha256':sha((SDK/'upstream/emscripten/em++.py').read_bytes()),'nodeSha256':sha((SDK/'node/24.19.0_64bit/node.exe').read_bytes())},
 'scope':'Actual production callback includes and extracted actual screen RAII/query/virtual boundaries, with app/image/flat4x4 geometry doubles. Independent addressed scalar arithmetic and full ARGB/state preservation. Constant combined vertex inputs only for new screen route; gradients/invalid/offscreen fallbacks compared byte-exact to9. No original execution/framebuffer, ordinary scene, cache/native scan/interpolation, full engine build/browser/audio or all-game claim.'}
(OUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
summary={'status':receipt['status'],'variants':{tag:{k:v for k,v in result.items() if k not in ['fallbackRecords','sourceInputsSha256']} for tag,result in results.items()},
         'changedExpandedCallbacks':receipt['changedExpandedCallbacks'],'unchangedExpandedCallbackCount':len(unchanged),
         'fallbackRecordCount':len(results['software9']['fallbackRecords']),'resultsSha256':sha((OUT/'results.json').read_bytes())}
print(json.dumps(summary,indent=2))
