// Independent scalar transcription of addressed nearest workers, no PE execution.
// Combined TA1: normal4D6210/additive4D7910; all eight pixel copies reviewed.
// Opaque TA0: normal4B5120/additive4B5E20; four normal/additive cores peer-reviewed.
#pragma once
#include <algorithm>
#include <cstdint>
namespace AddressedNearest {
inline uint32_t sample(const uint32_t* t,unsigned width,unsigned end,unsigned u,unsigned v){
 const uint32_t p=(v>>16)*width+(u>>16);return p<end?t[p]:0;
}
inline uint32_t pixel(uint32_t t,uint32_t d,const uint32_t v[4],const uint32_t g[4],bool combined,bool additive){
 unsigned a=combined?t>>24:255;
 if(a<=8)return d;
 unsigned q[4];
 for(unsigned k=0;k<4;k++)q[k]=combined?((v[k]*g[k]>>8)*g[k]>>24):g[k];
 const unsigned effective=a*q[0]>>8;
 uint32_t out=0xff000000;
 for(unsigned k=0;k<3;k++){
  const unsigned shift=k*8,src=((t>>shift)&255)*q[3-k]>>8,dst=(d>>shift)&255;
  const unsigned value=additive?std::min(255u,dst+(src*effective>>8)):
   effective>=240?src:(src*effective>>8)+(dst*(255-effective)>>8);
  out|=value<<shift;
 }
 return out;
}
}
