// The runner inserts unchanged production screen boundaries and 92 callbacks.
// Image/app/geometry are doubles; only authored tests execute under Node.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <vector>
#include "native-reference.h"
using ulong=unsigned long;static_assert(sizeof(ulong)==4);
namespace Sexy {
struct SexyAppBase{};struct Rect{};struct Color{};struct SexyMatrix3{};
struct TriVertex{float x,y,u,v;uint32_t color;};
struct SWHelper{struct SWVertex{int x,y,a,r,g,b,u,v;};struct SWTextureInfo{const unsigned*pTexture;int pitch;unsigned endpos;};struct SWDiffuse{unsigned a,r,g,b;};using signed64=int64_t;};
class MemoryImage;using Hook=void(*)(MemoryImage*);static Hook drawHook=nullptr;
class Image{public:virtual ~Image()=default;virtual void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)=0;virtual void BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)=0;};
class MemoryImage:public Image{public:
 int mWidth=0,mHeight=0;bool mPurgeBits=false,mForcedMode=false,mHasAlpha=true,mHasTrans=true;std::vector<uint32_t> bits;
 explicit MemoryImage(SexyAppBase*){};virtual void Create(int w,int h){mWidth=w;mHeight=h;bits.assign(w*h+49,0xff202020);bits.back()=0x4beefade;}
 uint32_t* GetBits(){return bits.data();}void SetImageMode(bool t,bool a){mForcedMode=true;mHasTrans=t;mHasAlpha=a;}
 void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)override{if(drawHook)drawHook(this);}
 void BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)override{if(drawHook)drawHook(this);}
};
bool NativeScreenRasterTargetMatches(const void*,unsigned);
class SoftwareScreenImage final:public MemoryImage{public:explicit SoftwareScreenImage(SexyAppBase*);void Create(int,int)override;void BltMatrix(Image*,float,float,const SexyMatrix3&,const Rect&,const Color&,int,const Rect&,bool)override;
void BltTrianglesTex(Image*,const TriVertex[][3],int,const Rect&,const Color&,int,float,float,bool)override;};
}
using namespace Sexy;
namespace
{
struct ScreenRasterTarget
{
    const void* surface = nullptr;
    unsigned int bytePitch = 0;
};
thread_local ScreenRasterTarget gScreenRasterTarget;

class ScopedScreenRasterTarget
{
    ScreenRasterTarget mPrevious;
public:
    ScopedScreenRasterTarget(const void* surface, unsigned int bytePitch)
        : mPrevious(gScreenRasterTarget)
    {
        gScreenRasterTarget = {surface, bytePitch};
    }
    ~ScopedScreenRasterTarget() { gScreenRasterTarget = mPrevious; }
    ScopedScreenRasterTarget(const ScopedScreenRasterTarget&) = delete;
    ScopedScreenRasterTarget& operator=(const ScopedScreenRasterTarget&) = delete;
};
}

bool Sexy::NativeScreenRasterTargetMatches(const void* surface, unsigned int bytePitch)
{
    return surface != nullptr && surface == gScreenRasterTarget.surface &&
        bytePitch != 0 && bytePitch == gScreenRasterTarget.bytePitch;
}

SoftwareScreenImage::SoftwareScreenImage(SexyAppBase* app) : MemoryImage(app)
{
    SetImageMode(false, false);
    mPurgeBits = false;
}
void SoftwareScreenImage::Create(int width, int height)
{
    MemoryImage::Create(width, height);
    SetImageMode(false, false);
    mPurgeBits = false;
}
void SoftwareScreenImage::BltMatrix(Image* image, float x, float y, const SexyMatrix3& matrix,
    const Rect& clipRect, const Color& color, int drawMode, const Rect& sourceRect, bool blend)
{
    ScopedScreenRasterTarget target(GetBits(), static_cast<unsigned int>(mWidth) * 4u);
    MemoryImage::BltMatrix(image, x, y, matrix, clipRect, color, drawMode, sourceRect, blend);
}
void SoftwareScreenImage::BltTrianglesTex(Image* texture, const TriVertex vertices[][3], int triangleCount,
    const Rect& clipRect, const Color& color, int drawMode, float x, float y, bool blend)
{
    ScopedScreenRasterTarget target(GetBits(), static_cast<unsigned int>(mWidth) * 4u);
    MemoryImage::BltTrianglesTex(texture, vertices, triangleCount, clipRect, color, drawMode, x, y, blend);
}

static int FixedFloor(int x)
{
	if (x>0)
		return x&0xFFFF0000;
	else
		return (x&0xFFFF0000)-0x10000;
}
bool gPvzpTriangleDrawAdditive=false;
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA0_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_8888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA0_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD0_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB0_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB0_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB1_BLEND0(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0555_TEX1_TALPHA1_MOD1_GLOB1_BLEND1(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD1_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD0_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD0_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA0_MOD1_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD0_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB0_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND0_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
extern void PvzpDrawTriangle_0565_TEX1_TALPHA1_MOD1_GLOB1_BLEND1_ADDITIVE(SWHelper::SWVertex* pVerts, void* pFrameBuffer, const unsigned int bytepitch, const SWHelper::SWTextureInfo* textureInfo, SWHelper::SWDiffuse& globalDiffuse);
#include "PvzpLib/PvzpDrawTriangleInc.inc"
using Func=void(*)(SWHelper::SWVertex*,void*,unsigned,const SWHelper::SWTextureInfo*,SWHelper::SWDiffuse&);
struct Case{
 int family=0,width=1,u=0,v=0,shape=0;unsigned end=1,pitch=16;
 bool additive=true,screen=true,foreign=false,triangles=false;
 uint32_t initial=0xff202020,g[4]={255,255,255,255},vertices[3][4];
 std::vector<uint32_t> texture{0x80808080};
 Case(){for(auto& row:vertices)for(auto& c:row)c=0xff0000;}
};
static const Case* active=nullptr;static bool arithmetic=false,fallback=false;
static uint64_t normalChecks[2]{},normalFailures[2]{},addChecks[2]{},addFailures[2]{};
static uint64_t stateChecks=0,stateFailures=0,calls=0,degenerateCalls=0;
static std::vector<std::vector<uint32_t>> fallbackRecords;
static void state(bool ok){++stateChecks;if(!ok)++stateFailures;}
static void callBoundary(MemoryImage& im,const Case& c){
 Image* base=&im;Rect r;Color color;SexyMatrix3 m;TriVertex t[1][3]{};
 if(c.triangles)base->BltTrianglesTex(nullptr,t,1,r,color,c.additive?1:0,0,0,false);
 else base->BltMatrix(nullptr,0,0,m,r,color,c.additive?1:0,r,false);
}
static void raster(MemoryImage* target){
 const auto& c=*active;const bool screen=dynamic_cast<SoftwareScreenImage*>(target)!=nullptr;
 state(NativeScreenRasterTargetMatches(target->GetBits(),16)==screen);
 state(!NativeScreenRasterTargetMatches(target->GetBits(),20));
 state(!NativeScreenRasterTargetMatches(nullptr,16));
 state(!NativeScreenRasterTargetMatches(target->GetBits(),0));
 std::array<uint32_t,65> foreign;std::fill(foreign.begin(),foreign.end(),c.initial);foreign.back()=0x4beefade;
 auto surface=c.foreign?foreign.data():target->GetBits();
 SWHelper::SWTextureInfo tx{c.texture.data(),c.width,c.end};
 SWHelper::SWDiffuse global{c.g[0],c.g[1],c.g[2],c.g[3]};
 SWHelper::SWVertex vs[3];
 for(int i=0;i<3;i++)vs[i]={i==1?4<<16:0,i==2?4<<16:0,int(c.vertices[i][0]),int(c.vertices[i][1]),int(c.vertices[i][2]),int(c.vertices[i][3]),c.u,c.v};
 if(c.shape==1)for(auto& row:vs)row.y=0;
 if(c.shape==2)for(auto& row:vs)row.x=0;
 const auto original=std::array<SWHelper::SWVertex,3>{vs[0],vs[1],vs[2]};
 const Func entry=c.family==0?PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB1_BLEND0:PvzpDrawTriangle_0888_TEX1_TALPHA0_MOD0_GLOB1_BLEND0;
 gPvzpTriangleDrawAdditive=c.additive;entry(vs,surface,c.pitch,&tx,global);++calls;
 if(c.shape)++degenerateCalls;
 state(target->bits.back()==0x4beefade);state(foreign.back()==0x4beefade);
 state(global.a==c.g[0]&&global.r==c.g[1]&&global.g==c.g[2]&&global.b==c.g[3]);
 for(unsigned i=0;i<3;i++){
  const unsigned actual[]={unsigned(vs[i].a),unsigned(vs[i].r),unsigned(vs[i].g),unsigned(vs[i].b)};
  for(unsigned k=0;k<4;k++)state(actual[k]==(c.family==0?c.vertices[i][k]*c.g[k]>>8:c.vertices[i][k]));
  state(vs[i].x==original[i].x&&vs[i].y==original[i].y&&vs[i].u==original[i].u&&vs[i].v==original[i].v);
 }
 if(arithmetic){
  const auto tex=AddressedNearest::sample(c.texture.data(),unsigned(c.width),c.end,unsigned(c.u),unsigned(c.v));
  const auto want=AddressedNearest::pixel(tex,c.initial,c.vertices[0],c.g,c.family==0,c.additive);
  for(unsigned i=0;i<64;i++){
   const unsigned x=i%4,y=i/4;const bool covered=!c.shape&&y<4&&x<4-y;
   const bool bad=surface[i]!=(covered?want:c.initial);
   if(c.additive){++addChecks[c.family];addFailures[c.family]+=bad;}
   else{++normalChecks[c.family];normalFailures[c.family]+=bad;}
  }
 }
 if(fallback){
  std::vector<uint32_t> record(target->bits.begin(),target->bits.end());
  record.insert(record.end(),foreign.begin(),foreign.end());
  for(const auto& row:vs){const int fields[]={row.x,row.y,row.a,row.r,row.g,row.b,row.u,row.v};for(auto val:fields)record.push_back(unsigned(val));}
  record.insert(record.end(),c.g,c.g+4);fallbackRecords.push_back(std::move(record));
 }
}
static void run(const Case& c,bool native=true,bool same9=false){
 active=&c;arithmetic=native;fallback=same9;
 MemoryImage plain(nullptr);SoftwareScreenImage cpu(nullptr);
 MemoryImage& im=c.screen?static_cast<MemoryImage&>(cpu):plain;
 im.Create(4,4);std::fill(im.bits.begin(),im.bits.end()-1,c.initial);
 callBoundary(im,c);state(!NativeScreenRasterTargetMatches(im.GetBits(),16));
}
int main(){
 drawHook=raster;
 const unsigned vertexSets[][4]={{0xff0000,0xff0000,0xff0000,0xff0000},{0x800000,0x4b0000,0x640000,0xff0000},{0,0xff0000,0x800000,0x400000},{0x10000,0xff0000,0x800000,0x400000},{0x80abcd,0x4b1234,0x647fff,0x40ffff}};
 const unsigned globalSets[][4]={{255,255,255,255},{128,75,100,255},{0,255,128,64},{1,255,128,64},{239,240,241,242},{240,239,254,255},{128,128,128,128}};
 // Colored alpha/effective-alpha/normal-copy/saturation controls in both modes.
 for(int family:{0,1})for(bool add:{false,true})
 for(unsigned a:{0u,1u,8u,9u,64u,128u,239u,240u,241u,254u,255u})
 for(uint32_t rgb:{0u,0x0080ff20u,0x00ff0180u,0x00ffffffu})
 for(uint32_t dst:{0xff000000u,0xff203040u,0xfffefdfcu})
 for(const auto& v:vertexSets)for(const auto& g:globalSets){
  Case c;c.family=family;c.additive=add;c.initial=dst;c.texture={(a<<24)|rgb};
  std::copy_n(g,4,c.g);for(auto& row:c.vertices)std::copy_n(v,4,row);
  c.triangles=add;run(c);
 }
 // Every stored alpha for TA0; full ARGB distinguishes skips from opaque writes.
 for(int family:{0,1})for(bool add:{false,true})for(unsigned a=0;a<256;a++)
 for(uint32_t high:{0u,0x7f000000u,0xff000000u}){
  Case c;c.family=family;c.additive=add;c.initial=high|0x00203040;c.texture={(a<<24)|0x00ff8020};
  c.g[0]=a%2?0:255;run(c);
 }
 // Combined maximum Q=253: raw A242/243 gives effective alpha239/240.
 for(bool add:{false,true})for(unsigned a:{242u,243u}){
  Case c;c.additive=add;c.initial=0x7f203040;c.texture={(a<<24)|0x00ff8020};run(c);
 }
 // Zero and out-of-end samples distinguish full-word TA1 skip from TA0 write.
 for(int family:{0,1})for(bool add:{false,true})for(int mode:{0,1,2})
 for(uint32_t high:{0u,0x7f000000u,0xff000000u})for(unsigned ga:{0u,255u}){
  Case c;c.family=family;c.additive=add;c.initial=high|0x00203040;c.texture={0};c.g[0]=ga;
  if(mode==1)c.u=65536;if(mode==2)c.v=65536;run(c);
 }
 // Every global value in each independent channel with nontrivial fractions.
 for(int family:{0,1})for(bool add:{false,true})for(unsigned k=0;k<4;k++)for(unsigned value=0;value<256;value++){
  Case c;c.family=family;c.additive=add;c.g[k]=value;c.texture={0xf0ff8040};
  for(auto& row:c.vertices){row[0]=0xff0000;row[1]=0x80abcd;row[2]=0x4bffff;row[3]=0xfe8000;}run(c);
 }
 // Fractional raw vertex boundaries, including the maximum allowed input.
 for(bool add:{false,true})for(unsigned k=0;k<4;k++)
 for(unsigned value:{0u,1u,127u,128u,239u,240u,254u,255u})for(unsigned fraction:{0u,1u,32768u,65535u}){
  if(value==255&&fraction)continue;
  for(unsigned g:{0u,1u,128u,239u,240u,255u}){
   Case c;c.additive=add;for(auto& row:c.vertices)row[k]=(value<<16)+fraction;c.g[k]=g;run(c);
  }
 }
 // Flattened sample edges: u==width aliases next row; v==height gives zero.
 for(int family:{0,1})for(bool add:{false,true})for(int uu:{0,1,65535,65536,131071,131072})for(int vv:{0,65535,65536,131071,131072}){
  Case c;c.family=family;c.additive=add;c.width=2;c.end=4;c.texture={0x08ff0180,0x0901ff80,0x80fe8040,0xff8040fe};c.u=uu;c.v=vv;run(c);
 }
 // Legal maximum dimension, with complete backing allocations and valid UV0.
 for(int family:{0,1})for(bool tall:{false,true}){
  Case c;c.family=family;c.width=tall?1:32767;c.end=32767;c.texture.assign(c.end,0x80ff8040);run(c);
 }
 // Degenerate triangles still run the authentic combined prepass once.
 for(int family:{0,1})for(bool add:{false,true})for(int shape:{1,2}){
  Case c;c.family=family;c.additive=add;c.shape=shape;c.g[0]=128;c.g[1]=75;c.g[2]=0;c.g[3]=255;
  for(auto& row:c.vertices){row[0]=0x80abcd;row[1]=0x4b1234;row[2]=0xff0000;row[3]=0x40ffff;}run(c);
 }
 // Offscreen/wrong-surface/wrong-pitch: complete storage and state must equal9.
 for(int family:{0,1})for(bool add:{false,true})for(int mode=0;mode<6;mode++){
  Case c;c.family=family;c.additive=add;c.initial=0x7f203040;
  if(mode==0)c.screen=false;if(mode==1)c.foreign=true;
  if(mode==2)c.pitch=20;if(mode==3)c.pitch=18;if(mode==4)c.pitch=0;
  if(mode==5){c.screen=false;c.triangles=true;}run(c,false,true);
 }
 // Individually rejected dimensions/layout/UV/global guards, safe generic reads.
 for(int family:{0,1})for(int test=0;test<15;test++){
  Case c;c.family=family;
  if(test==0)c.width=0;
  if(test==1){c.width=2;c.end=3;c.texture.assign(3,0x80808080);}
  if(test==2)c.end=0;
  if(test==3){c.width=32768;c.end=32768;c.texture.assign(c.end,0x80808080);}
  if(test==4){c.width=1;c.end=32768;c.texture.assign(c.end,0x80808080);}
  if(test==5)c.width=-1;
  if(test==6)c.u=-1;if(test==7)c.v=-1;if(test==8)c.u=65537;if(test==9)c.v=65537;
  if(test==10)c.g[0]=256;if(test==11)c.g[1]=256;if(test==12)c.g[2]=256;if(test==13)c.g[3]=256;
  if(test==14)c.g[0]=0xffffffff;run(c,false,true);
 }
 // Raw invalidity before premultiplication; valid-looking mutated128 catches it.
 for(unsigned k=0;k<4;k++)for(unsigned raw:{0xffffffffu,0xff0001u,0x1000000u}){
  Case c;c.g[0]=c.g[1]=c.g[2]=c.g[3]=128;for(auto& row:c.vertices)row[k]=raw;run(c,false,true);
 }
 // Original gradients survive the prepass and must retain generic9 behavior.
 for(unsigned k=0;k<4;k++)for(unsigned g:{128u,255u}){
  Case c;c.g[k]=g;for(auto& row:c.vertices)row[k]=0x800000;c.vertices[1][k]+=65536;run(c,false,true);
 }
 printf("{\"normalAssertions\":[%llu,%llu],\"normalFailures\":[%llu,%llu],\"additiveAssertions\":[%llu,%llu],\"additiveFailures\":[%llu,%llu],\"stateAssertions\":%llu,\"stateFailures\":%llu,\"calls\":%llu,\"degenerateCalls\":%llu,\"fallbackRecords\":[",normalChecks[0],normalChecks[1],normalFailures[0],normalFailures[1],addChecks[0],addChecks[1],addFailures[0],addFailures[1],stateChecks,stateFailures,calls,degenerateCalls);
 for(unsigned i=0;i<fallbackRecords.size();i++){if(i)printf(",");printf("[");for(unsigned j=0;j<fallbackRecords[i].size();j++){if(j)printf(",");printf("%u",fallbackRecords[i][j]);}printf("]");}
 printf("]}\n");return normalFailures[0]||normalFailures[1]||addFailures[0]||addFailures[1]||stateFailures?1:0;
}
