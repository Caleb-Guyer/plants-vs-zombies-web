"""Create an isolated, unbuilt Software.10 from authenticated Software.9.

Only version plus two addressed additive callback families change. This
producer never executes a game, starts a service or edits an existing tree.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import zipfile

EXPECTED = 'b4ca8b710fe2c61ead0ab5ee1f1a4dffbae92e7c9c705b8ac2e3c4e0f4f83fc4'
ALLOWED = ['CMake/ProjectVersion.cmake', 'src/PvzpLib/PvzpDrawTriangle.inc',
           'src/PvzpLib/PvzpNativeScreenPixel888.inc']

def sha(data):
    return hashlib.sha256(data).hexdigest()

p = argparse.ArgumentParser()
p.add_argument('--source-archive', required=True, type=Path)
p.add_argument('--output', required=True, type=Path)
a = p.parse_args()
archive, out = a.source_archive.resolve(), a.output.resolve()
assert not out.exists(), 'A new candidate directory is required.'
assert sha(archive.read_bytes()) == EXPECTED
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == 806 and z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist()))
    prefix = 'software9-candidate/source/'
    entries = {name[len(prefix):]: z.read(name) for name in z.namelist()
               if name.startswith(prefix) and not name.endswith('/')}
    build_recipe = z.read('software9-candidate/build-candidate.ps1')
assert len(entries) == 757
for name in entries:
    q = PurePosixPath(name)
    assert not q.is_absolute() and '..' not in q.parts and '\\' not in name
out.mkdir()
for name, data in entries.items():
    path = out / 'source' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

path = out / 'source/CMake/ProjectVersion.cmake'
data = path.read_bytes()
assert data.count(b'0.2.6-web-software.9') == 1
path.write_bytes(data.replace(b'0.2.6-web-software.9', b'0.2.6-web-software.10'))

path = out / 'source/src/PvzpLib/PvzpDrawTriangle.inc'
data = path.read_bytes()
old = b'''// Only these alpha-textured RGB888 combinations have addressed native proof.
// Other targets/formats/combinations retain the existing callback code.
#if (TRI0==1) && (TRI2==1) && ((TRI3==0) || ((TRI4==0) && ((TRI5==1) || defined(NAME_ADDITIVE))))'''
new = b'''// Only these RGB888 combinations have addressed native proof.
// The two new global-color families are nearest/additive only.
// Other targets/formats/combinations retain the existing callback code.
#if (TRI0==1) && (((TRI2==1) && ((TRI3==0) || ((TRI4==0) && ((TRI5==1) || defined(NAME_ADDITIVE))))) || \\
    (defined(NAME_ADDITIVE) && (TRI5==0) && (TRI4==1) && \\
    (((TRI2==1) && (TRI3==1)) || ((TRI2==0) && (TRI3==0)))))'''
assert data.count(old) == 1
data = data.replace(old, new)
old = b'''#if defined(NAME_ADDITIVE) && (TRI3==1) && (TRI4==0) && (TRI5==0)
        // Only the newly admitted nearest-additive family requires constant
        // input vertex color; unproved gradients retain the existing path.'''
new = b'''#if defined(NAME_ADDITIVE) && (TRI3==1) && (TRI5==0)
        // The admitted nearest/additive vertex-color families require
        // constant input color; unproved gradients retain the existing path.'''
assert data.count(old) == 1
data = data.replace(old, new)
anchor = b'''        && pVerts[0].b == pVerts[1].b && pVerts[0].b == pVerts[2].b
#endif
'''
raw_guard = b'''#if defined(NAME_ADDITIVE) && (TRI2==1) && (TRI3==1) && (TRI4==1) && (TRI5==0)
        // Check original fixed-point inputs before the authentic global
        // prepass. Keep the later combined global modulation unchanged too.
        && pVerts[0].a >= 0 && pVerts[0].a <= 0xff0000
        && pVerts[0].r >= 0 && pVerts[0].r <= 0xff0000
        && pVerts[0].g >= 0 && pVerts[0].g <= 0xff0000
        && pVerts[0].b >= 0 && pVerts[0].b <= 0xff0000
#endif
'''
assert data.count(anchor) == 1
path.write_bytes(data.replace(anchor, anchor + raw_guard))

path = out / 'source/src/PvzpLib/PvzpNativeScreenPixel888.inc'
data = path.read_bytes()
anchor = b'''    #include "PvzpLib/PvzpNativeScreenTexel.inc"
    if (alpha > 8)'''
replacement = b'''    #include "PvzpLib/PvzpNativeScreenTexel.inc"
    #if defined(NAME_ADDITIVE) && !defined(TEX_ALPHA) && !defined(MOD_ARGB) && defined(GLOBAL_ARGB) && !defined(LINEAR_BLEND)
        // The addressed opaque nearest worker ignores stored texture alpha.
        // Force it before global modulation, including zero/empty texels.
        alpha = 255;
    #endif
    if (alpha > 8)'''
assert data.count(anchor) == 1
path.write_bytes(data.replace(anchor, replacement))

parent = {
    'schemaVersion': 1, 'version': '0.2.6-web-software.9',
    'archive': archive.name, 'archiveSha256': EXPECTED,
    'archiveEntries': 806, 'sourceFiles': {n: sha(b) for n, b in entries.items()},
    'sourceBytes': sum(map(len, entries.values())),
}
(out / 'software9-parent.json').write_text(json.dumps(parent, indent=2) + '\n')
(out / 'build-candidate.ps1').write_bytes(build_recipe)
changed = sorted(n for n, b in entries.items() if (out / 'source' / n).read_bytes() != b)
assert changed == ALLOWED
assert not (out / 'build').exists() and not (out / 'source/.git').exists()
receipt = {
    'status': 'PASS isolated authenticated9 source copied; three scoped edits; UNBUILT',
    'version': '0.2.6-web-software.10', 'parentArchiveSha256': EXPECTED,
    'sourceFiles': 757, 'unchangedSourceFiles': 754, 'changedPaths': changed,
    'sourcePins': {n: sha((out / 'source' / n).read_bytes()) for n in changed},
    'parentManifestSha256': sha((out / 'software9-parent.json').read_bytes()),
    'buildRecipeSha256': sha(build_recipe), 'creatorSha256': sha(Path(__file__).read_bytes()),
    'scope': 'Only nearest/additive RGB888 TA1/MOD1/GLOB1 constant-color and TA0/MOD0/GLOB1 admission, original-vertex bounds, scoped opaque alpha override and version. Normal/other callbacks require paired preservation verification. Authentic double-global mutation and pixel modulation retained. No full build, UI, original execution, ordinary additive scene, native geometry/UV or overall parity claim.',
}
(out / 'scaffold-preparation.json').write_text(json.dumps(receipt, indent=2) + '\n')
(out / 'prepare-from-software9.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(receipt, indent=2))
