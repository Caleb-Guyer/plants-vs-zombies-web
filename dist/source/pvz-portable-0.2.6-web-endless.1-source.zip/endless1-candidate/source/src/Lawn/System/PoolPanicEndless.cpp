// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanicEndless.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../LawnCommon.h"
#include "PlayerInfo.h"
#include "../../LawnApp.h"
#include "Common.h"
#include <algorithm>
#include <climits>
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#endif

namespace PoolPanicEndless
{
namespace
{
void RestoreEmptyPads(Board& board)
{
    for (const Cell& cell : kLilyPads)
        if (!board.GetTopPlantAt(cell.mCol,cell.mRow,TOPPLANT_ANY))
            board.AddPlant(cell.mCol,cell.mRow,SEED_LILYPAD,SEED_NONE);
}
void UpdateSupply(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    board.mSeedBank->UpdateConveyorBelt();
    if (challenge.mChallengeScore >= kPacketQuota ||
        board.mSeedBank->GetNumSeedsOnConveyorBelt() >= board.mSeedBank->mNumPackets) return;
    if (challenge.mConveyorBeltCounter > 0) --challenge.mConveyorBeltCounter;
    if (challenge.mConveyorBeltCounter != 0) return;
    const SeedType seed = SeedForSupply(challenge.mSurvivalStage,challenge.mChallengeScore);
    board.mSeedBank->AddSeed(seed);
    challenge.mLastConveyorSeedType = seed;
    ++challenge.mChallengeScore;
    challenge.mConveyorBeltCounter = kSupplyInterval;
}
void CompleteFlag(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    if (challenge.mSurvivalStage < INT_MAX) ++challenge.mSurvivalStage;
    challenge.mChallengeState = kBetween;
    challenge.mChallengeStateCounter = kBetweenDelay;
    // Accepted native packets carry unchanged. Only this completed flag's
    // unissued quota expires; the next flag starts a new delivery allowance.
    challenge.mChallengeScore = 0;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    board.mCurrentWave = 0;
    board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kBetweenDelay;
    RestoreEmptyPads(board);
    board.SurvivalSaveScore();
    board.SaveGame(GetSavedGameName(kMode,board.mApp->mPlayerInfo->mId));
#ifdef __EMSCRIPTEN__
    // Use the existing serialized browser persistence queue after BOTH native
    // files were written. Its helper owns promise/error handling; Node lacks it.
    EM_ASM({
        if (typeof globalThis.syncSavesInBackground === 'function')
            globalThis.syncSavesInBackground();
    });
#endif
}
}
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mSurvivalStage = 0;
    challenge.mChallengeScore = 0;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    challenge.mChallengeGridX = Sexy::Rand(8);
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = 0;
    board.mShowShovel = false;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (int i = 0; i < kOpeningPackets; ++i)
    {
        const SeedType seed = SeedForSupply(0,challenge.mChallengeScore);
        board.mSeedBank->AddSeed(seed,true);
        challenge.mLastConveyorSeedType = seed;
        ++challenge.mChallengeScore;
    }
    RestoreEmptyPads(board);
}
void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) ||
        board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.mTimeStopCounter > 0 ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    UpdateSupply(board);
    if (challenge.mChallengeState == kBetween)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            challenge.mChallengeState = kActive;
            challenge.mChallengeStateCounter = kResumeDelay;
            board.mZombieCountDown = board.mZombieCountDownStart = kResumeDelay;
        }
        return;
    }
    const int wave = std::clamp(board.mCurrentWave,0,kWaveCount);
    if (wave < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter == 0)
        {
            for (const Spawn& spawn : WaveFor(challenge.mSurvivalStage,wave,challenge.mChallengeGridX))
            {
                if (spawn.mType == ZOMBIE_INVALID) continue;
                Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,wave);
                zombie->mPosX = static_cast<float>(spawn.mX);
                zombie->mX = spawn.mX;
                zombie->UpdateReanim();
            }
            board.mCurrentWave = wave + 1;
            if (board.mTotalSpawnedWaves < INT_MAX) ++board.mTotalSpawnedWaves;
            if (wave == kWaveCount-1) board.mFlagRaiseCounter = 100;
            challenge.mChallengeStateCounter = FormationInterval(challenge.mSurvivalStage);
            board.mZombieCountDown = board.mZombieCountDownStart = challenge.mChallengeStateCounter;
        }
        return;
    }
    if (!board.AreEnemyZombiesOnScreen()) CompleteFlag(board);
}
}
