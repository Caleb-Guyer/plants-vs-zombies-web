// SPDX-License-Identifier: LGPL-3.0-or-later
#include "PoolPanicEndlessPresentation.h"
#include "../../GameConstants.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/PvzpStringFile.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/Font.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <limits>
#include <memory>
#include <string>
#include <vector>

namespace PoolPanicEndlessPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;
std::unique_ptr<Sexy::MemoryImage> sBestLabel;
uint32_t sBestRecord = 0;
std::string sBestText;
const Sexy::_Font* sBestFront = nullptr;
const Sexy::_Font* sBestOutline = nullptr;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("LoadingImages") || !PvzpLoadResources("DelayLoad_Background3") ||
        !Sexy::IMAGE_BACKGROUND3 || !Sexy::IMAGE_POOL) return nullptr;

    // Keep the original riding zombie and dolphin in their complete native
    // assembly. No independently moved limbs, redrawn parts or extra badges.
    auto portrait = Blank(300, 220);
    Sexy::Graphics native(portrait.get());
    native.SetLinearBlend(true);
    Reanimation rider;
    rider.ReanimationInitializeType(60.0f, 35.0f, REANIM_ZOMBIE_DOLPHINRIDER);
    rider.SetFramesForLayer("anim_ride");
    rider.Draw(&native);
    const Sexy::Rect bounds = VisibleBounds(*portrait);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return nullptr;

    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    // The backdrop has a white pool opening. Match the original software pool
    // composition before cropping: PoolEffect draws water at (34,278), while
    // Board::DrawBackdrop places the background at (-BOARD_OFFSET,0).
    auto landscape = Blank(Sexy::IMAGE_BACKGROUND3->GetWidth(), Sexy::IMAGE_BACKGROUND3->GetHeight());
    Sexy::Graphics ground(landscape.get());
    ground.DrawImage(Sexy::IMAGE_BACKGROUND3, 0, 0);
    ground.DrawImage(Sexy::IMAGE_POOL, 34 + BOARD_OFFSET, 278);
    picture.DrawImage(landscape.get(), Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 225, 480, 240));
    const float scale = std::min(68.0f / bounds.mWidth, 57.0f / bounds.mHeight);
    PvzpDrawImageScaledF(&picture, portrait.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sCard = std::move(card);
    return sCard.get();
}

bool DrawFittedBestRecord(Sexy::Graphics* graphics, uint32_t record, std::string_view nativeText, int x, int y)
{
    Sexy::_Font* front = Sexy::FONT_CONTINUUMBOLD14;
    Sexy::_Font* outline = Sexy::FONT_CONTINUUMBOLD14OUTLINE;
    if (!record || !front || !outline) return false;
    std::string text(nativeText);
    const bool unsignedRecord = record > static_cast<uint32_t>(std::numeric_limits<int>::max());
    if (unsignedRecord)
        text = PvzpReplaceString("[LONGEST_STREAK]", "{STREAK}", std::to_string(record));
    if (sBestLabel && record == sBestRecord && text == sBestText && front == sBestFront && outline == sBestOutline)
    {
        graphics->DrawImage(sBestLabel.get(), x + 13, y + 4);
        return true;
    }

    int widest = 0, lines = 0;
    size_t start = 0;
    for (size_t i = 0; i <= text.size(); ++i)
        if (i == text.size() || text[i] == '\n')
        {
            const std::string_view line(text.data() + start, i - start);
            widest = std::max({widest, front->StringWidth(line), outline->StringWidth(line)});
            ++lines;
            start = i + 1;
        }
    // Keep every normally fitting native label on the original draw path,
    // including its exact font pixels, colors and positions.
    if (widest <= 96 && !unsignedRecord) return false;

    const int padding = 8;
    const int width = widest + padding * 2 + 2;
    const int height = std::max(front->GetLineSpacing(), outline->GetLineSpacing()) * lines +
        std::max(front->GetHeight(), outline->GetHeight()) + padding * 2;
    auto nativeLabel = Blank(width, height);
    Sexy::Graphics ink(nativeLabel.get());
    ink.SetLinearBlend(true);
    const Sexy::Rect wrap(padding, padding, widest + 2, height - padding * 2);
    PvzpDrawStringWrapped(&ink, text, wrap, outline, Sexy::Color::White, DS_ALIGN_CENTER);
    PvzpDrawStringWrapped(&ink, text, wrap, front, Sexy::Color(255, 0, 0), DS_ALIGN_CENTER);
    const Sexy::Rect bounds = VisibleBounds(*nativeLabel);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return false;

    auto fitted = Blank(80, 65);
    Sexy::Graphics picture(fitted.get());
    picture.SetLinearBlend(true);
    picture.ClipRect(0, 0, 80, 65);
    const float scale = std::min({1.0f, 76.0f / bounds.mWidth, 57.0f / bounds.mHeight});
    PvzpDrawImageScaledF(&picture, nativeLabel.get(),
        40.0f - (bounds.mX + bounds.mWidth * 0.5f) * scale,
        32.5f - (bounds.mY + bounds.mHeight * 0.5f) * scale, scale, scale);
    sBestLabel = std::move(fitted);
    sBestRecord = record;
    sBestText = std::move(text);
    sBestFront = front;
    sBestOutline = outline;
    graphics->DrawImage(sBestLabel.get(), x + 13, y + 4);
    return true;
}

void DisposeImage()
{
    sCard.reset();
    sBestLabel.reset();
    sBestRecord = 0;
    sBestText.clear();
    sBestFront = sBestOutline = nullptr;
}
}
