// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>
#include <string_view>

class Board;

// Separate from finite Pool Panic. All progress uses existing saved counters;
// native plants, packets, zombies, mowers and effects retain their own states.
namespace PoolPanicEndless
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_POOL_PANIC_ENDLESS;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(127);
inline constexpr ChallengeState kBetween = static_cast<ChallengeState>(128);
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestFormation = 8;
inline constexpr int kBankSize = 10;
inline constexpr int kOpeningPackets = 4;
inline constexpr int kPacketQuota = 48;
inline constexpr int kSupplyInterval = 200;
inline constexpr int kOpeningDelay = 1600;
inline constexpr int kBetweenDelay = 1200;
inline constexpr int kResumeDelay = 400;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kBetween); }
inline constexpr std::array<SeedType,8> kSupplyCycle = {
    SEED_SQUASH, SEED_TANGLEKELP, SEED_CHERRYBOMB, SEED_TANGLEKELP,
    SEED_SQUASH, SEED_JALAPENO, SEED_CHERRYBOMB, SEED_TANGLEKELP
};
constexpr SeedType SeedForSupply(int flags, int ordinal)
{
    if (ordinal < 0 || ordinal >= kPacketQuota) return SEED_NONE;
    const int rotation = flags > 0 ? (flags % 8) * 3 : 0;
    return kSupplyCycle[(ordinal + rotation) % kSupplyCycle.size()];
}
constexpr int FormationInterval(int flags)
{ return flags >= 4 ? 800 : 1000 - (flags > 0 ? flags : 0) * 50; }
struct Cell { int mCol; int mRow; };
inline constexpr std::array<Cell,8> kLilyPads = {{{0,2},{1,2},{2,2},{3,2},{0,3},{1,3},{2,3},{3,3}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
// Independently authored opening flags. N normal, C cone, B bucket, S screen
// door, R football, H snorkel and F dolphin; digits are canonical native rows.
inline constexpr std::array<std::array<std::string_view,kWaveCount>,3> kOpeningFlags = {{
    {{"N0 N2","N5 C3","C0 N1 N2","N4 C5 C3","C0 C1 N2 C3","C4 C5 C2 N3",
      "B0 N1 C2 C3","N4 B5 C2 C3","C0 C1 N2 C3 F3","N4 C5 C2 F2 B3"}},
    {{"C0 N5 N2","N1 C4 C3","B0 C1 C2 N3","C4 B5 N2 C3","S0 C1 C2 H3 N5",
      "C0 S4 C5 H2 C3","B0 N1 C2 F2 B3","C4 B5 B2 F3 C3","R0 C1 C4 C2 H2 F3","C1 C4 R5 F2 B3 H3"}},
    {{"B0 N5 C2 H3","C1 B4 H2 N3","S0 C1 C2 F2 B3","C4 S5 B2 H3 F3","B0 R1 C5 C2 B3 H3",
      "C0 R4 B5 H2 C3 F3","S0 B1 N4 B2 F2 H3","N1 B4 S5 H2 B3 F3","R0 C1 B4 S5 C2 H2 F3","C0 S1 C4 R5 F2 B3 H3"}}
}};
constexpr ZombieType TypeFor(char type)
{
    switch (type)
    {
    case 'N': return ZOMBIE_NORMAL;
    case 'C': return ZOMBIE_TRAFFIC_CONE;
    case 'B': return ZOMBIE_PAIL;
    case 'S': return ZOMBIE_DOOR;
    case 'R': return ZOMBIE_FOOTBALL;
    case 'H': return ZOMBIE_SNORKEL;
    case 'F': return ZOMBIE_DOLPHIN_RIDER;
    default: return ZOMBIE_INVALID;
    }
}
constexpr Formation ParseWave(std::string_view text)
{
    Formation result{};
    int count = 0;
    for (std::size_t i = 0; i + 1 < text.size() && count < kLargestFormation; i += 3)
    {
        result[count] = {TypeFor(text[i]),text[i+1]-'0',800+(count%3)*40};
        ++count;
    }
    return result;
}
constexpr int ZombieCount(const Formation& formation)
{
    int count = 0;
    for (const Spawn& spawn : formation) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
constexpr int TransformRow(int row, int flags, int variation, int wave)
{
    if (row == 2 || row == 3) return 2 + (row-2 + variation/4 + flags%2 + wave) % 2;
    constexpr int land[4] = {0,1,4,5};
    const int index = row < 2 ? row : row-2;
    return land[(index + variation%4 + flags%4) % 4];
}
constexpr Formation WaveFor(int flags, int wave, int variation)
{
    Formation result{};
    if (flags < 0 || wave < 0 || wave >= kWaveCount || variation < 0 || variation >= 8) return result;
    if (flags < 3) result = ParseWave(kOpeningFlags[flags][wave]);
    else
    {
        // Later flags rotate the authored grouping, cap density, and introduce
        // native special abilities instead of increasing enemy statistics.
        const Formation source = ParseWave(kOpeningFlags[2][(wave+(flags%5)*2)%kWaveCount]);
        const int sourceCount = ZombieCount(source);
        const int count = ZombieCount(ParseWave(kOpeningFlags[0][wave])) + 3;
        for (int i = 0; i < count; ++i)
        {
            result[i] = source[i%sourceCount];
            result[i].mX = 800+(i%3)*40;
            const int key = (flags%16 + wave*3 + i*5) % 16;
            const bool water = result[i].mRow == 2 || result[i].mRow == 3;
            if (water)
            {
                constexpr ZombieType types[5] = {ZOMBIE_NORMAL,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,ZOMBIE_SNORKEL,ZOMBIE_DOLPHIN_RIDER};
                result[i].mType = types[(key+flags%5)%5];
            }
            else if (flags >= 6 && key == 0) result[i].mType = ZOMBIE_GARGANTUAR;
            else if (flags >= 5 && key == 2) result[i].mType = ZOMBIE_LADDER;
            else if (flags >= 4 && key == 1) result[i].mType = ZOMBIE_JACK_IN_THE_BOX;
            else if (key%5 == 0) result[i].mType = ZOMBIE_FOOTBALL;
            else if (key%7 == 0) result[i].mType = ZOMBIE_NEWSPAPER;
        }
    }
    for (Spawn& spawn : result) if (spawn.mType != ZOMBIE_INVALID)
        spawn.mRow = TransformRow(spawn.mRow,flags,variation,wave);
    return result;
}
constexpr int ZombiesPerFlag(int flags)
{
    int count = 0;
    for (int wave = 0; wave < kWaveCount; ++wave) count += ZombieCount(WaveFor(flags,wave,0));
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
    {
        const Formation formation = WaveFor(0,wave,0);
        for (int i = 0; i < ZombieCount(formation); ++i) output[wave][i] = formation[i].mType;
    }
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOLPHIN_RIDER));
    for (auto& allowed : output) allowed = false;
    for (int wave = 0; wave < kWaveCount; ++wave) for (const Spawn& spawn : WaveFor(0,wave,0))
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank) { bank.mNumPackets = kBankSize; }
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode) == 87);
static_assert(ZombiesPerFlag(0)==36 && ZombiesPerFlag(1)==46 && ZombiesPerFlag(2)==56 && ZombiesPerFlag(3)==66);
}
