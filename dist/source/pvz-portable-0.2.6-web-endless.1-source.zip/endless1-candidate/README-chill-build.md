# Pool Panic Endless: source and native tests

Published Pool.1 parent source SHA-256:
9d1cb0b7fdc6e10cb4ea79b869b922d98417b14c829862899c6361f80c7dc988.
Parent: 37,098,165 bytes / 991 entries / 848 production files under
pool1-candidate/source/. Current prefix: endless1-candidate/; production: 852 files.

Pool Panic Endless appends mode87, profile record86 and the fifteenth Bonus
card. Ten formations make a flag. The first three flags contain36,46 and56
native zombies; later density caps at66 and original special types provide
variety. Eight saved spatial variants rotate the four land and two water lanes.
All plants, enemies, effects, health, damage and original saved layouts remain
unchanged. Global Survival classifiers remain unchanged. The new mode alone
uses the original Survival flag label and best-record display, never a finite
completion award or trophy.

Each flag opens a48-packet delivery allowance using the four original single-use
plants. The native conveyor carries accepted packets between flags and keeps
moving at capacity while delivery waits. Only unissued quota expires at a clear.
Existing plants, their health and used mowers carry forward. Only missing empty
rear support cells regain native Lily Pads; existing plants are not healed.
Native mower purchases are respected. A fresh profile has no Pool Cleaners.

The exact boundary saves the completed flags and high-water profile record
through native APIs, then requests the existing browser persistence queue.
The intermission lasts1200 simulation ticks, followed by400 to the next first
formation. Native Save/Continue and Retry remain separate: Retry resets current
progress and preserves the best. The original Menu, speed, pause, conveyor,
progress meter and flag footer provide the interface.

Build normal Release with build-chill.py. All23 native suites are release gates.
Ten silent complete-engine drivers link the exact134 production objects except
main. The new24-case/12-pair matrix uses actual packet/tile input at1x/2x across
two seeds. Twenty independently observed three-flag prefixes end by genuine
native defeat after input stops; no finite victories are claimed. Tests include
native automatic boundary files before any manual save, active-effect saves,
native persisted profile details, lower-score Retry protection, exact packet
accounting, both aquatic types and original single-use activations.

The independent first-three roster fixture authenticates30 formations and138
actors (68 water,70 land) per prefix. All469 original artwork inputs are pinned.
Native MemoryImage exports are visual fixtures, not battle or browser/GPU
parity proof; actual muted-browser inspection is separate. Normal audio remains
available. web-endless.1.patch and pool1-to-endless1.patch reconstruct every
production byte. All retained regressions, fourteen prior cards and accepted
bitmaps remain release gates.
