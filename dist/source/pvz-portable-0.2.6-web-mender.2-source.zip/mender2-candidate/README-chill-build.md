# Mender.2 animation and Almanac revision

Starts from the exact published Mender.1 source archive, SHA-256
`d91f663297f7787be7063f478027cd4935ff4285c9dbed600c1c71703d1e08a3`.
Its 795 source inputs use the mender1-candidate/source/ prefix.

Chill-shroom and Mender-bloom gain clearly readable idle motion, compact native
Almanac catalog portraits, correctly styled statistics/flavor and characterful
descriptions. Mender-bloom is composed from original plant parts; custom chooser
packets move inside the panel. Abilities, unlocks, Chill sprites and serialized
layouts remain unchanged.

Run build-chill.py with the retained local Emscripten toolchain, then the ten
tests/test-*.py production-method suites without launching game/audio output.
package-chill.py authenticates source/build/test pins and reconstructs both raw
upstream and exact Mender.1 parent patches byte for byte. It stages binaries,
web-mender.2.patch, mender1-to-mender2.patch, corresponding source and provenance
in a fresh staging directory. The ZIP prefix is mender2-candidate/.
