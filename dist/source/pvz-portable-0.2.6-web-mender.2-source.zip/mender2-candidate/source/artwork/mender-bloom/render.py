"""Compose Mender-bloom from checksum-pinned original game sprite parts.

No network, AI image tool or generated master supplies current sprite pixels.
The original Sunflower pose supplies the stem/leaves, face and blink. Six wider
native petal pieces are explicitly recolored and arranged as a distinct flower.
"""
from pathlib import Path
import argparse
import colorsys
import hashlib
import json
import math
from PIL import Image, __version__ as PILLOW_VERSION

ROOT = Path(__file__).resolve().parent
VERSION = '0.2.6-web-mender.2'

def sha(raw): return hashlib.sha256(raw).hexdigest()

def read_image(name):
    with Image.open(ROOT / name) as image:
        return image.convert('RGBA')

def place(out, image, x, y, scale_x, scale_y, oversample):
    size = (round(image.width * scale_x * oversample), round(image.height * scale_y * oversample))
    image = image.resize(size, Image.Resampling.LANCZOS)
    out.alpha_composite(image, (round(x * oversample), round(y * oversample)))

def clean(image, threshold):
    image = image.copy()
    image.putdata([(r,g,b,a) if a > threshold else (0,0,0,0)
                   for r,g,b,a in image.get_flattened_data()])
    return image

def tint_petals(image, tint):
    pixels = []
    for r,g,b,a in image.get_flattened_data():
        hue,saturation,value = colorsys.rgb_to_hsv(r/255, g/255, b/255)
        color = colorsys.hsv_to_rgb((hue + tint['hueShift']) % 1,
                                    saturation * tint['saturationScale'], value * tint['valueScale'])
        pixels.append(tuple(round(component * 255) for component in color) + (a,))
    image = image.copy()
    image.putdata(pixels)
    return image

def compose(recipe):
    sample = recipe['oversample']
    size = tuple(value * sample for value in recipe['canvas'])
    stem,head = Image.new('RGBA',size), Image.new('RGBA',size)
    dx,dy = recipe['stem']['translation']
    for part in recipe['stem']['tracks']:
        place(stem, read_image('native/' + part['source']), part['x'] + dx, part['y'] + dy,
              part['sx'], part['sy'], sample)
    petals = recipe['petals']
    for index,angle in enumerate(petals['angles']):
        image = tint_petals(read_image('native/' + petals['sources'][index % len(petals['sources'])]), petals['tint'])
        image = image.resize(tuple(value * sample for value in petals['size']), Image.Resampling.LANCZOS)
        image = image.rotate(petals['axisCorrectionDegrees'] - angle, Image.Resampling.BICUBIC, expand=True)
        radians = math.radians(angle)
        cx = petals['center'][0] + petals['radius'][0] * math.sin(radians)
        cy = petals['center'][1] - petals['radius'][1] * math.cos(radians)
        head.alpha_composite(image,(round(cx * sample - image.width/2),round(cy * sample - image.height/2)))
    face = recipe['face']
    face_image = read_image('native/' + face['source'])
    face_x,face_y = face['position']
    face_sx,face_sy = face['size'][0]/face_image.width, face['size'][1]/face_image.height
    place(head,face_image,face_x,face_y,face_sx,face_sy,sample)
    expression = Image.new('RGBA',(face_image.width * sample,face_image.height * sample))
    place(expression,face_image,0,0,1,1,sample)
    blink = recipe['blink']
    place(expression,read_image('native/' + blink['source']),*blink['facePosition'],*blink['faceScale'],sample)
    expression = expression.resize(tuple(value * sample for value in face['size']),Image.Resampling.LANCZOS)
    closed_head = head.copy()
    closed_head.alpha_composite(expression,(round(face_x * sample),round(face_y * sample)))
    canvas = tuple(recipe['canvas'])
    head = clean(head.resize(canvas,Image.Resampling.LANCZOS),recipe['discardAlphaAtMost'])
    stem = clean(stem.resize(canvas,Image.Resampling.LANCZOS),recipe['discardAlphaAtMost'])
    closed_head = clean(closed_head.resize(canvas,Image.Resampling.LANCZOS),recipe['discardAlphaAtMost'])
    head_blink = head.copy()
    for left,top,right,bottom in recipe['eyeRegions']:
        for y in range(top,bottom):
            for x in range(left,right):
                original = head.getpixel((x,y))
                assert original[3] > 240
                head_blink.putpixel((x,y),closed_head.getpixel((x,y))[:3] + (original[3],))
    canonical = Image.alpha_composite(stem,head)
    blink = Image.alpha_composite(stem,head_blink)
    assert blink.getchannel('A').tobytes() == canonical.getchannel('A').tobytes()
    return {'canonical':canonical,'head':head,'stem':stem,'head-blink':head_blink,'blink':blink}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--header',type=Path,required=True)
    args = parser.parse_args()
    recipe_raw = (ROOT / 'extraction.json').read_bytes()
    generation_raw = (ROOT / 'generation.json').read_bytes()
    native_raw = (ROOT / 'native-provenance.json').read_bytes()
    native = json.loads(native_raw)
    for part in native['sourceInputs']:
        assert sha((ROOT / part['path']).read_bytes()) == part['sha256'], part['path']
    images = compose(json.loads(recipe_raw))
    args.output.mkdir(parents=True,exist_ok=True)
    records = {}
    for name,image in images.items():
        path = args.output / (name+'.png')
        image.save(path,compress_level=9)
        records[name] = {'pngSha256':sha(path.read_bytes()),'rgbaSha256':sha(image.tobytes()),
                         'visibleBounds':image.getbbox(),'width':image.width,'height':image.height}
    header = ['// Generated by artwork/mender-bloom/render.py from original sprite parts. Straight-alpha ARGB.',
              '#pragma once','#include <cstdint>','namespace MenderBloomArt {',
              'inline constexpr int kWidth = 80;','inline constexpr int kHeight = 80;']
    for name,image in [('kArgb',images['canonical']),('kHeadArgb',images['head']),('kStemArgb',images['stem']),('kHeadBlinkArgb',images['head-blink'])]:
        raw = image.tobytes()
        values = [(raw[i+3]<<24)|(raw[i]<<16)|(raw[i+1]<<8)|raw[i+2] for i in range(0,len(raw),4)]
        header.append('inline constexpr uint32_t '+name+'[] = {')
        for start in range(0,len(values),10): header.append('    '+', '.join(f'0x{pixel:08x}u' for pixel in values[start:start+10])+',')
        header.append('};')
    header.append('}')
    args.header.parent.mkdir(parents=True,exist_ok=True)
    args.header.write_text('\n'.join(header)+'\n',encoding='utf-8',newline='\n')
    provenance = {'schema':2,'version':VERSION,'displayName':'Mender-bloom',
        'imageGenerationUsed':False,'historicalImageGenerationUsed':True,
        'historicalGeneratedArtworkActive':False,'standaloneChallengeIllustrations':False,
        'method':'Native Sunflower face, blink, stem and leaves; six recolored original petal pieces',
        'pillowVersion':PILLOW_VERSION,'sourceInputs':native['sourceInputs'],
        'assetBundleId':native['assetBundleId'],'nativeInputsSha256':sha(native_raw),
        'generationSha256':sha(generation_raw),'extractionSha256':sha(recipe_raw),
        'historicalGenerationSha256':sha((ROOT/'generation-history.json').read_bytes()),
        'generatorSha256':sha(Path(__file__).read_bytes()),'headerSha256':sha(args.header.read_bytes()),
        'canonicalRgbaSha256':sha(images['canonical'].tobytes()),'parts':records}
    for name,data in [('generation.json',generation_raw),('extraction.json',recipe_raw),('provenance.json',(json.dumps(provenance,indent=2)+'\n').encode('utf-8'))]:
        (args.output / name).write_bytes(data)
    print(json.dumps(provenance,indent=2))

if __name__ == '__main__': main()
