// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>

class Board;
class GridItem;

namespace ZombotanyVasebreaker
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_ZOMBOTANY_VASEBREAKER;
inline constexpr int kProfileIndex = 96;
inline constexpr int kBoardCount = 5;
inline constexpr int kMaxVases = 30;
inline constexpr int kTransitionTicks = 120;
inline constexpr int kRulesVersion = 1;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(152);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(153);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(154);
inline constexpr ChallengeState kFailed = static_cast<ChallengeState>(155);
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && ((state >= kActive && state <= kFailed) ||
    state == STATECHALLENGE_SCARY_POTTER_MALLETING); }
constexpr bool IsHead(ZombieType type)
{ return type >= ZOMBIE_PEA_HEAD && type <= ZOMBIE_TALLNUT_HEAD; }

struct Vase
{
    int col = -1;
    int row = 0;
    ScaryPotType kind = SCARYPOT_SEED;
    SeedType seed = SEED_NONE;
    ZombieType zombie = ZOMBIE_INVALID;
    int sunCount = 0;
    GridItemState shell = GRIDITEM_STATE_SCARY_POT_QUESTION;
};
struct Puzzle { std::array<Vase, kMaxVases> vases{}; };
extern const std::array<Puzzle, kBoardCount> kBoards;

int VaseCount(int stage);
ZombieType HeadForSpawn(GameMode mode, ZombieType type);
void PopulateAllowedZombies(Board& board);
void PopulateWaves(Board& board);
void PreloadResources();
void Populate(Board& board);
void ResetStage(Board& board, int stage);
void Update(Board& board);
bool CanBreak(Board& board);
void MalletPot(Board& board, GridItem* pot);
void OnPotOpened(Board& board);
bool Validate(const Board& board);
}
