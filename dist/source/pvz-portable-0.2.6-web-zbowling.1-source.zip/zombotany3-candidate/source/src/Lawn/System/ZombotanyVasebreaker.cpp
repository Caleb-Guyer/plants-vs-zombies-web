// SPDX-License-Identifier: LGPL-3.0-or-later
#include "ZombotanyVasebreaker.h"
#include "ZombotanyVasebreakerBoards.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../GridItem.h"
#include "../Coin.h"
#include "../Projectile.h"
#include "../SeedPacket.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/Reanimator.h"
#include <algorithm>

namespace ZombotanyVasebreaker
{
namespace
{
void ClearMallet(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (Reanimation* hammer = board.mApp->ReanimationTryToGet(challenge.mReanimChallenge))
        hammer->ReanimationDie();
    challenge.mReanimChallenge = REANIMATIONID_NULL;
    challenge.mChallengeGridX = challenge.mChallengeGridY = 0;
}

bool AllowedSeed(int stage, SeedType seed)
{
    if (seed == SEED_CHERRYBOMB) return true; // Original, normally priced bank.
    for (const Vase& vase : kBoards[stage].vases)
        if (vase.col >= 0 && vase.kind == SCARYPOT_SEED && vase.seed == seed) return true;
    return false;
}

bool ValidBoards()
{
    for (const Puzzle& puzzle : kBoards)
    {
        bool occupied[9][5]{};
        int count = 0;
        for (const Vase& vase : puzzle.vases)
        {
            if (vase.col == -1) continue;
            if (vase.col < 0 || vase.col >= 9 || vase.row < 0 || vase.row >= 5 || occupied[vase.col][vase.row]) return false;
            occupied[vase.col][vase.row] = true;
            ++count;
            if (vase.shell != GRIDITEM_STATE_SCARY_POT_QUESTION &&
                vase.shell != GRIDITEM_STATE_SCARY_POT_LEAF && vase.shell != GRIDITEM_STATE_SCARY_POT_ZOMBIE) return false;
            if (vase.kind == SCARYPOT_SEED)
            {
                if (vase.seed < SEED_PEASHOOTER || vase.seed >= NUM_SEED_TYPES ||
                    vase.seed == SEED_SUNFLOWER || vase.seed == SEED_TWINSUNFLOWER ||
                    vase.seed == SEED_SUNSHROOM || vase.seed == SEED_HYPNOSHROOM ||
                    vase.zombie != ZOMBIE_INVALID || vase.sunCount != 0) return false;
            }
            else if (vase.kind == SCARYPOT_ZOMBIE)
            {
                if (!IsHead(vase.zombie) || vase.seed != SEED_NONE || vase.sunCount != 0) return false;
            }
            else if (vase.kind == SCARYPOT_SUN)
            {
                if (vase.sunCount <= 0 || vase.sunCount > 6 || vase.seed != SEED_NONE || vase.zombie != ZOMBIE_INVALID) return false;
            }
            else return false;
        }
        if (!count) return false;
    }
    return true;
}
}

int VaseCount(int stage)
{
    if (stage < 0 || stage >= kBoardCount) return 0;
    int count = 0;
    for (const Vase& vase : kBoards[stage].vases) count += vase.col >= 0;
    return count;
}

ZombieType HeadForSpawn(GameMode mode, ZombieType type)
{
    if (!IsMode(mode) || type < ZOMBIE_NORMAL || type >= NUM_ZOMBIE_TYPES || IsHead(type)) return type;
    return ZOMBIE_PEA_HEAD;
}

void PopulateAllowedZombies(Board& board)
{
    for (auto& allowed : board.mZombieAllowed) allowed = false;
    const int stage = std::clamp(board.mChallenge->mSurvivalStage, 0, kBoardCount - 1);
    for (const Vase& vase : kBoards[stage].vases)
        if (vase.col >= 0 && vase.kind == SCARYPOT_ZOMBIE) board.mZombieAllowed[vase.zombie] = true;
}

void PopulateWaves(Board& board)
{
    for (auto& wave : board.mZombiesInWave) for (auto& type : wave) type = ZOMBIE_INVALID;
    board.mNumWaves = kBoardCount;
}

void PreloadResources()
{
    ReanimatorEnsureDefinitionLoaded(REANIM_HAMMER, true);
    for (int type = ZOMBIE_PEA_HEAD; type <= ZOMBIE_TALLNUT_HEAD; ++type)
        Zombie::PreloadZombieResources(static_cast<ZombieType>(type));
    Plant::PreloadPlantResources(SEED_CHERRYBOMB);
    for (const Puzzle& puzzle : kBoards)
        for (const Vase& vase : puzzle.vases)
            if (vase.col >= 0 && vase.kind == SCARYPOT_SEED) Plant::PreloadPlantResources(vase.seed);
}

void Populate(Board& board)
{
    PVZP_ASSERT(ValidBoards());
    Challenge& challenge = *board.mChallenge;
    ClearMallet(board);
    challenge.mSurvivalStage = std::clamp(challenge.mSurvivalStage, 0, kBoardCount - 1);
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = 0;
    challenge.mChallengeScore = kRulesVersion;
    challenge.mScaryPotterPots = VaseCount(challenge.mSurvivalStage);
    // This mode never uses Tree of Wisdom cloud storage. Give every new
    // puzzle deterministic saved bytes without changing any older mode.
    for (int& counter : challenge.mCloudsCounter) counter = 0;
    board.mSunMoney = 0;
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mProgressMeterWidth = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = 100000;
    board.mNextSurvivalStageCounter = 0;
    board.mRiseFromGraveCounter = 0;
    board.mEnableGraveStones = false;
    board.mLevelAwardSpawned = false;
    board.mBonusLawnMowersRemaining = 0;
    board.mSeedBank->mNumPackets = 1;
    board.mSeedBank->mSeedPackets[0].SetPacketType(SEED_CHERRYBOMB);
    board.ClearCursor();
    board.ClearAdviceImmediately();
    PopulateWaves(board);
    PopulateAllowedZombies(board);
    for (const Vase& vase : kBoards[challenge.mSurvivalStage].vases)
    {
        if (vase.col < 0) continue;
        GridItem* item = board.mGridItems.DataArrayAlloc();
        item->mGridItemType = GRIDITEM_SCARY_POT;
        item->mGridItemState = vase.shell;
        item->mGridX = vase.col;
        item->mGridY = vase.row;
        item->mScaryPotType = vase.kind;
        item->mSeedType = vase.seed;
        item->mZombieType = vase.zombie;
        item->mSunCount = vase.sunCount;
        item->mRenderOrder = Board::MakeRenderOrder(RENDER_LAYER_PLANT, vase.row, 0);
    }
}

void ResetStage(Board& board, int stage)
{
    ClearMallet(board);
    board.RefreshSeedPacketFromCursor();
    board.ClearCursor();
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) zombie->DieNoLoot();
    for (Plant* plant : board.mPlants) if (!plant->mDead) plant->Die();
    for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
    for (GridItem* item : board.mGridItems) if (!item->mDead) item->GridItemDie();
    for (Projectile* projectile : board.mProjectiles) if (!projectile->mDead) projectile->Die();
    board.mChallenge->mSurvivalStage = std::clamp(stage, 0, kBoardCount - 1);
    board.mLevelComplete = false;
    Populate(board);
}

bool CanBreak(Board& board)
{
    return board.mApp && board.mChallenge && IsMode(board.mApp->mGameMode) &&
        board.mChallenge->mChallengeState == kActive && !board.mPaused &&
        board.mApp->mGameScene == SCENE_PLAYING && !board.mLevelComplete &&
        !board.HasLevelAwardDropped() && board.mApp->GetDialog(DIALOG_GAME_OVER) == nullptr &&
        board.mApp->GetDialog(DIALOG_CONTINUE) == nullptr &&
        board.mChallenge->mReanimChallenge == REANIMATIONID_NULL;
}

void MalletPot(Board& board, GridItem* pot)
{
    if (!CanBreak(board) || !pot || pot->mDead || pot->mBoard != &board || pot->mGridItemType != GRIDITEM_SCARY_POT) return;
    board.mChallenge->ScaryPotterMalletPot(pot);
}

void OnPotOpened(Board& board)
{
    board.mChallenge->mScaryPotterPots = board.mChallenge->ScaryPotterCountPots();
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) || board.mPaused ||
        board.mTimeStopCounter > 0 || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mLevelComplete || board.HasLevelAwardDropped()) return;
    if (challenge.mChallengeState == kTransition)
    {
        if (--challenge.mChallengeStateCounter > 0) return;
        ClearMallet(board);
        challenge.PuzzleNextStageClear();
        for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
        for (Projectile* projectile : board.mProjectiles) if (!projectile->mDead) projectile->Die();
        Populate(board);
        return;
    }
    if (challenge.mChallengeState == STATECHALLENGE_SCARY_POTTER_MALLETING)
    {
        Reanimation* hammer = board.mApp->ReanimationTryToGet(challenge.mReanimChallenge);
        if (hammer && hammer->mLoopCount <= 0) return;
        if (hammer)
            if (GridItem* pot = board.GetGridItemAt(GRIDITEM_SCARY_POT, challenge.mChallengeGridX, challenge.mChallengeGridY))
                challenge.ScaryPotterOpenPot(pot);
        ClearMallet(board);
        challenge.mChallengeState = kActive;
    }
    if (challenge.mChallengeState != kActive) return;
    OnPotOpened(board);
    if (challenge.mScaryPotterPots || board.AreEnemyZombiesOnScreen()) return;
    ClearMallet(board);
    board.RefreshSeedPacketFromCursor();
    board.ClearCursor();
    board.ClearAdviceImmediately();
    if (challenge.mSurvivalStage == kBoardCount - 1)
    {
        challenge.mChallengeState = kFinished;
        challenge.SpawnLevelAward(4, 2);
    }
    else
    {
        challenge.mChallengeState = kTransition;
        challenge.mChallengeStateCounter = kTransitionTicks;
    }
}

bool Validate(const Board& board)
{
    if (!board.mApp || !board.mChallenge || !board.mSeedBank || !ValidBoards()) return false;
    const Challenge& challenge = *board.mChallenge;
    const int stage = challenge.mSurvivalStage;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) ||
        stage < 0 || stage >= kBoardCount || challenge.mChallengeScore != kRulesVersion ||
        board.mBackground != BACKGROUND_2_NIGHT || board.mNumWaves != kBoardCount ||
        board.mCurrentWave != 0 || board.mTotalSpawnedWaves != 0 || board.mNextSurvivalStageCounter != 0 ||
        board.mSeedBank->mNumPackets != 1 || board.mSeedBank->mSeedPackets[0].mPacketType != SEED_CHERRYBOMB) return false;
    for (int row = 0; row < 5; ++row) if (board.mPlantRow[row] != PLANTROW_NORMAL) return false;
    if (board.mPlantRow[5] != PLANTROW_DIRT) return false;
    for (const auto& wave : board.mZombiesInWave) for (ZombieType type : wave) if (type != ZOMBIE_INVALID) return false;
    int pots = 0;
    bool occupied[9][5]{};
    for (GridItem* item : board.mGridItems)
    {
        if (item->mDead) continue;
        if (item->mGridItemType == GRIDITEM_CRATER && AllowedSeed(stage, SEED_DOOMSHROOM)) continue;
        if (item->mGridItemType != GRIDITEM_SCARY_POT || item->mGridX < 0 || item->mGridX >= 9 ||
            item->mGridY < 0 || item->mGridY >= 5 || occupied[item->mGridX][item->mGridY]) return false;
        occupied[item->mGridX][item->mGridY] = true;
        bool matched = false;
        for (const Vase& vase : kBoards[stage].vases)
            if (vase.col == item->mGridX && vase.row == item->mGridY && vase.kind == item->mScaryPotType &&
                vase.seed == item->mSeedType && vase.zombie == item->mZombieType &&
                vase.sunCount == item->mSunCount && vase.shell == item->mGridItemState) matched = true;
        if (!matched) return false;
        ++pots;
    }
    if (pots != challenge.mScaryPotterPots) return false;
    bool enemies = false;
    for (Zombie* zombie : board.mZombies)
    {
        if (zombie->mDead) continue;
        if (!IsHead(zombie->mZombieType)) return false;
        if (zombie->mHasHead && !zombie->IsDeadOrDying() && !zombie->mMindControlled) enemies = true;
    }
    for (Plant* plant : board.mPlants) if (!plant->mDead && !AllowedSeed(stage, plant->mSeedType)) return false;
    for (Coin* coin : board.mCoins)
        if (!coin->mDead && coin->mType == COIN_USABLE_SEED_PACKET && !AllowedSeed(stage, coin->mUsableSeedType)) return false;
    if (challenge.mChallengeState == STATECHALLENGE_SCARY_POTTER_MALLETING)
    {
        const Reanimation* hammer = board.mApp->ReanimationTryToGet(challenge.mReanimChallenge);
        if (!hammer || hammer->mReanimationType != REANIM_HAMMER ||
            challenge.mChallengeGridX < 0 || challenge.mChallengeGridX >= 9 ||
            challenge.mChallengeGridY < 0 || challenge.mChallengeGridY >= 5) return false;
    }
    else if (challenge.mReanimChallenge != REANIMATIONID_NULL) return false;
    if (challenge.mChallengeState == kTransition && (stage == kBoardCount - 1 || pots ||
        enemies || challenge.mChallengeStateCounter <= 0 ||
        challenge.mChallengeStateCounter > kTransitionTicks)) return false;
    if (challenge.mChallengeState == kFinished && (stage != kBoardCount - 1 || pots || enemies)) return false;
    return true;
}
}
