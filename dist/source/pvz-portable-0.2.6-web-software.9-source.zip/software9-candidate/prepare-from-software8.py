"""Producer-only new candidate creator from authenticated8 source archive.

Requires --source-archive and a fresh --output; never overwrites/releases/builds.
The complete copied9 source, not this helper, is sufficient for a full rebuild.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,shutil,zipfile
EXPECTED='6a6470f33dec2c763c595062fa407fbb691a92d43093a64b1d322b6905d7621b'
def sha(b):return hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--source-archive',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
archive=a.source_archive.resolve();out=a.output.resolve();assert not out.exists(),'New candidate directory required'
assert sha(archive.read_bytes())==EXPECTED
eight=archive.parent
parents={n:{'bytes':(eight/n).stat().st_size,'sha256':sha((eight/n).read_bytes())} for n in ['package.json','verification.json',archive.name,'web-software.8.patch','software7-to-software8.patch','build/pvz-portable.js','build/pvz-portable.wasm','build/ProjectVersion.h']}
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.infolist())==794
 entries={n.removeprefix('software8-candidate/source/'):z.read(n) for n in z.namelist() if n.startswith('software8-candidate/source/')}
assert len(entries)==757
for n,b in entries.items():
 q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts
 assert b==(eight/'source'/n).read_bytes(),n
out.mkdir()
for n,b in entries.items():
 target=out/'source'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
parent={'schemaVersion':1,'candidate':'0.2.6-web-software.8','archive':archive.name,'archiveSha256':EXPECTED,'archiveEntries':794,'sourceFiles':{n:sha(b) for n,b in entries.items()},'sourceBytes':sum(map(len,entries.values())),'artifactRecords':parents}
(out/'software8-parent.json').write_text(json.dumps(parent,indent=2)+'\n',encoding='utf8',newline='\n')
version=out/'source/CMake/ProjectVersion.cmake';b=version.read_bytes();assert b.count(b'0.2.6-web-software.8')==1;version.write_bytes(b.replace(b'0.2.6-web-software.8',b'0.2.6-web-software.9'))
include=out/'source/src/PvzpLib/PvzpDrawTriangle.inc';b=include.read_bytes()
old=b'#if (TRI0==1) && (TRI2==1) && ((TRI3==0) || ((TRI4==0) && (TRI5==1)))'
new=b'#if (TRI0==1) && (TRI2==1) && ((TRI3==0) || ((TRI4==0) && ((TRI5==1) || defined(NAME_ADDITIVE))))'
assert b.count(old)==1;b=b.replace(old,new)
anchor=b'#if defined(GLOBAL_ARGB)\n        && globalDiffuse.a <= 255 && globalDiffuse.r <= 255 && globalDiffuse.g <= 255 && globalDiffuse.b <= 255\n#endif\n'
assert b.count(anchor)==1
constant=b'''#if defined(NAME_ADDITIVE) && (TRI3==1) && (TRI4==0) && (TRI5==0)
        // Only the newly admitted nearest-additive family requires constant
        // input vertex color; unproved gradients retain the existing path.
        && pVerts[0].a == pVerts[1].a && pVerts[0].a == pVerts[2].a
        && pVerts[0].r == pVerts[1].r && pVerts[0].r == pVerts[2].r
        && pVerts[0].g == pVerts[1].g && pVerts[0].g == pVerts[2].g
        && pVerts[0].b == pVerts[1].b && pVerts[0].b == pVerts[2].b
#endif
'''
b=b.replace(anchor,anchor+constant);include.write_bytes(b)
for name in ['build-candidate.ps1','build-and-record.py']:
 b=(eight/name).read_bytes()
 if name.endswith('.py'):b=b.replace(b'Software.8',b'Software.9').replace(b'software8-candidate',b'software9-candidate')
 (out/name).write_bytes(b)
shutil.copyfile(Path(__file__),out/'prepare-from-software8.py')
changed=[]
for n,b in entries.items():
 if (out/'source'/n).read_bytes()!=b:changed.append(n)
assert sorted(changed)==['CMake/ProjectVersion.cmake','src/PvzpLib/PvzpDrawTriangle.inc']
assert not(out/'build').exists() and not(out/'source/.git').exists()
assert all({'bytes':(eight/n).stat().st_size,'sha256':sha((eight/n).read_bytes())}==v for n,v in parents.items())
receipt={'status':'PASS isolated authenticated8 source copied; two scoped9 source edits; UNBUILT',
 'sourceFiles':757,'sourceBytesBefore':sum(map(len,entries.values())),'unchangedFiles':755,'changedPaths':sorted(changed),
 'candidate':'0.2.6-web-software.9','parentArchiveSha256':EXPECTED,'parentArchiveEntries':794,
 'sourcePins':{n:sha((out/'source'/n).read_bytes()) for n in changed},
 'parentArtifactsUnchanged':True,'newCmakeBuildDirectory':True,'buildStarted':False,
 'scope':'Only version and ADDITIVE-only RGB888/TEX_ALPHA/MOD1/GLOB0/nearest admission plus constant-input-color guard. Existing pixel/sampler/geometry/context/audio code unchanged. No original execution or ordinary additive-scene claim.'}
(out/'scaffold-preparation.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(receipt,indent=2))
