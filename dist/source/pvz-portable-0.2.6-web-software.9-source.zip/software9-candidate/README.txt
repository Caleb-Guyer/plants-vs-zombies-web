SOFTWARE.9 - CURRENT SOURCE AND FOCUSED VERTEX CORRECTION

This isolated candidate starts from authenticated Software.8 source archive
6a6470f33dec2c763c595062fa407fbb691a92d43093a64b1d322b6905d7621b.
All757 engine files were copied exactly before applying two source changes:
CMake/ProjectVersion.cmake identifies9; PvzpDrawTriangle.inc admits only the
RGB888 TEX_ALPHA MOD1/GLOB0/BLEND0 ADDITIVE specialization to the existing
screen-specific sampler/pixel code, with equal input vertex color required.
All755 other engine files, pixel/sampler math, context, geometry, normal body,
other callbacks and audio remain8. Source8/public16/binaries stay untouched.

This closes a conditional arithmetic API gap for constant input vertex colors
under the existing complete-dimension/UV/interpolant/buffer+pitch guards.
SourceA<=8 is skipped before tint. Otherwise a=A*VA/256 and c=S*VC/256,
then output=min(255,D+c*a/256), highbyteFF. The normal dispatcher already calls
the additive specialization when the game additive flag is true; its normal
preprocessed body is unchanged. Gradient input, offscreen, invalid/unproved
coordinates/colors/dimensions, other formats and combined vertex/global paths
retain8. No global extension, float/scan/clip/UV precision or cache fix is made.

Actual focused reproduction (requires the existing pinned SDK/toolchain):
  python work/portable-build/software9-candidate/verify-source-inputs.py
  python work/portable-build/software9-candidate/vertex-tests/run-paired-tests.py
The guard reads only the included source+parent hashes. The paired runner uses
included authenticated8 fragments; it needs no sibling8 source or binaries.
Outputs go to vertex-tests/results/. Neither command starts an engine/browser,
audio, original executable or service. README in vertex-tests explains scope.

Current focused results per variant:5184normal assertions0failures in both;
5184additive assertions produce2160expected8 failures and0candidate failures;
53824extra fractional/color/alpha/nearest-bound/size assertions produce22720
expected8 failures and0candidate failures.28445state/context checks pass in
both. Total92637assertions each. Fallback and offscreen output hashes match.
Of92 expanded production callbacks, only the intended additive body differs;
the other91 bodies are byte-identical, including its normal dispatcher body.
These are authored fixture/conditional native-equation checks, not native
runtime, full framebuffer, scan geometry or ordinary additive-scene proof.

Ordinary CPU Space-pause Newspaper reanimation supports nearest NORMAL family
source reachability and bounded normal equality. Its extra additive flag is
false. No ordinary additive-nearest scene was established in the bounded
search; that limit does not invalidate the conditional API difference.
Previous7/8 tests/UI/wins remain historical; they were not rerun or relabeled9.
All original content and the full1:1 goal remain required and incomplete.

The root's isolated full Release build recipe is:
  python work/portable-build/software9-candidate/build-and-record.py
This uses the same pinned SDK, fresh9/source+9/build, Release, DO_FIX_BUGS=OFF,
PVZ_DEBUG=OFF, LOW_MEMORY=OFF and parallel4. No8 CMake cache/artifact is reused.
Actual build command/flags/exit/time are recorded in logs/build-result.json;
verification.json records the completed build and static artifact checks only
after a successful result exists. The actual pre-build757-file snapshot is
included and compared with current/post-build source; this is source-freeze
evidence, not a per-object compiler-input attestation. Generated build metadata
is recorded as-is, including an unknown commit date when no.git exists.

Corresponding-source producer recipes (do not start the game):
  python write-provenance.py --parent-archive PATH --upstream-archive PATH
  python package-candidate.py --parent-archive PATH --upstream-archive PATH
The writer accepts --preflight for read-only source/test/recipe checks. Final
provenance requires a real completed Release result. Archive regeneration uses
the exact named/hashed standalone8 and raw0.2.6 source archives for real
git apply --check/apply reconstruction; they are not nested in this archive.
No parent source archive is needed to compile the complete current tree or
run the self-contained new focused test; only patch regeneration needs them.
web-software.9.patch is the raw-upstream combined patch;
software8-to-software9.patch is the two-path incremental patch.
The packager refuses to overwrite an existing corresponding-source archive.
Only the current full source, producer/build recipes, actual new focused
vertex-test inputs/results and build records are included. Old7/8 report/test
trees, compiled engine/test binaries, original assets/executable/disassembly,
actual private/native/QA saves and account state are excluded. Separately
approved runtime resources are not corresponding-source recipe inputs.
No9browser/native/frame/performance/ordinary-additive-scene or fullparity
claim follows from the producer record. Later runtime QA has its own receipt.
Normal player audio is retained; browser testing uses the early quiet guard.

Producer-only prepare-from-software8.py requires an authenticated8 source ZIP
and a NEW output directory. It creates the complete9 source and parent hashes;
it is not a standalone test command and is not needed to rebuild this full tree.
Installed original PE/disassembly/private assets/saves/account data are not
source/package inputs. Native static proof remains in separate private audits.
