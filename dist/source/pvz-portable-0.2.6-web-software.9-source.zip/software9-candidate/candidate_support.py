"""Lean corresponding-source helpers. Importing never builds or starts the game."""
from pathlib import Path, PurePosixPath
import difflib, hashlib, json, os, subprocess, zipfile, zlib

ROOT = Path(__file__).resolve().parent
VERSION = '0.2.6-web-software.9'
PARENT_SHA = '6a6470f33dec2c763c595062fa407fbb691a92d43093a64b1d322b6905d7621b'
PARENT_MANIFEST_SHA = 'd1b40b82c7e51fdfe8e55916d75fe6d7664576d51f4a505a30e4d286b64f18f9'
UPSTREAM_SHA = '40af59aa49d936ad21756a1a28ee14d8db51e6aaccbee44c647c2913e9c83556'
ALLOWED = ['CMake/ProjectVersion.cmake', 'src/PvzpLib/PvzpDrawTriangle.inc']
FLAGS = {'CMAKE_BUILD_TYPE': 'Release', 'DO_FIX_BUGS': 'OFF', 'PVZ_DEBUG': 'OFF', 'LOW_MEMORY': 'OFF'}
VERTEX_BASE = ['src/PvzpLib/EffectSystem.h', 'src/PvzpLib/PvzpDrawTriangle.inc',
    'src/PvzpLib/PvzpDrawTriangleInc.inc', 'src/PvzpLib/PvzpNativeScreenPixel888.inc',
    'src/PvzpLib/PvzpNativeScreenTexel.inc', 'src/SexyAppFramework/graphics/SoftwareScreenImage.cpp',
    'src/SexyAppFramework/graphics/SoftwareScreenImage.h', 'src/SexyAppFramework/graphics/SWTri.cpp',
    'src/SexyAppFramework/graphics/SWTri/SWTri_GetTexel.inc', 'src/SexyAppFramework/graphics/SWTri/SWTri_Loop.inc',
    'src/SexyAppFramework/graphics/SWTri/SWTri_Pixel555.inc', 'src/SexyAppFramework/graphics/SWTri/SWTri_Pixel565.inc',
    'src/SexyAppFramework/graphics/SWTri/SWTri_Pixel888.inc', 'src/SexyAppFramework/graphics/SWTri/SWTri_Pixel8888.inc',
    'src/SexyAppFramework/graphics/SWTri/SWTri_TexelARGB.inc']
VERTEX_FILES = ['README.txt', 'fixtures.cpp', 'run-paired-tests.py', 'native-matrix-rgb888-reference.h',
    'baseline-manifest.json', 'results/results.json']
VERTEX_FILES += ['software8-baseline/' + n for n in VERTEX_BASE]
VERTEX_FILES += ['results/' + v + '/' + n for v in ('software8', 'software9')
    for n in ('actual.cpp', 'expanded.cpp', 'build.log', 'run.log')]
RECIPE_FILES = ['README.txt', 'candidate_support.py', 'build-candidate.ps1', 'build-and-record.py',
    'verify-source-inputs.py', 'prepare-from-software8.py', 'write-provenance.py', 'package-candidate.py',
    'software8-parent.json', 'scaffold-preparation.json', 'pre-build-source-snapshot.json']
PREBUILD_SHA = 'faac248908e3300acc6fe26594641bc9b25cc337e0562e8360fa75ab3d05c2b6'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def record(data):
    return {'bytes': len(data), 'sha256': sha(data), 'crc32': f'{zlib.crc32(data) & 0xffffffff:08x}'}

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf8')

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf8'))

def put_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_bytes(json_bytes(value))
    os.replace(tmp, path)

def safe_name(name):
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and '\\' not in name, name
    return name

def source_bytes():
    out = {}
    for p in sorted((ROOT / 'source').rglob('*')):
        if p.is_file() and '.git' not in p.relative_to(ROOT / 'source').parts:
            out[p.relative_to(ROOT / 'source').as_posix()] = p.read_bytes()
    return out

def authenticated_parent():
    data = (ROOT / 'software8-parent.json').read_bytes()
    assert sha(data) == PARENT_MANIFEST_SHA, 'Initial authenticated parent manifest changed'
    parent = json.loads(data)
    assert parent['archiveSha256'] == PARENT_SHA and len(parent['sourceFiles']) == 757
    return parent

def source_scope():
    parent = authenticated_parent()
    current = source_bytes()
    assert len(current) == 757 and set(current) == set(parent['sourceFiles']), 'Source file set changed'
    changed = sorted(n for n, b in current.items() if sha(b) != parent['sourceFiles'][n])
    assert changed == ALLOWED, ('Unexpected source scope', changed)
    return parent, current, changed

def archive_source(path, expected_sha, prefix, expected_count):
    path = Path(path)
    assert sha(path.read_bytes()) == expected_sha, f'Wrong baseline archive: {path}'
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive members'
        assert z.testzip() is None, 'Bad archive CRC'
        out = {safe_name(n[len(prefix):]): z.read(n) for n in names
            if n.startswith(prefix) and not n.endswith('/')}
    assert len(out) == expected_count, (prefix, len(out))
    return out

def patch_bytes(before, after):
    changes = []
    output = []
    for name in sorted(set(before) | set(after)):
        a, b = before.get(name, b''), after.get(name, b'')
        if a == b:
            continue
        assert not a or a.endswith(b'\n'), f'Unterminated original file: {name}'
        assert not b or b.endswith(b'\n'), f'Unterminated new file: {name}'
        output.extend(difflib.unified_diff(a.decode('utf8').splitlines(keepends=True),
            b.decode('utf8').splitlines(keepends=True),
            fromfile='a/' + name if name in before else '/dev/null',
            tofile='b/' + name if name in after else '/dev/null', n=3))
        changes.append({'path': name, 'beforeSha256': sha(a), 'afterSha256': sha(b)})
    return ''.join(output).encode('utf8'), changes

def tool_paths():
    work = next(p for p in ROOT.parents if (p / 'toolchain').is_dir())
    sdk = work / 'toolchain/emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
    return {'node': sdk / 'node/24.19.0_64bit/bin/node.exe'
        if (sdk / 'node/24.19.0_64bit/bin/node.exe').exists()
        else sdk / 'node/24.19.0_64bit/node.exe'}

def checked(command, **kwargs):
    run = subprocess.run(list(map(str, command)), capture_output=True, text=True, **kwargs)
    assert run.returncode == 0, {'command': list(map(str, command)), 'exitCode': run.returncode,
        'stdout': run.stdout[-4000:], 'stderr': run.stderr[-4000:]}
    return run

def focused_vertex(current):
    results = read_json(ROOT / 'vertex-tests/results/results.json')
    assert results['status'].startswith('PASS')
    assert results['changedSourcePaths'] == ALLOWED and results['unchangedSourceFiles'] == 755
    assert results['changedExpandedCallback'] == 'PvzpDrawTriangle_0888_TEX1_TALPHA1_MOD1_GLOB0_BLEND0_ADDITIVE'
    assert results['normalBodyPreprocessedByteExact'] and results['fallbackAndOffscreenHashesIdentical']
    assert len(results['unchangedExpandedBodiesSha256']) == 91
    expected = {'software8': (2160,22720,1), 'software9': (0,0,0)}
    for variant, (add_fail, extra_fail, exit_code) in expected.items():
        row = results['variants'][variant]
        assert [row[n] for n in ('normalAssertions','additiveAssertions','extraAssertions','stateAssertions')] == [5184,5184,53824,28445]
        assert [row[n] for n in ('normalFailures','additiveFailures','extraFailures','stateFailures','exitCode')] == [0,add_fail,extra_fail,0,exit_code]
        for name, key in [('actual.cpp','actualCppSha256'),('expanded.cpp','expandedCppSha256')]:
            assert sha((ROOT/'vertex-tests/results'/variant/name).read_bytes()) == row[key]
    assert results['variants']['software8']['fallbackHash'] == results['variants']['software9']['fallbackHash']
    assert results['variants']['software8']['offscreenHash'] == results['variants']['software9']['offscreenHash']
    for name, expected in results['variants']['software9']['sourceInputsSha256'].items():
        assert sha(current[name]) == expected, name
    for name, key in [('run-paired-tests.py','runnerSha256'),('fixtures.cpp','fixturesSha256'),
                      ('baseline-manifest.json','baselineManifestSha256'),('native-matrix-rgb888-reference.h','referenceSha256')]:
        assert sha((ROOT/'vertex-tests'/name).read_bytes()) == results[key], name
    baseline = read_json(ROOT/'vertex-tests/baseline-manifest.json')
    assert baseline['parentArchiveSha256'] == PARENT_SHA and set(baseline['files']) == set(VERTEX_BASE)
    parent = authenticated_parent()
    for name, expected in baseline['files'].items():
        assert sha((ROOT/'vertex-tests/software8-baseline'/name).read_bytes()) == expected == parent['sourceFiles'][name], name
    return results

def verify_prebuild(current):
    data = (ROOT/'pre-build-source-snapshot.json').read_bytes()
    assert sha(data) == PREBUILD_SHA, 'Actual prebuild source snapshot changed'
    snapshot = json.loads(data)
    assert snapshot['candidate'] == VERSION and snapshot['changedPathsVs8'] == ALLOWED
    assert snapshot['sourceFiles'] == {n:sha(b) for n,b in current.items()}, 'Current/postbuild source differs from actual prebuild snapshot'
    return snapshot


def file_inputs(names):
    return {n: record((ROOT / n).read_bytes()) for n in sorted(names)}

def assert_immutable_generated(path, data):
    path = Path(path)
    if path.exists():
        assert path.read_bytes() == data, f'Refusing to overwrite different generated file: {path}'
    else:
        path.write_bytes(data)

def git_reconstruct(before, patch, after, fixture):
    fixture = Path(fixture)
    assert not fixture.exists(), f'Fixture exists; choose a new audit directory: {fixture}'
    fixture.mkdir(parents=True)
    for n, data in before.items():
        p = fixture / safe_name(n)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
    checked(['git', 'init', '--quiet', str(fixture)])
    command = ['git', '-C', fixture, '-c', 'core.autocrlf=false', 'apply']
    checked(command + ['--check', str(Path(patch).resolve())])
    checked(command + [str(Path(patch).resolve())])
    actual = {p.relative_to(fixture).as_posix(): p.read_bytes() for p in fixture.rglob('*')
        if p.is_file() and '.git' not in p.relative_to(fixture).parts}
    assert actual == after, 'Real git apply failed to reconstruct every source byte'
    return {'gitApplyCheckExitCode': 0, 'gitApplyExitCode': 0, 'baseFiles': len(before),
        'reconstructedFiles': len(actual), 'everySourceByteMatchesCandidate': True}
