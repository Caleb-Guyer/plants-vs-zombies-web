"""Run the pinned isolated Release recipe, preserving real build stdout/exit."""
from pathlib import Path
import json,subprocess,time
ROOT=Path(__file__).resolve().parent;(ROOT/'logs').mkdir(exist_ok=True)
cmd=['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(ROOT/'build-candidate.ps1')]
start=time.time()
print('Starting private Software.9 pinned Release build; output logs/build.log',flush=True)
with (ROOT/'logs/build.log').open('wb') as log:run=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
receipt={'command':cmd,'exitCode':run.returncode,'elapsedSeconds':round(time.time()-start,3),'flags':{'CMAKE_BUILD_TYPE':'Release','DO_FIX_BUGS':'OFF','PVZ_DEBUG':'OFF','LOW_MEMORY':'OFF'},'scope':'Pinned existing SDK/tool flags; isolated software9-candidate/source and build. No game/runtime initialization.'}
(ROOT/'logs/build-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));raise SystemExit(run.returncode)
