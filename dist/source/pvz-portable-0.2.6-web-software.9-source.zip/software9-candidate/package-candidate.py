"""Package authenticated current source/recipes/new tests, not historical test trees."""
import argparse, json, uuid, zipfile
from pathlib import Path
from candidate_support import *

arg = argparse.ArgumentParser()
arg.add_argument('--parent-archive', type=Path, default=ROOT.parent / 'software8-candidate/pvz-portable-0.2.6-web-software.8-source.zip')
arg.add_argument('--upstream-archive', type=Path, default=ROOT.parents[1] / 'lawn-defense/dist/source/pvz-portable-0.2.6-source.zip')
arg.add_argument('--audit-dir', type=Path, help='New directory for actual git-apply fixtures; defaults to a fresh directory beside this candidate')
args = arg.parse_args()
parent, current, changed = source_scope()
verification = read_json(ROOT / 'verification.json')
assert verification['candidate'] == VERSION and verification['checks']['fullRelease']['exitCode'] == 0
manifest = read_json(ROOT / 'source-manifest.json')
assert manifest['files'] == {n: record(b) for n, b in sorted(current.items())}
for n, expected in verification['producerInputRecords'].items():
    assert record((ROOT / n).read_bytes()) == expected, f'Frozen provenance input changed: {n}'
for a in verification['artifacts']:
    assert record((ROOT / a['path']).read_bytes()) == {k:a[k] for k in ('bytes','sha256','crc32')}, a['path']
focused_vertex(current); verify_prebuild(current)
old = archive_source(args.parent_archive, PARENT_SHA, 'software8-candidate/source/', 757)
upstream = archive_source(args.upstream_archive, UPSTREAM_SHA, 'PvZ-Portable-0.2.6/', 753)
assert patch_bytes(old, current)[0] == (ROOT / 'software8-to-software9.patch').read_bytes()
assert patch_bytes(upstream, current)[0] == (ROOT / 'web-software.9.patch').read_bytes()
assert sha((ROOT / 'web-software.9.patch').read_bytes()) == verification['sourcePatchSha256']
audit_dir = args.audit_dir.resolve() if args.audit_dir else ROOT.parent / ('software9-patch-audit-' + uuid.uuid4().hex)
assert not audit_dir.exists(), 'Audit directory must not already exist'
audit_dir.mkdir(parents=True)
apply = {'upstream': git_reconstruct(upstream, ROOT / 'web-software.9.patch', current, audit_dir / 'upstream'),
         'software8': git_reconstruct(old, ROOT / 'software8-to-software9.patch', current, audit_dir / 'software8')}
apply['scope'] = 'Actual git apply --check/apply on authenticated complete baselines; all757 reconstructed source bytes compared. No normalization/whitespace-ignore fallback.'
put_json(ROOT / 'patch-check.json', apply)
extra = RECIPE_FILES + ['source-manifest.json', 'software9-change-record.json', 'verification.json',
    'web-software.9.patch', 'software8-to-software9.patch', 'patch-check.json', 'logs/build.log', 'logs/build-result.json', 'build/ProjectVersion.h']
extra += ['vertex-tests/' + n for n in VERTEX_FILES]
assert len(extra) == len(set(extra))
prefix = ROOT.name + '/'
members = {prefix + 'source/' + n: b for n, b in current.items()}
members.update({prefix + n: (ROOT / n).read_bytes() for n in extra})
assert len(members) == len(current) + len(extra)
assert all(not any(x in PurePosixPath(n).parts for x in ('.git', 'temp', '__pycache__')) for n in members)
assert all(not n.endswith(('.wasm', '.js', '.o', '.exe', '.dll', '.pak', '.dat', '.zip')) for n in members if not n.startswith(prefix + 'source/'))
archive = ROOT / ('pvz-portable-' + VERSION + '-source.zip')
assert not archive.exists(), 'Source archive already exists; preserve it and choose a separately authorized revision'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, data in sorted(members.items()):
        info = zipfile.ZipInfo(safe_name(n), date_time=(2026, 10, 28, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(members)
    assert set(z.namelist()) == set(members)
    for n, b in members.items():
        assert z.read(n) == b and z.getinfo(n).CRC == (zlib.crc32(b) & 0xffffffff), n
    uncompressed = sum(i.file_size for i in z.infolist())
package = {'candidate': VERSION, 'scope': 'Full Release engine/corresponding source plus newly run focused constant-vertex nearest additive tests; own browser QA pending',
    'sourceArchive': {'path': archive.name, **record(archive.read_bytes()), 'entries': len(members), 'uncompressedBytes': uncompressed},
    'sourceFiles': len(current), 'sourceBytes': sum(map(len,current.values())),
    'sourceDeltaVsSoftware8': read_json(ROOT / 'software9-change-record.json')['changedPaths'],
    'combinedUpstreamPatch': {'path': 'web-software.9.patch', **record((ROOT / 'web-software.9.patch').read_bytes()), 'changedPaths': 23, 'applyCheck': apply['upstream']},
    'software8IncrementalPatch': {'path': 'software8-to-software9.patch', **record((ROOT / 'software8-to-software9.patch').read_bytes()), 'changedPaths': 2, 'applyCheck': apply['software8']},
    'engineArtifacts': verification['artifacts'], 'verification': record((ROOT / 'verification.json').read_bytes()),
    'sourceArchiveAllowlist': sorted(members), 'allEntriesCrcAndByteCompared': True,
    'historicalParentEvidenceOnly': True, 'onlyNewFocusedVertexSuiteIncluded': True,
    'codeArchiveExclusions': ['Git metadata', 'compiled engine/test binaries/objects', 'old Software.7/8 test/report trees',
        'original EXE/PAK/assets/disassembly/native audit data', 'real/private/native/QA saves/settings/account state'],
    'engineInitialized': False, 'browserLaunched': False, 'audioDeviceOpened': False,
    'publicOrStable8Modified': False, 'limits': verification['limits']}
put_json(ROOT / 'package.json', package)
print(json.dumps({'status': 'PASS source archive/CRC/real patch reconstruction', 'sourceArchive': package['sourceArchive'],
    'sourceFiles': len(current), 'sourceBytes': package['sourceBytes'], 'package': record((ROOT / 'package.json').read_bytes())}, indent=2))
