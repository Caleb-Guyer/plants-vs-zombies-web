/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
// Addressed original RGB888 sampler; caller proves complete dimensions/UVs.
unsigned int tex;
#if !defined(LINEAR_BLEND)
{
    const unsigned int position = (v >> 16) * nativeTextureWidth + (u >> 16);
    tex = position < tex_endpos ? pTexture[position] : 0;
}
#else
{
    const int qx = static_cast<int>(u) - 0x8000;
    const int qy = static_cast<int>(v) - 0x8000;
    const int bx = qx > 0 ? qx & ~0xffff : 0;
    const int by = qy > 0 ? qy & ~0xffff : 0;
    const unsigned int dx = qx > 0 && static_cast<unsigned int>(bx >> 16) < nativeTextureWidth - 1 ? 1 : 0;
    const unsigned int dy = qy > 0 && static_cast<unsigned int>(by >> 16) < nativeTextureHeight - 1 ? nativeTextureWidth : 0;
    const unsigned int position = static_cast<unsigned int>(by >> 16) * nativeTextureWidth + static_cast<unsigned int>(bx >> 16);
    const unsigned int pixels[4] = {pTexture[position], pTexture[position + dx],
        pTexture[position + dy], pTexture[position + dx + dy]};
    const unsigned int fx = (static_cast<unsigned int>(qx - bx) & 0xfffe) + 1;
    const unsigned int fy = (static_cast<unsigned int>(qy - by) & 0xfffe) + 1;
    const unsigned int weights[4] = {((0x10000u - fx) * (0x10000u - fy)) >> 16,
        (fx * (0x10000u - fy)) >> 16, ((0x10000u - fx) * fy) >> 16, (fx * fy) >> 16};
    unsigned int alphas[4];
    unsigned int totalAlpha = 0;
    for (int i = 0; i < 4; ++i)
    {
        alphas[i] = ((pixels[i] >> 24) * weights[i]) >> 16;
        totalAlpha += alphas[i];
    }
    tex = (totalAlpha & 255) << 24;
    for (int shift = 0; shift < 24; shift += 8)
    {
        unsigned int sum = 0;
        for (int i = 0; i < 4; ++i)
            sum += ((pixels[i] >> shift) & 255) * alphas[i];
        tex |= ((sum >> 8) & 255) << shift;
    }
}
#endif
unsigned int alpha = tex >> 24;
