/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
// Keep unproved inputs and every offscreen call on the frozen6 implementation.
if (nativeScreenRaster && u <= nativeTextureWidth * 0x10000u && v <= nativeTextureHeight * 0x10000u
#if defined(MOD_ARGB)
    && a <= 0xff0000u && r <= 0xff0000u && g <= 0xff0000u && b <= 0xff0000u
#endif
    )
{
    #include "PvzpLib/PvzpNativeScreenTexel.inc"
    #if defined(NAME_ADDITIVE) && !defined(TEX_ALPHA) && !defined(MOD_ARGB) && defined(GLOBAL_ARGB) && !defined(LINEAR_BLEND)
        // The addressed opaque nearest worker ignores stored texture alpha.
        // Force it before global modulation, including zero/empty texels.
        alpha = 255;
    #endif
    if (alpha > 8)
    {
        // Existing tint interpolation/modulation is independently matched.
        #include "graphics/SWTri/SWTri_TexelARGB.inc"
        unsigned int result = 0xff000000u;
        for (int shift = 0; shift < 24; shift += 8)
        {
            const unsigned int source = (tex >> shift) & 255;
            const unsigned int destination = (*pix >> shift) & 255;
            unsigned int output;
            #if defined(NAME_ADDITIVE)
                #if defined(LINEAR_BLEND)
                    const unsigned int contribution = source;
                #else
                    const unsigned int contribution = (source * alpha) >> 8;
                #endif
                output = destination + contribution;
                if (output > 255) output = 255;
            #else
                if (alpha >= 240)
                    output = source;
                else
                {
                    #if defined(LINEAR_BLEND)
                        const unsigned int contribution = source;
                    #else
                        const unsigned int contribution = (source * alpha) >> 8;
                    #endif
                    output = contribution + ((destination * (255 - alpha)) >> 8);
                }
            #endif
            result |= output << shift;
        }
        *pix = result;
    }
}
else
{
    #include "graphics/SWTri/SWTri_Pixel888.inc"
}
