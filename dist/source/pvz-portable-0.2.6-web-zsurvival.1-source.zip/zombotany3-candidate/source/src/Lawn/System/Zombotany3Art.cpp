// SPDX-License-Identifier: LGPL-3.0-or-later
#include "Zombotany3Art.h"
#include "ReanimationLawn.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Attachment.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/ReanimAtlas.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <cmath>
#include <memory>
#include <vector>

namespace Zombotany3Art
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;
std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}
Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
bool Fit(Sexy::Graphics& graphics, Sexy::MemoryImage& image, float centerX,
    float baseline, float maxWidth, float maxHeight)
{
    const Sexy::Rect bounds = VisibleBounds(image);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return false;
    const float scale = std::min(maxWidth / bounds.mWidth, maxHeight / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, &image,
        centerX - (bounds.mX + bounds.mWidth * .5f) * scale,
        baseline - (bounds.mY + bounds.mHeight) * scale, scale, scale);
    return true;
}
}

bool IsHead(ZombieType type)
{
    return type == ZOMBIE_PUFF_HEAD || type == ZOMBIE_FUME_HEAD || type == ZOMBIE_ICE_HEAD;
}

HeadSpec GetHeadSpec(ZombieType type)
{
    switch (type)
    {
    case ZOMBIE_PUFF_HEAD: return {REANIM_PUFFSHROOM, 69.0f, -28.0f, 1.05f};
    case ZOMBIE_FUME_HEAD: return {REANIM_FUMESHROOM, 62.0f, -22.0f, .90f};
    case ZOMBIE_ICE_HEAD: return {REANIM_ICESHROOM, 60.0f, -18.0f, .85f};
    default: return {REANIM_NONE, 0, 0, 1};
    }
}

Sexy::SexyMatrix3 HeadTransform(ZombieType type)
{
    const HeadSpec spec = GetHeadSpec(type);
    Sexy::SexyMatrix3 transform;
    // This is the original Peashooter-headed zombie's native attachment path.
    // Each complete mushroom keeps its own original cap, face and neck pixels.
    PvzpScaleRotateTransformMatrix(transform, spec.x, spec.y, .2f, -spec.scale, spec.scale);
    return transform;
}

void PrepareBodyRig(Reanimation& carrier)
{
    if (!carrier.TrackExists("anim_head1")) return;
    carrier.AssignRenderGroupToPrefix("anim_hair", RENDER_GROUP_HIDDEN);
    carrier.AssignRenderGroupToPrefix("anim_head2", RENDER_GROUP_HIDDEN);
    carrier.GetTrackInstanceByName("anim_head1")->mImageOverride = Sexy::IMAGE_BLANK;
    carrier.mFrameBasePose = 0;
}

void SetupHead(Zombie& zombie)
{
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return;
    Reanimation* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    if (!carrier || !carrier->TrackExists("anim_head1")) return;
    PrepareBodyRig(*carrier);
    const HeadSpec spec = GetHeadSpec(zombie.mZombieType);
    Reanimation* head = zombie.mApp->AddReanimation(0, 0, 0, spec.reanimation);
    head->PlayReanim("anim_idle", REANIM_LOOP, 0, 15.0f);
    zombie.mSpecialHeadReanimID = zombie.mApp->ReanimationGetID(head);
    auto* track = carrier->GetTrackInstanceByName("anim_head1");
    AttachEffect* attachment = AttachReanim(track->mAttachmentID, head, 0, 0);
    attachment->mOffset = HeadTransform(zombie.mZombieType);
}

void DrawCachedHead(Sexy::Graphics* graphics, Reanimation& carrier, ZombieType type)
{
    if (!IsHead(type) || !carrier.TrackExists("anim_head1")) return;
    Reanimation head;
    head.ReanimationInitializeType(0, 0, GetHeadSpec(type).reanimation);
    head.SetFramesForLayer("anim_idle");
    Sexy::SexyTransform2D anchor;
    carrier.GetAttachmentOverlayMatrix(carrier.FindTrackIndex("anim_head1"), anchor);
    head.mOverlayMatrix = anchor * HeadTransform(type);
    head.mColorOverride = carrier.mColorOverride;
    head.Draw(graphics);
}

bool GetMouthPosition(Zombie& zombie, float& x, float& y)
{
    x = zombie.mPosX; y = zombie.mPosY;
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return false;
    Reanimation* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    Reanimation* head = zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID);
    if (!carrier || !head || !carrier->TrackExists("anim_head1")) return false;
    const char* track = zombie.mZombieType == ZOMBIE_PUFF_HEAD ? "PuffShroom_tip" :
        zombie.mZombieType == ZOMBIE_FUME_HEAD ? "DoomShroom_tip" : "IceShroom_head";
    if (!head->TrackExists(track)) return false;
    Sexy::SexyTransform2D attachment;
    carrier->GetAttachmentOverlayMatrix(carrier->FindTrackIndex("anim_head1"), attachment);
    const Sexy::SexyMatrix3 previous = head->mOverlayMatrix;
    head->mOverlayMatrix = attachment * HeadTransform(zombie.mZombieType);
    const int index = head->FindTrackIndex(track);
    Sexy::SexyTransform2D mouth;
    head->GetTrackMatrix(index, mouth);
    ReanimatorTransform tip;
    head->GetCurrentTransform(index, &tip);
    float width = 0;
    if (tip.mImage && head->mDefinition->mReanimAtlas)
    {
        if (auto* image = head->mDefinition->mReanimAtlas->GetEncodedReanimAtlas(tip.mImage)) width = image->mWidth;
        else if (reinterpret_cast<uintptr_t>(tip.mImage) > 1000) width = tip.mImage->GetCelWidth();
    }
    else if (tip.mImage) width = tip.mImage->GetCelWidth();
    // GetTrackMatrix supplies the original image pivot. The muzzle is the
    // outward edge of the animated native spout, with the whole carrier's
    // normal or Hypno mirror already applied. Body offsets include the native
    // fractional position, so add its integer drawing origin exactly once.
    const float edge = zombie.mZombieType == ZOMBIE_ICE_HEAD ? 0 : std::max(0.0f, width * .5f - 2.0f);
    x = zombie.mX + mouth.m02 + mouth.m00 * edge;
    y = zombie.mY + mouth.m12 + mouth.m10 * edge;
    head->mOverlayMatrix = previous;
    return true;
}

void DrawAttackVisual(Zombie& zombie, Sexy::Graphics* graphics)
{
    if (!IsHead(zombie.mZombieType) || !zombie.mApp || zombie.mDead || !zombie.mHasHead ||
        zombie.mZombiePhase != PHASE_ZOMBIE_NORMAL || zombie.mIceTrapCounter > 0 || zombie.mButteredCounter > 0) return;
    Reanimation* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    if (!carrier || !carrier->TrackExists("anim_head1")) return;
    if (zombie.mZombieType == ZOMBIE_FUME_HEAD && zombie.mBossBungeeCounter < 0 && zombie.mBossBungeeCounter >= -60 &&
        Sexy::IMAGE_PUFFSHROOM_PUFF1)
    {
        const float elapsed = static_cast<float>(60 + zombie.mBossBungeeCounter);
        float worldX, worldY;
        if (!GetMouthPosition(zombie, worldX, worldY)) return;
        const float mouthX = worldX - zombie.mX;
        const float mouthY = worldY - zombie.mY;
        const float direction = zombie.mMindControlled ? 1.0f : -1.0f;
        // Original FumeCloud.xml launches forty puffs, with .7–1.1 scale,
        // fifty-to-sixty-tick particle lives and a late alpha fade. Map its
        // hundred-tick profile onto this existing sixty-tick visual clock.
        // Staggered births and independent native position ranges form a
        // growing cloud rather than a row of equally spaced stamps.
        const uint32_t seed = (static_cast<uint32_t>(zombie.mRow + 1) * 0x9e3779b9u) ^
            (static_cast<uint32_t>(zombie.mFromWave) * 0x85ebca6bu);
        const auto sample = [seed](uint32_t index)
        {
            uint32_t value = seed ^ (index * 0x27d4eb2du);
            value ^= value >> 16; value *= 0x7feb352du;
            value ^= value >> 15; value *= 0x846ca68bu;
            value ^= value >> 16;
            return (value & 0x00ffffffu) / 16777215.0f;
        };
        const float systemFade = std::clamp((60.0f - elapsed) / 12.0f, 0.0f, 1.0f);
        for (int i = 0; i < 40; ++i)
        {
            const float age = elapsed - i * .6f;
            const float lifetime = (50.0f + 10.0f * sample(i * 7 + 1)) * .6f;
            if (age < 0 || age >= lifetime) continue;
            const float time = age / lifetime;
            const float fieldX = sample(i * 7 + 2);
            const float middleX = 16.0f + 224.0f * fieldX;
            const float endX = 20.0f + 220.0f * fieldX;
            const float distance = time < .6f ? middleX * time / .6f :
                middleX + (endX - middleX) * (time - .6f) / .4f;
            const float spread = (sample(i * 7 + 3) * 2.0f - 1.0f) * (5.0f + 15.0f * time) +
                std::sin(sample(i * 7 + 4) * 6.28318530718f + elapsed * .7f) * (1.0f - time);
            const float scale = .7f + .4f * sample(i * 7 + 5);
            const float particleFade = std::clamp((1.0f - time) / .2f, 0.0f, 1.0f);
            const int alpha = static_cast<int>(255.0f * .9f * .9f * particleFade * systemFade);
            Sexy::Graphics puff(*graphics);
            puff.SetColorizeImages(true); puff.SetColor(Sexy::Color(255, 255, 255, alpha));
            PvzpDrawImageScaledF(&puff, Sexy::IMAGE_PUFFSHROOM_PUFF1,
                mouthX + direction * distance - Sexy::IMAGE_PUFFSHROOM_PUFF1->GetWidth() * scale * .5f,
                mouthY + spread - Sexy::IMAGE_PUFFSHROOM_PUFF1->GetHeight() * scale * .5f, scale, scale);
        }
    }
    else if (zombie.mZombieType == ZOMBIE_ICE_HEAD && zombie.mBossBungeeCounter > 0)
    {
        Reanimation* headRig = zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID);
        if (!headRig) return;
        const float charge = std::clamp(1.0f - zombie.mBossBungeeCounter / 125.0f, 0.0f, 1.0f);
        const float pulse = .5f + .5f * std::sin((125 - zombie.mBossBungeeCounter) * .28f);
        Sexy::Graphics glow(*graphics);
        const Sexy::Color previous = headRig->mColorOverride;
        const bool extra = headRig->mEnableExtraAdditiveDraw;
        const bool overlay = headRig->mEnableExtraOverlayDraw;
        headRig->mEnableExtraAdditiveDraw = false;
        headRig->mEnableExtraOverlayDraw = false;
        headRig->mColorOverride = Sexy::Color(90, 190, 255, static_cast<int>(35 + charge * (40 + 45 * pulse)));
        glow.SetDrawMode(Sexy::Graphics::DRAWMODE_ADDITIVE);
        // Redraw the same original frozen cap on its existing attachment;
        // anticipation remains part of the character rather than a HUD icon.
        headRig->Draw(&glow);
        headRig->mColorOverride = previous;
        headRig->mEnableExtraAdditiveDraw = extra;
        headRig->mEnableExtraOverlayDraw = overlay;
    }
}

Sexy::Image* GetImage()
{
    if (sCard) return sCard.get();
    if (!gLawnApp || !gLawnApp->mReanimatorCache ||
        !PvzpLoadResources("DelayLoad_Background2") || !Sexy::IMAGE_BACKGROUND2) return nullptr;
    auto puff = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_PUFF_HEAD);
    auto fume = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_FUME_HEAD);
    auto ice = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_ICE_HEAD);
    if (!puff || !fume || !ice) return nullptr;
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true); picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND2, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 80, 480, 390));
    // All three complete native silhouettes share a lawn baseline. The purple
    // Fume cap is central, with the small Puff and blue Ice heads at its sides.
    if (!Fit(picture, *puff, 13, 63, 25, 43) || !Fit(picture, *fume, 40, 63, 30, 59) ||
        !Fit(picture, *ice, 67, 63, 25, 50)) return nullptr;
    sCard = std::move(card);
    return sCard.get();
}

void DisposeImages() { sCard.reset(); }
}
