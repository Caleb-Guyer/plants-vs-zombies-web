// SPDX-License-Identifier: LGPL-3.0-or-later
#include "Zombotany3.h"
#include "Zombotany3Art.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../Projectile.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpParticle.h"
#include "../../PvzpLib/PvzpFoley.h"
#include "../../PvzpLib/PvzpCommon.h"
#include <algorithm>

namespace Zombotany3
{
namespace
{
bool Eligible(Plant& plant)
{
    return !plant.mDead && !plant.mSquished && plant.mPlantHealth>0 && !plant.NotOnGround();
}
int Range(const Zombie& zombie)
{ return zombie.mZombieType==ZOMBIE_PUFF_HEAD?kPuffRange:zombie.mZombieType==ZOMBIE_FUME_HEAD?kFumeRange:kIceRange; }
int Cadence(const Zombie& zombie)
{ return zombie.mZombieType==ZOMBIE_PUFF_HEAD?kPuffCadence:kFumeCadence; }
int Windup(const Zombie& zombie)
{ return zombie.mZombieType==ZOMBIE_PUFF_HEAD?kPuffWindup:zombie.mZombieType==ZOMBIE_FUME_HEAD?kFumeWindup:kIceWindup; }
Reanimation* Head(Zombie& zombie)
{ return zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID); }
void Idle(Zombie& zombie)
{
    if(Reanimation* head=Head(zombie))
    {
        if(!head->IsAnimPlaying("anim_idle"))head->PlayReanim("anim_idle",REANIM_LOOP,10,15.0f);
        else if(!zombie.IsImmobilizied())head->mAnimRate=15.0f;
    }
}
Zombie* FriendlyTarget(Zombie& source,int range)
{
    Zombie* best=nullptr;
    for(Zombie* target:source.mBoard->mZombies)
    {
        if(target==&source || target->mDead || !target->mHasHead || target->mMindControlled || target->IsDeadOrDying() ||
            target->mRow!=source.mRow || !target->EffectedByDamage(9))continue;
        const float distance=target->mPosX-source.mPosX;
        if(distance<0 || distance>range)continue;
        if(!best || target->mPosX<best->mPosX)best=target;
    }
    return best;
}
bool HasTarget(Zombie& zombie)
{ return zombie.mMindControlled?FriendlyTarget(zombie,Range(zombie))!=nullptr:FindTarget(zombie,Range(zombie))!=nullptr; }
void ShootPuff(Zombie& zombie)
{
    float x=0.0f,y=0.0f;
    if(!Zombotany3Art::GetMouthPosition(zombie,x,y))return;
    // The original puff sprite and trail are centered thirteen pixels from
    // their projectile origin. Center those native pixels on the actual mouth.
    Projectile* projectile=zombie.mBoard->AddProjectile(static_cast<int>(x)-13,static_cast<int>(y)-13,zombie.mRenderOrder+1,zombie.mRow,PROJECTILE_PUFF);
    projectile->mMotionType=zombie.mMindControlled?MOTION_PUFF:MOTION_BACKWARDS;
    projectile->mDamageRangeFlags=zombie.mMindControlled?9:kHostilePuffMarker;
    zombie.mApp->PlayFoley(FOLEY_PUFF);
}
void Fume(Zombie& zombie)
{
    if(zombie.mMindControlled)
    {
        for(Zombie* target:zombie.mBoard->mZombies)
            if(target!=&zombie && !target->mDead && !target->mMindControlled && target->mRow==zombie.mRow &&
                target->mPosX>=zombie.mPosX && target->mPosX-zombie.mPosX<=kFumeRange && target->EffectedByDamage(9))
                target->TakeDamage(kFumeDamage,2);
    }
    else
    {
        for(int col=0;col<9;++col)
        {
            Plant* plant=zombie.mBoard->GetTopPlantAt(col,zombie.mRow,TOPPLANT_EATING_ORDER);
            if(!plant || !Eligible(*plant))continue;
            const float distance=zombie.mPosX+40.0f-(plant->mX+40.0f);
            if(distance<0 || distance>kFumeRange)continue;
            plant->mPlantHealth-=kFumeDamage;
            plant->mEatenFlashCountdown=std::max(plant->mEatenFlashCountdown,25);
            if(plant->mPlantHealth<=0)plant->Die();
        }
    }
    zombie.mApp->PlayFoley(FOLEY_FUME);
}
void Ice(Zombie& zombie)
{
    if(zombie.mMindControlled)
    {
        for(Zombie* target:zombie.mBoard->mZombies)
            if(target!=&zombie && !target->mDead && !target->mMindControlled && target->EffectedByDamage(1))target->HitIceTrap();
    }
    else if(IsMode(zombie.mApp->mGameMode))
    {
        zombie.mBoard->mChallenge->mChallengeStateCounter=std::max(zombie.mBoard->mChallenge->mChallengeStateCounter,kFreezeTicks);
        zombie.mBoard->mChallenge->mChallengeGridX=zombie.mBoard->mMainCounter;
    }
    zombie.mSummonCounter=-1;
    zombie.mApp->PlayFoley(FOLEY_FROZEN);
    zombie.mApp->AddPvzpParticle(zombie.mPosX+50.0f,zombie.mPosY+35.0f,zombie.mRenderOrder+2,PARTICLE_ICE_TRAP);
}
}
void Populate(Board& board)
{
    board.mChallenge->mChallengeState=kActive;
    board.mChallenge->mChallengeGridY=kRulesVersion;
    board.mChallenge->mChallengeStateCounter=0;
    board.mChallenge->mChallengeGridX=0;
    board.mZombieCountDown=board.mZombieCountDownStart=kOpeningDelay;
    board.mShowShovel=true;
}
void Update(Board& board)
{
    if(board.mApp->mGameScene!=SCENE_PLAYING || board.mPaused || board.mTimeStopCounter>0)return;
    // Plants update before zombies, and the challenge updates last. Keep the
    // release tick intact so the next150 actual plant updates are frozen.
    if(board.mChallenge->mChallengeStateCounter>0 && board.mChallenge->mChallengeGridX!=board.mMainCounter)
        --board.mChallenge->mChallengeStateCounter;
}
bool Validate(const Board& board)
{
    return board.mApp && board.mChallenge && IsMode(board.mApp->mGameMode) &&
        board.mChallenge->mChallengeState==kActive && board.mChallenge->mChallengeGridY==kRulesVersion &&
        board.mChallenge->mChallengeStateCounter>=0 && board.mChallenge->mChallengeStateCounter<=kFreezeTicks &&
        board.mChallenge->mChallengeGridX>=0 && board.mChallenge->mChallengeGridX<=board.mMainCounter &&
        board.mNumWaves==kWaveCount && board.mCurrentWave>=0 && board.mCurrentWave<=kWaveCount;
}
void PreloadResources()
{
    for(SeedType seed:{SEED_PUFFSHROOM,SEED_FUMESHROOM,SEED_ICESHROOM})Plant::PreloadPlantResources(seed);
    for(ZombieType type:{ZOMBIE_PUFF_HEAD,ZOMBIE_FUME_HEAD,ZOMBIE_ICE_HEAD})Zombie::PreloadZombieResources(type);
}
void InitializeZombie(Zombie& zombie)
{
    zombie.mVariant=false;
    zombie.mBossBungeeCounter=0;
    zombie.mSummonCounter=Cadence(zombie)-Windup(zombie);
    Zombotany3Art::SetupHead(zombie);
}
Plant* FindTarget(Zombie& zombie,int range)
{
    Plant* best=nullptr;
    for(Plant* plant:zombie.mBoard->mPlants)
    {
        if(!Eligible(*plant) || plant->mRow!=zombie.mRow)continue;
        const float distance=zombie.mPosX+40.0f-(plant->mX+40.0f);
        if(distance<0 || distance>range)continue;
        if(!best || plant->mX>best->mX)best=plant;
    }
    return best;
}
bool IsCharging(const Zombie& zombie)
{ return IsZombie(zombie.mZombieType) && zombie.mBossBungeeCounter>0; }
bool IsSpent(const Zombie& zombie)
{ return zombie.mZombieType==ZOMBIE_ICE_HEAD && zombie.mSummonCounter<0; }
void UpdateZombie(Zombie& zombie)
{
    if(!IsZombie(zombie.mZombieType) || !zombie.IsOnBoard())return;
    if(zombie.mBossBungeeCounter<0)++zombie.mBossBungeeCounter;
    if(!zombie.mHasHead || zombie.IsDeadOrDying() || zombie.mZombiePhase==PHASE_RISING_FROM_GRAVE ||
        zombie.mZombieHeight!=HEIGHT_ZOMBIE_NORMAL || zombie.mPosX>760.0f || zombie.mPosX<0.0f)
    {
        if(zombie.mBossBungeeCounter>0)zombie.mBossBungeeCounter=0;
        return;
    }
    if(zombie.IsImmobilizied())
    {
        if(IsCharging(zombie))
        {
            zombie.mBossBungeeCounter=0;
            zombie.mSummonCounter=std::max(zombie.mSummonCounter,60);
        }
        return;
    }
    if(IsSpent(zombie)) { Idle(zombie);return; }
    if(IsCharging(zombie))
    {
        if(!HasTarget(zombie))
        {
            zombie.mBossBungeeCounter=0;zombie.mSummonCounter=60;Idle(zombie);return;
        }
        --zombie.mBossBungeeCounter;
        if(zombie.mBossBungeeCounter==0)
        {
            if(zombie.mZombieType==ZOMBIE_PUFF_HEAD)ShootPuff(zombie);
            else if(zombie.mZombieType==ZOMBIE_FUME_HEAD)Fume(zombie);
            else Ice(zombie);
            zombie.mBossBungeeCounter=-kPuffLifetime;
            if(zombie.mZombieType!=ZOMBIE_ICE_HEAD)zombie.mSummonCounter=Cadence(zombie)-Windup(zombie);
            Idle(zombie);
        }
        return;
    }
    Idle(zombie);
    if(zombie.mSummonCounter>0)--zombie.mSummonCounter;
    if(zombie.mSummonCounter>0 || !HasTarget(zombie))return;
    zombie.mBossBungeeCounter=Windup(zombie);
    if(Reanimation* head=Head(zombie))
        if(head->TrackExists("anim_shooting"))head->PlayReanim("anim_shooting",REANIM_PLAY_ONCE_AND_HOLD,10,35.0f);
}
bool IsFrozen(const Plant& plant)
{
    return plant.mBoard && plant.mApp && IsMode(plant.mApp->mGameMode) && plant.mApp->mGameScene==SCENE_PLAYING &&
        plant.mBoard->mChallenge && plant.mBoard->mChallenge->mChallengeStateCounter>0 && plant.mIsOnBoard && !plant.mDead;
}
bool UpdateFrozenPlant(Plant& plant)
{
    // Earlier saves can contain a live plant at exactly zero health.
    if(plant.mBoard && plant.mApp && IsMode(plant.mApp->mGameMode) &&
        plant.mApp->mGameScene==SCENE_PLAYING && plant.mIsOnBoard && !plant.mDead && plant.mPlantHealth<=0)
    {
        plant.Die();
        return true;
    }
    if(!IsFrozen(plant))return false;
    if(Reanimation* body=plant.mApp->ReanimationTryToGet(plant.mBodyReanimID))
    {
        body->mColorOverride=Sexy::Color(120,180,255);
        body->mEnableExtraAdditiveDraw=false;
        body->mEnableExtraOverlayDraw=false;
        body->PropogateColorToAttachments();
    }
    return true;
}
bool IsHostilePuff(const Projectile& projectile)
{ return projectile.mProjectileType==PROJECTILE_PUFF && projectile.mDamageRangeFlags==kHostilePuffMarker; }
bool UpdateHostilePuffCollision(Projectile& projectile)
{
    if(!IsHostilePuff(projectile))return false;
    if(projectile.mProjectileAge>=kPuffLifetime) { projectile.Die();return true; }
    const Sexy::Rect projectileRect=projectile.GetProjectileRect();
    for(Plant* candidate:projectile.mBoard->mPlants)
    {
        if(candidate->mRow!=projectile.mRow || !Eligible(*candidate))continue;
        if(GetRectOverlap(projectileRect,candidate->GetPlantRect())<=8)continue;
        Plant* plant=projectile.mBoard->GetTopPlantAt(candidate->mPlantCol,candidate->mRow,TOPPLANT_EATING_ORDER);
        if(!plant || !Eligible(*plant))continue;
        plant->mPlantHealth-=kPuffDamage;
        plant->mEatenFlashCountdown=std::max(plant->mEatenFlashCountdown,25);
        if(plant->mPlantHealth<=0)plant->Die();
        projectile.mApp->PlayFoley(FOLEY_SPLAT);
        projectile.mApp->AddPvzpParticle(projectile.mPosX,projectile.mPosY,projectile.mRenderOrder+1,PARTICLE_PUFF_SPLAT);
        projectile.Die();break;
    }
    return true;
}
}
