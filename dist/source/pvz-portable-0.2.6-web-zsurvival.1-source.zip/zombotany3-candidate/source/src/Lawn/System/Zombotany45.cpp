// SPDX-License-Identifier: LGPL-3.0-or-later
#include "Zombotany45.h"
#include "Zombotany45Art.h"
#include "Zombotany3.h"
#include "Zombotany3Art.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../Projectile.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/PvzpFoley.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/Attachment.h"
#include "../../PvzpLib/EffectSystem.h"
#include "graphics/Image.h"
#include <algorithm>
#include <cmath>

namespace Zombotany45
{
namespace
{
bool Eligible(const Plant& plant)
{ return !plant.mDead && !plant.mSquished && plant.mPlantHealth>0 && !const_cast<Plant&>(plant).NotOnGround(); }
int Range(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaRange:type==ZOMBIE_CABBAGE_HEAD?kCabbageRange:type==ZOMBIE_KERNEL_HEAD?kKernelRange:kMelonRange; }
int Cadence(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaCadence:type==ZOMBIE_CABBAGE_HEAD?kCabbageCadence:type==ZOMBIE_KERNEL_HEAD?kKernelCadence:kMelonCadence; }
int Windup(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaWindup:type==ZOMBIE_CABBAGE_HEAD?kCabbageWindup:type==ZOMBIE_KERNEL_HEAD?kKernelWindup:kMelonWindup; }
Zombie* FriendlyTarget(Zombie& source)
{
    Zombie* best=nullptr;
    const int minimum=IsLobber(source.mZombieType)?kLobMinimumRange:0;
    for(Zombie* target:source.mBoard->mZombies)
    {
        if(target==&source || target->mDead || target->mMindControlled || target->mRow!=source.mRow || !target->EffectedByDamage(9))continue;
        const float distance=target->mPosX-source.mPosX;
        if(distance<minimum || distance>Range(source.mZombieType))continue;
        if(!best || target->mPosX<best->mPosX)best=target;
    }
    return best;
}
void Cancel(Zombie& zombie)
{
    if(zombie.mBossBungeeCounter>0)zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
    zombie.mBossBungeeCounter=0;zombie.mBossMode=0;
    Zombotany45Art::SetIdle(zombie,true);
    if(zombie.mButteredCounter>0)
        if(auto head=zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID))head->mAnimRate=0;
}
void ShootSea(Zombie& zombie)
{
    float x,y;if(!Zombotany45Art::GetMouthPosition(zombie,x,y))return;
    auto projectile=zombie.mBoard->AddProjectile(static_cast<int>(x)-13,static_cast<int>(y)-13,zombie.mRenderOrder+1,zombie.mRow,PROJECTILE_PUFF);
    projectile->mMotionType=zombie.mMindControlled?MOTION_PUFF:MOTION_BACKWARDS;
    // Sea-shroom uses the exact native travelling puff and lethal collision.
    projectile->mDamageRangeFlags=zombie.mMindControlled?9:Zombotany3::kHostilePuffMarker;
    zombie.mApp->PlayFoley(FOLEY_PUFF);
}
Image* LobImage(ProjectileType type)
{
    if(type==PROJECTILE_CABBAGE)return Sexy::IMAGE_REANIM_CABBAGEPULT_CABBAGE;
    if(type==PROJECTILE_KERNEL)return Sexy::IMAGE_REANIM_CORNPULT_KERNAL;
    if(type==PROJECTILE_BUTTER)return Sexy::IMAGE_REANIM_CORNPULT_BUTTER;
    return Sexy::IMAGE_REANIM_MELONPULT_MELON;
}
void ShootLob(Zombie& zombie,Plant* plant,Zombie* target)
{
    float mouthX,mouthY;if(!Zombotany45Art::GetMouthPosition(zombie,mouthX,mouthY))return;
    const ProjectileType type=zombie.mZombieType==ZOMBIE_CABBAGE_HEAD?PROJECTILE_CABBAGE:
        zombie.mZombieType==ZOMBIE_KERNEL_HEAD?(zombie.mBossMode==1?PROJECTILE_BUTTER:PROJECTILE_KERNEL):PROJECTILE_MELON;
    Image* image=LobImage(type);if(!image)return;
    const float pivotX=image->GetCelWidth()*.5f,pivotY=image->GetCelHeight()*.5f;
    float targetX,targetY;
    if(plant){const Sexy::Rect rect=plant->GetPlantRect();targetX=rect.mX+rect.mWidth*.5f;targetY=rect.mY+rect.mHeight*.5f;}
    else {const Sexy::Rect rect=target->GetZombieRect();targetX=rect.mX+rect.mWidth*.5f;targetY=rect.mY+rect.mHeight*.5f;}
    auto p=zombie.mBoard->AddProjectile(static_cast<int>(mouthX-pivotX),static_cast<int>(mouthY-pivotY),zombie.mRenderOrder+1,zombie.mRow,type);
    p->mMotionType=MOTION_LOBBED;
    p->mDamageRangeFlags=zombie.mMindControlled?kFriendlyLobMarker:kHostileLobMarker;
    p->mCobTargetX=targetX;p->mCobTargetRow=zombie.mRow;
    p->mVelX=(targetX-pivotX-p->mPosX)/kLobFlightTicks;
    p->mVelY=(targetY-pivotY-p->mPosY)/kLobFlightTicks;
    p->mAccZ=.15f;p->mVelZ=-p->mAccZ*(kLobFlightTicks+1)*.5f;
    if(target)p->mTargetZombieID=static_cast<ZombieID>(zombie.mBoard->mZombies.DataArrayGetID(target));
    zombie.mApp->PlayFoley(FOLEY_THROW);
}
void ClearButterRow(Challenge& challenge,int row)
{
    challenge.mCloudsCounter[row]=0;
    for(int col=0;col<9;++col)challenge.mBeghouledEated[col][row]=0;
}
void Butter(Plant& plant)
{
    if(!plant.mBoard || !plant.mApp || !IsRoof(plant.mApp->mGameMode) || !Eligible(plant))return;
    Challenge& challenge=*plant.mBoard->mChallenge;
    if(IsButtered(plant))return; // Repeated butter cannot extend an existing pause.
    ClearButterRow(challenge,plant.mRow);
    challenge.mBeghouledEated[plant.mPlantCol][plant.mRow]=static_cast<int32_t>(plant.mBoard->mPlants.DataArrayGetID(&plant));
    challenge.mCloudsCounter[plant.mRow]=plant.mBoard->mMainCounter+kButterTicks;
}
void DamagePlant(Plant* plant,int damage,bool butter)
{
    if(!plant || !Eligible(*plant))return;
    plant->mPlantHealth-=damage;plant->mEatenFlashCountdown=std::max(plant->mEatenFlashCountdown,25);
    if(plant->mPlantHealth<=0)plant->Die();else if(butter)Butter(*plant);
}
bool Umbrella(Projectile& p,int col,int row)
{
    Plant* umbrella=p.mBoard->FindUmbrellaPlant(col,row);
    if(!umbrella || IsButtered(*umbrella))return false;
    if(umbrella->mState==STATE_UMBRELLA_REFLECTING)
    {
        p.mApp->PlayFoley(FOLEY_SPLAT);
        p.mApp->AddPvzpParticle(p.mPosX+20,p.mPosY+p.mPosZ+20,Board::MakeRenderOrder(RENDER_LAYER_TOP,0,1),PARTICLE_UMBRELLA_REFLECT);
        p.Die();
    }
    else if(umbrella->mState!=STATE_UMBRELLA_TRIGGERED)
    {
        p.mApp->PlayFoley(FOLEY_UMBRELLA);umbrella->DoSpecial();
    }
    return true;
}
}
ZombieType PlantHeadForSpawn(GameMode mode,ZombieType type,int row)
{
    if(!IsFamilyMode(mode) || type<ZOMBIE_NORMAL || type>=NUM_ZOMBIE_TYPES || Zombie::IsZombotany(type))return type;
    if(IsRoof(mode))return ZOMBIE_CABBAGE_HEAD;
    if(IsFog(mode))return row==2 || row==3?ZOMBIE_SEA_HEAD:ZOMBIE_PUFF_HEAD;
    return Zombotany3::IsMode(mode)?ZOMBIE_PUFF_HEAD:ZOMBIE_PEA_HEAD;
}
void RestorePlantHeadOnly(Board& board)
{
    const GameMode mode=board.mApp->mGameMode;
    if(!IsFamilyMode(mode))return;
    // The native save contains its future wave table. Normalize old entries
    // without rebuilding waves or changing any course/progress counters.
    for(auto& wave:board.mZombiesInWave)for(auto& type:wave)type=PlantHeadForSpawn(mode,type);
    if(Zombotany3::IsMode(mode))Zombotany3::PopulateAllowedZombies(board.mZombieAllowed);
    else if(IsMode(mode))PopulateAllowedZombies(board.mZombieAllowed,mode);
    else for(int type=0;type<NUM_ZOMBIE_TYPES;++type)
        if(!Zombie::IsZombotany(static_cast<ZombieType>(type)))board.mZombieAllowed[type]=false;
    for(Zombie* zombie:board.mZombies)
    {
        if(zombie->mDead)continue;
        if(!Zombie::IsZombotany(zombie->mZombieType))
        {
            Reanimation* body=board.mApp->ReanimationTryToGet(zombie->mBodyReanimID);
            if((zombie->mZombieType!=ZOMBIE_NORMAL && zombie->mZombieType!=ZOMBIE_FLAG) ||
                !zombie->mHasHead || zombie->IsDeadOrDying() || !body || !body->TrackExists("anim_head1"))
            {
                // Native DieNoLoot also tries to award the level. Its existing
                // dropped-loot guard prevents a migration from granting one.
                zombie->mDroppedLoot=true;
                zombie->DieNoLoot();
                continue;
            }
            if(zombie->mZombieType==ZOMBIE_FLAG && body)
            {
                // Native DropFlag's hand cleanup, without spawning a dropped
                // flag particle or changing the actor's existing animation.
                if(body->TrackExists("Zombie_flaghand"))AttachmentDie(body->GetTrackInstanceByName("Zombie_flaghand")->mAttachmentID);
                body->AssignRenderGroupToPrefix("anim_innerarm",RENDER_GROUP_NORMAL);
                body->AssignRenderGroupToTrack("Zombie_flaghand",RENDER_GROUP_HIDDEN);
                body->AssignRenderGroupToTrack("Zombie_innerarm_screendoor",RENDER_GROUP_HIDDEN);
            }
            if(zombie->mZombatarHeadReanimID!=REANIMATIONID_NULL)
            {
                if(body && body->TrackExists("anim_head1"))AttachmentDie(body->GetTrackInstanceByName("anim_head1")->mAttachmentID);
                board.mApp->RemoveReanimation(zombie->mZombatarHeadReanimID);
                zombie->mZombatarHeadReanimID=REANIMATIONID_NULL;
            }
            board.mApp->RemoveReanimation(zombie->mSpecialHeadReanimID);
            zombie->mSpecialHeadReanimID=REANIMATIONID_NULL;
            zombie->mZombieType=PlantHeadForSpawn(mode,zombie->mZombieType,zombie->mRow);
            zombie->mVariant=false;zombie->mHasObject=false;
            zombie->mBossBungeeCounter=0;zombie->mBossMode=0;
            if(Zombotany3::IsZombie(zombie->mZombieType))
                zombie->mSummonCounter=Zombotany3::kPuffCadence-Zombotany3::kPuffWindup;
            else if(IsZombie(zombie->mZombieType))zombie->mSummonCounter=Cadence(zombie->mZombieType)-Windup(zombie->mZombieType);
            else zombie->mSummonCounter=0;
            // Only the known plain rig is converted. Keep its actor ID,
            // position, health, status, body clock and eating/swim pose.
            body->AssignRenderGroupToTrack("anim_head1",RENDER_GROUP_NORMAL);
            if(Zombotany3::IsZombie(zombie->mZombieType))Zombotany3Art::SetupHead(*zombie);
            else if(IsZombie(zombie->mZombieType))Zombotany45Art::SetupHead(*zombie);
            else
            {
                // Exact original Peashooter head attachment for native1/2.
                body->AssignRenderGroupToPrefix("anim_hair",RENDER_GROUP_HIDDEN);
                body->AssignRenderGroupToPrefix("anim_head2",RENDER_GROUP_HIDDEN);
                auto* track=body->GetTrackInstanceByName("anim_head1");
                track->mImageOverride=Sexy::IMAGE_BLANK;
                Reanimation* head=board.mApp->AddReanimation(0,0,0,REANIM_PEASHOOTER);
                head->PlayReanim("anim_head_idle",REANIM_LOOP,0,15.0f);
                zombie->mSpecialHeadReanimID=board.mApp->ReanimationGetID(head);
                AttachEffect* attachment=AttachReanim(track->mAttachmentID,head,0,0);
                body->mFrameBasePose=0;
                PvzpScaleRotateTransformMatrix(attachment->mOffset,65.0f,-5.0f,.2f,-1.0f,1.0f);
                if(zombie->mZombiePhase==PHASE_ZOMBIE_NORMAL)zombie->mPhaseCounter=150;
            }
            if(auto head=board.mApp->ReanimationTryToGet(zombie->mSpecialHeadReanimID))
            {
                if((zombie->mZombieType==ZOMBIE_PEA_HEAD || zombie->mZombieType==ZOMBIE_PUFF_HEAD) &&
                    gEffectSystem && gEffectSystem->mAttachmentHolder)
                {
                    // AttachReanim links a new head, but its overlay normally
                    // waits for an effect update. Seed the exact saved body's
                    // attachment matrix before the first Continue draw, with
                    // no animation or gameplay clock advancement.
                    auto* track=body->GetTrackInstanceByName("anim_head1");
                    if(auto attachment=gEffectSystem->mAttachmentHolder->mAttachments.DataArrayTryToGet(static_cast<unsigned int>(track->mAttachmentID)))
                    {
                        for(int i=0;i<attachment->mNumEffects;++i)
                        {
                            const AttachEffect& effect=attachment->mEffectArray[i];
                            if(effect.mEffectType!=EffectType::EFFECT_REANIM ||
                                effect.mEffectID!=static_cast<unsigned int>(zombie->mSpecialHeadReanimID))continue;
                            Sexy::SexyTransform2D parent;
                            body->GetAttachmentOverlayMatrix(body->FindTrackIndex("anim_head1"),parent);
                            head->mOverlayMatrix=parent*effect.mOffset;
                            break;
                        }
                    }
                }
                head->mColorOverride=body->mColorOverride;
                head->PropogateColorToAttachments();
                if(zombie->mButteredCounter>0)head->mAnimRate=0.0f;
            }
        }
        if(zombie->mZombieType==ZOMBIE_SEA_HEAD)Zombotany45Art::UpdateHeadAnchor(*zombie);
    }
}
void Populate(Board& board)
{
    auto& c=*board.mChallenge;c.mChallengeState=kActive;c.mChallengeGridY=kRulesVersion;
    c.mChallengeGridX=0;c.mChallengeStateCounter=0;
    for(int row=0;row<6;++row)ClearButterRow(c,row);
    board.mZombieCountDown=board.mZombieCountDownStart=kOpeningDelay;board.mShowShovel=true;
    // Native CutScene::AddFlowerPots supplies the three starting columns.
}
void Update(Board& board)
{
    if(!IsRoof(board.mApp->mGameMode) || board.mApp->mGameScene!=SCENE_PLAYING || board.mPaused || board.mTimeStopCounter>0)return;
    auto& c=*board.mChallenge;
    for(int row=0;row<6;++row)
    {
        bool alive=false;
        for(int col=0;col<9;++col)if(c.mBeghouledEated[col][row])
        {
            auto p=board.mPlants.DataArrayTryToGet(static_cast<unsigned int>(c.mBeghouledEated[col][row]));
            alive|=p && !p->mDead && p->mRow==row && p->mPlantCol==col;
        }
        if(c.mCloudsCounter[row]<=board.mMainCounter || !alive)ClearButterRow(c,row);
    }
}
bool Validate(const Board& board)
{
    if(!board.mApp || !board.mChallenge || !IsMode(board.mApp->mGameMode))return false;
    const auto& c=*board.mChallenge;
    if(c.mChallengeState!=kActive || c.mChallengeGridY!=kRulesVersion || board.mNumWaves!=kWaveCount || board.mCurrentWave<0 || board.mCurrentWave>kWaveCount)return false;
    if(IsFog(board.mApp->mGameMode))return board.mBackground==BACKGROUND_4_FOG;
    if(board.mBackground!=BACKGROUND_5_ROOF)return false;
    for(int row=0;row<6;++row)if(c.mCloudsCounter[row]<0 || c.mCloudsCounter[row]>board.mMainCounter+kButterTicks)return false;
    return true;
}
void PreloadResources(GameMode mode)
{
    if(IsFog(mode))for(SeedType seed:{SEED_SEASHROOM,SEED_PUFFSHROOM,SEED_FUMESHROOM,SEED_PEASHOOTER,SEED_WALLNUT})Plant::PreloadPlantResources(seed);
    else for(SeedType seed:{SEED_CABBAGEPULT,SEED_KERNELPULT,SEED_MELONPULT,SEED_TALLNUT,SEED_FLOWERPOT,SEED_UMBRELLA})Plant::PreloadPlantResources(seed);
    for(ZombieType type:{ZOMBIE_SEA_HEAD,ZOMBIE_CABBAGE_HEAD,ZOMBIE_KERNEL_HEAD,ZOMBIE_MELON_HEAD})Zombie::PreloadZombieResources(type);
}
void InitializeZombie(Zombie& zombie)
{
    zombie.mVariant=false;zombie.mBossBungeeCounter=0;zombie.mBossMode=0;
    zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
    Zombotany45Art::SetupHead(zombie);
}
Plant* FindPlantTarget(Zombie& zombie)
{
    Plant* best=nullptr;
    const bool lob=IsLobber(zombie.mZombieType);
    for(int col=0;col<9;++col)
    {
        Plant* plant=zombie.mBoard->GetTopPlantAt(col,zombie.mRow,lob?TOPPLANT_CATAPULT_ORDER:TOPPLANT_EATING_ORDER);
        if(!plant || !Eligible(*plant))continue;
        const float distance=zombie.mPosX-plant->mX;
        if(distance<(lob?kLobMinimumRange:0) || distance>Range(zombie.mZombieType))continue;
        if(!best || (lob?plant->mX<best->mX:plant->mX>best->mX))best=plant;
    }
    return best;
}
bool IsCharging(const Zombie& zombie)
{ return IsZombie(zombie.mZombieType) && zombie.mBossBungeeCounter>0; }
void UpdateZombie(Zombie& zombie)
{
    if(!IsZombie(zombie.mZombieType) || !zombie.IsOnBoard())return;
    if(!zombie.mHasHead || zombie.IsDeadOrDying() || zombie.mZombiePhase==PHASE_RISING_FROM_GRAVE ||
        zombie.mZombieHeight!=HEIGHT_ZOMBIE_NORMAL || zombie.mPosX>760 || zombie.mPosX<0 || zombie.IsImmobilizied())
    { Cancel(zombie);return; }
    Plant* plant=zombie.mMindControlled?nullptr:FindPlantTarget(zombie);
    Zombie* target=zombie.mMindControlled?FriendlyTarget(zombie):nullptr;
    if(zombie.mBossBungeeCounter>0)
    {
        if(!plant && !target){Cancel(zombie);return;}
        --zombie.mBossBungeeCounter;
        if(zombie.mBossBungeeCounter==0)
        {
            if(zombie.mZombieType==ZOMBIE_SEA_HEAD)ShootSea(zombie);else ShootLob(zombie,plant,target);
            zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
            Zombotany45Art::SetIdle(zombie);
        }
        return;
    }
    Zombotany45Art::SetIdle(zombie);
    if(zombie.mSummonCounter>0)--zombie.mSummonCounter;
    if(zombie.mSummonCounter>0 || (!plant && !target))return;
    zombie.mBossBungeeCounter=Windup(zombie.mZombieType);
    zombie.mBossMode=zombie.mZombieType==ZOMBIE_KERNEL_HEAD && Rand(kButterChance)==0?1:0;
    Zombotany45Art::SetAttack(zombie,zombie.mBossMode==1);
}
bool IsLobProjectile(const Projectile& p)
{
    return p.mMotionType==MOTION_LOBBED && (p.mDamageRangeFlags==kHostileLobMarker || p.mDamageRangeFlags==kFriendlyLobMarker) &&
        (p.mProjectileType==PROJECTILE_CABBAGE || p.mProjectileType==PROJECTILE_KERNEL || p.mProjectileType==PROJECTILE_BUTTER || p.mProjectileType==PROJECTILE_MELON);
}
bool UpdateLobMotion(Projectile& p)
{
    if(!IsLobProjectile(p))return false;
    p.mVelZ+=p.mAccZ;p.mPosX+=p.mVelX;p.mPosY+=p.mVelY;p.mPosZ+=p.mVelZ;
    const bool friendly=p.mDamageRangeFlags==kFriendlyLobMarker;
    const int col=p.mBoard->PixelToGridXKeepOnBoard(p.mCobTargetX,0),row=p.mCobTargetRow;
    if(!friendly && p.mProjectileAge>=kLobFlightTicks-kUmbrellaAnticipationTicks)
    {
        if(Umbrella(p,col,row))
        {
            // Native umbrellas open in five ticks. A last-moment planting still
            // intercepts the incoming lob while its original block pose opens.
            if(p.mDead || p.mProjectileAge<kLobFlightTicks)return true;
            p.Die();return true;
        }
    }
    if(p.mProjectileAge<kLobFlightTicks)return true;
    if(friendly)
    {
        Zombie* hit=nullptr;
        for(Zombie* z:p.mBoard->mZombies)if(!z->mDead && !z->mMindControlled && z->mRow==row && z->EffectedByDamage(9) && std::abs(z->mPosX+40-p.mCobTargetX)<=80)
            if(!hit || std::abs(z->mPosX+40-p.mCobTargetX)<std::abs(hit->mPosX+40-p.mCobTargetX))hit=z;
        p.mDamageRangeFlags=9;p.DoImpact(hit);return true;
    }
    if(p.mProjectileType==PROJECTILE_MELON)
    {
        for(int r=std::max(0,row-1);r<=std::min(4,row+1);++r)
            for(int c=std::max(0,col-1);c<=std::min(8,col+1);++c)
                DamagePlant(p.mBoard->GetTopPlantAt(c,r,TOPPLANT_CATAPULT_ORDER),r==row&&c==col?kMelonDamage:kMelonSplashDamage,false);
    }
    else DamagePlant(p.mBoard->GetTopPlantAt(col,row,TOPPLANT_CATAPULT_ORDER),p.GetProjectileDef().mDamage,p.mProjectileType==PROJECTILE_BUTTER);
    // Keep original impact sounds, rotations and particle artwork. Zero range
    // flags prevent an enemy melon effect from damaging its own zombie team.
    p.mDamageRangeFlags=0;p.DoImpact(nullptr);return true;
}
bool IsButtered(const Plant& plant)
{
    if(!plant.mApp || !plant.mBoard || !plant.mBoard->mChallenge || !IsRoof(plant.mApp->mGameMode) ||
        plant.mApp->mGameScene!=SCENE_PLAYING || !plant.mIsOnBoard || plant.mDead || plant.mRow<0 || plant.mRow>=6 || plant.mPlantCol<0 || plant.mPlantCol>=9)return false;
    const auto& c=*plant.mBoard->mChallenge;
    return c.mCloudsCounter[plant.mRow]>=plant.mBoard->mMainCounter && c.mCloudsCounter[plant.mRow]>0 &&
        static_cast<unsigned int>(c.mBeghouledEated[plant.mPlantCol][plant.mRow])==plant.mBoard->mPlants.DataArrayGetID(const_cast<Plant*>(&plant));
}
bool UpdateButteredPlant(Plant& plant)
{
    if(plant.mApp && plant.mBoard && IsMode(plant.mApp->mGameMode) && plant.mApp->mGameScene==SCENE_PLAYING &&
        plant.mIsOnBoard && !plant.mDead && plant.mPlantHealth<=0){plant.Die();return true;}
    return IsButtered(plant);
}
}
