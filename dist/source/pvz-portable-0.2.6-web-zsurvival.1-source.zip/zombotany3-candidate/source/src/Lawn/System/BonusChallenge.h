// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include "NightShift.h"
#include "LanternGlow.h"
#include "GardenShuffle.h"
#include "SeedSwap.h"
#include "IntensiveCare.h"
#include "ChainReaction.h"
#include "RallyZombie.h"
#include "RallyRaid.h"
#include "LightsOut.h"
#include "GarlicRun.h"
#include "BungeeBusiness.h"
#include "CobCannonCommand.h"
#include "PoolPanic.h"
#include "PoolPanicEndless.h"
#include "ScrapYard.h"
#include "VaseAmbush.h"
#include "FireDrill.h"
#include "DoubleAgent.h"
#include "GustChallenge.h"
#include "Zombotany3.h"
#include "Zombotany45.h"
#include <array>
#include <cstddef>
#include <string_view>

// Stable content identity and native data for the first optional challenge.
// The mode owns an unused record in the existing 100-entry profile array;
// it never changes a saved object layout or an original challenge definition.
namespace BonusChallenge
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_CONE_ZONE;
inline constexpr std::string_view kId = "cone-zone";
inline constexpr int kRevision = 1;
inline constexpr int kStartingSun = 150;
inline constexpr int kWaveCount = 20;
inline constexpr int kLargestWave = 16;
inline constexpr std::array<SeedType, 6> kSeeds = {
    SEED_SUNFLOWER, SEED_PEASHOOTER, SEED_WALLNUT,
    SEED_POTATOMINE, SEED_SNOWPEA, SEED_CHERRYBOMB
};
inline constexpr std::array<ZombieType, 4> kPreviewZombies = {
    ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL
};

struct Wave
{
    int mNormal;
    int mCones;
    int mPoles;
    int mBuckets;
};

// A gentle first three waves leave time for sun production. Coneheads become
// the main threat; occasional poles and buckets reward layered defenses.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {1, 0, 0, 0}, {2, 0, 0, 0}, {3, 0, 0, 0}, {2, 1, 0, 0},
    {2, 2, 0, 0}, {2, 3, 0, 0}, {2, 3, 1, 0}, {2, 4, 0, 0},
    {2, 4, 0, 1}, {4, 5, 1, 1}, {2, 4, 0, 1}, {2, 5, 1, 0},
    {2, 4, 0, 2}, {2, 5, 1, 1}, {2, 5, 0, 2}, {2, 6, 1, 1},
    {2, 6, 0, 2}, {2, 5, 2, 2}, {2, 6, 0, 3}, {3, 7, 2, 3}
}};

constexpr bool IsMode(GameMode mode) { return Zombotany45::IsMode(mode) || Zombotany3::IsMode(mode) || GustChallenge::IsMode(mode) || DoubleAgent::IsMode(mode) || FireDrill::IsMode(mode) || VaseAmbush::IsMode(mode) || ScrapYard::IsMode(mode) || PoolPanicEndless::IsMode(mode) || PoolPanic::IsMode(mode) || CobCannonCommand::IsMode(mode) || BungeeBusiness::IsMode(mode) || GarlicRun::IsMode(mode) || LightsOut::IsMode(mode) || mode == kMode || NightShift::IsMode(mode) || LanternGlow::IsMode(mode) || GardenShuffle::IsMode(mode) || SeedSwap::IsMode(mode) || IntensiveCare::IsMode(mode) || ChainReaction::IsMode(mode) || RallyZombie::IsMode(mode) || RallyRaid::IsMode(mode); }
constexpr bool IsFlagWave(int wave) { return wave >= 0 && wave < kWaveCount && (wave + 1) % 10 == 0; }
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    const Wave& entry = kWaves[wave];
    return entry.mNormal + entry.mCones + entry.mPoles + entry.mBuckets + (IsFlagWave(wave) ? 1 : 0);
}

// Fail before touching output when a caller lacks room for the terminator.
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const Wave& entry = kWaves[wave];
    int count = 0;
    if (IsFlagWave(wave)) output[count++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mNormal; ++i) output[count++] = ZOMBIE_NORMAL;
    for (int i = 0; i < entry.mCones; ++i) output[count++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mPoles; ++i) output[count++] = ZOMBIE_POLEVAULTER;
    for (int i = 0; i < entry.mBuckets; ++i) output[count++] = ZOMBIE_PAIL;
    return count;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output)
        for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}

template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_PAIL));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kPreviewZombies) output[zombie] = true;
}

template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}

// Shared routing keeps the original Cone Zone data and helpers unchanged.
constexpr int StartingSun(GameMode mode) { return Zombotany45::IsMode(mode) ? Zombotany45::kStartingSun : Zombotany3::IsMode(mode) ? Zombotany3::kStartingSun : GustChallenge::IsMode(mode) ? GustChallenge::kStartingSun : DoubleAgent::IsMode(mode) ? DoubleAgent::kStartingSun : FireDrill::IsMode(mode) ? FireDrill::kStartingSun : VaseAmbush::IsMode(mode) ? 0 : ScrapYard::IsMode(mode) ? ScrapYard::kStartingSun : PoolPanicEndless::IsMode(mode) ? 0 : PoolPanic::IsMode(mode) ? 0 : CobCannonCommand::IsMode(mode) ? 0 : BungeeBusiness::IsMode(mode) ? BungeeBusiness::kBoards[0].mSun : GarlicRun::IsMode(mode) ? 0 : LightsOut::IsMode(mode) ? 0 : RallyRaid::IsMode(mode) ? RallyRaid::kBoards[0].mSun : RallyZombie::IsMode(mode) ? RallyZombie::kStartingSun : ChainReaction::IsMode(mode) ? 0 : IntensiveCare::IsMode(mode) ? 0 : SeedSwap::IsMode(mode) ? 0 : GardenShuffle::IsMode(mode) ? 0 : LanternGlow::IsMode(mode) ? LanternGlow::kStartingSun : NightShift::IsMode(mode) ? NightShift::kStartingSun : kStartingSun; }
constexpr int SeedCount(GameMode mode) { return Zombotany45::IsMode(mode) ? 0 : Zombotany3::IsMode(mode) ? 0 : GustChallenge::IsMode(mode) ? GustChallenge::kBankSize : DoubleAgent::IsMode(mode) ? static_cast<int>(DoubleAgent::kSeeds.size()) : FireDrill::IsMode(mode) ? static_cast<int>(FireDrill::kSeeds.size()) : VaseAmbush::IsMode(mode) ? 0 : ScrapYard::IsMode(mode) ? static_cast<int>(ScrapYard::kSeeds.size()) : PoolPanicEndless::IsMode(mode) ? PoolPanicEndless::kBankSize : PoolPanic::IsMode(mode) ? PoolPanic::kBankSize : CobCannonCommand::IsMode(mode) ? 0 : BungeeBusiness::IsMode(mode) ? BungeeBusiness::kSeedCount : GarlicRun::IsMode(mode) ? 0 : LightsOut::IsMode(mode) ? 0 : RallyRaid::IsMode(mode) ? RallyRaid::kSeedCount : RallyZombie::IsMode(mode) ? static_cast<int>(RallyZombie::kSeeds.size()) : ChainReaction::IsMode(mode) ? ChainReaction::kSeedCount : IntensiveCare::IsMode(mode) ? IntensiveCare::kSeedCount : SeedSwap::IsMode(mode) ? 0 : GardenShuffle::IsMode(mode) ? 0 : static_cast<int>(LanternGlow::IsMode(mode) ? LanternGlow::kSeeds.size() : NightShift::IsMode(mode) ? NightShift::kSeeds.size() : kSeeds.size()); }

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(GameMode mode, ZombieType (&output)[Waves][Slots])
{
    if (Zombotany45::IsMode(mode)) return Zombotany45::PopulateWaves(output, mode);
    if (Zombotany3::IsMode(mode)) return Zombotany3::PopulateWaves(output);
    if (GustChallenge::IsMode(mode)) return GustChallenge::PopulateWaves(output);
    if (VaseAmbush::IsMode(mode)) return VaseAmbush::PopulateWaves(output);
    if (DoubleAgent::IsMode(mode)) return DoubleAgent::PopulateWaves(output);
    if (FireDrill::IsMode(mode)) return FireDrill::PopulateWaves(output);
    if (ScrapYard::IsMode(mode)) return ScrapYard::PopulateWaves(output);
    if (PoolPanicEndless::IsMode(mode)) return PoolPanicEndless::PopulateWaves(output);
    if (PoolPanic::IsMode(mode)) return PoolPanic::PopulateWaves(output);
    if (CobCannonCommand::IsMode(mode)) return CobCannonCommand::PopulateWaves(output);
    if (BungeeBusiness::IsMode(mode)) return BungeeBusiness::PopulateWaves(output);
    if (GarlicRun::IsMode(mode)) return GarlicRun::PopulateWaves(output);
    if (LightsOut::IsMode(mode)) return LightsOut::PopulateWaves(output);
    if (RallyRaid::IsMode(mode)) return RallyRaid::PopulateWaves(output);
    if (RallyZombie::IsMode(mode)) return RallyZombie::PopulateWaves(output);
    if (ChainReaction::IsMode(mode)) return ChainReaction::PopulateWaves(output);
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::PopulateWaves(output);
    if (SeedSwap::IsMode(mode)) return SeedSwap::PopulateWaves(output);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::PopulateWaves(output);
    return LanternGlow::IsMode(mode) ? LanternGlow::PopulateWaves(output) : NightShift::IsMode(mode) ? NightShift::PopulateWaves(output) : PopulateWaves(output);
}

template<std::size_t Count>
void PopulateAllowedZombies(GameMode mode, bool (&output)[Count])
{
    if (Zombotany45::IsMode(mode)) Zombotany45::PopulateAllowedZombies(output, mode);
    else if (Zombotany3::IsMode(mode)) Zombotany3::PopulateAllowedZombies(output);
    else if (GustChallenge::IsMode(mode)) GustChallenge::PopulateAllowedZombies(output);
    else if (VaseAmbush::IsMode(mode)) VaseAmbush::PopulateAllowedZombies(output);
    else if (DoubleAgent::IsMode(mode)) DoubleAgent::PopulateAllowedZombies(output);
    else if (FireDrill::IsMode(mode)) FireDrill::PopulateAllowedZombies(output);
    else if (ScrapYard::IsMode(mode)) ScrapYard::PopulateAllowedZombies(output);
    else if (PoolPanicEndless::IsMode(mode)) PoolPanicEndless::PopulateAllowedZombies(output);
    else if (PoolPanic::IsMode(mode)) PoolPanic::PopulateAllowedZombies(output);
    else if (CobCannonCommand::IsMode(mode)) CobCannonCommand::PopulateAllowedZombies(output);
    else if (BungeeBusiness::IsMode(mode)) BungeeBusiness::PopulateAllowedZombies(output);
    else if (GarlicRun::IsMode(mode)) GarlicRun::PopulateAllowedZombies(output);
    else if (LightsOut::IsMode(mode)) LightsOut::PopulateAllowedZombies(output);
    else if (RallyRaid::IsMode(mode)) RallyRaid::PopulateAllowedZombies(output);
    else if (RallyZombie::IsMode(mode)) RallyZombie::PopulateAllowedZombies(output);
    else if (ChainReaction::IsMode(mode)) ChainReaction::PopulateAllowedZombies(output);
    else if (IntensiveCare::IsMode(mode)) IntensiveCare::PopulateAllowedZombies(output);
    else if (SeedSwap::IsMode(mode)) SeedSwap::PopulateAllowedZombies(output);
    else if (GardenShuffle::IsMode(mode)) GardenShuffle::PopulateAllowedZombies(output);
    else if (LanternGlow::IsMode(mode)) LanternGlow::PopulateAllowedZombies(output);
    else if (NightShift::IsMode(mode)) NightShift::PopulateAllowedZombies(output);
    else PopulateAllowedZombies(output);
}

template<class Bank>
void FillSeedBank(GameMode mode, Bank& bank)
{
    if (Zombotany45::IsMode(mode)) return;
    if (Zombotany3::IsMode(mode)) return;
    if (GustChallenge::IsMode(mode)) GustChallenge::FillSeedBank(bank);
    else if (VaseAmbush::IsMode(mode)) bank.mNumPackets = 0;
    else if (DoubleAgent::IsMode(mode)) DoubleAgent::FillSeedBank(bank);
    else if (FireDrill::IsMode(mode)) FireDrill::FillSeedBank(bank);
    else if (ScrapYard::IsMode(mode)) ScrapYard::FillSeedBank(bank);
    else if (PoolPanicEndless::IsMode(mode)) PoolPanicEndless::FillSeedBank(bank);
    else if (PoolPanic::IsMode(mode)) PoolPanic::FillSeedBank(bank);
    else if (CobCannonCommand::IsMode(mode)) bank.mNumPackets = 0;
    else if (BungeeBusiness::IsMode(mode)) BungeeBusiness::FillSeedBank(bank);
    else if (GarlicRun::IsMode(mode)) bank.mNumPackets = 0;
    else if (LightsOut::IsMode(mode)) bank.mNumPackets = 0;
    else if (RallyRaid::IsMode(mode)) RallyRaid::FillSeedBank(bank);
    else if (RallyZombie::IsMode(mode)) RallyZombie::FillSeedBank(bank);
    else if (ChainReaction::IsMode(mode)) ChainReaction::FillSeedBank(bank);
    else if (IntensiveCare::IsMode(mode)) IntensiveCare::FillSeedBank(bank);
    else if (SeedSwap::IsMode(mode)) bank.mNumPackets = 0;
    else if (GardenShuffle::IsMode(mode)) bank.mNumPackets = 0;
    else if (LanternGlow::IsMode(mode)) LanternGlow::FillSeedBank(bank);
    else if (NightShift::IsMode(mode)) NightShift::FillSeedBank(bank);
    else FillSeedBank(bank);
}

static_assert(static_cast<int>(kMode) == 73);
// Revision 2 lives in existing serialized Challenge state. Old checkpoints use
// STATECHALLENGE_NORMAL and retain their original bank, waves and mechanics.
inline constexpr ChallengeState kArcadeState = static_cast<ChallengeState>(100);
inline constexpr ChallengeState kColdSetupState = static_cast<ChallengeState>(101);
inline constexpr ChallengeState kColdDefendState = static_cast<ChallengeState>(102);
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{
    if (Zombotany45::IsMode(mode)) return Zombotany45::IsCurrentRules(mode, state);
    if (Zombotany3::IsMode(mode)) return Zombotany3::IsCurrentRules(mode, state);
    if (GustChallenge::IsMode(mode)) return GustChallenge::IsCurrentRules(mode, state);
    if (VaseAmbush::IsMode(mode)) return VaseAmbush::IsCurrentRules(mode, state);
    if (DoubleAgent::IsMode(mode)) return DoubleAgent::IsCurrentRules(mode, state);
    if (FireDrill::IsMode(mode)) return FireDrill::IsCurrentRules(mode, state);
    if (ScrapYard::IsMode(mode)) return ScrapYard::IsCurrentRules(mode, state);
    if (PoolPanicEndless::IsMode(mode)) return PoolPanicEndless::IsCurrentRules(mode, state);
    if (PoolPanic::IsMode(mode)) return PoolPanic::IsCurrentRules(mode, state);
    if (CobCannonCommand::IsMode(mode)) return CobCannonCommand::IsCurrentRules(mode, state);
    if (BungeeBusiness::IsMode(mode)) return BungeeBusiness::IsCurrentRules(mode, state);
    if (GarlicRun::IsMode(mode)) return GarlicRun::IsCurrentRules(mode, state);
    if (LightsOut::IsMode(mode)) return LightsOut::IsCurrentRules(mode, state);
    if (RallyRaid::IsMode(mode)) return RallyRaid::IsCurrentRules(mode, state);
    if (RallyZombie::IsMode(mode)) return RallyZombie::IsCurrentRules(mode, state);
    if (ChainReaction::IsMode(mode)) return ChainReaction::IsCurrentRules(mode, state);
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::IsCurrentRules(mode, state);
    if (SeedSwap::IsMode(mode)) return SeedSwap::IsCurrentRules(mode, state);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::IsCurrentRules(mode, state);
    return (mode == kMode || NightShift::IsMode(mode)) ? state == kArcadeState :
        LanternGlow::IsMode(mode) && (state == kColdSetupState || state == kColdDefendState);
}
constexpr bool IsConveyor(GameMode mode, ChallengeState state)
{
    return GustChallenge::IsCurrentRules(mode, state) || PoolPanicEndless::IsCurrentRules(mode, state) || PoolPanic::IsCurrentRules(mode, state) || ChainReaction::IsCurrentRules(mode, state) || IntensiveCare::IsCurrentRules(mode, state) ||
        ((mode == kMode || NightShift::IsMode(mode)) && state == kArcadeState);
}
constexpr bool IsBowling(GameMode mode, ChallengeState state) { return mode == kMode && state == kArcadeState; }
constexpr bool IsSetup(GameMode mode, ChallengeState state) { return LanternGlow::IsMode(mode) && state == kColdSetupState; }
constexpr bool IsDefending(GameMode mode, ChallengeState state) { return LanternGlow::IsMode(mode) && state == kColdDefendState; }
constexpr int WaveCount(GameMode mode, ChallengeState state)
{
    if (Zombotany45::IsMode(mode)) return Zombotany45::kWaveCount;
    if (Zombotany3::IsMode(mode)) return Zombotany3::kWaveCount;
    if (GustChallenge::IsMode(mode)) return GustChallenge::kWaveCount;
    if (VaseAmbush::IsMode(mode)) return VaseAmbush::kBoardCount;
    if (DoubleAgent::IsMode(mode)) return DoubleAgent::kWaveCount;
    if (FireDrill::IsMode(mode)) return FireDrill::kWaveCount;
    if (ScrapYard::IsMode(mode)) return ScrapYard::kWaveCount;
    if (PoolPanicEndless::IsMode(mode)) return PoolPanicEndless::kWaveCount;
    if (PoolPanic::IsMode(mode)) return PoolPanic::kWaveCount;
    if (CobCannonCommand::IsMode(mode)) return CobCannonCommand::kWaveCount;
    if (BungeeBusiness::IsMode(mode)) return BungeeBusiness::kBoardCount;
    if (GarlicRun::IsMode(mode)) return GarlicRun::kBoardCount;
    if (LightsOut::IsMode(mode)) return LightsOut::kWaveCount;
    if (RallyRaid::IsMode(mode)) return RallyRaid::kBoardCount;
    if (RallyZombie::IsMode(mode)) return RallyZombie::kWaveCount;
    if (ChainReaction::IsMode(mode)) return ChainReaction::kBoardCount;
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::kWaveCount;
    if (SeedSwap::IsMode(mode)) return SeedSwap::kWaveCount;
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::kWaveCount;
    return IsCurrentRules(mode, state) ? (LanternGlow::IsMode(mode) ? LanternGlow::kPuzzleWaveCount : 10) : kWaveCount;
}
constexpr int StartingSun(GameMode mode, ChallengeState state)
{
    if (Zombotany45::IsMode(mode)) return Zombotany45::kStartingSun;
    if (Zombotany3::IsMode(mode)) return Zombotany3::kStartingSun;
    if (GustChallenge::IsMode(mode)) return GustChallenge::kStartingSun;
    if (VaseAmbush::IsMode(mode)) return 0;
    if (DoubleAgent::IsMode(mode)) return DoubleAgent::kStartingSun;
    if (FireDrill::IsMode(mode)) return FireDrill::kStartingSun;
    if (ScrapYard::IsMode(mode)) return ScrapYard::kStartingSun;
    if (BungeeBusiness::IsMode(mode)) return BungeeBusiness::kBoards[0].mSun;
    if (RallyRaid::IsMode(mode)) return RallyRaid::kBoards[0].mSun;
    if (RallyZombie::IsMode(mode)) return RallyZombie::kStartingSun;
    return IsCurrentRules(mode, state) ? (LanternGlow::IsMode(mode) ? LanternGlow::kPuzzleStartingSun : 0) : StartingSun(mode);
}
constexpr int SeedCount(GameMode mode, ChallengeState state)
{
    return IsConveyor(mode, state) ? 10 : SeedCount(mode);
}
// Cone Zone keeps each original zombie's movement, shield and special behavior.
// Their extra cone uses the native cone helmet damage and 370-point armor.
inline constexpr int kConeHelmHealth = 370;
constexpr bool IsConeHeadType(ZombieType type)
{
    return type == ZOMBIE_TRAFFIC_CONE || type == ZOMBIE_FLAG || type == ZOMBIE_DOOR ||
        type == ZOMBIE_NEWSPAPER || type == ZOMBIE_POLEVAULTER || type == ZOMBIE_LADDER ||
        type == ZOMBIE_JACK_IN_THE_BOX || type == ZOMBIE_FOOTBALL;
}
constexpr bool UsesAttachedCone(ZombieType type)
{
    return IsConeHeadType(type) && type != ZOMBIE_TRAFFIC_CONE && type != ZOMBIE_FLAG && type != ZOMBIE_DOOR;
}
inline constexpr std::array<SeedType, 5> kBowlingOpeningSeeds = {
    SEED_WALLNUT, SEED_WALLNUT, SEED_EXPLODE_O_NUT, SEED_WALLNUT, SEED_GIANT_WALLNUT
};
constexpr SeedType BowlingSeedForDelivery(int ordinal, SeedType weightedPick)
{
    return ordinal >= 0 && ordinal < static_cast<int>(kBowlingOpeningSeeds.size()) ? kBowlingOpeningSeeds[ordinal] :
        ordinal >= 0 && ordinal % 8 == 7 ? SEED_GIANT_WALLNUT : weightedPick;
}
inline constexpr std::array<ZombieType, 8> kMiniPreviewZombies = {
    ZOMBIE_TRAFFIC_CONE, ZOMBIE_DOOR, ZOMBIE_NEWSPAPER, ZOMBIE_POLEVAULTER,
    ZOMBIE_LADDER, ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_FOOTBALL, ZOMBIE_FLAG
};
struct MiniWave
{
    int mCones;
    int mDoors;
    int mNewspapers;
    int mPoles;
    int mLadders;
    int mJacks;
    int mFootball;
};
inline constexpr int kMiniWaveCount = 10;
inline constexpr int kMiniLargestWave = 15;
inline constexpr std::array<MiniWave, kMiniWaveCount> kMiniWaves = {{
    {2,0,0,0,0,0,0}, {3,1,0,0,0,0,0}, {3,1,1,0,0,0,0}, {3,1,1,1,0,0,0},
    {3,2,1,1,0,0,0}, {3,2,1,1,1,0,0}, {3,2,1,1,1,1,0}, {3,2,2,1,1,1,1},
    {4,3,2,1,1,1,1}, {5,3,2,1,1,1,1}
}};
constexpr bool MiniFlagWave(int wave) { return wave == kMiniWaveCount - 1; }
constexpr int MiniZombieCount(int wave)
{
    if (wave < 0 || wave >= kMiniWaveCount) return 0;
    const MiniWave& entry = kMiniWaves[wave];
    return entry.mCones + entry.mDoors + entry.mNewspapers + entry.mPoles + entry.mLadders +
        entry.mJacks + entry.mFootball + (MiniFlagWave(wave) ? 1 : 0);
}
constexpr int ComposeMiniWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kMiniWaveCount || !output || capacity <= MiniZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const MiniWave& entry = kMiniWaves[wave];
    int n = 0;
    if (MiniFlagWave(wave)) output[n++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mCones; ++i) output[n++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mDoors; ++i) output[n++] = ZOMBIE_DOOR;
    for (int i = 0; i < entry.mNewspapers; ++i) output[n++] = ZOMBIE_NEWSPAPER;
    for (int i = 0; i < entry.mPoles; ++i) output[n++] = ZOMBIE_POLEVAULTER;
    for (int i = 0; i < entry.mLadders; ++i) output[n++] = ZOMBIE_LADDER;
    for (int i = 0; i < entry.mJacks; ++i) output[n++] = ZOMBIE_JACK_IN_THE_BOX;
    for (int i = 0; i < entry.mFootball; ++i) output[n++] = ZOMBIE_FOOTBALL;
    return n;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateMiniWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kMiniWaveCount && Slots > kMiniLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kMiniWaveCount; ++i) ComposeMiniWave(i, output[i], static_cast<int>(Slots));
    return kMiniWaveCount;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(GameMode mode, ChallengeState state, ZombieType (&output)[Waves][Slots])
{
    if (Zombotany45::IsMode(mode)) return Zombotany45::PopulateWaves(output, mode);
    if (Zombotany3::IsMode(mode)) return Zombotany3::PopulateWaves(output);
    if (GustChallenge::IsMode(mode)) return GustChallenge::PopulateWaves(output);
    if (VaseAmbush::IsMode(mode)) return VaseAmbush::PopulateWaves(output);
    if (DoubleAgent::IsMode(mode)) return DoubleAgent::PopulateWaves(output);
    if (FireDrill::IsMode(mode)) return FireDrill::PopulateWaves(output);
    if (ScrapYard::IsMode(mode)) return ScrapYard::PopulateWaves(output);
    if (PoolPanicEndless::IsMode(mode)) return PoolPanicEndless::PopulateWaves(output);
    if (PoolPanic::IsMode(mode)) return PoolPanic::PopulateWaves(output);
    if (CobCannonCommand::IsMode(mode)) return CobCannonCommand::PopulateWaves(output);
    if (BungeeBusiness::IsMode(mode)) return BungeeBusiness::PopulateWaves(output);
    if (GarlicRun::IsMode(mode)) return GarlicRun::PopulateWaves(output);
    if (LightsOut::IsMode(mode)) return LightsOut::PopulateWaves(output);
    if (RallyRaid::IsMode(mode)) return RallyRaid::PopulateWaves(output);
    if (RallyZombie::IsMode(mode)) return RallyZombie::PopulateWaves(output);
    if (ChainReaction::IsMode(mode)) return ChainReaction::PopulateWaves(output);
    if (IntensiveCare::IsMode(mode)) return IntensiveCare::PopulateWaves(output);
    if (SeedSwap::IsMode(mode)) return SeedSwap::PopulateWaves(output);
    if (GardenShuffle::IsMode(mode)) return GardenShuffle::PopulateWaves(output);
    if (!IsCurrentRules(mode, state)) return PopulateWaves(mode, output);
    if (LanternGlow::IsMode(mode)) return LanternGlow::PopulatePuzzleWaves(output);
    if (NightShift::IsMode(mode)) return NightShift::PopulateMiniWaves(output);
    return PopulateMiniWaves(output);
}
template<std::size_t Count>
void PopulateAllowedZombies(GameMode mode, ChallengeState state, bool (&output)[Count])
{
    if (!IsBowling(mode, state)) { PopulateAllowedZombies(mode, output); return; }
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_JACK_IN_THE_BOX));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kMiniPreviewZombies) output[zombie] = true;
}
template<class Bank>
void FillSeedBank(GameMode mode, ChallengeState state, Bank& bank)
{
    if (Zombotany45::IsMode(mode)) return;
    if (Zombotany3::IsMode(mode)) return;
    if (GustChallenge::IsMode(mode)) { GustChallenge::FillSeedBank(bank); return; }
    if (VaseAmbush::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (DoubleAgent::IsMode(mode)) { DoubleAgent::FillSeedBank(bank); return; }
    if (FireDrill::IsMode(mode)) { FireDrill::FillSeedBank(bank); return; }
    if (ScrapYard::IsMode(mode)) { ScrapYard::FillSeedBank(bank); return; }
    if (PoolPanicEndless::IsMode(mode)) { PoolPanicEndless::FillSeedBank(bank); return; }
    if (PoolPanic::IsMode(mode)) { PoolPanic::FillSeedBank(bank); return; }
    if (BungeeBusiness::IsMode(mode)) { BungeeBusiness::FillSeedBank(bank); return; }
    if (GarlicRun::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (LightsOut::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (RallyRaid::IsMode(mode)) { RallyRaid::FillSeedBank(bank); return; }
    if (RallyZombie::IsMode(mode)) { RallyZombie::FillSeedBank(bank); return; }
    if (ChainReaction::IsMode(mode)) { ChainReaction::FillSeedBank(bank); return; }
    if (IntensiveCare::IsMode(mode)) { IntensiveCare::FillSeedBank(bank); return; }
    if (SeedSwap::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (GardenShuffle::IsMode(mode)) { bank.mNumPackets = 0; return; }
    if (!IsCurrentRules(mode, state)) { FillSeedBank(mode, bank); return; }
    bank.mNumPackets = SeedCount(mode, state);
    if (IsConveyor(mode, state)) return;
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(LanternGlow::kPuzzleSeeds[i]);
    bank.RefreshAllPackets();
}
static_assert(MiniZombieCount(kMiniWaveCount - 1) == kMiniLargestWave);

static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
