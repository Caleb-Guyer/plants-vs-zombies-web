// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include "misc/SexyMatrix.h"

class Zombie;
class Reanimation;
namespace Sexy { class Graphics; class Image; }

namespace Zombotany3Art
{
struct HeadSpec
{
    ReanimationType reanimation;
    float x;
    float y;
    float scale;
};
bool IsHead(ZombieType type);
HeadSpec GetHeadSpec(ZombieType type);
Sexy::SexyMatrix3 HeadTransform(ZombieType type);
void PrepareBodyRig(Reanimation& carrier);
void SetupHead(Zombie& zombie);
void DrawCachedHead(Sexy::Graphics* graphics, Reanimation& carrier, ZombieType type);
bool GetMouthPosition(Zombie& zombie, float& x, float& y);
void DrawAttackVisual(Zombie& zombie, Sexy::Graphics* graphics);
Sexy::Image* GetImage();
void DisposeImages();
}
