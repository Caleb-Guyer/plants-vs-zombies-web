// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>

class Board;

namespace ZombotanySurvival
{
inline constexpr GameMode kMode = GAMEMODE_SURVIVAL_ZOMBOTANY_DAY;
inline constexpr int kProfileIndex = 95;
inline constexpr int kStageCount = 5;
inline constexpr int kWavesPerStage = 10;
inline constexpr int kFlagGoal = 5;
inline constexpr int kStartingSun = 50;
// Existing native heads retain their original health, attacks and animation.
inline constexpr std::array<ZombieType,6> kHeadTypes = {
    ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_SQUASH_HEAD,
    ZOMBIE_GATLING_HEAD, ZOMBIE_TALLNUT_HEAD, ZOMBIE_JALAPENO_HEAD
};
using Wave = std::array<int,6>;
using Stage = std::array<Wave,kWavesPerStage>;
// Pea, Wall-nut, Squash, Gatling Pea, Tall-nut, Jalapeno. The next native
// seed chooser previews exactly the threats in that round before play resumes.
inline constexpr std::array<Stage,kStageCount> kStages = {{
    {{ {1,0,0,0,0,0}, {1,0,0,0,0,0}, {2,0,0,0,0,0}, {2,0,0,0,0,0},
       {2,1,0,0,0,0}, {2,1,0,0,0,0}, {2,1,0,0,0,0}, {3,1,0,0,0,0},
       {3,1,0,0,0,0}, {4,2,0,0,0,0} }},
    {{ {2,0,0,0,0,0}, {2,1,0,0,0,0}, {2,0,1,0,0,0}, {2,1,0,0,0,0},
       {3,1,0,0,0,0}, {2,1,1,0,0,0}, {3,1,0,0,0,0}, {3,1,1,0,0,0},
       {3,2,0,0,0,0}, {4,2,1,0,0,0} }},
    {{ {2,1,0,0,0,0}, {2,1,0,0,0,0}, {2,1,0,1,0,0}, {2,1,1,0,0,0},
       {3,1,0,1,0,0}, {2,1,1,0,0,0}, {3,1,0,0,0,0}, {3,1,0,1,0,0},
       {3,2,1,0,0,0}, {3,2,0,1,0,0} }},
    {{ {2,1,0,0,0,0}, {2,1,0,1,0,0}, {2,1,1,0,0,0}, {2,1,0,0,1,0},
       {2,1,0,1,0,0}, {2,1,1,0,0,0}, {3,1,0,1,0,0}, {3,1,0,0,1,0},
       {3,1,1,1,0,0}, {3,1,0,1,1,0} }},
    {{ {2,1,0,1,0,0}, {2,1,1,0,0,0}, {2,1,0,0,1,0}, {2,1,0,1,0,0},
       {2,1,0,0,0,1}, {3,1,1,1,0,0}, {3,1,0,0,1,0}, {3,1,0,1,0,0},
       {3,1,1,1,0,0}, {3,2,0,1,1,0} }}
}};
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsHead(ZombieType type)
{
    for (const auto head : kHeadTypes) if (type == head) return true;
    return false;
}
// Applies only to this mode; existing Zombotany and Survival modes are untouched.
ZombieType HeadForSpawn(GameMode mode, ZombieType type);
void PopulateAllowedZombies(Board& board);
void PopulateWaves(Board& board);
void PreloadResources();
bool Validate(const Board& board);
}
