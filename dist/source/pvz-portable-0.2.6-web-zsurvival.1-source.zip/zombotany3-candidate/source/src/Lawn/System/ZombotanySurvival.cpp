// SPDX-License-Identifier: LGPL-3.0-or-later
#include "ZombotanySurvival.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include <algorithm>

namespace ZombotanySurvival
{
ZombieType HeadForSpawn(GameMode mode, ZombieType type)
{
    if (!IsMode(mode) || type < ZOMBIE_NORMAL || type >= NUM_ZOMBIE_TYPES || IsHead(type)) return type;
    return ZOMBIE_PEA_HEAD;
}

void PopulateAllowedZombies(Board& board)
{
    for (auto& allowed : board.mZombieAllowed) allowed = false;
    const int stage = std::clamp(board.mChallenge->mSurvivalStage, 0, kStageCount - 1);
    for (const auto& wave : kStages[stage])
        for (std::size_t i = 0; i < wave.size(); ++i)
            if (wave[i] > 0) board.mZombieAllowed[kHeadTypes[i]] = true;
}

void PopulateWaves(Board& board)
{
    const int stage = std::clamp(board.mChallenge->mSurvivalStage, 0, kStageCount - 1);
    for (auto& wave : board.mZombiesInWave) for (auto& type : wave) type = ZOMBIE_INVALID;
    board.mNumWaves = kWavesPerStage;
    for (int wave = 0; wave < kWavesPerStage; ++wave)
    {
        int slot = 0;
        for (std::size_t i = 0; i < kHeadTypes.size(); ++i)
            for (int count = 0; count < kStages[stage][wave][i]; ++count)
                board.mZombiesInWave[wave][slot++] = kHeadTypes[i];
    }
}

void PreloadResources()
{
    for (const auto type : kHeadTypes) Zombie::PreloadZombieResources(type);
}

bool Validate(const Board& board)
{
    if (!board.mApp || !board.mChallenge || !IsMode(board.mApp->mGameMode) ||
        board.mBackground != BACKGROUND_1_DAY || board.mNumWaves != kWavesPerStage ||
        board.mChallenge->mChallengeState != STATECHALLENGE_NORMAL ||
        board.mChallenge->mSurvivalStage < 0 || board.mChallenge->mSurvivalStage >= kStageCount ||
        board.mCurrentWave < 0 || board.mCurrentWave > kWavesPerStage) return false;
    const auto& stage = kStages[board.mChallenge->mSurvivalStage];
    for (int wave = 0; wave < kWavesPerStage; ++wave)
    {
        int slot = 0;
        for (std::size_t i = 0; i < kHeadTypes.size(); ++i)
            for (int count = 0; count < stage[wave][i]; ++count)
                if (board.mZombiesInWave[wave][slot++] != kHeadTypes[i]) return false;
        if (board.mZombiesInWave[wave][slot] != ZOMBIE_INVALID) return false;
    }
    for (const Zombie* zombie : board.mZombies)
        if (!zombie->mDead && !IsHead(zombie->mZombieType)) return false;
    return true;
}
}
