// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include "misc/SexyMatrix.h"

class Zombie;
class Plant;
class Reanimation;
namespace Sexy { class Graphics; class Image; }

namespace Zombotany45Art
{
struct HeadSpec
{
    ReanimationType reanimation;
    float x;
    float y;
    float scale;
};
bool IsHead(ZombieType type);
HeadSpec GetHeadSpec(ZombieType type);
Sexy::SexyMatrix3 HeadTransform(ZombieType type);
void PrepareBodyRig(Reanimation& carrier);
void SetupHead(Zombie& zombie);
// Rebuilds the Sea head's native collar joint from the current animation pose.
// Also used after loading legacy reanimations, before their first render.
void UpdateHeadAnchor(Zombie& zombie);
void SetIdle(Zombie& zombie, bool force = false);
void SetAttack(Zombie& zombie, bool butter = false);
void DrawCachedHead(Sexy::Graphics* graphics, Reanimation& carrier, ZombieType type);
// Returns the actual animated native spout/payload center in world coordinates.
bool GetMouthPosition(Zombie& zombie, float& x, float& y);
void DrawPlantButter(Sexy::Graphics* graphics, Plant& plant, float drawHeightOffset);
Sexy::Image* GetImage(GameMode mode);
void DisposeImages();
}
