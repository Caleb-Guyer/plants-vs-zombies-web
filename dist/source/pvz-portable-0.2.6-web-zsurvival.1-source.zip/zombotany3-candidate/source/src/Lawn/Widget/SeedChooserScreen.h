/*
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef __SEEDCHOOSERSCREEN_H__
#define __SEEDCHOOSERSCREEN_H__

#include "../../ConstEnums.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "widget/Widget.h"
#include <memory>
#include "../System/DeckPresets.h"
using namespace Sexy;

class Board;
class LawnApp;
class GameButton;
class ToolTipWidget;
namespace Sexy
{
	class MTRand;
}

class ChosenSeed
{
public:
	int                     mX;
	int                     mY;
	int                     mTimeStartMotion;
	int                     mTimeEndMotion;
	int                     mStartX;
	int                     mStartY;
	int                     mEndX;
	int                     mEndY;
	SeedType                mSeedType;
	ChosenSeedState         mSeedState;
	int                     mSeedIndexInBank;
	bool                    mRefreshing;
	int                     mRefreshCounter;
	SeedType                mImitaterType;
	bool                    mCrazyDavePicked;
};

class SeedChooserScreen : public Widget
{
private:
	enum
	{
		SeedChooserScreen_Start = 100,
		SeedChooserScreen_Random = 101,
		SeedChooserScreen_ViewLawn = 102,
		SeedChooserScreen_Almanac = 103,
		SeedChooserScreen_Menu = 104,
		SeedChooserScreen_Store = 105,
		SeedChooserScreen_Imitater = 106,
		SeedChooserScreen_Decks = 107
	};

public:
	std::unique_ptr<GameButton> mStartButton;
	std::unique_ptr<GameButton> mRandomButton;
	std::unique_ptr<GameButton> mViewLawnButton;
	std::unique_ptr<GameButton> mStoreButton;
	std::unique_ptr<GameButton> mAlmanacButton;
	std::unique_ptr<GameButton> mMenuButton;
	std::unique_ptr<GameButton> mImitaterButton;
	std::unique_ptr<GameButton> mDecksButton;
	ChosenSeed              mChosenSeeds[NUM_SEED_TYPES];
	LawnApp*                mApp;
	Board*                  mBoard;
	int                     mNumSeedsToChoose;
	int                     mSeedChooserAge;
	int                     mSeedsInFlight;
	int                     mSeedsInBank;
	std::unique_ptr<ToolTipWidget> mToolTip;
	int                     mToolTipSeed;
	int                     mLastMouseX;
	int                     mLastMouseY;
	SeedChooserState        mChooseState;
	int                     mViewLawnTime;

public:
	SeedChooserScreen();
	~SeedChooserScreen() override;

	// Appended seeds keep IDs 75/76/78; unused runtime chooser slots store them.
	// Original enum sentinels, the 53-entry array and all serialized data stay fixed.
	static constexpr int ChooserSeedCount() { return NUM_SEEDS_IN_CHOOSER + 3; }
	static constexpr SeedType ChooserSeedType(int index)
	{
		return index == NUM_SEEDS_IN_CHOOSER ? SEED_LANTERNSHROOM :
			index == NUM_SEEDS_IN_CHOOSER + 1 ? SEED_MENDERBLOOM :
			index == NUM_SEEDS_IN_CHOOSER + 2 ? SEED_GUSTBLOOM : static_cast<SeedType>(index);
	}
	static constexpr bool IsChooserSeed(int type)
	{
		return (type >= SEED_PEASHOOTER && type < NUM_SEEDS_IN_CHOOSER) || type == SEED_LANTERNSHROOM || type == SEED_MENDERBLOOM || type == SEED_GUSTBLOOM;
	}
	static constexpr int ChosenSeedIndex(int type)
	{
		return type == SEED_LANTERNSHROOM ? NUM_SEEDS_IN_CHOOSER :
			type == SEED_MENDERBLOOM ? NUM_SEEDS_IN_CHOOSER + 1 :
			type == SEED_GUSTBLOOM ? NUM_SEEDS_IN_CHOOSER + 2 : type;
	}
	static_assert(NUM_SEEDS_IN_CHOOSER + 3 <= NUM_SEED_TYPES);

	static int   PickFromWeightedArrayUsingSpecialRandSeed(PvzpWeightedArray* theArray, int theCount, MTRand& theLevelRNG);
	void                    CrazyDavePickSeeds();
	bool                    Has7Rows();
	void                    GetSeedPositionInChooser(int theIndex, int& x, int& y);
	float                   GetSeedPacketScaleProgress(const ChosenSeed& theChosenSeed);
	void         GetSeedPositionInBank(int theIndex, int& x, int& y);
	unsigned int SeedNotRecommendedToPick(SeedType theSeedType);
	bool         SeedNotAllowedToPick(SeedType theSeedType);
	bool         SeedNotAllowedDuringTrial(SeedType theSeedType);
	void                    Draw(Graphics* g) override;
	void                    UpdateViewLawn();
	void                    LandFlyingSeed(ChosenSeed& theChosenSeed);
	void                    UpdateCursor();
	void                    Update() override;
	bool         DisplayRepickWarningDialog(const char* theMessage);
	bool                    FlyersAreComming();
	bool                    FlyProtectionCurrentlyPlanted();
	bool                    CheckSeedUpgrade(SeedType theSeedTypeTo, SeedType theSeedTypeFrom);
	void                    OnStartButton();
	void                    PickRandomSeeds();
	virtual void            ButtonDepress(int theId);
	SeedType                SeedHitTest(int x, int y);
	SeedType                FindSeedInBank(int theIndexInBank);
	void         EnableStartButton(bool theEnabled);
	void                    ClickedSeedInBank(ChosenSeed& theChosenSeed);
	void                    ClickedSeedInChooser(ChosenSeed& theChosenSeed);
	void                    ShowToolTip();
	void         RemoveToolTip();
	void         CancelLawnView();
	void                    MouseUp(int x, int y, int theClickCount) override;
	void                    UpdateImitaterButton();
	void                    MouseDown(int x, int y, int theClickCount) override;
	bool         PickedPlantType(SeedType theSeedType);
	void                    CloseSeedChooser();
	void                    KeyDown(KeyCode theKey) override;
	void                    KeyChar(char theChar) override;
	void                    UpdateAfterPurchase();
	std::vector<DeckPresetSeed> CurrentDeckPreset();
	bool                    DeckSeedAvailable(const DeckPresetSeed& seed);
	DeckSelectionPlan       ApplyDeckPreset(const std::vector<DeckPresetSeed>& seeds);
};

#endif
