# Zombotany Survival: Day

Version `0.2.6-web-zsurvival.1` builds on the published
`0.2.6-web-zombotany45.2` release. The production tree contains 888 files and
152 non-main game objects. Mode 96 uses the existing reserved profile record 95;
the saved class layouts and serializers are unchanged.

This is normal native Survival on the day lawn: five ten-wave flags, four
native seed-selection breaks, and the same lawn, sun and surviving mowers.
The fifty authored waves contain 207 original plant-headed zombies. The five
rounds contain 29, 40, 44, 45 and 49 actors. Original health, attacks, sun costs,
plant recharge and animations are retained. Beat the original Zombotany to
unlock it; progress of 1–4 flags remains partial and 5 completes the course.

The new thumbnail renders original body and plant-head reanimations. Native
tests compare its heads with real enemy renders and reject the previous
ordinary-head image. Real earned runs, losses, synthetic controls and the
separately earned original-Zombotany prerequisite retain distinct evidence.
The prerequisite originates from an earlier development build and keeps its
original executable/input/normal-build identities.

Restore the losslessly packed native test executables, then validate retained
results or execute the complete 24-case Survival matrix:

```text
python unpack-native-artifacts.py
python tests/test-zsurvival1.py
python tests/test-zsurvival1.py --native --asset-root /absolute/path/to/game-assets
```

The matrix covers two seeds at both speeds, normal and delayed play, combat
and transition saves, natural losses, and separately labeled zero-credit
controls. Native tests use dummy audio output and check that no audio device
opens. Native renders and simulations do not certify browser performance.

`build-candidate.ps1` and `build-chill.py` use the existing Windows Emscripten
toolchain layout. Complete test drivers link the normal game objects at O2
with a separate test entry point. `package-zsurvival1.py` authenticates all 31
primary suites, the separate family regression and exact reconstructed patches
before creating a new release stage. It does not run games or edit source.
The source package excludes the separately served original game-resource
payloads. Its immediate-parent reconstruction restores all 886 published .45.2
source files byte for byte.
