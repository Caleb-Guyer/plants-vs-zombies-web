# Zombotany 3 native release

Version: `0.2.6-web-zombotany3.1`. Immediate parent:
`0.2.6-web-gust.1`, source archive SHA-256
`10acb269866b175ed4836c2c64c6a79dc86a11241de9e48c7be54f8f89808be8`.

The production tree contains 882 files and builds 149 non-main game objects.
The four added files are `Zombotany3.h/.cpp` and `Zombotany3Art.h/.cpp` under
`source/src/Lawn/System`. The original saved classes and portable serializers
are unchanged. Mode 93 uses reserved profile record 92.

`logs/build-result.json` and both source snapshots bind the normal Release
build. The complete native test drivers link the same game objects, replacing
only the interactive entry point with an isolated test entry point. Their
`*-build.json`, `*-results.json`, contracts and raw logs retain the individual
source, recipe, object and executable identities. Test-only actors and poses
are explicitly separate from ordinary mouse-driven battles and earned wins.

The executable test files are stored losslessly in `tests/native-artifacts.xz`.
Restore their exact independently pinned bytes with:

```text
python unpack-native-artifacts.py
```

The retained-report check does not play another game:

```text
python tests/test-zombotany3.py
```

To execute the complete 36-case night matrix with an authorized original asset
directory, use:

```text
python tests/test-zombotany3.py --native --asset-root /absolute/path/to/game-assets
```

This uses dummy audio output and verifies that no audio device opens. Original
game resource payloads are separate distribution assets, not part of this
corresponding-source archive.

The included `build-candidate.ps1` and `build-chill.py` reproduce the normal
build with the existing Windows Emscripten/CMake toolchain layout; toolchains
are not bundled. The upstream source README documents its CMake project.
The native builder `tests/build-zombotany3.py` requires a completed, unchanged
normal Release build and supports an explicit `--sdk` path. A fresh complete
O2 link is required before new final gameplay evidence is accepted.

`package-zombotany3.py` validates all 29 current native suites, their source and
build bindings, the unchanged parent test snapshot, both reconstructed patches
and the lossless executable pack before creating a new release stage. It does
not start gameplay, fetch dependencies or edit production source.
