"""Deterministically pack a source-pinned AI plant atlas; requires Pillow 12.2.0.

No model/network is used here. The plant-only generation prompt is generation.json.
Usage: python render.py --output /public/chill-shroom --header /source/ChillShroomArt.h
"""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path
from PIL import Image, __version__ as PILLOW_VERSION

ROOT = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()

def extract(atlas, spec, threshold):
    part = atlas.crop(spec['sourceRegion']).copy()
    alpha = part.getchannel('A')
    bounds = alpha.point(lambda value: 255 if value > threshold else 0).getbbox()
    if not bounds:
        raise ValueError('Empty source atlas region')
    # Remove tiny model-export alpha tails outside the drawn silhouette.
    part.putalpha(alpha.point(lambda value: value if value > threshold else 0))
    part = part.crop(bounds)
    x, y, width, height = spec['targetBox']
    if spec['fit'] == 'contain':
        scale = min(width/part.width, height/part.height)
        size = (round(part.width*scale), round(part.height*scale))
    elif spec['fit'] == 'resize':
        size = (width, height)
    else:
        raise ValueError('Unsupported part fit')
    part = part.resize(size, Image.Resampling.LANCZOS)
    result = Image.new('RGBA', spec['targetCanvas'])
    result.alpha_composite(part, (x+(width-size[0])//2, y+(height-size[1])//2))
    return result

def build_parts(atlas, recipe):
    layers = {key: extract(atlas, value, recipe['alphaThreshold'])
              for key, value in recipe['parts'].items()}
    bodies = {}
    for key, eyes in [('body','openEyes'), ('blink1','halfEyes'), ('blink2','closedEyes')]:
        body = layers['blankBody'].copy()
        body.alpha_composite(layers[eyes])
        bodies[key] = body
    return {'cap':layers['cap'], 'body':bodies['body'], 'base':layers['base'],
            'blink1':bodies['blink1'], 'blink2':bodies['blink2']}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--header', type=Path, required=True)
    parser.add_argument('--proof', type=Path)
    args = parser.parse_args()
    recipe_raw = (ROOT/'extraction.json').read_bytes()
    recipe = json.loads(recipe_raw)
    generation_raw = (ROOT/'generation.json').read_bytes()
    generation = json.loads(generation_raw)
    raw = base64.b64decode((ROOT/'sprite-atlas.png.base64.txt').read_bytes(), validate=False)
    if sha(raw) != generation['atlasSha256']:
        raise ValueError('Source atlas does not match its generation record')
    atlas = Image.open(io.BytesIO(raw)).convert('RGBA')
    if list(atlas.size) != recipe['inputSize']:
        raise ValueError('Unexpected source atlas canvas')
    parts = build_parts(atlas, recipe)
    args.output.mkdir(parents=True, exist_ok=True)
    header = ['// AI-assisted plant artwork; generation and deterministic extraction',
              '// source: artwork/chill-shroom/. Runtime uses straight ARGB arrays.',
              '#pragma once', '#include <cstdint>', 'namespace ChillShroomArt {']
    records = {}
    for key, img in parts.items():
        path = args.output/(key+'.png')
        img.save(path, optimize=False, compress_level=9)
        name = key[0].upper()+key[1:]
        rgba = img.tobytes()
        pixels = [(rgba[i+3]<<24)|(rgba[i]<<16)|(rgba[i+1]<<8)|rgba[i+2]
                  for i in range(0,len(rgba),4)]
        header.extend([f'inline constexpr int k{name}Width = {img.width};',
                       f'inline constexpr int k{name}Height = {img.height};',
                       f'inline constexpr uint32_t k{name}Argb[] = {{'])
        for index in range(0,len(pixels),10):
            header.append('    '+', '.join(f'0x{v:08x}u' for v in pixels[index:index+10])+',')
        header.append('};')
        records[key] = {'width':img.width, 'height':img.height,
                        'pngSha256':sha(path.read_bytes()), 'rgbaSha256':sha(rgba)}
    header.append('}')
    args.header.parent.mkdir(parents=True,exist_ok=True)
    args.header.write_text('\n'.join(header)+'\n',encoding='utf-8',newline='\n')
    manifest = {'schema':1, 'version':'0.2.6-web-chill.4',
                'method':'AI-assisted plant sprite atlas with deterministic extraction and compositing',
                'imageGenerationUsed':True, 'standaloneChallengeIllustrations':False,
                'pillowVersion':PILLOW_VERSION, 'atlasSha256':sha(raw),
                'extractionSha256':sha(recipe_raw), 'generationSha256':sha(generation_raw),
                'generatorSha256':sha(Path(__file__).read_bytes()),
                'headerSha256':sha(args.header.read_bytes()), 'parts':records}
    for name,data in [('provenance.json',(json.dumps(manifest,indent=2)+'\n').encode()),
                      ('generation.json',generation_raw), ('extraction.json',recipe_raw)]:
        (args.output/name).write_bytes(data)
    if args.proof:
        sheet = Image.new('RGBA',(100,90),'#6f805e')
        for key,x,y in [('body',13.7,38.1), ('base',8.5,60.1), ('cap',-1.4,1.5)]:
            img = parts[key]
            img = img.resize((round(img.width*.8),round(img.height*.8)),Image.Resampling.LANCZOS)
            sheet.alpha_composite(img,(round(x+10),round(y+4)))
        sheet.resize((400,360),Image.Resampling.NEAREST).save(args.proof)
    print(json.dumps(manifest,indent=2))

if __name__ == '__main__':
    main()
