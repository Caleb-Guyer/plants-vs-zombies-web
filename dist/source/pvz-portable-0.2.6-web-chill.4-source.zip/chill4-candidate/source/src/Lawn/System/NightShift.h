// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>
#include <string_view>

// Uses the native nighttime lawn, sun economy, graves and mushroom behavior.
// Mode 74 owns reserved profile record 73 without extending serialized objects.
namespace NightShift
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_NIGHT_SHIFT;
inline constexpr std::string_view kId = "night-shift";
inline constexpr int kRevision = 1;
inline constexpr int kStartingSun = 150;
inline constexpr int kWaveCount = 20;
inline constexpr int kLargestWave = 16;
inline constexpr std::array<SeedType, 6> kSeeds = {
    SEED_SUNSHROOM, SEED_PUFFSHROOM, SEED_FUMESHROOM,
    SEED_GRAVEBUSTER, SEED_ICESHROOM, SEED_DOOMSHROOM
};
inline constexpr std::array<ZombieType, 5> kPreviewZombies = {
    ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_NEWSPAPER, ZOMBIE_DOOR, ZOMBIE_PAIL
};

struct Wave
{
    int mNormal;
    int mCones;
    int mNewspapers;
    int mDoors;
    int mBuckets;
};

// Free Puff-shrooms protect the opening economy. Newspapers arrive on wave 4,
// doors on wave 8 and buckets on wave 15; native Fume-shrooms counter shields.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {1, 0, 0, 0, 0}, {2, 0, 0, 0, 0}, {3, 0, 0, 0, 0}, {2, 0, 1, 0, 0},
    {2, 1, 1, 0, 0}, {3, 1, 1, 0, 0}, {3, 2, 1, 0, 0}, {3, 2, 1, 1, 0},
    {3, 2, 2, 1, 0}, {4, 3, 2, 1, 0}, {3, 3, 1, 2, 0}, {3, 3, 2, 2, 0},
    {3, 3, 2, 3, 0}, {3, 3, 2, 3, 0}, {3, 3, 2, 3, 1}, {3, 4, 2, 3, 1},
    {3, 4, 2, 3, 2}, {3, 3, 3, 3, 2}, {3, 4, 2, 3, 2}, {3, 4, 3, 3, 2}
}};

constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsFlagWave(int wave) { return wave >= 0 && wave < kWaveCount && (wave + 1) % 10 == 0; }
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    const Wave& entry = kWaves[wave];
    return entry.mNormal + entry.mCones + entry.mNewspapers + entry.mDoors + entry.mBuckets + (IsFlagWave(wave) ? 1 : 0);
}

// Reject invalid input before writing any part of the native wave buffer.
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    const Wave& entry = kWaves[wave];
    int count = 0;
    if (IsFlagWave(wave)) output[count++] = ZOMBIE_FLAG;
    for (int i = 0; i < entry.mNormal; ++i) output[count++] = ZOMBIE_NORMAL;
    for (int i = 0; i < entry.mCones; ++i) output[count++] = ZOMBIE_TRAFFIC_CONE;
    for (int i = 0; i < entry.mNewspapers; ++i) output[count++] = ZOMBIE_NEWSPAPER;
    for (int i = 0; i < entry.mDoors; ++i) output[count++] = ZOMBIE_DOOR;
    for (int i = 0; i < entry.mBuckets; ++i) output[count++] = ZOMBIE_PAIL;
    return count;
}

template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output)
        for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}

template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOOR));
    for (auto& allowed : output) allowed = false;
    for (ZombieType zombie : kPreviewZombies) output[zombie] = true;
}

template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
}

static_assert(static_cast<int>(kMode) == 74);
static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
