# Chill.4 shaded plant and animation revision

Chill-shroom uses an AI-assisted plant-parts atlas generated with the built-in
image_gen tool. Its complete prompt, style-reference identities and atlas SHA
are recorded in source/artwork/chill-shroom/generation.json. The authenticated
PNG is embedded as text in sprite-atlas.png.base64.txt so source patches remain
text-applicable. render.py, extraction.json and Pillow 12.2.0 deterministically
extract and assemble all five native ARGB arrays/PNG parts. No network/model or
PNG decoder is needed at runtime. All three full-body expression variants share
the exact same painted skin, eliminating rectangular overlay seams.

The rounded cap has stronger volume, a narrower outline and deep underside.
The squat shaded stem has larger eyes and tucked roots. A foot-anchored .83
minimum body squash replaces .75; a separate bounded cap lag/rebound supplies
follow-through. Native blink/idle/sleep timing is retained. No global original
sprite, enum, serialized layout, attack/range/chill/cadence or challenge rule changes.

Challenge pictures remain centered native compositions of actual game sprites;
no separate image-generated challenge illustration is used.

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Focused suites compile actual production methods without game/audio startup.
Full/upstream and Chill.3 delta patches reconstruct every current source byte.
Native-save fields and IDs remain compatible. Broad original parity and subjective
style perfection are not implied by focused tests or bounded visual observations.
