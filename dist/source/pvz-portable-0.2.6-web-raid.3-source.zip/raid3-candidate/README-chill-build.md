# Live cardboard plant animation: corresponding source and tests

Exact published Raid.2 parent source SHA-256:
0bb8e6ae265488e1d1da8b472c10730f0bd17df9a56337c8acc34c4c3911a225.
The parent archive has 23,967,714 bytes, 918 entries and 828 production files
under raid2-candidate/source/. Current recipes and source use raid3-candidate/.

Raid.3 renders Chill-shroom and Mender-bloom from their current existing live
rigs through the original four cardboard passes instead of static previews.
Only CMake/ProjectVersion.cmake and RallyRaidPresentation.cpp differ from Raid.2.
The native I, Zombie head/UI fix, shared normal-mode rigs, accepted artwork,
content metadata, authored boards, budgets, combat, IDs and saves are unchanged.
No new animation clocks, per-frame image buffers or unbounded caches are used.

Build the normal Release browser engine with build-chill.py. Separate muted
Care, Chain Reaction, Rally Zombie and Rally Raid CLI drivers link the same
production objects with test-only entry points. All seventeen native reports
and eight backend JS/WASM artifacts remain release gates. The Raid backend
separates the retained 28 scenarios from four new plant-animation controls;
controls inspect actual body motion rather than relying on moving frost.
The published static Raid.2 helper is the animation regression negative.
Native test hardware never opens an audio device.

package-chill.py authenticates source/build/test receipts and exact upstream
and Raid.2 patch reconstruction before staging matching source/binaries.
Patches are web-raid.3.patch and raid2-to-raid3.patch. Site-source packaging
retains the existing pinned Rally.3 reference used by native-UI checks.
