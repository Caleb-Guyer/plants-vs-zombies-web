// SPDX-License-Identifier: LGPL-3.0-or-later
#include "RallyRaidPresentation.h"
#include "RallyPresentation.h"
#include "RallyRaid.h"
#include "LanternShroom.h"
#include "MenderBloom.h"
#include "../../LawnApp.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../../Resources.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/FilterEffect.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <format>
#include <memory>
#include <vector>

namespace RallyRaidPresentation
{
namespace
{
std::unique_ptr<Sexy::MemoryImage> sCard;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image=std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(),width,height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left=image.GetWidth(),top=image.GetHeight(),right=-1,bottom=-1;
    const uint32_t* pixels=image.GetBits();
    for (int y=0;y<image.GetHeight();++y) for (int x=0;x<image.GetWidth();++x)
        if ((pixels[y*image.GetWidth()+x]>>24)>8)
        {left=std::min(left,x);top=std::min(top,y);right=std::max(right,x);bottom=std::max(bottom,y);}
    return right<left ? Sexy::Rect() : Sexy::Rect(left,top,right-left+1,bottom-top+1);
}
}

std::string LevelLabel(int stage)
{
    return std::format("Rally Raid - {}/{}",std::clamp(stage+1,1,RallyRaid::kBoardCount),RallyRaid::kBoardCount);
}

Sexy::Image* GetBonusImage()
{
    if (sCard) return sCard.get();
    if (!PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1 || !Sexy::IMAGE_BRAIN)
        return nullptr;
    auto portrait=Blank(240,230);
    Sexy::Graphics native(portrait.get());native.SetLinearBlend(true);
    Reanimation body;
    body.ReanimationInitializeType(100,35,REANIM_ZOMBIE);
    body.SetFramesForLayer("anim_idle");
    Zombie::SetupReanimLayers(&body,ZOMBIE_RALLY);
    RallyPresentation::PrepareRig(body);
    body.Draw(&native);RallyPresentation::DrawRig(&native,body,true,.45f);
    const Sexy::Rect bounds=VisibleBounds(*portrait);
    if (bounds.mWidth<=0 || bounds.mHeight<=0) return nullptr;
    auto* brainImage=dynamic_cast<Sexy::MemoryImage*>(Sexy::IMAGE_BRAIN);
    const Sexy::Rect brainBounds=brainImage ? VisibleBounds(*brainImage) :
        Sexy::Rect(0,0,Sexy::IMAGE_BRAIN->GetWidth(),Sexy::IMAGE_BRAIN->GetHeight());
    if (brainBounds.mWidth<=0 || brainBounds.mHeight<=0) return nullptr;
    auto card=Blank(80,65);
    Sexy::Graphics picture(card.get());picture.SetLinearBlend(true);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1,Sexy::Rect(0,0,80,65),Sexy::Rect(400,140,480,390));
    // Paint the original brain at its final readable size rather than
    // shrinking it with the tall carrier. A 4px gap keeps it off the hand/horn;
    // their complete visible composition remains centered in the native card.
    const float brainScale=std::min(22.0f/brainBounds.mWidth,20.0f/brainBounds.mHeight);
    const float brainWidth=brainBounds.mWidth*brainScale;
    const float bodyScale=std::min((68.0f-brainWidth-4.0f)/bounds.mWidth,57.0f/bounds.mHeight);
    const float totalWidth=brainWidth+4.0f+bounds.mWidth*bodyScale;
    const float left=40.0f-totalWidth*.5f;
    PvzpDrawImageScaledF(&picture,portrait.get(),left+brainWidth+4.0f-bounds.mX*bodyScale,
        32.5f-(bounds.mY+bounds.mHeight*.5f)*bodyScale,bodyScale,bodyScale);
    PvzpDrawImageScaledF(&picture,Sexy::IMAGE_BRAIN,left-brainBounds.mX*brainScale,
        61.0f-(brainBounds.mY+brainBounds.mHeight)*brainScale,brainScale,brainScale);
    sCard=std::move(card);
    return sCard.get();
}

bool DrawCustomPlant(Sexy::Graphics* graphics,Plant& plant)
{
    if (plant.mSeedType!=SEED_LANTERNSHROOM && plant.mSeedType!=SEED_MENDERBLOOM) return false;
    Reanimation* body=plant.mApp ? plant.mApp->ReanimationTryToGet(plant.mBodyReanimID) : nullptr;
    if (!body) return true;
    struct RestoreFilter
    {
        Reanimation& body;
        FilterEffect previous;
        ~RestoreFilter() { body.mFilterEffect=previous; }
    } restore{*body,body->mFilterEffect};
    Sexy::Graphics cutout(*graphics);
    cutout.SetDrawMode(Sexy::Graphics::DRAWMODE_NORMAL);
    cutout.SetColorizeImages(true);
    // Reuse the current registered rig and its bounded part/filter images.
    // The carrier already supplies the live pose, height and shake offsets.
    const auto drawPass=[&](float offset,const Sexy::Color& color,FilterEffect filter)
    {
        cutout.mTransX=graphics->mTransX+offset;
        cutout.mTransY=graphics->mTransY+offset;
        cutout.SetColor(color);
        body->mFilterEffect=filter;
        if (plant.mSeedType==SEED_LANTERNSHROOM)
            LanternShroom::DrawPlantRig(&cutout,plant,*body);
        else
            MenderBloom::DrawPlantRig(&cutout,plant,*body);
    };
    drawPass(4.0f,Sexy::Color(122,86,58),FILTER_EFFECT_WHITE);
    drawPass(2.0f,Sexy::Color(171,135,107),FILTER_EFFECT_WHITE);
    drawPass(-2.0f,Sexy::Color(171,135,107),FILTER_EFFECT_WHITE);
    drawPass(0.0f,Sexy::Color(255,201,160),FILTER_EFFECT_NONE);
    return true;
}

void DisposeImage() { sCard.reset(); }
}
