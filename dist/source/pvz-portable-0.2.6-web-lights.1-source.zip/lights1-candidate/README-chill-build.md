# Lights Out: source and tests

Exact published Raid.5 parent source SHA-256:
1415b9a6f916b9780abd3425c5ea9ab32436c1ee56f1e59b89e0ce4d3db78307.
The parent archive has 24,033,055 bytes, 920 entries and 828 production files
under raid5-candidate/source/. Current source and recipes use lights1-candidate/.

Lights.1 adds Lights Out as mode 82 and state 114, using an unused record in
the existing 100-entry profile array. A fixed garden shares one original
Plantern. Native glove moves preserve its ID, health, particles and saved clocks.
Light eligibility gates attack abilities and direct firing; health, idle motion
and in-flight projectiles remain native. The same cell predicate clears native
fog, with a translucent outer field, five-row alignment and a safe HUD clip.
Existing content IDs, object layouts and the accepted custom artwork remain.

Build the normal Release engine with build-chill.py. The source tree contains
832 production files. Muted Care, Chain Reaction, Rally Zombie, Rally Raid and
Lights Out CLI drivers link the same production objects with test-only entry
points. All eighteen native reports and ten backend JS/WASM files remain
release gates. Test hardware opens no audio device; normal game audio remains
available. Legal battle policies use native mouse input, combat and progression;
synthetic actor/layout controls are labeled separately from earned wins.

package-chill.py authenticates source/build/test receipts and exact upstream
and Raid.5 patch reconstruction. Patches are web-lights.1.patch and
raid5-to-lights1.patch. Source packaging retains the authenticated native-UI
reference and inherited rejected-renderer fixtures needed by the retained checks.
