# Lantern.2 native art revision

This revision replaces the rejected full-body bitmap with the original mushroom
body, native blinking and animation plus a cap-only texture edit. Added Bonus
cards have distinct compositions of native artwork; added hover tips are removed.
Original game content, native saved layouts and Lantern-shroom mechanics remain.

Build with the existing Emscripten toolchain:

    python build-lantern2.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-lantern2.py

Test runners accept --native for host C++20 and initialize no full game or audio.
Release flags: DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF. The recipe expects
work/toolchain; configure SDK paths elsewhere. Packaging checks current source,
artifact and test pins and reconstructs upstream and Lantern.1 patches to compare
every source byte. Each --output names a new directory inside this candidate.
The full source omits redundant patch copies; exact patches are separate downloads.

LanternShroomCap.h embeds the cap PNG. Public dist/content/lantern-shroom-cap.png
and lantern-shroom-cap-art.json retain the input-derived image and prompt. Other
plant components and challenge art use original bundled resources. No private
saves, credentials or compiled test executables belong in this archive.
