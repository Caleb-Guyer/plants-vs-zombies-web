// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LanternShroom.h"
#include "LanternShroomCap.h"
#include "../Plant.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../SexyAppFramework/graphics/GLImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/ReanimAtlas.h"
#include <png.h>
#include <algorithm>
#include <cstdint>
#include <memory>
#include <vector>

namespace LanternShroom
{
namespace
{
struct SpriteCache
{
    std::unique_ptr<Sexy::GLImage> cap;
    std::unique_ptr<Sexy::MemoryImage> preview;
    bool attempted = false;
};
SpriteCache& CachedSprite()
{
    static SpriteCache cache;
    return cache;
}
}

void DisposeImage()
{
    // Clear native textures before LawnApp and its graphics owner are destroyed.
    SpriteCache& cache = CachedSprite();
    cache.preview.reset();
    cache.cap.reset();
    cache.attempted = false;
}

Sexy::Image* GetCapImage()
{
    SpriteCache& cache = CachedSprite();
    if (cache.attempted) return cache.cap.get();
    cache.attempted = true;
    png_image input{};
    input.version = PNG_IMAGE_VERSION;
    if (!png_image_begin_read_from_memory(&input, LanternShroomCapArt::kPng, LanternShroomCapArt::kPngSize))
        return nullptr;
    input.format = PNG_FORMAT_RGBA;
    std::vector<unsigned char> rgba(PNG_IMAGE_SIZE(input));
    if (!png_image_finish_read(&input, nullptr, rgba.data(), 0, nullptr))
    {
        png_image_free(&input);
        return nullptr;
    }
    // The native Puff-shroom cap's canvas, alpha edge and pivot stay exact.
    // Only its painted cap colors are replaced; the original body is untouched.
    Reanimation originalBody;
    originalBody.ReanimationInitializeType(0.0f, 0.0f, REANIM_PUFFSHROOM);
    originalBody.SetFramesForLayer("anim_idle");
    ReanimatorTransform transform;
    originalBody.GetCurrentTransform(originalBody.FindTrackIndex("PuffShroom_head"), &transform);
    Sexy::Image* nativeCap = transform.mImage;
    if (originalBody.mDefinition->mReanimAtlas && nativeCap)
        if (ReanimAtlasImage* entry = originalBody.mDefinition->mReanimAtlas->GetEncodedReanimAtlas(nativeCap))
            nativeCap = entry->mOriginalImage;
    auto* original = dynamic_cast<Sexy::MemoryImage*>(nativeCap);
    if (!original)
    {
        png_image_free(&input);
        return nullptr;
    }
    const int width = original->mWidth, height = original->mHeight;
    const uint32_t* originalBits = original->GetBits();
    std::vector<uint32_t> pixels(width * height, 0);
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x)
        {
            unsigned int red = 0, green = 0, blue = 0;
            for (int sy = 0; sy < 4; ++sy)
                for (int sx = 0; sx < 4; ++sx)
                {
                    const int sourceX = std::min(static_cast<int>(input.width) - 1,
                        static_cast<int>((x + (sx + 0.5f) * 0.25f) * input.width / width));
                    const int sourceY = std::min(static_cast<int>(input.height) - 1,
                        static_cast<int>((y + (sy + 0.5f) * 0.25f) * input.height / height));
                    const auto* sample = &rgba[(sourceY * input.width + sourceX) * 4];
                    red += sample[0]; green += sample[1]; blue += sample[2];
                }
            const uint32_t alpha = originalBits[y * width + x] & 0xff000000U;
            pixels[y * width + x] = alpha | ((red / 16) << 16) | ((green / 16) << 8) | (blue / 16);
        }
    png_image_free(&input);
    cache.cap = std::make_unique<Sexy::GLImage>(gLawnApp->mGLInterface.get());
    cache.cap->SetBits(pixels.data(), width, height);
    return cache.cap.get();
}

void BindCap(Reanimation& reanimation, int glow)
{
    if (!reanimation.TrackExists("PuffShroom_head")) return;
    Sexy::Image* cap = GetCapImage();
    if (cap && reanimation.GetImageOverride("PuffShroom_head") != cap)
        reanimation.SetImageOverride("PuffShroom_head", cap);
    // A brief native track-color lift replaces the former screen-sized ring.
    const int light = 238 + std::clamp(glow, 0, kPulseFrames) * 17 / kPulseFrames;
    reanimation.GetTrackInstanceByName("PuffShroom_head")->mTrackColor = Sexy::Color(light, light, light);
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body)
    {
        // Lantern.1 checkpoints predate the native body. Migrate presentation
        // only; the saved pulse phase, health, position and game state survive.
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, plant.mSeedType, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0.0f, offsetY, plant.mRenderOrder + 1, REANIM_PUFFSHROOM);
        body->SetFramesForLayer(plant.mIsAsleep ? "anim_sleep" : "anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mAnimRate = 12.0f;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
        if (plant.mBlinkCountdown <= 0) plant.mBlinkCountdown = 400;
    }
    BindCap(*body, plant.mIsAsleep ? 0 : plant.mDoSpecialCountdown);
}

Sexy::Image* GetImage()
{
    SpriteCache& cache = CachedSprite();
    if (cache.preview) return cache.preview.get();
    std::vector<uint32_t> pixels(120 * 120, 0);
    cache.preview = std::make_unique<Sexy::MemoryImage>();
    cache.preview->SetBits(pixels.data(), 120, 120);
    Sexy::Graphics graphics(cache.preview.get());
    graphics.SetLinearBlend(true);
    Reanimation native;
    native.ReanimationInitializeType(20.0f, 20.0f, REANIM_PUFFSHROOM);
    native.SetFramesForLayer("anim_idle");
    BindCap(native);
    native.Draw(&graphics);
    return cache.preview.get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* preview = GetImage())
        PvzpDrawImageScaledF(graphics, preview, x - 20.0f * scaleX, y - 20.0f * scaleY, scaleX, scaleY);
}
}
