// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"

namespace Sexy { class Image; class Graphics; }
class Plant;
class Reanimation;

// Stored in existing Plant counters; native saved-object layouts stay unchanged.
namespace LanternShroom
{
Sexy::Image* GetCapImage();
Sexy::Image* GetImage();
void DisposeImage();
void BindCap(Reanimation& reanimation, int glow = 0);
void EnsurePlantReanimation(Plant& plant);
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY);

inline constexpr SeedType kSeed = SEED_LANTERNSHROOM;
inline constexpr int kCost = 75;
inline constexpr int kRecharge = 750;
inline constexpr int kPulseInterval = 400;
inline constexpr int kSlowDuration = 150;
inline constexpr int kRadius = 150;
inline constexpr int kPulseFrames = 30;

constexpr bool AdvancePulse(int& cooldown, int& glow)
{
    if (glow > 0) --glow;
    if (cooldown > 0) --cooldown;
    if (cooldown != 0) return false;
    cooldown = kPulseInterval;
    glow = kPulseFrames;
    return true;
}
constexpr bool InRange(float dx, float dy)
{
    return dx * dx + dy * dy <= static_cast<float>(kRadius * kRadius);
}
static_assert(static_cast<int>(kSeed) == 75);
}
