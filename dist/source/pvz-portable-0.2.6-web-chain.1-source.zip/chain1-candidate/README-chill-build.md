# Chain Reaction

Exact parent Care.3 corresponding source SHA-256:
`50d01dd1bbd793e1cda1dfbc74a70ca6724eee8741dab9260d188b3f49c882d4`.
818 production inputs under care3-candidate/source/.

Build the normal browser engine with build-chill.py using the retained Release
Emscripten toolchain. Two separate silent full-engine drivers link the unchanged
production objects with test-only entry points: retained complete Care scenarios
and Chain Reaction puzzle solutions/failures. The original explosion, movement,
save, resource and award code executes; no combat-model fallback is available.

Run all fifteen suites after source freezes. Complete-engine execution requires
authenticated game assets through --asset-root. Source-only verification checks
the exact executed report, source and artifact pins; CI reruns with game assets.
The test drivers, builders and pinned test-only Node/WASM artifacts accompany
the corresponding source. No audio device is opened.

package-chill.py stages only after current source/build/test authentication and
byte-exact upstream/parent patch reconstruction. Outputs: web-chain.1.patch,
care3-to-chain1.patch and corresponding source with chain1-candidate/ prefix.
