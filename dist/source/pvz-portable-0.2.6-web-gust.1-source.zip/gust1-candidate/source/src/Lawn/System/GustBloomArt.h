// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include <string>

namespace Sexy { class Graphics; class Image; }
class Plant;
class Reanimation;

// All painted components come from the original resource bundle. The native
// saved Blover rig supplies the clock and appearance, never Blover's ability.
namespace GustBloomArt
{
void EnsurePlantReanimation(Plant& plant);
void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier);
bool DrawCardboardPlant(Sexy::Graphics* graphics, Plant& plant);
Sexy::Image* GetImage();
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY);
Sexy::Image* GetHeadwindImage();
std::string LevelLabel(int wave);
void DisposeImages();
}
