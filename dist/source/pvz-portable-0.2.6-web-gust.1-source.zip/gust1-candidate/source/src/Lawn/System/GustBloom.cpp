// SPDX-License-Identifier: LGPL-3.0-or-later
#include "GustBloom.h"
#include "GustChallenge.h"
#include "PlayerInfo.h"
#include "../Board.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include <algorithm>

namespace GustBloom
{
bool IsUnlocked(const LawnApp* app)
{ return app && app->mPlayerInfo && app->mPlayerInfo->mChallengeRecords[GustChallenge::kProfileIndex] > 0; }

bool IsRecovering(const Zombie& zombie)
{ return zombie.mZombieType != ZOMBIE_BOSS && zombie.mBossHeadCounter > 0; }

int PushPixels(const Zombie& zombie)
{
    switch (zombie.mZombieType)
    {
    case ZOMBIE_NORMAL: case ZOMBIE_FLAG: case ZOMBIE_TRAFFIC_CONE:
    case ZOMBIE_NEWSPAPER: case ZOMBIE_DANCER: case ZOMBIE_BACKUP_DANCER:
    case ZOMBIE_IMP: case ZOMBIE_YETI: case ZOMBIE_RALLY: case ZOMBIE_TORCHBEARER:
        return kLightPushPixels;
    case ZOMBIE_PAIL:
        return zombie.mHelmType != HELMTYPE_NONE && zombie.mHelmHealth > 0 ? kHeavyPushPixels : kLightPushPixels;
    case ZOMBIE_DOOR:
        return zombie.mShieldType == SHIELDTYPE_DOOR && zombie.mShieldHealth > 0 ? kHeavyPushPixels : kLightPushPixels;
    case ZOMBIE_LADDER:
        return zombie.mShieldType == SHIELDTYPE_LADDER && zombie.mShieldHealth > 0 ? kHeavyPushPixels : kLightPushPixels;
    case ZOMBIE_FOOTBALL:
        return kHeavyPushPixels;
    default:
        // Vehicles, giants, airborne and specialist movement retain their
        // native physics; wind cannot interrupt a vault, dig or bungee landing.
        return 0;
    }
}

namespace
{
bool IsMovable(Zombie& zombie)
{
    const bool grounded = zombie.mInPool ? zombie.mAltitude <= 0.0f :
        zombie.mAltitude == (zombie.mOnHighGround ? static_cast<float>(HIGH_GROUND_HEIGHT) : 0.0f);
    return PushPixels(zombie) > 0 && zombie.IsOnBoard() && !zombie.IsDeadOrDying() &&
        !zombie.mMindControlled && zombie.mHasHead && !zombie.IsFlying() &&
        !zombie.mBlowingAway && zombie.mZombieHeight == HEIGHT_ZOMBIE_NORMAL &&
        grounded;
}
}

bool CanTarget(const Plant& plant, Zombie& zombie)
{
    if (!IsMovable(zombie) || zombie.IsImmobilizied() || IsRecovering(zombie) ||
        zombie.mRow != plant.mRow || zombie.mPosX >= kRightCap) return false;
    const Rect bounds = zombie.GetZombieRect();
    const float distance = bounds.mX + bounds.mWidth * 0.5f - (plant.mX + 40.0f);
    return distance >= 0.0f && distance <= kRange;
}

void Initialize(Plant& plant)
{
    plant.mLaunchCounter = 0;
    plant.mStateCountdown = 0;
    plant.mDoSpecialCountdown = 0;
}

void Update(Plant& plant)
{
    if (!plant.mBoard || !plant.mApp || !plant.IsInPlay() || plant.mDead ||
        plant.mPlantHealth <= 0 || plant.mIsAsleep || plant.mSquished ||
        plant.mOnBungeeState != NOT_ON_BUNGEE || plant.mApp->mGameScene != SCENE_PLAYING ||
        plant.mBoard->mPaused || plant.mBoard->mTimeStopCounter > 0) return;
    if (plant.mDoSpecialCountdown > 0) --plant.mDoSpecialCountdown;
    if (plant.mStateCountdown > 0) --plant.mStateCountdown;
    if (plant.mLaunchCounter == 0 && plant.mStateCountdown > 0) return;

    bool hasTarget = false;
    for (Zombie* zombie : plant.mBoard->mZombies)
        if (CanTarget(plant, *zombie)) { hasTarget = true; break; }
    if (!hasTarget)
    {
        // A stolen, dead or out-of-range target cannot trigger a phantom blast.
        plant.mLaunchCounter = 0;
        return;
    }
    if (plant.mLaunchCounter == 0)
    {
        plant.mLaunchCounter = kWindupTicks;
        return;
    }
    if (--plant.mLaunchCounter != 0) return;
    bool released = false;
    for (Zombie* zombie : plant.mBoard->mZombies)
    {
        if (!CanTarget(plant, *zombie)) continue;
        zombie->mBossStompCounter = kPushTicks;
        zombie->mBossHeadCounter = kRecoveryTicks;
        released = true;
    }
    if (released)
    {
        plant.mDoSpecialCountdown = kGustFrames;
        plant.mStateCountdown = kPlantCooldown;
        plant.mApp->PlaySample(SOUND_BLOVER);
    }
}

void UpdateZombie(Zombie& zombie)
{
    // These fields initialize to -1 for all non-boss actors. Original boss
    // update code is the only other reader, and this guard excludes it fully.
    if (zombie.mZombieType == ZOMBIE_BOSS ||
        (zombie.mBossStompCounter <= 0 && zombie.mBossHeadCounter <= 0)) return;
    if (!IsMovable(zombie))
    {
        zombie.mBossStompCounter = zombie.mBossHeadCounter = 0;
        return;
    }
    if (!zombie.mApp || !zombie.mBoard || zombie.mApp->mGameScene != SCENE_PLAYING ||
        zombie.mBoard->mPaused || zombie.mBoard->mTimeStopCounter > 0) return;
    if (zombie.IsImmobilizied())
    {
        // Butter or a full freeze ends the impulse. Do not resume an old gust
        // after its visible plume has faded; recovery counts mobile time only.
        zombie.mBossStompCounter = 0;
        return;
    }
    if (zombie.mBossHeadCounter > 0) --zombie.mBossHeadCounter;
    if (zombie.mBossStompCounter <= 0) return;
    const int remaining = std::clamp(zombie.mBossStompCounter, 1, kPushTicks);
    const float before = (kPushTicks - remaining) / static_cast<float>(kPushTicks);
    const float after = (kPushTicks - remaining + 1) / static_cast<float>(kPushTicks);
    const float movement = PushPixels(zombie) * (PushEase(after) - PushEase(before));
    zombie.mPosX = std::max(zombie.mPosX, std::min(static_cast<float>(kRightCap), zombie.mPosX + movement));
    zombie.mBossStompCounter = remaining - 1;
    if (zombie.mIsEating) zombie.StopEating();
}
}
