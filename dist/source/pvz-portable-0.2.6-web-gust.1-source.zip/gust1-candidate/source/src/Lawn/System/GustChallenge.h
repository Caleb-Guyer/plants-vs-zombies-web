// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;

// Headwind uses a fixed native Spikeweed course and a finite conveyor.
// Short gusts recycle light crowds over spikes; stock heavy counters matter.
namespace GustChallenge
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_HEADWIND;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(144);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(145);
inline constexpr int kProfileIndex = 91;
inline constexpr int kRulesVersion = 1;
inline constexpr int kStartingSun = 0;
inline constexpr int kWaveCount = 6;
inline constexpr int kLargestFormation = 8;
inline constexpr int kOpeningDelay = 700;
inline constexpr int kFormationInterval = 1800;
inline constexpr int kBankSize = 10;
inline constexpr int kOpeningPackets = 4;
inline constexpr int kPacketCount = 32;
inline constexpr int kSupplyInterval = 200;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && (state == kActive || state == kFinished); }
inline constexpr std::array<SeedType,6> kSeeds = {SEED_GUSTBLOOM,SEED_PEASHOOTER,
    SEED_REPEATER,SEED_WALLNUT,SEED_CHERRYBOMB,SEED_SQUASH};
inline constexpr std::array<SeedType,8> kSupplyCycle = {SEED_GUSTBLOOM,SEED_PEASHOOTER,
    SEED_GUSTBLOOM,SEED_REPEATER,SEED_WALLNUT,SEED_GUSTBLOOM,SEED_CHERRYBOMB,SEED_SQUASH};
constexpr SeedType SeedForSupply(int ordinal)
{ return ordinal >= 0 && ordinal < kPacketCount ? kSupplyCycle[ordinal % kSupplyCycle.size()] : SEED_NONE; }
struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
inline constexpr std::array<StartingPlant,15> kStartingPlants = {{{SEED_PEASHOOTER,0,0},
    {SEED_PEASHOOTER,0,1},{SEED_PEASHOOTER,0,2},{SEED_PEASHOOTER,0,3},{SEED_PEASHOOTER,0,4},
    {SEED_SPIKEWEED,5,0},{SEED_SPIKEWEED,5,1},{SEED_SPIKEWEED,5,2},{SEED_SPIKEWEED,5,3},{SEED_SPIKEWEED,5,4},
    {SEED_SPIKEWEED,6,0},{SEED_SPIKEWEED,6,1},{SEED_SPIKEWEED,6,2},{SEED_SPIKEWEED,6,3},{SEED_SPIKEWEED,6,4}}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; int mX = 0; };
using Formation = std::array<Spawn,kLargestFormation>;
inline constexpr std::array<Formation,kWaveCount> kFormations = {{
    {{{ZOMBIE_NORMAL,1,760},{ZOMBIE_NORMAL,3,760}}},
    {{{ZOMBIE_TRAFFIC_CONE,0,800},{ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_TRAFFIC_CONE,4,800}}},
    {{{ZOMBIE_NORMAL,0,800},{ZOMBIE_DOOR,1,800},{ZOMBIE_NORMAL,2,840},{ZOMBIE_DOOR,3,800},{ZOMBIE_NORMAL,4,800}}},
    {{{ZOMBIE_FOOTBALL,0,800},{ZOMBIE_PAIL,1,800},{ZOMBIE_TRAFFIC_CONE,2,800},{ZOMBIE_PAIL,3,800},{ZOMBIE_FOOTBALL,4,800}}},
    {{{ZOMBIE_NORMAL,0,800},{ZOMBIE_NORMAL,1,800},{ZOMBIE_NORMAL,2,800},{ZOMBIE_NORMAL,3,800},{ZOMBIE_NORMAL,4,800},
      {ZOMBIE_TRAFFIC_CONE,1,860},{ZOMBIE_TRAFFIC_CONE,3,860}}},
    {{{ZOMBIE_PAIL,0,800},{ZOMBIE_FOOTBALL,1,800},{ZOMBIE_GARGANTUAR,2,850},{ZOMBIE_FOOTBALL,3,800},
      {ZOMBIE_PAIL,4,800},{ZOMBIE_NORMAL,0,880},{ZOMBIE_NORMAL,4,880}}}
}};
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count = 0; for (const Spawn& spawn : kFormations[wave]) count += spawn.mType != ZOMBIE_INVALID;
    return count;
}
template<std::size_t Waves,std::size_t Slots> int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestFormation);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int wave = 0; wave < kWaveCount; ++wave)
        for (int i = 0; i < ZombieCount(wave); ++i) output[wave][i] = kFormations[wave][i].mType;
    return kWaveCount;
}
template<std::size_t Count> void PopulateAllowedZombies(bool (&output)[Count])
{
    for (auto& allowed : output) allowed = false;
    for (const Formation& wave : kFormations) for (const Spawn& spawn : wave)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank> void FillSeedBank(Bank& bank) { bank.mNumPackets = kBankSize; }
bool Validate(const Board& board);
void PreloadResources();
void Populate(Board& board);
void Update(Board& board);
static_assert(static_cast<int>(kMode) == 92 && ZombieCount(0)+ZombieCount(1)+ZombieCount(2)+
    ZombieCount(3)+ZombieCount(4)+ZombieCount(5) == 29);
}
