// SPDX-License-Identifier: LGPL-3.0-or-later
#include "GustBloomArt.h"
#include "GustBloom.h"
#include "ReanimationLawn.h"
#include "../Plant.h"
#include "../Board.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/FilterEffect.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include "graphics/SharedImage.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <memory>
#include <vector>

namespace GustBloomArt
{
namespace
{
constexpr float kPi = 3.14159265359f;
constexpr int kLayers = 11;
struct Images
{
    std::array<std::unique_ptr<Sexy::MemoryImage>, kLayers> layers;
    std::array<std::array<std::unique_ptr<Sexy::MemoryImage>, NUM_FILTER_EFFECTS>, kLayers> filtered;
    std::unique_ptr<Sexy::MemoryImage> plant;
    std::unique_ptr<Sexy::MemoryImage> card;
};
Images& Cache() { static Images images; return images; }

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

std::unique_ptr<Sexy::MemoryImage> Original(const char* path)
{
    if (!gLawnApp) return nullptr;
    Sexy::SharedImageRef shared = gLawnApp->GetSharedImage(path);
    auto* image = static_cast<Sexy::MemoryImage*>(shared);
    if (!image) return nullptr;
    auto copy = Blank(image->GetWidth(), image->GetHeight());
    std::copy_n(image->GetBits(), image->GetWidth() * image->GetHeight(), copy->GetBits());
    copy->BitsChanged();
    return copy;
}

bool PaintOriginal(Sexy::Graphics& graphics, const char* path, int x, int y, int width, int height)
{
    auto source = Original(path);
    if (!source) return false;
    graphics.DrawImage(source.get(), Sexy::Rect(x, y, width, height),
        Sexy::Rect(0, 0, source->GetWidth(), source->GetHeight()));
    return true;
}

bool EnsureImages()
{
    Images& cache = Cache();
    if (cache.plant) return true;
    for (int i = 0; i < 4; ++i) cache.layers[i] = Blank(80, 80);
    Sexy::Graphics root(cache.layers[0].get()), stem(cache.layers[1].get());
    Sexy::Graphics face(cache.layers[2].get()), blowing(cache.layers[3].get());
    root.SetLinearBlend(true); stem.SetLinearBlend(true);
    face.SetLinearBlend(true); blowing.SetLinearBlend(true);
    bool okay = PaintOriginal(root, "reanim/PeaShooter_frontleaf", 12, 56, 57, 23) &&
        PaintOriginal(stem, "reanim/PeaShooter_stalk_bottom", 34, 49, 17, 23) &&
        PaintOriginal(stem, "reanim/PeaShooter_stalk_top", 34, 39, 16, 20);
    // The original folded leaf hood gives a distinct tall silhouette. Both
    // original cabbage eyes lie fully beneath the complete Blover face.
    for (Sexy::Graphics* head : {&face, &blowing})
        okay = PaintOriginal(*head, "reanim/Cabbagepult_head", 9, 3, 59, 47) && okay;
    okay = PaintOriginal(face, "reanim/Blover_head", 27, 23, 42, 36) && okay;
    okay = PaintOriginal(blowing, "reanim/Blover_head2", 27, 23, 42, 36) && okay;
    const char* puffs[] = {"reanim/puff_1", "reanim/puff_2", "reanim/puff_3",
        "reanim/puff_4", "reanim/puff_5", "reanim/puff_6", "reanim/puff_7"};
    for (int i = 0; i < 7; ++i)
    {
        cache.layers[4 + i] = Original(puffs[i]);
        okay = cache.layers[4 + i] && okay;
    }
    if (!okay) { cache = Images(); return false; }
    for (int layer = 0; layer < kLayers; ++layer)
        for (int filter = 0; filter < NUM_FILTER_EFFECTS; ++filter)
            cache.filtered[layer][filter].reset(FilterEffectCreateImage(cache.layers[layer].get(), static_cast<FilterEffect>(filter)));
    cache.plant = Blank(80, 80);
    Sexy::Graphics composite(cache.plant.get());
    composite.SetLinearBlend(true);
    composite.DrawImage(cache.layers[0].get(), 0, 0);
    composite.DrawImage(cache.layers[1].get(), 0, 0);
    composite.DrawImage(cache.layers[2].get(), 0, 0);
    return true;
}

Sexy::Image* Layer(int layer, FilterEffect filter)
{
    if (filter >= 0 && filter < NUM_FILTER_EFFECTS && Cache().filtered[layer][filter])
        return Cache().filtered[layer][filter].get();
    return Cache().layers[layer].get();
}

void DrawLayer(Sexy::Graphics* graphics, Reanimation& carrier, int layer,
    float x, float y, float angle = 0, float scaleX = 1, float scaleY = 1, int alpha = 255)
{
    Sexy::Image* image = Layer(layer, carrier.mFilterEffect);
    if (!image) return;
    SexyMatrix3 local;
    PvzpScaleRotateTransformMatrix(local, x, y, angle, scaleX, scaleY);
    SexyMatrix3 matrix;
    SexyMatrix3Multiply(matrix, carrier.mOverlayMatrix, local);
    SexyMatrix3Translation(matrix, graphics->mTransX, graphics->mTransY);
    Sexy::Color color = carrier.mColorOverride;
    if (graphics->GetColorizeImages()) color = ColorsMultiply(color, graphics->GetColor());
    color.mAlpha = ColorComponentMultiply(color.mAlpha, alpha);
    if (color.mAlpha <= 0) return;
    const Sexy::Rect source(0, 0, image->GetWidth(), image->GetHeight());
    carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect, color, graphics->GetDrawMode(), source);
    if (carrier.mEnableExtraAdditiveDraw)
    {
        Sexy::Color additive = carrier.mExtraAdditiveColor;
        additive.mAlpha = ColorComponentMultiply(additive.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect,
            additive, Sexy::Graphics::DRAWMODE_ADDITIVE, source);
    }
    if (carrier.mEnableExtraOverlayDraw)
    {
        Sexy::Color overlay = carrier.mExtraOverlayColor;
        overlay.mAlpha = ColorComponentMultiply(overlay.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, Layer(layer, FILTER_EFFECT_WHITE), matrix,
            graphics->mClipRect, overlay, Sexy::Graphics::DRAWMODE_NORMAL, source);
    }
}

void DrawAir(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier)
{
    if (plant.mDoSpecialCountdown <= 0 || plant.mDoSpecialCountdown > GustBloom::kGustFrames) return;
    const float elapsed = static_cast<float>(GustBloom::kGustFrames - plant.mDoSpecialCountdown);
    const float envelope = std::min(1.0f, (elapsed + 1.0f) / 5.0f) *
        std::min(1.0f, plant.mDoSpecialCountdown / 18.0f);
    // A full-range plume accompanies the already committed push. Original
    // neutral puff cells flow through it and dissolve rather than teleporting.
    for (int i = 0; i < 9; ++i)
    {
        const float travel = std::fmod(i * 27.0f + elapsed * 4.0f, 235.0f);
        const float y = 39.0f + std::sin(i * 2.1f + elapsed * .12f) * (5.0f + travel * .025f);
        const float fade = std::sin((travel + 5.0f) / 245.0f * kPi);
        DrawLayer(graphics, carrier, 4 + (i + static_cast<int>(elapsed / 5)) % 7,
            65.0f + travel, y, .08f * std::sin(i + elapsed * .1f),
            1.1f + travel * .009f, .65f + travel * .002f,
            static_cast<int>(145 * envelope * fade));
    }
}

void DrawBody(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier, bool cardboard)
{
    const bool active = !plant.mIsAsleep && !plant.mSquished && plant.mOnBungeeState == NOT_ON_BUNGEE;
    const float phase = active && !cardboard ? carrier.mAnimTime * 2 * kPi : 0;
    const float windup = active && plant.mLaunchCounter > 0 ?
        1.0f - std::clamp(plant.mLaunchCounter, 0, GustBloom::kWindupTicks) / static_cast<float>(GustBloom::kWindupTicks) : 0;
    const float release = active && plant.mDoSpecialCountdown > 0 ?
        std::exp(-(GustBloom::kGustFrames - plant.mDoSpecialCountdown) / 13.0f) : 0;
    const float lean = .085f * std::sin(phase) - .19f * windup + .20f * release;
    const float neckX = 42.0f - 20.0f * std::sin(lean);
    const float neckY = 70.0f - 20.0f * std::cos(lean);
    const float stemX = 42.0f - 30.0f * std::sin(lean) - 2.0f * std::cos(lean);
    const float stemY = 70.0f - 30.0f * std::cos(lean) + 2.0f * std::sin(lean);
    DrawLayer(graphics, carrier, 0, 40, 40, .018f * std::sin(phase + .8f));
    DrawLayer(graphics, carrier, 1, stemX, stemY, lean);
    const float headAngle = lean + .035f * std::sin(phase * 2);
    const float swell = .018f * (1 - std::cos(phase)) + .075f * windup;
    const float sx = 1.0f + swell + .045f * release;
    const float sy = 1.0f + swell - .025f * release;
    // Registered neck (42,50) is shared by both moving layers.
    const float headX = neckX - (2 * std::cos(headAngle) - 10 * std::sin(headAngle)) * sx;
    const float headY = neckY - (2 * std::sin(headAngle) + 10 * std::cos(headAngle)) * sy;
    DrawLayer(graphics, carrier, (windup > .55f || plant.mDoSpecialCountdown > 35) ? 3 : 2,
        headX, headY, headAngle, sx, sy);
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((image.GetBits()[y * image.GetWidth() + x] >> 24) > 8)
            { left = std::min(left, x); top = std::min(top, y); right = std::max(right, x); bottom = std::max(bottom, y); }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}
void Fit(Sexy::Graphics& graphics, Sexy::MemoryImage& image, float centerX, float baseline, float width, float height)
{
    const Sexy::Rect bounds = VisibleBounds(image);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return;
    const float scale = std::min(width / bounds.mWidth, height / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, &image, centerX - (bounds.mX + bounds.mWidth * .5f) * scale,
        baseline - (bounds.mY + bounds.mHeight) * scale, scale, scale);
}
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != GustBloom::kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth <= 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (body && body->mReanimationType != REANIM_BLOVER)
    {
        plant.EndBlink();
        plant.mApp->RemoveReanimation(plant.mBodyReanimID);
        plant.mBodyReanimID = REANIMATIONID_NULL;
        body = nullptr;
    }
    if (!body)
    {
        const float offset = PlantDrawHeightOffset(plant.mBoard, &plant, GustBloom::kSeed, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0, offset, plant.mRenderOrder + 1, REANIM_BLOVER);
        body->SetFramesForLayer("anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
    }
    body->mAnimRate = std::max(1, body->mFrameCount) / 2.6f;
    body->AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
    if (Reanimation* blink = plant.mApp->ReanimationTryToGet(plant.mBlinkReanimID))
        blink->AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
}

void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier)
{
    if (plant.mSeedType != GustBloom::kSeed || carrier.mDead || plant.mDead || plant.mPlantHealth <= 0 || !EnsureImages()) return;
    DrawAir(graphics, plant, carrier);
    DrawBody(graphics, plant, carrier, false);
}

bool DrawCardboardPlant(Sexy::Graphics* graphics, Plant& plant)
{
    if (plant.mSeedType != GustBloom::kSeed) return false;
    if (!plant.mApp || !EnsureImages()) return true;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body) return true;
    const FilterEffect previous = body->mFilterEffect;
    const Sexy::Color colors[] = {Sexy::Color(122,86,58), Sexy::Color(171,135,107),
        Sexy::Color(171,135,107), Sexy::Color(255,201,160)};
    const int offsets[] = {4,2,-2,0};
    for (int i = 0; i < 4; ++i)
    {
        Sexy::Graphics pass(*graphics);
        pass.mTransX += offsets[i]; pass.mTransY += offsets[i];
        pass.SetColorizeImages(true); pass.SetColor(colors[i]);
        body->mFilterEffect = i < 3 ? FILTER_EFFECT_WHITE : FILTER_EFFECT_NONE;
        DrawBody(&pass, plant, *body, true);
    }
    body->mFilterEffect = previous;
    DrawAir(graphics, plant, *body);
    return true;
}

Sexy::Image* GetImage() { return EnsureImages() ? Cache().plant.get() : nullptr; }
void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* image = GetImage()) PvzpDrawImageScaledF(graphics, image, x, y, scaleX, scaleY);
}
std::string LevelLabel(int) { return "Headwind"; }

Sexy::Image* GetHeadwindImage()
{
    Images& cache = Cache();
    if (cache.card) return cache.card.get();
    if (!EnsureImages() || !gLawnApp || !gLawnApp->mReanimatorCache ||
        !PvzpLoadResources("DelayLoad_Background1") || !Sexy::IMAGE_BACKGROUND1) return nullptr;
    auto zombie = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_TRAFFIC_CONE);
    if (!zombie) return nullptr;
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true); picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(Sexy::IMAGE_BACKGROUND1, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(400, 140, 480, 390));
    Fit(picture, *zombie, 62, 63, 31, 59);
    for (int i = 0; i < 4; ++i)
    {
        picture.SetColorizeImages(true); picture.SetColor(Sexy::Color(255,255,255,155));
        PvzpDrawImageScaledF(&picture, cache.layers[5 + i].get(), 29.0f + i * 10, 26.0f + (i % 2) * 8, 1.4f, .65f);
    }
    picture.SetColorizeImages(false);
    // This complete registered plant has its original head, joined stem and
    // root leaves. The blowing face is used only for this action thumbnail.
    auto blowing = Blank(80, 80);
    Sexy::Graphics composite(blowing.get()); composite.SetLinearBlend(true);
    for (int layer : {0,1,3}) composite.DrawImage(cache.layers[layer].get(), 0, 0);
    Fit(picture, *blowing, 22, 62, 40, 46);
    cache.card = std::move(card);
    return cache.card.get();
}
void DisposeImages() { Cache() = Images(); }
}
