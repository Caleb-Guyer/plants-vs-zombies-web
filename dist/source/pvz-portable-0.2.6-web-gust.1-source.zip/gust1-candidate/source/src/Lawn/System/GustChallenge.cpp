// SPDX-License-Identifier: LGPL-3.0-or-later
#include "GustChallenge.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../SeedPacket.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include <algorithm>

namespace GustChallenge
{
bool Validate(const Board& board)
{
    if (!board.mApp || !board.mChallenge || !board.mSeedBank || !IsMode(board.mApp->mGameMode)) return false;
    const Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) || challenge.mChallengeGridY != kRulesVersion ||
        challenge.mSurvivalStage < 0 || challenge.mSurvivalStage > kWaveCount || challenge.mChallengeScore < kOpeningPackets ||
        challenge.mChallengeScore > kPacketCount || challenge.mChallengeStateCounter < 0 ||
        challenge.mChallengeStateCounter > kFormationInterval || challenge.mConveyorBeltCounter < 0 ||
        challenge.mConveyorBeltCounter > kSupplyInterval || board.mSeedBank->mNumPackets != kBankSize || board.mSunMoney != 0) return false;
    for (const SeedPacket& packet : board.mSeedBank->mSeedPackets)
    {
        if (packet.mPacketType == SEED_NONE) continue;
        if (std::find(kSeeds.begin(),kSeeds.end(),packet.mPacketType) == kSeeds.end()) return false;
    }
    return true;
}
void PreloadResources()
{
    for (SeedType seed : kSeeds) Plant::PreloadPlantResources(seed);
    Plant::PreloadPlantResources(SEED_SPIKEWEED);
    for (const Formation& wave : kFormations) for (const Spawn& spawn : wave)
        if (spawn.mType != ZOMBIE_INVALID) Zombie::PreloadZombieResources(spawn.mType);
}
void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    challenge.mChallengeState = kActive;
    challenge.mChallengeStateCounter = kOpeningDelay;
    challenge.mChallengeScore = challenge.mSurvivalStage = 0;
    challenge.mChallengeGridY = kRulesVersion;
    challenge.mConveyorBeltCounter = kSupplyInterval;
    board.mCurrentWave = board.mTotalSpawnedWaves = 0;
    board.mZombieCountDown = board.mZombieCountDownStart = kOpeningDelay;
    board.mZombieHealthToNextWave = -1;
    board.mSunMoney = 0;
    board.mShowShovel = true;
    board.mBonusLawnMowersRemaining = 0;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (SeedPacket& packet : board.mSeedBank->mSeedPackets) packet.mPacketType = SEED_NONE;
    for (int i = 0; i < kOpeningPackets; ++i)
    {
        const SeedType seed = SeedForSupply(challenge.mChallengeScore++);
        board.mSeedBank->AddSeed(seed,true);
        challenge.mLastConveyorSeedType = seed;
    }
    for (const StartingPlant& plant : kStartingPlants) board.AddPlant(plant.mCol,plant.mRow,plant.mSeed,SEED_NONE);
}
void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (challenge.mChallengeState != kActive || board.mApp->mGameScene != SCENE_PLAYING || board.mPaused ||
        board.mTimeStopCounter > 0 || board.mLevelComplete || board.HasLevelAwardDropped()) return;
    board.mShowShovel = true;
    board.mSeedBank->UpdateConveyorBelt();
    if (challenge.mChallengeScore < kPacketCount &&
        board.mSeedBank->GetNumSeedsOnConveyorBelt() < board.mSeedBank->mNumPackets)
    {
        if (challenge.mConveyorBeltCounter > 0) --challenge.mConveyorBeltCounter;
        if (challenge.mConveyorBeltCounter == 0)
        {
            const SeedType seed = SeedForSupply(challenge.mChallengeScore++);
            board.mSeedBank->AddSeed(seed);
            challenge.mLastConveyorSeedType = seed;
            challenge.mConveyorBeltCounter = kSupplyInterval;
        }
    }
    const int next = std::clamp(challenge.mSurvivalStage,0,kWaveCount);
    if (next < kWaveCount)
    {
        if (challenge.mChallengeStateCounter > 0) --challenge.mChallengeStateCounter;
        board.mZombieCountDown = challenge.mChallengeStateCounter;
        if (challenge.mChallengeStateCounter != 0) return;
        board.NextWaveComing();
        for (const Spawn& spawn : kFormations[next])
        {
            if (spawn.mType == ZOMBIE_INVALID) continue;
            Zombie* zombie = board.AddZombieInRow(spawn.mType,spawn.mRow,next);
            zombie->mPosX = static_cast<float>(spawn.mX);
            zombie->mX = spawn.mX;
            zombie->UpdateReanim();
        }
        challenge.mSurvivalStage = next + 1;
        board.mCurrentWave = board.mTotalSpawnedWaves = next + 1;
        board.mZombieHealthWaveStart = board.TotalZombiesHealthInWave(next);
        board.mZombieHealthToNextWave = -1;
        challenge.mChallengeStateCounter = kFormationInterval;
        board.mZombieCountDown = board.mZombieCountDownStart = kFormationInterval;
        return;
    }
    if (board.AreEnemyZombiesOnScreen()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    challenge.mChallengeState = kFinished;
    challenge.SpawnLevelAward(4,2);
}
}
