// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"

class Plant;
class Zombie;
class LawnApp;

// All ability clocks use existing saved Plant fields. Non-boss zombies reserve
// their otherwise unused boss stomp/head counters for the push/recovery clocks.
// Bosses are never eligible and retain their original use of those counters.
namespace GustBloom
{
inline constexpr SeedType kSeed = SEED_GUSTBLOOM;
inline constexpr int kCost = 150;
inline constexpr int kHealth = 300;
inline constexpr int kRecharge = 1500;
inline constexpr int kRange = 240;
inline constexpr int kWindupTicks = 35;
inline constexpr int kGustFrames = 60;
inline constexpr int kPlantCooldown = 450;
inline constexpr int kPushTicks = 24;
inline constexpr int kLightPushPixels = 64;
inline constexpr int kHeavyPushPixels = 16;
inline constexpr int kRecoveryTicks = 2000;
inline constexpr int kRightCap = 760;

constexpr float PushEase(float progress)
{ return progress * progress * (3.0f - 2.0f * progress); }
bool IsUnlocked(const LawnApp* app);
bool IsRecovering(const Zombie& zombie);
int PushPixels(const Zombie& zombie);
bool CanTarget(const Plant& plant, Zombie& zombie);
void Initialize(Plant& plant);
void Update(Plant& plant);
void UpdateZombie(Zombie& zombie);
static_assert(static_cast<int>(kSeed) == 78);
}
