// SPDX-License-Identifier: LGPL-3.0-or-later
#ifndef PVZ_DECK_PRESETS_H
#define PVZ_DECK_PRESETS_H

#include <array>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

class LawnApp;

struct DeckPresetSeed
{
    int mSeed = -1;
    int mImitater = -1;
    bool operator==(const DeckPresetSeed&) const = default;
};

struct DeckPreset
{
    std::string mName;
    std::vector<DeckPresetSeed> mSeeds;
};

struct DeckSelectionPlan
{
    std::vector<DeckPresetSeed> mSeeds;
    int mUnavailable = 0;
    int mOverflow = 0;
};

template<class Available>
DeckSelectionPlan PlanDeckSelection(const std::vector<DeckPresetSeed>& desired,
    const std::vector<DeckPresetSeed>& forced, int capacity, Available canUse)
{
    DeckSelectionPlan plan;
    capacity = capacity < 0 ? 0 : capacity > 10 ? 10 : capacity;
    for (const auto& seed : forced)
        if (static_cast<int>(plan.mSeeds.size()) < capacity) plan.mSeeds.push_back(seed);
    for (const auto& seed : desired)
    {
        bool duplicate = false;
        for (const auto& selected : plan.mSeeds) if (selected.mSeed == seed.mSeed) duplicate = true;
        if (duplicate) continue;
        if (!canUse(seed)) { ++plan.mUnavailable; continue; }
        if (static_cast<int>(plan.mSeeds.size()) >= capacity) { ++plan.mOverflow; continue; }
        plan.mSeeds.push_back(seed);
    }
    return plan;
}

// Pure versioned model: no native profile, board, or unlock data is changed.
class DeckPresets
{
public:
    static constexpr int SLOT_COUNT = 8;
    static constexpr int MAX_NAME = 18;
    std::array<DeckPreset, SLOT_COUNT> mDecks;

    DeckPresets()
    {
        const char* names[] = {"Day", "Night", "Pool", "Roof", "Deck 5", "Deck 6", "Deck 7", "Deck 8"};
        for (int i = 0; i < SLOT_COUNT; ++i) mDecks[i].mName = names[i];
    }

    static std::string CleanName(std::string name)
    {
        std::string result;
        for (unsigned char ch : name)
        {
            if (ch >= 32 && ch < 127 && result.size() < MAX_NAME) result += static_cast<char>(ch);
        }
        while (!result.empty() && result.front() == ' ') result.erase(result.begin());
        while (!result.empty() && result.back() == ' ') result.pop_back();
        return result;
    }

    static bool ValidSeed(const DeckPresetSeed& seed)
    {
        return ((seed.mSeed >= 0 && seed.mSeed < 49) || seed.mSeed == 75 || seed.mSeed == 76 || seed.mSeed == 78) &&
            (seed.mSeed == 48 ? seed.mImitater >= 0 && seed.mImitater < 40 : seed.mImitater == -1);
    }

    static bool ValidSeeds(const std::vector<DeckPresetSeed>& seeds)
    {
        if (seeds.size() > 10) return false;
        std::array<bool, 52> used{};
        for (const auto& seed : seeds)
        {
            if (!ValidSeed(seed)) return false;
            const int index = seed.mSeed == 75 ? 49 : seed.mSeed == 76 ? 50 : seed.mSeed == 78 ? 51 : seed.mSeed;
            if (used[index]) return false;
            used[index] = true;
        }
        return true;
    }

    std::string Encode() const
    {
        std::ostringstream stream;
        stream << "PVZDECKS 1\n" << SLOT_COUNT << '\n';
        for (const auto& deck : mDecks)
        {
            stream << std::quoted(deck.mName) << ' ' << deck.mSeeds.size();
            for (const auto& seed : deck.mSeeds) stream << ' ' << seed.mSeed << ' ' << seed.mImitater;
            stream << '\n';
        }
        return stream.str();
    }

    bool Decode(const std::string& text)
    {
        if (text.size() > 8192) return false;
        std::istringstream stream(text);
        std::string magic;
        int version = 0, slots = 0;
        if (!(stream >> magic >> version >> slots) || magic != "PVZDECKS" || version != 1 || slots != SLOT_COUNT) return false;
        DeckPresets parsed;
        for (auto& deck : parsed.mDecks)
        {
            int count = -1;
            if (!(stream >> std::quoted(deck.mName) >> count) || count < 0 || count > 10 ||
                deck.mName.empty() || deck.mName != CleanName(deck.mName)) return false;
            for (int i = 0; i < count; ++i)
            {
                DeckPresetSeed seed;
                if (!(stream >> seed.mSeed >> seed.mImitater)) return false;
                deck.mSeeds.push_back(seed);
            }
            if (!ValidSeeds(deck.mSeeds)) return false;
        }
        stream >> std::ws;
        if (!stream.eof()) return false;
        *this = parsed;
        return true;
    }

    bool Load(LawnApp* app);
    bool Save(LawnApp* app) const;
};

#endif
