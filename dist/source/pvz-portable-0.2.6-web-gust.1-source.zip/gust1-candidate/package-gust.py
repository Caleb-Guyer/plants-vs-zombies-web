"""Package the frozen Gust-bloom engine and its freshly executed native tests.

The parent source, original contracts and failed development evidence remain
authenticated inputs. Nothing in this script starts gameplay or edits source.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, shutil, sys, tempfile, zipfile

ROOT = Path(__file__).resolve().parent
VERSION = '0.2.6-web-gust.1'
PARENT_SHA = '35b635770bbb040dd3b2c41c4c86ed49f351cbd29926b8efa286394ff89ad5b3'
SOURCE_COUNT = 878
OBJECT_COUNT = 147
FOCUSED = ['game-speed','qol-controls','decks-cooldowns','bonus-challenge','bonus-completion',
 'night-shift','lantern-shroom','garden-shuffle','seed-swap','mender-bloom','intensive-care','native-layout','care-fatigue']
ENGINES = ['care-full-run','chain-reaction','rally-zombie','rally-raid','lights-out','garlic-run',
 'bungee-business','cob-cannon-command','pool-panic','pool-panic-endless','scrap-yard','vase-ambush','torchbearer','double-agent','gust-bloom']

def module(name, filename):
 spec=importlib.util.spec_from_file_location(name, ROOT/filename)
 result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

helpers=module('gust_packaging_helpers','package-chill.py')
require=helpers.require;digest=helpers.digest;record=helpers.record
read_json=helpers.read_json;json_bytes=helpers.json_bytes;safe_name=helpers.safe_name

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--release-root',type=Path,default=ROOT.parents[1]/'plants-vs-zombies-web-release')
 parser.add_argument('--output',type=Path,required=True)
 args=parser.parse_args();release=args.release_root.resolve();output=args.output.resolve()
 require(output.is_relative_to(ROOT) and output!=ROOT and not output.exists(),'A new candidate staging directory is required')
 source=helpers.source_tree(ROOT/'source');require(len(source)==SOURCE_COUNT,'Production source count differs')
 hashes={name:digest(data) for name,data in source.items()}
 source_pins={'source/'+name:pin for name,pin in hashes.items()}
 normal_bytes=(ROOT/'logs/build-result.json').read_bytes();normal=json.loads(normal_bytes)
 require(normal['status']=='PASS' and normal['exitCode']==0 and normal['sourceUnchangedDuringBuild'] is True
  and normal['sourceFiles']==SOURCE_COUNT,'Passing unchanged normal Release build required')
 for name in ('source-before.json','source-after.json'):
  require(read_json(ROOT/'logs'/name)==hashes,'Normal build source snapshot differs')
 cache={}
 for line in (ROOT/'build/CMakeCache.txt').read_text().splitlines():
  if not line.startswith(('#','//')) and '=' in line and ':' in line.split('=',1)[0]:
   key,value=line.split('=',1);cache[key.split(':',1)[0]]=value
 require(all(cache.get(key)==value for key,value in helpers.FLAGS.items()),'Normal Release flags differ')
 require(Path(cache['CMAKE_HOME_DIRECTORY']).resolve()==(ROOT/'source').resolve(),'Normal build belongs to another source directory')
 artifacts={}
 for name in ('pvz-portable.js','pvz-portable.wasm','ProjectVersion.h'):
  pin=record((ROOT/'build'/name).read_bytes());expected=normal['outputs']['build/'+name]
  require(pin['bytes']==expected['bytes'] and pin['sha256']==expected['sha256'],'Normal build output differs: '+name)
  artifacts[name]=pin
 require(VERSION.encode() in source['CMake/ProjectVersion.cmake'] and VERSION.encode() in (ROOT/'build/ProjectVersion.h').read_bytes(),'Compiled version differs')
 reports={};report_bytes={};object_pins=None
 for name in FOCUSED+ENGINES:
  path=ROOT/'tests'/f'{name}-results.json';report_bytes[name]=path.read_bytes();report=json.loads(report_bytes[name])
  require(str(report['status']).startswith('PASS') and report['exitCode']==0 and report['failures']==0
   and isinstance(report['checks'],int) and report['checks']>0,'Native suite did not pass: '+name)
  require(report['sourceSha256'] and all(source_pins.get(p)==pin for p,pin in report['sourceSha256'].items()),'Stale suite source: '+name)
  require(digest((ROOT/'tests'/f'{name}-harness.cpp').read_bytes())==report['generatedHarnessSha256'],'Stale harness: '+name)
  if name in ENGINES:
   require(report['execution']=='complete-production-engine' and report['optimization']=='O2'
    and report['sourceSha256']==source_pins and report['productionObjectCount']==OBJECT_COUNT
    and len(report['productionObjectSha256'])==OBJECT_COUNT
    and report['productionBuildReceiptSha256']==digest(normal_bytes),'Stale complete engine: '+name)
   if object_pins is None:object_pins=report['productionObjectSha256']
   require(report['productionObjectSha256']==object_pins,'Drivers linked different game objects')
   for field,filename in [('builderSha256',f'build-{name}.py'),('runnerSha256',f'test-{name}.py')]:
    require(digest((ROOT/'tests'/filename).read_bytes())==report[field],'Changed recipe: '+filename)
   for filename,pin in report['testArtifactSha256'].items():
    require(digest((ROOT/'tests'/safe_name(filename)).read_bytes())==pin,'Changed native executable: '+filename)
   # Complete-engine runners default to read-only retained-report validation.
   # Focused runners always compile/execute, so never invoke them here after
   # their frozen results have already passed the independent focused gate.
   helpers.checked([sys.executable,ROOT/'tests'/f'test-{name}.py'],cwd=ROOT)
  reports[name]=report
 require(len(reports)==28,'All retained27 and the new Gust-bloom suite are required')
 require(all(digest((ROOT/'build'/safe_name(name)).read_bytes())==pin for name,pin in object_pins.items()),'Linked production objects changed after testing')
 # Keep the authenticated immediate parent independent of which release is
 # currently installed in the local website checkout.
 parent_manifest_raw=(ROOT/'parent-engine-provenance.json').read_bytes();parent_manifest=json.loads(parent_manifest_raw)
 require(parent_manifest['id']=='0.2.6-web-double.1' and parent_manifest['artifacts']['sourceSha256']==PARENT_SHA,'Immediate published parent differs')
 parent_path=release/'dist/source/pvz-portable-0.2.6-web-double.1-source.zip'
 parent=helpers.archive_source(parent_path,PARENT_SHA,'double1-candidate/source/',872)
 added={'src/Lawn/System/'+name+suffix for name in ('GustBloom','GustChallenge','GustBloomArt') for suffix in ('.h','.cpp')}
 require(set(source)-set(parent)==added and set(parent)<set(source),'Unexpected added/removed production paths')
 upstream=helpers.archive_source(release/'dist/source/pvz-portable-0.2.6-source.zip',helpers.UPSTREAM_SHA,'PvZ-Portable-0.2.6/',753)
 full_patch,full_changes=helpers.make_patch(upstream,source);delta_patch,delta_changes=helpers.make_patch(parent,source)
 patch_checks={'upstream':helpers.reconstruct(upstream,full_patch,source),'double1':helpers.reconstruct(parent,delta_patch,source)}
 historical_paths,historical=helpers.historical_comparison_inputs(release)
 codec=module('gust_native_codec','pack-native-artifacts.py')
 packed,metadata_bytes,native_names=codec.pack(ROOT/'tests');metadata=json.loads(metadata_bytes)
 expected={name+'-engine'+suffix for name in ENGINES+['endless3-parent'] for suffix in ('.js','.wasm')}
 require(native_names==expected,'Unexpected linked native executable set')
 tests={}
 for path in sorted((ROOT/'tests').rglob('*')):
  if not path.is_file():continue
  require(not path.is_symlink(),'Test symlink is not allowed')
  relative=path.relative_to(ROOT).as_posix()
  if any(part in {'__pycache__','node_modules'} for part in path.parts):continue
  require(path.suffix.lower()!='.pak','Private game assets cannot enter corresponding source')
  if path.name in native_names or path.suffix.lower() in {'.js','.wasm','.o','.obj','.a','.lib','.pyc','.tmp','.exe','.dll','.pdb','.so','.dylib'} or path.name.endswith('-harness-native'):continue
  if path.name in helpers.DEVELOPMENT_ONLY_TEST_FILES:continue
  tests[relative]=path.read_bytes()
 # Failed observations remain evidence, never classified as successful cases.
 tests['tests/native-artifacts.xz']=packed;tests['tests/native-artifacts.json']=metadata_bytes
 require(len(historical_paths)==2,'Both historical comparator files must remain independently authenticated')
 snapshot=(ROOT/'tests/gust1-retained-parent/manifest.json').read_bytes()
 require(digest(snapshot)=='afae585b66dfaef7effed2fcdf4e352bb3d273a2e77b4ad50a093a177e0aea67','Published Double test snapshot changed')
 with zipfile.ZipFile(parent_path) as archive:
  for name,pin in json.loads(snapshot)['files'].items():
   original=archive.read('double1-candidate/tests/'+name)
   require((ROOT/'tests/gust1-retained-parent'/safe_name(name)).read_bytes()==original and len(original)==pin['bytes'] and digest(original)==pin['sha256'],'Published parent test input changed: '+name)
 recipes={p.name:p.read_bytes() for p in sorted(ROOT.iterdir()) if p.is_file() and p.suffix in {'.py','.ps1','.md','.json'}}
 members={'source/'+name:data for name,data in source.items()};members.update(tests);members.update(recipes)
 for name in ('logs/build-result.json','logs/source-before.json','logs/source-after.json','build/ProjectVersion.h'):
  members[name]=(ROOT/name).read_bytes()
 members['source-manifest.json']=json_bytes({'version':VERSION,'files':{name:record(data) for name,data in source.items()}})
 with tempfile.TemporaryDirectory(prefix='gust-codec-check-',dir=ROOT) as temporary:
  folder=Path(temporary);(folder/'tests').mkdir();(folder/'tests/native-artifacts.xz').write_bytes(packed);(folder/'tests/native-artifacts.json').write_bytes(metadata_bytes)
  helpers.checked([sys.executable,ROOT/'unpack-native-artifacts.py','--root',folder])
  require(all((folder/'tests'/name).read_bytes()==(ROOT/'tests'/name).read_bytes() for name in native_names),'Packed native bytes differ')
 require(helpers.source_tree(ROOT/'source')==source,'Source changed during validation')
 require(all((ROOT/'tests'/f'{name}-results.json').read_bytes()==raw for name,raw in report_bytes.items()),'Test evidence changed during validation')
 output.mkdir();(output/'game').mkdir();(output/'source').mkdir()
 for name in ('pvz-portable.js','pvz-portable.wasm'):shutil.copyfile(ROOT/'build'/name,output/'game'/name)
 full_name='web-gust.1.patch';delta_name='double1-to-gust1.patch';source_name=f'pvz-portable-{VERSION}-source.zip'
 (output/'source'/full_name).write_bytes(full_patch);(output/'source'/delta_name).write_bytes(delta_patch)
 archive_path=output/'source'/source_name;prefix='gust1-candidate/'
 with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,data in sorted(members.items()):
   safe_name(name);info=zipfile.ZipInfo(prefix+name,date_time=(2026,11,11,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16;archive.writestr(info,data)
 with zipfile.ZipFile(archive_path) as archive:
  require(archive.testzip() is None and len(archive.namelist())==len(members),'Invalid corresponding source ZIP')
  require(all(archive.read(prefix+name)==data for name,data in members.items()),'Source ZIP byte mismatch')
 source_record={'path':source_name,**record(archive_path.read_bytes()),'entries':len(members),'uncompressedBytes':sum(map(len,members.values()))}
 packing={'format':metadata['format'],'rawFiles':len(expected),'currentFiles':len(ENGINES)*2,'historicalFiles':2,
  'metadata':{'path':'tests/native-artifacts.json',**record(metadata_bytes)},'archive':{'path':'tests/native-artifacts.xz',**record(packed)},
  'decoder':{'path':'unpack-native-artifacts.py',**record(recipes['unpack-native-artifacts.py'])},'rawBytes':metadata['rawBytes'],'rawSha256':metadata['rawSha256']}
 checks=sum(r['checks'] for r in reports.values());late=reports['pool-panic-endless']['lateGame']['checks']
 limits=['Adds Gust-bloom and its Headwind unlock challenge using native art and controls. No saved object layouts change.',
  'All retained native cases run against the current production objects. Synthetic controls are separately labeled. Browser observations and timing measurements are recorded separately; native tests do not certify browser/compositor performance. Historical Torch observations remain historical.']
 provenance={'id':VERSION,'upstream':parent_manifest['upstream'],'sourceArchive':source_record,
  'artifacts':[{'path':'build/'+name,**pin} for name,pin in artifacts.items()],
  'sourceFiles':SOURCE_COUNT,'sourceBytes':sum(map(len,source.values())),'sourceDeltaVsDouble1':delta_changes,
  'compiledVersionHeader':(ROOT/'build/ProjectVersion.h').read_text(),'nativeArtifactPacking':packing,
  'checks':{'fullRelease':{'exitCode':0,'flags':helpers.FLAGS,'sourceUnchangedDuringBuild':True,'receipt':{'path':'logs/build-result.json',**record(normal_bytes)}},
   'focusedNativeTests':{'status':'PASS28 native suites','failures':0,'checks':checks,'lateChecks':late,'totalChecksWithLate':checks+late,
    'scope':'13 focused and15 complete production-engine suites; retained gameplay matrices freshly executed with audio disabled.',
    'reports':[{'path':'tests/'+name+'-results.json',**record((ROOT/'tests'/f'{name}-results.json').read_bytes()),'checks':reports[name]['checks']} for name in FOCUSED+ENGINES]},
   'patchReconstruction':patch_checks,'historicalComparison':historical},
  'combinedPatch':{'path':full_name,**record(full_patch),'sourcePaths':len(full_changes)},
  'incrementalPatch':{'path':delta_name,**record(delta_patch),'sourcePaths':len(delta_changes)},
  'parent':{'id':parent_manifest['id'],'sourceArchiveSha256':PARENT_SHA,'releaseManifestSha256':digest(parent_manifest_raw)},'limits':limits}
 engine={'id':VERSION,'upstream':parent_manifest['upstream'],'artifacts':{'jsSha256':artifacts['pvz-portable.js']['sha256'],'wasmSha256':artifacts['pvz-portable.wasm']['sha256'],
  'source':'../source/'+source_name,'sourceSha256':source_record['sha256'],'patch':'../source/'+full_name,'patchSha256':digest(full_patch)},
  'buildRecord':'../source/build-provenance.json','change':'Adds Gust-bloom, its Almanac and regular seed unlock, and the Headwind conveyor challenge.',
  'caption':'with Gust-bloom.','gameAssetsIncluded':parent_manifest['gameAssetsIncluded'],'assetManifest':parent_manifest['assetManifest'],'assetBundleId':parent_manifest['assetBundleId'],
  'parent':parent_manifest,'parentScope':'Historical Double.1 metadata; all current results are recorded separately.','limits':limits}
 (output/'source/build-provenance.json').write_bytes(json_bytes(provenance));(output/'game/engine-provenance.json').write_bytes(json_bytes(engine))
 require(helpers.source_tree(ROOT/'source')==source,'Source changed while staging')
 print(json.dumps({'status':'PASS staged Gust-bloom','staging':str(output),'sourceArchive':source_record,'sourceFiles':SOURCE_COUNT,'nativeSuites':len(reports),'nativeArtifactPacking':packing,'changedSourcePaths':[x['path'] for x in delta_changes]},indent=2))

if __name__=='__main__':main()
