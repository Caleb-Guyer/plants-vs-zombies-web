# Intensive Lawn Care full-run validation

Exact parent Care.2 corresponding source SHA-256:
`d8c52ecbb0f4f417b871137fb2a27017a2cb8699b1f6702fb363399a7ea7bf98`.
817 production inputs under care2-candidate/source/.

Build the normal browser engine with build-chill.py, using the retained Release
Emscripten toolchain. The separate test driver links the actual engine objects
with a silent resource bootstrap. It does not replace combat, collision, wave,
healing, mower or save implementations with a balance model. Its build recipe,
source and pinned test-only Node/WASM artifacts accompany the fourteen suites.

Run all suites after source freezes. The full-run suite requires authenticated
approved game assets via --asset-root. Missing assets must not become a passing
approximate simulation. Ordinary source-only verification authenticates recorded
results/artifacts; runtime CI executes the scenarios with its bundled assets.

package-chill.py stages only after matching source/build/test receipts and exact
upstream/parent patch reconstruction. Output: web-care.3.patch,
care2-to-care3.patch and source archive with care3-candidate/ prefix.
