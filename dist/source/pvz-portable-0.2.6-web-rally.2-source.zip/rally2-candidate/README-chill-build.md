# Rally Zombie animation maintenance

Exact published Rally.1 parent source SHA-256:
a37ba37528139bc38df887a027c7c54aadfb2065897f32a48a556b3dc15df63e.
824 production inputs under rally1-candidate/source/.

Build the normal Release browser engine with build-chill.py. Separate silent
Care, Chain Reaction and Rally Zombie drivers link those same production
objects with test-only entry points. All sixteen retained suites rerun against
this build. Rally actor controls additionally compare native arm transitions
with the original carrier tracks and reject the old skipped-blend rendering.
Fresh native Board construction is also tested over four recycled-storage
patterns before wave selection; existing checkpoint graphs remain covered.

package-chill.py authenticates current source/build/test receipts and exact
parent/upstream patch reconstruction before staging matching source/binaries.
Corresponding source, tests and executed report artifacts use rally2-candidate/.
No audio device is opened by automated native tests.
