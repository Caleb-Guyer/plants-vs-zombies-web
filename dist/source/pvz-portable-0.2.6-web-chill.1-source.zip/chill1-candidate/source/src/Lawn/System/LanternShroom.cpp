// SPDX-License-Identifier: LGPL-3.0-or-later
#include "LanternShroom.h"
#include "FrostShroomCap.h"
#include "BonusChallengeArt.h"
#include "../Plant.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../SexyAppFramework/graphics/GLImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/Reanimator.h"
#include <png.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>

namespace LanternShroom
{
namespace
{
struct SpriteCache
{
    std::unique_ptr<Sexy::GLImage> cap;
    std::unique_ptr<Sexy::MemoryImage> preview;
    std::array<std::unique_ptr<Sexy::GLImage>, 3> bonus;
    bool attempted = false;
};
SpriteCache& CachedSprite()
{
    static SpriteCache cache;
    return cache;
}

std::vector<unsigned char> DecodeBase64(const char* text)
{
    std::vector<unsigned char> bytes;
    bytes.reserve(std::strlen(text) * 3 / 4);
    unsigned int value = 0;
    int bits = -8;
    for (const unsigned char* current = reinterpret_cast<const unsigned char*>(text); *current; ++current)
    {
        const unsigned char c = *current;
        if (c == '=') break;
        if (c == '\r' || c == '\n') continue;
        const int digit = c >= 'A' && c <= 'Z' ? c - 'A' : c >= 'a' && c <= 'z' ? c - 'a' + 26 :
            c >= '0' && c <= '9' ? c - '0' + 52 : c == '+' ? 62 : c == '/' ? 63 : -1;
        if (digit < 0) return {};
        value = (value << 6) | static_cast<unsigned int>(digit);
        bits += 6;
        if (bits >= 0)
        {
            bytes.push_back(static_cast<unsigned char>((value >> bits) & 255U));
            bits -= 8;
        }
    }
    return bytes;
}

std::unique_ptr<Sexy::GLImage> DecodeImage(const char* encoded, int width, int height, bool trimTransparent = false, int contentHeight = 0)
{
    const auto bytes = DecodeBase64(encoded);
    if (bytes.empty()) return nullptr;
    png_image input{};
    input.version = PNG_IMAGE_VERSION;
    if (!png_image_begin_read_from_memory(&input, bytes.data(), bytes.size())) return nullptr;
    input.format = PNG_FORMAT_RGBA;
    std::vector<unsigned char> rgba(PNG_IMAGE_SIZE(input));
    if (!png_image_finish_read(&input, nullptr, rgba.data(), 0, nullptr))
    {
        png_image_free(&input);
        return nullptr;
    }
    int left = 0, top = 0, right = static_cast<int>(input.width) - 1, bottom = static_cast<int>(input.height) - 1;
    if (trimTransparent)
    {
        left = static_cast<int>(input.width); top = static_cast<int>(input.height); right = bottom = -1;
        for (int y = 0; y < static_cast<int>(input.height); ++y)
            for (int x = 0; x < static_cast<int>(input.width); ++x)
                if (rgba[(y * input.width + x) * 4 + 3] > 8)
                {
                    left = std::min(left, x); top = std::min(top, y);
                    right = std::max(right, x); bottom = std::max(bottom, y);
                }
        if (right < left || bottom < top) { png_image_free(&input); return nullptr; }
    }
    const int sourceWidth = right - left + 1, sourceHeight = bottom - top + 1;
    const int drawnHeight = contentHeight > 0 ? std::min(contentHeight, height) : height;
    std::vector<uint32_t> pixels(width * height, 0);
    for (int y = 0; y < drawnHeight; ++y)
        for (int x = 0; x < width; ++x)
        {
            unsigned int alpha = 0, red = 0, green = 0, blue = 0;
            for (int sy = 0; sy < 4; ++sy)
                for (int sx = 0; sx < 4; ++sx)
                {
                    const int sourceX = std::min(right, left +
                        static_cast<int>((x + (sx + 0.5f) * 0.25f) * sourceWidth / width));
                    const int sourceY = std::min(bottom, top +
                        static_cast<int>((y + (sy + 0.5f) * 0.25f) * sourceHeight / drawnHeight));
                    const auto* sample = &rgba[(sourceY * input.width + sourceX) * 4];
                    const unsigned int a = sample[3];
                    alpha += a; red += sample[0] * a; green += sample[1] * a; blue += sample[2] * a;
                }
            if (alpha)
                pixels[y * width + x] = ((alpha / 16) << 24) | ((red / alpha) << 16) | ((green / alpha) << 8) | (blue / alpha);
        }
    png_image_free(&input);
    auto image = std::make_unique<Sexy::GLImage>(gLawnApp->mGLInterface.get());
    image->SetBits(pixels.data(), width, height);
    return image;
}
}

void DisposeImage()
{
    SpriteCache& cache = CachedSprite();
    for (auto& image : cache.bonus) image.reset();
    cache.preview.reset();
    cache.cap.reset();
    cache.attempted = false;
}

Sexy::Image* GetCapImage()
{
    SpriteCache& cache = CachedSprite();
    if (!cache.attempted)
    {
        cache.attempted = true;
        // Retain the native canvas/pivot, with room below the cap for Ice-shroom's eyes.
        cache.cap = DecodeImage(FrostShroomCapArt::kPngBase64, 103, 54, true, 46);
    }
    return cache.cap.get();
}

void BindCap(Reanimation& reanimation, int glow)
{
    (void)glow;
    if (!reanimation.TrackExists("IceShroom_head")) return;
    Sexy::Image* cap = GetCapImage();
    if (cap && reanimation.GetImageOverride("IceShroom_head") != cap)
        reanimation.SetImageOverride("IceShroom_head", cap);
}

void ConfigureAttackAnimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body) return;
    const bool winding = !plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE &&
        GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown) == AttackPhase::Windup;
    const char* layer = plant.mIsAsleep || winding ? "anim_sleep" : "anim_idle";
    if (!body->IsAnimPlaying(layer)) body->PlayReanim(layer, REANIM_LOOP, 6, 12.0f);
    if (winding)
    {
        plant.EndBlink();
        plant.mBlinkCountdown = std::max(plant.mBlinkCountdown, kWindupTicks + 1);
    }
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth < 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (body && body->mReanimationType != REANIM_ICESHROOM)
    {
        // Upgrade the previous muzzle-bearing carrier, retaining the same plant.
        plant.EndBlink();
        plant.mApp->RemoveReanimation(plant.mBodyReanimID);
        plant.mBodyReanimID = REANIMATIONID_NULL;
        body = nullptr;
    }
    if (!body)
    {
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, plant.mSeedType, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0.0f, offsetY, plant.mRenderOrder + 1, REANIM_ICESHROOM);
        body->SetFramesForLayer(plant.mIsAsleep ? "anim_sleep" : "anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mAnimRate = 12.0f;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
        if (plant.mBlinkCountdown <= 0) plant.mBlinkCountdown = 400;
        if (!plant.mIsAsleep && plant.mOnBungeeState == NOT_ON_BUNGEE)
        {
            const AttackPose pose = GetAttackPose(plant.mStateCountdown, plant.mDoSpecialCountdown);
            body->SetPosition(pose.offsetX, offsetY + pose.offsetY);
            body->OverrideScale(pose.scaleX, pose.scaleY);
        }
    }
    BindCap(*body);
    ConfigureAttackAnimation(plant);
}

Sexy::Image* GetImage()
{
    SpriteCache& cache = CachedSprite();
    if (cache.preview) return cache.preview.get();
    std::vector<uint32_t> pixels(120 * 120, 0);
    cache.preview = std::make_unique<Sexy::MemoryImage>();
    cache.preview->SetBits(pixels.data(), 120, 120);
    Sexy::Graphics graphics(cache.preview.get());
    graphics.SetLinearBlend(true);
    Reanimation native;
    native.ReanimationInitializeType(20.0f, 20.0f, REANIM_ICESHROOM);
    native.SetFramesForLayer("anim_idle");
    BindCap(native);
    native.Draw(&graphics);
    return cache.preview.get();
}

Sexy::Image* GetBonusImage(GameMode mode)
{
    const int index = mode == GAMEMODE_CHALLENGE_CONE_ZONE ? 0 : mode == GAMEMODE_CHALLENGE_NIGHT_SHIFT ? 1 :
        mode == GAMEMODE_CHALLENGE_LANTERN_GLOW ? 2 : -1;
    if (index < 0) return nullptr;
    SpriteCache& cache = CachedSprite();
    if (!cache.bonus[index])
    {
        const char* encoded = index == 0 ? BonusChallengeArt::kConeZoneBase64 : index == 1 ?
            BonusChallengeArt::kNightShiftBase64 : BonusChallengeArt::kColdFrontBase64;
        cache.bonus[index] = DecodeImage(encoded, 80, 65);
    }
    return cache.bonus[index].get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    if (Sexy::Image* preview = GetImage())
        PvzpDrawImageScaledF(graphics, preview, x - 20.0f * scaleX, y - 20.0f * scaleY, scaleX, scaleY);
}

void DrawAttackPulse(Sexy::Graphics* graphics, const Plant& plant, float offsetY)
{
    if (plant.mDead || plant.mPlantHealth < 0 || plant.mSquished || plant.mIsAsleep || plant.mOnBungeeState != NOT_ON_BUNGEE) return;
    const AttackPhase phase = GetAttackPhase(plant.mStateCountdown, plant.mDoSpecialCountdown);
    if (phase == AttackPhase::Idle) return;
    Sexy::Graphics frost(*graphics);
    // Keep transient frost on the lawn, clear of the seed bank and menu.
    frost.ClipRect(-plant.mX, 80 - plant.mY, 800, 520);
    frost.SetColorizeImages(true);
    struct Direction { float x; float y; };
    static constexpr Direction directions[12] = {
        {1,0},{0.8660254f,0.5f},{0.5f,0.8660254f},{0,1},{-0.5f,0.8660254f},{-0.8660254f,0.5f},
        {-1,0},{-0.8660254f,-0.5f},{-0.5f,-0.8660254f},{0,-1},{0.5f,-0.8660254f},{0.8660254f,-0.5f}
    };
    if (phase == AttackPhase::Windup)
    {
        const float progress = (kWindupTicks - plant.mStateCountdown) / static_cast<float>(kWindupTicks);
        const float radius = 20.0f - 14.0f * progress;
        frost.SetColor(Sexy::Color(210, 240, 255, 80 + static_cast<int>(progress * 100.0f)));
        if (Sexy::IMAGE_SNOWFLAKES)
            for (int i = 0; i < 12; i += 3)
                PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWFLAKES, 40.0f + directions[i].x * radius,
                    32.0f + offsetY + directions[i].y * radius * 0.65f, i % 3, 0.35f, 0.35f);
        return;
    }
    const float progress = 1.0f - std::clamp(plant.mDoSpecialCountdown, 0, kPulseFrames) / static_cast<float>(kPulseFrames);
    const float radius = 18.0f + (kRadius - 18.0f) * progress * (2.0f - progress);
    frost.SetColor(Sexy::Color(210, 240, 255, static_cast<int>((1.0f - progress) * 200.0f)));
    for (int i = 0; i < 12; ++i)
    {
        const float distance = radius * (0.82f + (i % 3) * 0.09f);
        if (Sexy::IMAGE_SNOWFLAKES)
            PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWFLAKES, 40.0f + directions[i].x * distance,
                40.0f + offsetY + directions[i].y * distance, i % 3, 0.45f + progress * 0.15f, 0.45f + progress * 0.15f);
        if (i % 2 == 0 && Sexy::IMAGE_SNOWPEA_PUFF)
            PvzpDrawImageCelCenterScaledF(&frost, Sexy::IMAGE_SNOWPEA_PUFF, 40.0f + directions[i].x * radius * 0.7f,
                40.0f + offsetY + directions[i].y * radius * 0.7f, std::min(5, static_cast<int>(progress * 6)),
                0.60f + progress * 0.25f, 0.60f + progress * 0.25f);
    }
}
}
