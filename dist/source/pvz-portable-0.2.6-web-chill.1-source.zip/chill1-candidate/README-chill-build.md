# Chill.1 identity and attack revision

Uses the original muzzle-free Ice-shroom carrier with a new snowy cap, a saved-phase
wind-up and radial frost release, and painted Bonus illustrations. Player-facing
names are Chill-shroom and Cold Front. Internal legacy IDs and saved layouts stay stable.

Run with the existing Emscripten toolchain:

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Runners accept --native for host C++20 and initialize no game or audio device.
Release flags: DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF, LOW_MEMORY=OFF. Configure the SDK
paths in build-candidate.ps1 when using a different workspace/toolchain.

FrostShroomCap.h and BonusChallengeArt.h contain lossless base64 encodings of the
image_gen PNGs. Runtime decodes/downsamples once to native sizes and retains alpha.
Public dist/content PNGs and metadata record the exact outputs and full prompts.
All corresponding source, tests and build/package receipts are included. Parent
and upstream archives are authenticated; patches reconstruct every source byte.
