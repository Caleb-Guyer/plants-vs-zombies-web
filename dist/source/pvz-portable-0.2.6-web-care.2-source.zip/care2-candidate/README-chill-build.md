# Native Intensive Lawn Care layout correction

Parent: exact published Care.1 source archive SHA-256
`540f1ee365b558e10304995692485976e91f23bb1b28c305e6ade6cd17f1ed11`.
817 production files under care1-candidate/source/.

Corrects the visible conveyor-frame/glove separation and the native opening hint,
including its paused presentation. Original artwork, minigame rules and saved
member layouts stay intact. Native layout tests use authenticated original image
dimensions, font metrics, real drawing paths and parent translations.

Build with build-chill.py using the retained Release Emscripten toolchain.
Run all twelve tests/test-*.py suites without launching audio. Package only after
source/build/test receipts freeze. package-chill.py authenticates parent/current
inputs and reconstructs raw upstream and exact Care.1 sources byte for byte.
Fresh staging contains web-care.2.patch, care1-to-care2.patch, engine binaries and
corresponding source with the care2-candidate/ prefix.
