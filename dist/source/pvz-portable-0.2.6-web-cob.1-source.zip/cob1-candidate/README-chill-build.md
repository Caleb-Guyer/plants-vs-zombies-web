# Cob Cannon Command: source and native tests

Published Bungee.1 parent source SHA-256:
452205b2a2e383a74183423ddcd730db978abe0ed086f8463c168c75142f9062.
Parent:31,850,177bytes/962entries/840production files underbungee1-candidate/source/.
Current prefix:cob1-candidate/; current production:844files.

Cob Cannon Command appends mode85, profile record84 and the thirteenth Bonus
card. One finite artillery battle starts with six native Cob Cannons, five
Wall-nuts and five original mowers. Eight authored formations include36
zombies, with native Gargantuars and real thrown Imps in the late battle.
Original two-click aim/cancel, initial500arming,3000reload plus charge animation,
COBBIG flight and native splash damage remain unchanged. The bank, planting,
sun and incidental loot are disabled only for this mode. Original wave meter,
Menu, speed, pause, aiming reticle and native footer provide the interface.
All progress uses existing saved fields; no serialized layouts or art change.

Build normal Release with build-chill.py. All21native suites are release gates.
Eight silent complete-engine drivers link the same130production objects except
main. The new24case/12pair matrix executes actual native aim/fire inputs,
projectile physics, damage, complete reloads, midflight/reload saves, Pause,
fresh Retry, awards and independent full replays. Both RNG seeds and1x/2x run;
the reload checkpoint uses a slower500tick policy, other wins250ticks. Genuine
no-fire defeats and isolated native input and rendering controls grant no win credit.
Fifty-three original art inputs authenticate cannon, reticle, effects, UI and
background. Offscreen MemoryImage rasters do not establish browser/GPU parity;
muted actual-browser inspection is separate. Normal game audio remains usable.

package-chill.py binds all exact build/source/test/artifact receipts. The full
web-cob.1.patch and incremental bungee1-to-cob1.patch reconstruct all844files
byte-for-byte. Every retained regression and accepted bitmap remains a gate.
