"""Build this content engine with the existing local Emscripten toolchain."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / 'logs'
LOGS.mkdir(exist_ok=True)

def sources():
    return {p.relative_to(ROOT / 'source').as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT / 'source').rglob('*')) if p.is_file()}

def write(name, value):
    (LOGS / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

before = sources()
write('source-before.json', before)
start = time.monotonic()
print('Building content engine with the local Release toolchain...', flush=True)
with (LOGS / 'build.log').open('w', encoding='utf-8') as log:
    result = subprocess.run([shutil.which('pwsh') or shutil.which('powershell'),
                             '-NoProfile', '-File', str(ROOT / 'build-candidate.ps1')],
                            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
after = sources()
write('source-after.json', after)
outputs = {}
for name in ('pvz-portable.js', 'pvz-portable.wasm', 'ProjectVersion.h'):
    path = ROOT / 'build' / name
    if path.is_file():
        data = path.read_bytes()
        outputs['build/' + name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
report = {'status': 'PASS' if result.returncode == 0 and before == after else 'FAIL',
          'exitCode': result.returncode, 'elapsedSeconds': round(time.monotonic() - start, 3),
          'sourceUnchangedDuringBuild': before == after, 'sourceFiles': len(after),
          'outputs': outputs}
write('build-result.json', report)
print(json.dumps(report, indent=2))
sys.exit(0 if report['status'] == 'PASS' else 1)
