# Polish.1 native engine build

Simplifies native menus and deck previews while retaining Content.1, Cone Zone
and all original game modes. Browser save-worker source lives in the website. Existing native saved-object layouts and
profile serialization remain unchanged.

Build and validate with the existing Emscripten toolchain:

    python build-content.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python package-polish.py

Test runners accept --native for a host C++20 compiler. They initialize no full
game or audio device. The build uses Release with DO_FIX_BUGS=OFF, PVZ_DEBUG=OFF
and LOW_MEMORY=OFF. The recipe expects work/toolchain alongside this workspace;
configure the SDK paths for another machine.

Packaging requires successful build/test receipts matching all current source
and artifact hashes. It applies full-upstream and incremental Content.1 patches to
temporary source trees and compares every resulting source byte. Parent source
identity and the frozen parent engine manifest are pinned. Each --output must be
a new directory inside this candidate. The source archive includes current
source, recipes, tests and receipts; compiled test executables, game resources,
private saves and credentials are excluded. Runtime assets remain separately
bundled by the website.
