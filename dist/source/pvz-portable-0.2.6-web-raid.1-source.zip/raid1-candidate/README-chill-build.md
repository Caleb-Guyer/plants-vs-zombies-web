# Rally Raid corresponding source and tests

Exact published Rally.3 parent source SHA-256:
2deb50f9a38d8599453f567f5458a20505d552956df0bc442e649e49ea1c5c24.
The parent has 824 production files under rally3-candidate/source/.

Build the normal Release browser engine with build-chill.py. Separate muted
Care, Chain Reaction, Rally Zombie and Rally Raid CLI drivers link those same
production objects with test-only entry points. The new Raid report separates
legal puzzle clears, scripted modal inputs and isolated negative controls.
All retained native source/method checks remain release gates.

package-chill.py authenticates current source/build/test receipts and exact
parent/upstream patch reconstruction before staging matching source/binaries.
Corresponding source, recipes and reports use raid1-candidate/.
Native test hardware never opens an audio device.
