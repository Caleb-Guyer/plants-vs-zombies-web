# Chill.6 approved silhouette and registered rig

The user accepted the whole-character proportions before implementation. The
approved PNG SHA-256 is f861148f8c57bbee31595e8fd5692aa23c1282172ab0016a159adf406f2a373d.
It has a broad rounded asymmetric cap, a short wide body and no pinched neck or
separate feet. One uniform whole-character resize produces the canonical80x80
canvas. Its neutral RGBA SHA-256 is c00b7d93e79d2fb8f39ea2dbddd178e02d040ac1f4fd2e8bb62f105502317fb7.

The source master, closed-eye edit and both exact built-in image_gen prompts
are in source/artwork/chill-shroom/. The PNGs are base64 text for patchability.
Pillow12.2.0 render.py creates registered cap/body layers after normalization;
no part is resized independently. Their neutral union equals the approved
canonical pixels exactly. Bounded eye patches preserve shape/alpha and all
outside-eye paint. Half/closed states share body registration. The base is blank.

DrawRig supplies one image-independent local rig for live plants, seed previews
and Cold Front portraits. The invisible native Ice carrier retains clock,
blink/sleep/attachment and save ownership, not visible artwork pivots. Native
color/flash/filter/world transforms and foot-anchored saved phase are retained.
Cap motion is bounded and vertical; all rendered parts are cached. No image
composition/decode/filter allocation occurs per frame.

Challenge cards compose actual sprites over original lawns. There is no new
standalone generated challenge illustration. All IDs, serialized layouts,
attack/cost/recharge/radius/chill/cadence and original plants are unchanged.

    python build-chill.py
    python tests/test-game-speed.py
    python tests/test-qol-controls.py
    python tests/test-decks-cooldowns.py
    python tests/test-bonus-challenge.py
    python tests/test-bonus-completion.py
    python tests/test-night-shift.py
    python tests/test-lantern-shroom.py
    python package-chill.py

Native focused tests start no audio device. Full/upstream and Chill.5 delta
patches reconstruct every source byte. Tests and bounded muted game review do
not prove subjective perfection or exhaustive original-game parity.
