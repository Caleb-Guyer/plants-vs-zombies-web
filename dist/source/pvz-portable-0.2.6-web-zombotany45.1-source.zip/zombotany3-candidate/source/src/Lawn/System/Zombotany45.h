// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Zombie;
class Plant;
class Projectile;

namespace Zombotany45
{
inline constexpr GameMode kFogMode = GAMEMODE_CHALLENGE_ZOMBOTANY_4;
inline constexpr GameMode kRoofMode = GAMEMODE_CHALLENGE_ZOMBOTANY_5;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(148);
inline constexpr int kFogProfileIndex = 93;
inline constexpr int kRoofProfileIndex = 94;
inline constexpr int kRulesVersion = 1;
inline constexpr int kWaveCount = 20;
inline constexpr int kWavesPerFlag = 10;
inline constexpr int kStartingSun = 50;
inline constexpr int kOpeningDelay = 1800;
inline constexpr int kRoofStartingPots = 15;
inline constexpr int kSeaRange = 180;
inline constexpr int kSeaDamage = 20;
inline constexpr int kSeaCadence = 150;
inline constexpr int kSeaWindup = 35;
inline constexpr int kSeaLifetime = 60;
inline constexpr int kCabbageRange = 520;
inline constexpr int kCabbageCadence = 250;
inline constexpr int kCabbageWindup = 55;
inline constexpr int kCabbageDamage = 40;
inline constexpr int kKernelRange = 480;
inline constexpr int kKernelCadence = 240;
inline constexpr int kKernelWindup = 55;
inline constexpr int kKernelDamage = 20;
inline constexpr int kButterDamage = 40;
inline constexpr int kButterTicks = 150;
inline constexpr int kButterChance = 4;
inline constexpr int kMelonRange = 560;
inline constexpr int kMelonCadence = 330;
inline constexpr int kMelonWindup = 65;
inline constexpr int kMelonDamage = 80;
inline constexpr int kMelonSplashDamage = 26;
inline constexpr int kLobMinimumRange = 100;
inline constexpr int kLobFlightTicks = 80;
inline constexpr int kUmbrellaAnticipationTicks = 20;
inline constexpr int kHostileLobMarker = -405;
inline constexpr int kFriendlyLobMarker = -406;
constexpr bool IsFog(GameMode mode) { return mode == kFogMode; }
constexpr bool IsRoof(GameMode mode) { return mode == kRoofMode; }
constexpr bool IsMode(GameMode mode) { return IsFog(mode) || IsRoof(mode); }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kActive; }
constexpr bool IsZombie(ZombieType type)
{ return type == ZOMBIE_SEA_HEAD || type == ZOMBIE_CABBAGE_HEAD || type == ZOMBIE_KERNEL_HEAD || type == ZOMBIE_MELON_HEAD; }
constexpr bool IsLobber(ZombieType type)
{ return type == ZOMBIE_CABBAGE_HEAD || type == ZOMBIE_KERNEL_HEAD || type == ZOMBIE_MELON_HEAD; }
struct FogWave { int mPuff; int mFume; int mPea; int mSea; int mWallnut; };
inline constexpr std::array<FogWave,kWaveCount> kFogWaves = {{
    {1,0,0,0,0},{1,0,0,1,0},{1,1,0,1,0},{2,0,1,1,0},{2,1,0,1,0},
    {2,1,1,1,0},{2,1,1,2,0},{3,1,1,2,0},{3,2,1,2,0},{3,2,1,2,1},
    {3,2,1,2,0},{3,2,1,2,0},{3,2,2,2,0},{3,2,2,3,0},{3,2,2,3,1},
    {3,3,2,3,0},{3,3,2,3,0},{3,3,2,3,1},{3,3,2,3,1},{4,3,2,3,1}
}};
struct RoofWave { int mCabbage; int mKernel; int mMelon; int mTallnut; };
inline constexpr std::array<RoofWave,kWaveCount> kRoofWaves = {{
    {1,0,0,0},{2,0,0,0},{1,1,0,0},{2,1,0,0},{2,1,0,0},
    {2,1,0,0},{3,1,0,0},{3,1,0,0},{3,1,1,0},{3,2,1,0},
    {3,2,1,0},{3,2,1,0},{3,2,1,1},{3,2,1,0},{4,2,1,0},
    {4,2,1,0},{4,2,1,1},{4,3,1,0},{4,3,1,1},{4,3,2,1}
}};
template<std::size_t Waves,std::size_t Slots> int PopulateWaves(ZombieType(&output)[Waves][Slots],GameMode mode)
{
    static_assert(Waves>=kWaveCount && Slots>16);
    for(auto& wave:output)for(auto& zombie:wave)zombie=ZOMBIE_INVALID;
    for(int wave=0;wave<kWaveCount;++wave)
    {
        int index=0;
        if((wave+1)%10==0)output[wave][index++]=ZOMBIE_FLAG;
        const auto add=[&](ZombieType type,int count){for(int n=0;n<count;++n)output[wave][index++]=type;};
        if(IsFog(mode))
        {
            const FogWave& entry=kFogWaves[wave];
            add(ZOMBIE_PUFF_HEAD,entry.mPuff);add(ZOMBIE_FUME_HEAD,entry.mFume);add(ZOMBIE_PEA_HEAD,entry.mPea);
            add(ZOMBIE_SEA_HEAD,entry.mSea);add(ZOMBIE_WALLNUT_HEAD,entry.mWallnut);
        }
        else
        {
            const RoofWave& entry=kRoofWaves[wave];
            add(ZOMBIE_CABBAGE_HEAD,entry.mCabbage);add(ZOMBIE_KERNEL_HEAD,entry.mKernel);
            add(ZOMBIE_MELON_HEAD,entry.mMelon);add(ZOMBIE_TALLNUT_HEAD,entry.mTallnut);
        }
    }
    return kWaveCount;
}
template<std::size_t Count> void PopulateAllowedZombies(bool(&output)[Count],GameMode mode)
{
    static_assert(Count>static_cast<std::size_t>(ZOMBIE_MELON_HEAD));
    for(auto& allowed:output)allowed=false;
    output[ZOMBIE_FLAG]=true;
    if(IsFog(mode))for(ZombieType type:{ZOMBIE_PUFF_HEAD,ZOMBIE_FUME_HEAD,ZOMBIE_PEA_HEAD,ZOMBIE_SEA_HEAD,ZOMBIE_WALLNUT_HEAD})output[type]=true;
    else for(ZombieType type:{ZOMBIE_CABBAGE_HEAD,ZOMBIE_KERNEL_HEAD,ZOMBIE_MELON_HEAD,ZOMBIE_TALLNUT_HEAD})output[type]=true;
}
void Populate(Board& board);
void Update(Board& board);
bool Validate(const Board& board);
void PreloadResources(GameMode mode);
void InitializeZombie(Zombie& zombie);
void UpdateZombie(Zombie& zombie);
Plant* FindPlantTarget(Zombie& zombie);
bool IsCharging(const Zombie& zombie);
bool IsLobProjectile(const Projectile& projectile);
bool UpdateLobMotion(Projectile& projectile);
bool IsButtered(const Plant& plant);
bool UpdateButteredPlant(Plant& plant);
static_assert(static_cast<int>(kFogMode)==94 && static_cast<int>(kRoofMode)==95 &&
    static_cast<int>(ZOMBIE_SEA_HEAD)==38 && static_cast<int>(ZOMBIE_MELON_HEAD)==41);
}
