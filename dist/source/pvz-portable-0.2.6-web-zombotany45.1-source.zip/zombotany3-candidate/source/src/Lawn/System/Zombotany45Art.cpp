// SPDX-License-Identifier: LGPL-3.0-or-later
#include "Zombotany45Art.h"
#include "Zombotany45.h"
#include "ReanimationLawn.h"
#include "../Zombie.h"
#include "../Plant.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/Attachment.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/ReanimAtlas.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "graphics/Graphics.h"
#include "graphics/MemoryImage.h"
#include <algorithm>
#include <array>
#include <memory>
#include <vector>

namespace Zombotany45Art
{
namespace
{
std::array<std::unique_ptr<Sexy::MemoryImage>, 2> sCards;

std::unique_ptr<Sexy::MemoryImage> Blank(int width, int height)
{
    std::vector<uint32_t> pixels(width * height, 0);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), width, height);
    return image;
}

Sexy::Rect VisibleBounds(Sexy::MemoryImage& image)
{
    int left = image.GetWidth(), top = image.GetHeight(), right = -1, bottom = -1;
    const uint32_t* pixels = image.GetBits();
    for (int y = 0; y < image.GetHeight(); ++y)
        for (int x = 0; x < image.GetWidth(); ++x)
            if ((pixels[y * image.GetWidth() + x] >> 24) > 8)
            {
                left = std::min(left, x); top = std::min(top, y);
                right = std::max(right, x); bottom = std::max(bottom, y);
            }
    return right < left ? Sexy::Rect() : Sexy::Rect(left, top, right - left + 1, bottom - top + 1);
}

bool Fit(Sexy::Graphics& graphics, Sexy::MemoryImage& image, float centerX,
    float baseline, float maxWidth, float maxHeight)
{
    const Sexy::Rect bounds = VisibleBounds(image);
    if (bounds.mWidth <= 0 || bounds.mHeight <= 0) return false;
    const float scale = std::min(maxWidth / bounds.mWidth, maxHeight / bounds.mHeight);
    PvzpDrawImageScaledF(&graphics, &image,
        centerX - (bounds.mX + bounds.mWidth * .5f) * scale,
        baseline - (bounds.mY + bounds.mHeight) * scale, scale, scale);
    return true;
}

void PrepareHeadRig(Reanimation& head, ZombieType type, bool butter = false)
{
    // Keep the original face, throwing basket and moving stalk together.
    // Ground foliage and the Sea-shroom's waterline do not belong on a neck.
    head.AssignRenderGroupToPrefix("frontleaf", RENDER_GROUP_HIDDEN);
    head.AssignRenderGroupToPrefix("Cabbagepult_backleaf", RENDER_GROUP_HIDDEN);
    if (head.TrackExists("anim_waterline"))
        head.AssignRenderGroupToTrack("anim_waterline", RENDER_GROUP_HIDDEN);
    if (type == ZOMBIE_KERNEL_HEAD)
    {
        head.AssignRenderGroupToTrack("Cornpult_butter", butter ? RENDER_GROUP_NORMAL : RENDER_GROUP_HIDDEN);
        head.AssignRenderGroupToTrack("Cornpult_kernal", butter ? RENDER_GROUP_HIDDEN : RENDER_GROUP_NORMAL);
    }
}

int Windup(ZombieType type)
{
    return type == ZOMBIE_SEA_HEAD ? Zombotany45::kSeaWindup :
        type == ZOMBIE_CABBAGE_HEAD ? Zombotany45::kCabbageWindup :
        type == ZOMBIE_KERNEL_HEAD ? Zombotany45::kKernelWindup : Zombotany45::kMelonWindup;
}

int ReleaseFrame(ZombieType type)
{
    // Original native keyframes: first hidden payload frame, relative to
    // anim_shooting. Sea-shroom opens its mouth on the seventh frame.
    return type == ZOMBIE_SEA_HEAD ? 7 : type == ZOMBIE_CABBAGE_HEAD ? 12 :
        type == ZOMBIE_KERNEL_HEAD ? 11 : 13;
}

const char* PayloadTrack(const Zombie& zombie)
{
    switch (zombie.mZombieType)
    {
    case ZOMBIE_SEA_HEAD: return "SeahShroom_mouth";
    case ZOMBIE_CABBAGE_HEAD: return "Cabbagepult_cabbage";
    case ZOMBIE_KERNEL_HEAD: return zombie.mBossMode == 1 ? "Cornpult_butter" : "Cornpult_kernal";
    case ZOMBIE_MELON_HEAD: return "Melonpult_mellon";
    default: return "";
    }
}

float ImageWidth(Reanimation& head, const ReanimatorTransform& transform)
{
    if (!transform.mImage) return 0;
    if (head.mDefinition->mReanimAtlas)
    {
        if (auto* image = head.mDefinition->mReanimAtlas->GetEncodedReanimAtlas(transform.mImage))
            return static_cast<float>(image->mWidth);
        if (reinterpret_cast<uintptr_t>(transform.mImage) <= 1000) return 0;
    }
    return static_cast<float>(transform.mImage->GetCelWidth());
}
}

bool IsHead(ZombieType type)
{
    return type == ZOMBIE_SEA_HEAD || type == ZOMBIE_CABBAGE_HEAD ||
        type == ZOMBIE_KERNEL_HEAD || type == ZOMBIE_MELON_HEAD;
}

HeadSpec GetHeadSpec(ZombieType type)
{
    switch (type)
    {
    case ZOMBIE_SEA_HEAD: return {REANIM_SEASHROOM, 69.0f, -34.0f, 1.00f};
    case ZOMBIE_CABBAGE_HEAD: return {REANIM_CABBAGEPULT, 65.0f, -21.0f, .82f};
    case ZOMBIE_KERNEL_HEAD: return {REANIM_KERNELPULT, 64.0f, -25.0f, .78f};
    case ZOMBIE_MELON_HEAD: return {REANIM_MELONPULT, 65.0f, -19.0f, .78f};
    default: return {REANIM_NONE, 0, 0, 1};
    }
}

Sexy::SexyMatrix3 HeadTransform(ZombieType type)
{
    const HeadSpec spec = GetHeadSpec(type);
    Sexy::SexyMatrix3 transform;
    PvzpScaleRotateTransformMatrix(transform, spec.x, spec.y, .2f, -spec.scale, spec.scale);
    return transform;
}

void PrepareBodyRig(Reanimation& carrier)
{
    if (!carrier.TrackExists("anim_head1")) return;
    carrier.AssignRenderGroupToPrefix("anim_hair", RENDER_GROUP_HIDDEN);
    carrier.AssignRenderGroupToPrefix("anim_head2", RENDER_GROUP_HIDDEN);
    carrier.GetTrackInstanceByName("anim_head1")->mImageOverride = Sexy::IMAGE_BLANK;
    carrier.mFrameBasePose = 0;
}

void SetupHead(Zombie& zombie)
{
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return;
    Reanimation* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    if (!carrier || !carrier->TrackExists("anim_head1")) return;
    PrepareBodyRig(*carrier);
    Reanimation* head = zombie.mApp->AddReanimation(0, 0, 0, GetHeadSpec(zombie.mZombieType).reanimation);
    PrepareHeadRig(*head, zombie.mZombieType);
    head->PlayReanim("anim_idle", REANIM_LOOP, 0, 15.0f);
    zombie.mSpecialHeadReanimID = zombie.mApp->ReanimationGetID(head);
    auto* track = carrier->GetTrackInstanceByName("anim_head1");
    AttachEffect* attachment = AttachReanim(track->mAttachmentID, head, 0, 0);
    attachment->mOffset = HeadTransform(zombie.mZombieType);
}

void SetIdle(Zombie& zombie, bool force)
{
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return;
    Reanimation* head = zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID);
    if (!head || head->IsAnimPlaying("anim_idle")) return;
    // Let the original throwing arm settle after release instead of snapping
    // immediately to its loaded idle pose. Cancellation can explicitly reset.
    if (!force && head->IsAnimPlaying("anim_shooting") && head->mLoopCount == 0) return;
    PrepareHeadRig(*head, zombie.mZombieType);
    head->PlayReanim("anim_idle", REANIM_LOOP, 10, 15.0f);
}

void SetAttack(Zombie& zombie, bool butter)
{
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return;
    Reanimation* head = zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID);
    if (!head || !head->TrackExists("anim_shooting")) return;
    PrepareHeadRig(*head, zombie.mZombieType, butter);
    head->PlayReanim("anim_shooting", REANIM_PLAY_ONCE_AND_HOLD, 0, 20.0f);
    // Reanimation advances time using frameCount and samples frameCount-1.
    // Align native payload disappearance with the saved gameplay windup.
    head->mAnimRate = ReleaseFrame(zombie.mZombieType) * 100.0f * head->mFrameCount /
        (Windup(zombie.mZombieType) * static_cast<float>(std::max(1, head->mFrameCount - 1)));
}

void DrawCachedHead(Sexy::Graphics* graphics, Reanimation& carrier, ZombieType type)
{
    if (!IsHead(type) || !carrier.TrackExists("anim_head1")) return;
    Reanimation head;
    head.ReanimationInitializeType(0, 0, GetHeadSpec(type).reanimation);
    PrepareHeadRig(head, type);
    head.SetFramesForLayer("anim_idle");
    Sexy::SexyTransform2D anchor;
    carrier.GetAttachmentOverlayMatrix(carrier.FindTrackIndex("anim_head1"), anchor);
    head.mOverlayMatrix = anchor * HeadTransform(type);
    head.mColorOverride = carrier.mColorOverride;
    head.Draw(graphics);
}

bool GetMouthPosition(Zombie& zombie, float& x, float& y)
{
    x = zombie.mPosX; y = zombie.mPosY;
    if (!IsHead(zombie.mZombieType) || !zombie.mApp) return false;
    Reanimation* carrier = zombie.mApp->ReanimationTryToGet(zombie.mBodyReanimID);
    Reanimation* head = zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID);
    const char* track = PayloadTrack(zombie);
    if (!carrier || !head || !carrier->TrackExists("anim_head1") || !head->TrackExists(track)) return false;
    Sexy::SexyTransform2D attachment;
    carrier->GetAttachmentOverlayMatrix(carrier->FindTrackIndex("anim_head1"), attachment);
    const Sexy::SexyMatrix3 previous = head->mOverlayMatrix;
    const float previousTime = head->mAnimTime;
    head->mOverlayMatrix = attachment * HeadTransform(zombie.mZombieType);
    const int index = head->FindTrackIndex(track);
    ReanimatorTransform transform;
    head->GetCurrentTransform(index, &transform);
    // The native release frame hides the carried vegetable. Sample its last
    // visible native center so GetTrackMatrix keeps the original image pivot.
    if (zombie.mZombieType != ZOMBIE_SEA_HEAD && transform.mFrame < 0 && head->IsAnimPlaying("anim_shooting"))
        head->mAnimTime = (ReleaseFrame(zombie.mZombieType) - 1.0f) / std::max(1, head->mFrameCount - 1);
    Sexy::SexyTransform2D mouth;
    head->GetTrackMatrix(index, mouth);
    head->GetCurrentTransform(index, &transform);
    const float edge = zombie.mZombieType == ZOMBIE_SEA_HEAD ? std::max(0.0f, ImageWidth(*head, transform) * .5f - 2.0f) : 0;
    x = zombie.mX + mouth.m02 + mouth.m00 * edge;
    y = zombie.mY + mouth.m12 + mouth.m10 * edge;
    head->mOverlayMatrix = previous;
    head->mAnimTime = previousTime;
    return true;
}

void DrawPlantButter(Sexy::Graphics* graphics, Plant& plant, float drawHeightOffset)
{
    if (!plant.mApp || !Zombotany45::IsButtered(plant) || !Sexy::IMAGE_REANIM_CORNPULT_BUTTER_SPLAT) return;
    float centerX = 40.0f, centerY = 30.0f + drawHeightOffset;
    bool found = false;
    for (ReanimationID id : {plant.mHeadReanimID, plant.mBodyReanimID})
    {
        Reanimation* rig = plant.mApp->ReanimationTryToGet(id);
        if (!rig) continue;
        for (const char* track : {"anim_face", "PeaShooter_head", "SnowPea_head", "GatlingPea_head", "SunFlower_head", "WallNut_body", "TallNut_body", "PuffShroom_head", "ScaredyShroom_head", "DoomShroom_head"})
        {
            if (!rig->TrackExists(track)) continue;
            Sexy::SexyTransform2D face;
            rig->GetTrackMatrix(rig->FindTrackIndex(track), face);
            centerX = face.m02; centerY = face.m12;
            found = true; break;
        }
        if (found) break;
    }
    Sexy::Graphics butter(*graphics);
    butter.ClipRect(-plant.mX, 80 - plant.mY, 800, 520);
    const float scale = .65f;
    PvzpDrawImageScaledF(&butter, Sexy::IMAGE_REANIM_CORNPULT_BUTTER_SPLAT,
        centerX - Sexy::IMAGE_REANIM_CORNPULT_BUTTER_SPLAT->GetWidth() * scale * .5f,
        centerY - Sexy::IMAGE_REANIM_CORNPULT_BUTTER_SPLAT->GetHeight() * scale * .5f,
        scale, scale);
}

Sexy::Image* GetImage(GameMode mode)
{
    const int index = mode == GAMEMODE_CHALLENGE_ZOMBOTANY_4 ? 0 : mode == GAMEMODE_CHALLENGE_ZOMBOTANY_5 ? 1 : -1;
    if (index < 0) return nullptr;
    if (sCards[index]) return sCards[index].get();
    if (!gLawnApp || !gLawnApp->mReanimatorCache) return nullptr;
    const bool fog = index == 0;
    if (!PvzpLoadResources(fog ? "DelayLoad_Background4" : "DelayLoad_Background5")) return nullptr;
    Sexy::Image* background = fog ? Sexy::IMAGE_BACKGROUND4 : Sexy::IMAGE_BACKGROUND5;
    if (!background) return nullptr;
    auto card = Blank(80, 65);
    Sexy::Graphics picture(card.get());
    picture.SetLinearBlend(true); picture.ClipRect(0, 0, 80, 65);
    picture.DrawImage(background, Sexy::Rect(0, 0, 80, 65), Sexy::Rect(300, 80, 600, 440));
    if (fog)
    {
        if (Sexy::IMAGE_FOG_SOFTWARE)
        {
            Sexy::Graphics mist(picture);
            mist.SetColorizeImages(true); mist.SetColor(Sexy::Color(255, 255, 255, 120));
            const Sexy::Rect cel(0, 0, Sexy::IMAGE_FOG_SOFTWARE->GetCelWidth(), Sexy::IMAGE_FOG_SOFTWARE->GetCelHeight());
            mist.DrawImage(Sexy::IMAGE_FOG_SOFTWARE, Sexy::Rect(-25, 0, 70, 65), cel);
            mist.DrawImage(Sexy::IMAGE_FOG_SOFTWARE, Sexy::Rect(53, 2, 70, 65), cel);
        }
        auto fume = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_FUME_HEAD);
        auto sea = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_SEA_HEAD);
        auto pea = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_PEA_HEAD);
        if (!fume || !sea || !pea || !Fit(picture, *fume, 13, 62, 26, 44) ||
            !Fit(picture, *pea, 68, 62, 23, 44) || !Fit(picture, *sea, 41, 63, 35, 58)) return nullptr;
    }
    else
    {
        auto cabbage = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_CABBAGE_HEAD);
        auto kernel = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_KERNEL_HEAD);
        auto melon = gLawnApp->mReanimatorCache->MakeCachedZombieFrame(ZOMBIE_MELON_HEAD);
        if (!cabbage || !kernel || !melon || !Fit(picture, *cabbage, 13, 63, 26, 45) ||
            !Fit(picture, *kernel, 39, 63, 28, 54) || !Fit(picture, *melon, 66, 63, 28, 59)) return nullptr;
    }
    sCards[index] = std::move(card);
    return sCards[index].get();
}

void DisposeImages()
{
    for (auto& image : sCards) image.reset();
}
}
