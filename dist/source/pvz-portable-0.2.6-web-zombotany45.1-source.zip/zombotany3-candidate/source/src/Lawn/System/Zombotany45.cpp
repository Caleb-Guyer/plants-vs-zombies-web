// SPDX-License-Identifier: LGPL-3.0-or-later
#include "Zombotany45.h"
#include "Zombotany45Art.h"
#include "Zombotany3.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../Projectile.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/PvzpFoley.h"
#include "../../PvzpLib/Reanimator.h"
#include "graphics/Image.h"
#include <algorithm>
#include <cmath>

namespace Zombotany45
{
namespace
{
bool Eligible(const Plant& plant)
{ return !plant.mDead && !plant.mSquished && plant.mPlantHealth>0 && !const_cast<Plant&>(plant).NotOnGround(); }
int Range(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaRange:type==ZOMBIE_CABBAGE_HEAD?kCabbageRange:type==ZOMBIE_KERNEL_HEAD?kKernelRange:kMelonRange; }
int Cadence(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaCadence:type==ZOMBIE_CABBAGE_HEAD?kCabbageCadence:type==ZOMBIE_KERNEL_HEAD?kKernelCadence:kMelonCadence; }
int Windup(ZombieType type)
{ return type==ZOMBIE_SEA_HEAD?kSeaWindup:type==ZOMBIE_CABBAGE_HEAD?kCabbageWindup:type==ZOMBIE_KERNEL_HEAD?kKernelWindup:kMelonWindup; }
Zombie* FriendlyTarget(Zombie& source)
{
    Zombie* best=nullptr;
    const int minimum=IsLobber(source.mZombieType)?kLobMinimumRange:0;
    for(Zombie* target:source.mBoard->mZombies)
    {
        if(target==&source || target->mDead || target->mMindControlled || target->mRow!=source.mRow || !target->EffectedByDamage(9))continue;
        const float distance=target->mPosX-source.mPosX;
        if(distance<minimum || distance>Range(source.mZombieType))continue;
        if(!best || target->mPosX<best->mPosX)best=target;
    }
    return best;
}
void Cancel(Zombie& zombie)
{
    if(zombie.mBossBungeeCounter>0)zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
    zombie.mBossBungeeCounter=0;zombie.mBossMode=0;
    Zombotany45Art::SetIdle(zombie,true);
    if(zombie.mButteredCounter>0)
        if(auto head=zombie.mApp->ReanimationTryToGet(zombie.mSpecialHeadReanimID))head->mAnimRate=0;
}
void ShootSea(Zombie& zombie)
{
    float x,y;if(!Zombotany45Art::GetMouthPosition(zombie,x,y))return;
    auto projectile=zombie.mBoard->AddProjectile(static_cast<int>(x)-13,static_cast<int>(y)-13,zombie.mRenderOrder+1,zombie.mRow,PROJECTILE_PUFF);
    projectile->mMotionType=zombie.mMindControlled?MOTION_PUFF:MOTION_BACKWARDS;
    // Sea-shroom uses the exact native travelling puff and lethal collision.
    projectile->mDamageRangeFlags=zombie.mMindControlled?9:Zombotany3::kHostilePuffMarker;
    zombie.mApp->PlayFoley(FOLEY_PUFF);
}
Image* LobImage(ProjectileType type)
{
    if(type==PROJECTILE_CABBAGE)return Sexy::IMAGE_REANIM_CABBAGEPULT_CABBAGE;
    if(type==PROJECTILE_KERNEL)return Sexy::IMAGE_REANIM_CORNPULT_KERNAL;
    if(type==PROJECTILE_BUTTER)return Sexy::IMAGE_REANIM_CORNPULT_BUTTER;
    return Sexy::IMAGE_REANIM_MELONPULT_MELON;
}
void ShootLob(Zombie& zombie,Plant* plant,Zombie* target)
{
    float mouthX,mouthY;if(!Zombotany45Art::GetMouthPosition(zombie,mouthX,mouthY))return;
    const ProjectileType type=zombie.mZombieType==ZOMBIE_CABBAGE_HEAD?PROJECTILE_CABBAGE:
        zombie.mZombieType==ZOMBIE_KERNEL_HEAD?(zombie.mBossMode==1?PROJECTILE_BUTTER:PROJECTILE_KERNEL):PROJECTILE_MELON;
    Image* image=LobImage(type);if(!image)return;
    const float pivotX=image->GetCelWidth()*.5f,pivotY=image->GetCelHeight()*.5f;
    float targetX,targetY;
    if(plant){const Sexy::Rect rect=plant->GetPlantRect();targetX=rect.mX+rect.mWidth*.5f;targetY=rect.mY+rect.mHeight*.5f;}
    else {const Sexy::Rect rect=target->GetZombieRect();targetX=rect.mX+rect.mWidth*.5f;targetY=rect.mY+rect.mHeight*.5f;}
    auto p=zombie.mBoard->AddProjectile(static_cast<int>(mouthX-pivotX),static_cast<int>(mouthY-pivotY),zombie.mRenderOrder+1,zombie.mRow,type);
    p->mMotionType=MOTION_LOBBED;
    p->mDamageRangeFlags=zombie.mMindControlled?kFriendlyLobMarker:kHostileLobMarker;
    p->mCobTargetX=targetX;p->mCobTargetRow=zombie.mRow;
    p->mVelX=(targetX-pivotX-p->mPosX)/kLobFlightTicks;
    p->mVelY=(targetY-pivotY-p->mPosY)/kLobFlightTicks;
    p->mAccZ=.15f;p->mVelZ=-p->mAccZ*(kLobFlightTicks+1)*.5f;
    if(target)p->mTargetZombieID=static_cast<ZombieID>(zombie.mBoard->mZombies.DataArrayGetID(target));
    zombie.mApp->PlayFoley(FOLEY_THROW);
}
void ClearButterRow(Challenge& challenge,int row)
{
    challenge.mCloudsCounter[row]=0;
    for(int col=0;col<9;++col)challenge.mBeghouledEated[col][row]=0;
}
void Butter(Plant& plant)
{
    if(!plant.mBoard || !plant.mApp || !IsRoof(plant.mApp->mGameMode) || !Eligible(plant))return;
    Challenge& challenge=*plant.mBoard->mChallenge;
    if(IsButtered(plant))return; // Repeated butter cannot extend an existing pause.
    ClearButterRow(challenge,plant.mRow);
    challenge.mBeghouledEated[plant.mPlantCol][plant.mRow]=static_cast<int32_t>(plant.mBoard->mPlants.DataArrayGetID(&plant));
    challenge.mCloudsCounter[plant.mRow]=plant.mBoard->mMainCounter+kButterTicks;
}
void DamagePlant(Plant* plant,int damage,bool butter)
{
    if(!plant || !Eligible(*plant))return;
    plant->mPlantHealth-=damage;plant->mEatenFlashCountdown=std::max(plant->mEatenFlashCountdown,25);
    if(plant->mPlantHealth<=0)plant->Die();else if(butter)Butter(*plant);
}
bool Umbrella(Projectile& p,int col,int row)
{
    Plant* umbrella=p.mBoard->FindUmbrellaPlant(col,row);
    if(!umbrella || IsButtered(*umbrella))return false;
    if(umbrella->mState==STATE_UMBRELLA_REFLECTING)
    {
        p.mApp->PlayFoley(FOLEY_SPLAT);
        p.mApp->AddPvzpParticle(p.mPosX+20,p.mPosY+p.mPosZ+20,Board::MakeRenderOrder(RENDER_LAYER_TOP,0,1),PARTICLE_UMBRELLA_REFLECT);
        p.Die();
    }
    else if(umbrella->mState!=STATE_UMBRELLA_TRIGGERED)
    {
        p.mApp->PlayFoley(FOLEY_UMBRELLA);umbrella->DoSpecial();
    }
    return true;
}
}
void Populate(Board& board)
{
    auto& c=*board.mChallenge;c.mChallengeState=kActive;c.mChallengeGridY=kRulesVersion;
    c.mChallengeGridX=0;c.mChallengeStateCounter=0;
    for(int row=0;row<6;++row)ClearButterRow(c,row);
    board.mZombieCountDown=board.mZombieCountDownStart=kOpeningDelay;board.mShowShovel=true;
    // Native CutScene::AddFlowerPots supplies the three starting columns.
}
void Update(Board& board)
{
    if(!IsRoof(board.mApp->mGameMode) || board.mApp->mGameScene!=SCENE_PLAYING || board.mPaused || board.mTimeStopCounter>0)return;
    auto& c=*board.mChallenge;
    for(int row=0;row<6;++row)
    {
        bool alive=false;
        for(int col=0;col<9;++col)if(c.mBeghouledEated[col][row])
        {
            auto p=board.mPlants.DataArrayTryToGet(static_cast<unsigned int>(c.mBeghouledEated[col][row]));
            alive|=p && !p->mDead && p->mRow==row && p->mPlantCol==col;
        }
        if(c.mCloudsCounter[row]<=board.mMainCounter || !alive)ClearButterRow(c,row);
    }
}
bool Validate(const Board& board)
{
    if(!board.mApp || !board.mChallenge || !IsMode(board.mApp->mGameMode))return false;
    const auto& c=*board.mChallenge;
    if(c.mChallengeState!=kActive || c.mChallengeGridY!=kRulesVersion || board.mNumWaves!=kWaveCount || board.mCurrentWave<0 || board.mCurrentWave>kWaveCount)return false;
    if(IsFog(board.mApp->mGameMode))return board.mBackground==BACKGROUND_4_FOG;
    if(board.mBackground!=BACKGROUND_5_ROOF)return false;
    for(int row=0;row<6;++row)if(c.mCloudsCounter[row]<0 || c.mCloudsCounter[row]>board.mMainCounter+kButterTicks)return false;
    return true;
}
void PreloadResources(GameMode mode)
{
    if(IsFog(mode))for(SeedType seed:{SEED_SEASHROOM,SEED_PUFFSHROOM,SEED_FUMESHROOM,SEED_PEASHOOTER,SEED_WALLNUT})Plant::PreloadPlantResources(seed);
    else for(SeedType seed:{SEED_CABBAGEPULT,SEED_KERNELPULT,SEED_MELONPULT,SEED_TALLNUT,SEED_FLOWERPOT,SEED_UMBRELLA})Plant::PreloadPlantResources(seed);
    for(ZombieType type:{ZOMBIE_SEA_HEAD,ZOMBIE_CABBAGE_HEAD,ZOMBIE_KERNEL_HEAD,ZOMBIE_MELON_HEAD})Zombie::PreloadZombieResources(type);
}
void InitializeZombie(Zombie& zombie)
{
    zombie.mVariant=false;zombie.mBossBungeeCounter=0;zombie.mBossMode=0;
    zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
    Zombotany45Art::SetupHead(zombie);
}
Plant* FindPlantTarget(Zombie& zombie)
{
    Plant* best=nullptr;
    const bool lob=IsLobber(zombie.mZombieType);
    for(int col=0;col<9;++col)
    {
        Plant* plant=zombie.mBoard->GetTopPlantAt(col,zombie.mRow,lob?TOPPLANT_CATAPULT_ORDER:TOPPLANT_EATING_ORDER);
        if(!plant || !Eligible(*plant))continue;
        const float distance=zombie.mPosX-plant->mX;
        if(distance<(lob?kLobMinimumRange:0) || distance>Range(zombie.mZombieType))continue;
        if(!best || (lob?plant->mX<best->mX:plant->mX>best->mX))best=plant;
    }
    return best;
}
bool IsCharging(const Zombie& zombie)
{ return IsZombie(zombie.mZombieType) && zombie.mBossBungeeCounter>0; }
void UpdateZombie(Zombie& zombie)
{
    if(!IsZombie(zombie.mZombieType) || !zombie.IsOnBoard())return;
    if(!zombie.mHasHead || zombie.IsDeadOrDying() || zombie.mZombiePhase==PHASE_RISING_FROM_GRAVE ||
        zombie.mZombieHeight!=HEIGHT_ZOMBIE_NORMAL || zombie.mPosX>760 || zombie.mPosX<0 || zombie.IsImmobilizied())
    { Cancel(zombie);return; }
    Plant* plant=zombie.mMindControlled?nullptr:FindPlantTarget(zombie);
    Zombie* target=zombie.mMindControlled?FriendlyTarget(zombie):nullptr;
    if(zombie.mBossBungeeCounter>0)
    {
        if(!plant && !target){Cancel(zombie);return;}
        --zombie.mBossBungeeCounter;
        if(zombie.mBossBungeeCounter==0)
        {
            if(zombie.mZombieType==ZOMBIE_SEA_HEAD)ShootSea(zombie);else ShootLob(zombie,plant,target);
            zombie.mSummonCounter=Cadence(zombie.mZombieType)-Windup(zombie.mZombieType);
            Zombotany45Art::SetIdle(zombie);
        }
        return;
    }
    Zombotany45Art::SetIdle(zombie);
    if(zombie.mSummonCounter>0)--zombie.mSummonCounter;
    if(zombie.mSummonCounter>0 || (!plant && !target))return;
    zombie.mBossBungeeCounter=Windup(zombie.mZombieType);
    zombie.mBossMode=zombie.mZombieType==ZOMBIE_KERNEL_HEAD && Rand(kButterChance)==0?1:0;
    Zombotany45Art::SetAttack(zombie,zombie.mBossMode==1);
}
bool IsLobProjectile(const Projectile& p)
{
    return p.mMotionType==MOTION_LOBBED && (p.mDamageRangeFlags==kHostileLobMarker || p.mDamageRangeFlags==kFriendlyLobMarker) &&
        (p.mProjectileType==PROJECTILE_CABBAGE || p.mProjectileType==PROJECTILE_KERNEL || p.mProjectileType==PROJECTILE_BUTTER || p.mProjectileType==PROJECTILE_MELON);
}
bool UpdateLobMotion(Projectile& p)
{
    if(!IsLobProjectile(p))return false;
    p.mVelZ+=p.mAccZ;p.mPosX+=p.mVelX;p.mPosY+=p.mVelY;p.mPosZ+=p.mVelZ;
    const bool friendly=p.mDamageRangeFlags==kFriendlyLobMarker;
    const int col=p.mBoard->PixelToGridXKeepOnBoard(p.mCobTargetX,0),row=p.mCobTargetRow;
    if(!friendly && p.mProjectileAge>=kLobFlightTicks-kUmbrellaAnticipationTicks)
    {
        if(Umbrella(p,col,row))
        {
            // Native umbrellas open in five ticks. A last-moment planting still
            // intercepts the incoming lob while its original block pose opens.
            if(p.mDead || p.mProjectileAge<kLobFlightTicks)return true;
            p.Die();return true;
        }
    }
    if(p.mProjectileAge<kLobFlightTicks)return true;
    if(friendly)
    {
        Zombie* hit=nullptr;
        for(Zombie* z:p.mBoard->mZombies)if(!z->mDead && !z->mMindControlled && z->mRow==row && z->EffectedByDamage(9) && std::abs(z->mPosX+40-p.mCobTargetX)<=80)
            if(!hit || std::abs(z->mPosX+40-p.mCobTargetX)<std::abs(hit->mPosX+40-p.mCobTargetX))hit=z;
        p.mDamageRangeFlags=9;p.DoImpact(hit);return true;
    }
    if(p.mProjectileType==PROJECTILE_MELON)
    {
        for(int r=std::max(0,row-1);r<=std::min(4,row+1);++r)
            for(int c=std::max(0,col-1);c<=std::min(8,col+1);++c)
                DamagePlant(p.mBoard->GetTopPlantAt(c,r,TOPPLANT_CATAPULT_ORDER),r==row&&c==col?kMelonDamage:kMelonSplashDamage,false);
    }
    else DamagePlant(p.mBoard->GetTopPlantAt(col,row,TOPPLANT_CATAPULT_ORDER),p.GetProjectileDef().mDamage,p.mProjectileType==PROJECTILE_BUTTER);
    // Keep original impact sounds, rotations and particle artwork. Zero range
    // flags prevent an enemy melon effect from damaging its own zombie team.
    p.mDamageRangeFlags=0;p.DoImpact(nullptr);return true;
}
bool IsButtered(const Plant& plant)
{
    if(!plant.mApp || !plant.mBoard || !plant.mBoard->mChallenge || !IsRoof(plant.mApp->mGameMode) ||
        plant.mApp->mGameScene!=SCENE_PLAYING || !plant.mIsOnBoard || plant.mDead || plant.mRow<0 || plant.mRow>=6 || plant.mPlantCol<0 || plant.mPlantCol>=9)return false;
    const auto& c=*plant.mBoard->mChallenge;
    return c.mCloudsCounter[plant.mRow]>=plant.mBoard->mMainCounter && c.mCloudsCounter[plant.mRow]>0 &&
        static_cast<unsigned int>(c.mBeghouledEated[plant.mPlantCol][plant.mRow])==plant.mBoard->mPlants.DataArrayGetID(const_cast<Plant*>(&plant));
}
bool UpdateButteredPlant(Plant& plant)
{
    if(plant.mApp && plant.mBoard && IsMode(plant.mApp->mGameMode) && plant.mApp->mGameScene==SCENE_PLAYING &&
        plant.mIsOnBoard && !plant.mDead && plant.mPlantHealth<=0){plant.Die();return true;}
    return IsButtered(plant);
}
}
