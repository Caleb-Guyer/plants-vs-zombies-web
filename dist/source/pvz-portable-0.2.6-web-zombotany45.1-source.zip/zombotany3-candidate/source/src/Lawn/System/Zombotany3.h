// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Zombie;
class Plant;
class Projectile;

namespace Zombotany3
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_ZOMBOTANY_3;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(146);
inline constexpr int kProfileIndex = 92;
inline constexpr int kRulesVersion = 1;
inline constexpr int kWaveCount = 20;
inline constexpr int kStartingSun = 50;
inline constexpr int kOpeningDelay = 1800;
inline constexpr int kPuffRange = 180;
inline constexpr int kPuffDamage = 20;
inline constexpr int kPuffCadence = 150;
inline constexpr int kPuffWindup = 35;
inline constexpr int kPuffLifetime = 60;
inline constexpr int kFumeRange = 240;
inline constexpr int kFumeDamage = 20;
inline constexpr int kFumeCadence = 200;
inline constexpr int kFumeWindup = 50;
inline constexpr int kIceRange = 300;
inline constexpr int kIceWindup = 125;
inline constexpr int kFreezeTicks = 150;
inline constexpr int kHostilePuffMarker = -303;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kActive; }
constexpr bool IsZombie(ZombieType type)
{ return type == ZOMBIE_PUFF_HEAD || type == ZOMBIE_FUME_HEAD || type == ZOMBIE_ICE_HEAD; }
struct Wave { int mNormal; int mPuff; int mFume; int mIce; };
inline constexpr std::array<Wave,kWaveCount> kWaves = {{
    {0,1,0,0},{1,1,0,0},{0,2,0,0},{0,2,0,0},{0,2,1,0},
    {0,2,1,0},{0,3,1,0},{0,3,1,0},{0,3,2,0},{0,3,2,1},
    {0,3,2,0},{0,3,2,0},{0,4,2,0},{0,4,2,0},{0,4,2,0},
    {0,4,3,0},{0,4,3,0},{0,4,3,0},{0,4,3,0},{0,5,3,1}
}};
constexpr int ZombieCount(int wave)
{
    if(wave<0 || wave>=kWaveCount) return 0;
    const Wave& entry=kWaves[wave];
    return entry.mNormal+entry.mPuff+entry.mFume+entry.mIce+((wave+1)%10==0?1:0);
}
template<std::size_t Waves,std::size_t Slots> int PopulateWaves(ZombieType(&output)[Waves][Slots])
{
    static_assert(Waves>=kWaveCount && Slots>10);
    for(auto& wave:output) for(auto& zombie:wave) zombie=ZOMBIE_INVALID;
    for(int wave=0;wave<kWaveCount;++wave)
    {
        int index=0;
        if((wave+1)%10==0)output[wave][index++]=ZOMBIE_FLAG;
        const Wave& entry=kWaves[wave];
        for(int n=0;n<entry.mNormal;++n)output[wave][index++]=ZOMBIE_NORMAL;
        for(int n=0;n<entry.mPuff;++n)output[wave][index++]=ZOMBIE_PUFF_HEAD;
        for(int n=0;n<entry.mFume;++n)output[wave][index++]=ZOMBIE_FUME_HEAD;
        for(int n=0;n<entry.mIce;++n)output[wave][index++]=ZOMBIE_ICE_HEAD;
    }
    return kWaveCount;
}
template<std::size_t Count> void PopulateAllowedZombies(bool(&output)[Count])
{
    static_assert(Count>static_cast<std::size_t>(ZOMBIE_ICE_HEAD));
    for(auto& allowed:output)allowed=false;
    for(ZombieType type:{ZOMBIE_NORMAL,ZOMBIE_FLAG,ZOMBIE_PUFF_HEAD,ZOMBIE_FUME_HEAD,ZOMBIE_ICE_HEAD})output[type]=true;
}
void Populate(Board& board);
void Update(Board& board);
bool Validate(const Board& board);
void InitializeZombie(Zombie& zombie);
void UpdateZombie(Zombie& zombie);
bool IsCharging(const Zombie& zombie);
bool IsSpent(const Zombie& zombie);
Plant* FindTarget(Zombie& zombie, int range);
bool IsFrozen(const Plant& plant);
bool UpdateFrozenPlant(Plant& plant);
bool IsHostilePuff(const Projectile& projectile);
bool UpdateHostilePuffCollision(Projectile& projectile);
void PreloadResources();
static_assert(static_cast<int>(kMode)==93 && static_cast<int>(ZOMBIE_PUFF_HEAD)==35 &&
    static_cast<int>(ZOMBIE_FUME_HEAD)==36 && static_cast<int>(ZOMBIE_ICE_HEAD)==37);
}
