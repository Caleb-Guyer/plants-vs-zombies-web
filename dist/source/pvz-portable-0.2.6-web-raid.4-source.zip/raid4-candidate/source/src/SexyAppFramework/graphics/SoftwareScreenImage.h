/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
#pragma once

#include "MemoryImage.h"

namespace Sexy
{

// The registered game callbacks may also draw into opaque offscreen images.
// Match the active virtual screen boundary AND its actual destination buffer.
bool NativeScreenRasterTargetMatches(const void* surface, unsigned int bytePitch);

// Opaque RGB888 CPU screen destination. Offscreen MemoryImages retain their
// distinct native MemoryImage composition. This emulates the audited nonvolatile
// DD32 software kernels, without DirectDraw surface-driver or16-bit fallbacks.
class SoftwareScreenImage final : public MemoryImage
{
    static uint32_t CompositePixel(uint32_t source, uint32_t destination,
        const Color& color, int drawMode, bool stretch, bool sourceHasAlpha, bool sourceHasTrans);

public:
    explicit SoftwareScreenImage(SexyAppBase* app);
    void Create(int width, int height) override;
    void FillRect(const Rect& rect, const Color& color, int drawMode) override;
    void DrawLineAA(double startX, double startY, double endX, double endY,
        const Color& color, int drawMode) override;
    void Blt(Image* image, int x, int y, const Rect& sourceRect, const Color& color,
        int drawMode, bool linearFilter = true) override;
    void BltMirror(Image* image, int x, int y, const Rect& sourceRect, const Color& color,
        int drawMode, bool linearFilter = true) override;
    void StretchBlt(Image* image, const Rect& destinationRect, const Rect& sourceRect,
        const Rect& clipRect, const Color& color, int drawMode, bool fastStretch) override;
    void StretchBltMirror(Image* image, const Rect& destinationRect, const Rect& sourceRect,
        const Rect& clipRect, const Color& color, int drawMode, bool fastStretch) override;
    void BltMatrix(Image* image, float x, float y, const SexyMatrix3& matrix,
        const Rect& clipRect, const Color& color, int drawMode, const Rect& sourceRect, bool blend) override;
    void BltTrianglesTex(Image* texture, const TriVertex vertices[][3], int triangleCount,
        const Rect& clipRect, const Color& color, int drawMode, float x, float y, bool blend) override;
};

}
