/* Copyright (C) 2026. SPDX-License-Identifier: LGPL-3.0-or-later */
#include "SoftwareScreenImage.h"
#include "Graphics.h"

#include <algorithm>
#include <cmath>
#include <cstdint>

using namespace Sexy;

namespace
{
struct ScreenRasterTarget
{
    const void* surface = nullptr;
    unsigned int bytePitch = 0;
};
thread_local ScreenRasterTarget gScreenRasterTarget;

class ScopedScreenRasterTarget
{
    ScreenRasterTarget mPrevious;
public:
    ScopedScreenRasterTarget(const void* surface, unsigned int bytePitch)
        : mPrevious(gScreenRasterTarget)
    {
        gScreenRasterTarget = {surface, bytePitch};
    }
    ~ScopedScreenRasterTarget() { gScreenRasterTarget = mPrevious; }
    ScopedScreenRasterTarget(const ScopedScreenRasterTarget&) = delete;
    ScopedScreenRasterTarget& operator=(const ScopedScreenRasterTarget&) = delete;
};
}

bool Sexy::NativeScreenRasterTargetMatches(const void* surface, unsigned int bytePitch)
{
    return surface != nullptr && surface == gScreenRasterTarget.surface &&
        bytePitch != 0 && bytePitch == gScreenRasterTarget.bytePitch;
}

SoftwareScreenImage::SoftwareScreenImage(SexyAppBase* app) : MemoryImage(app)
{
    SetImageMode(false, false);
    mPurgeBits = false;
}

void SoftwareScreenImage::BltMatrix(Image* image, float x, float y, const SexyMatrix3& matrix,
    const Rect& clipRect, const Color& color, int drawMode, const Rect& sourceRect, bool blend)
{
    ScopedScreenRasterTarget target(GetBits(), static_cast<unsigned int>(mWidth) * 4u);
    MemoryImage::BltMatrix(image, x, y, matrix, clipRect, color, drawMode, sourceRect, blend);
}

void SoftwareScreenImage::BltTrianglesTex(Image* texture, const TriVertex vertices[][3], int triangleCount,
    const Rect& clipRect, const Color& color, int drawMode, float x, float y, bool blend)
{
    ScopedScreenRasterTarget target(GetBits(), static_cast<unsigned int>(mWidth) * 4u);
    MemoryImage::BltTrianglesTex(texture, vertices, triangleCount, clipRect, color, drawMode, x, y, blend);
}

void SoftwareScreenImage::Create(int width, int height)
{
    MemoryImage::Create(width, height);
    SetImageMode(false, false);
    mPurgeBits = false;
}

void SoftwareScreenImage::DrawLineAA(double startX, double startY, double endX, double endY,
    const Color& color, int drawMode)
{
    if (drawMode == Graphics::DRAWMODE_ADDITIVE && startX != endX && startY != endY &&
        std::isfinite(startX) && std::isfinite(startY) && std::isfinite(endX) && std::isfinite(endY) &&
        mForcedMode && !mHasAlpha && !mHasTrans && !mIsVolatile &&
        mBits && !mColorTable && !mColorIndices)
    {
        // Native DD32's nonaxis additive-AA worker is empty. Its wrapper
        // discards auxiliary caches without marking the surface changed.
        // Here mBits is the authoritative framebuffer, not a DD surface copy.
        DeleteSWBuffers();
        return;
    }
    MemoryImage::DrawLineAA(startX, startY, endX, endY, color, drawMode);
}

uint32_t SoftwareScreenImage::CompositePixel(uint32_t source, uint32_t destination,
    const Color& color, int drawMode, bool stretch, bool sourceHasAlpha, bool sourceHasTrans)
{
    const bool white = color == Color::White;
    const int alpha = source >> 24;
    const bool copyNative = !stretch && drawMode == Graphics::DRAWMODE_NORMAL && white && !sourceHasAlpha;
    if (copyNative && sourceHasTrans && alpha == 0)
        return destination | 0xff000000u;
    if (!copyNative && drawMode == Graphics::DRAWMODE_NORMAL && alpha == 0)
        return destination | 0xff000000u;
    const int effectiveAlpha = white ? alpha : alpha * color.mAlpha / 255;
    if (!copyNative && drawMode == Graphics::DRAWMODE_NORMAL && effectiveAlpha == 0)
        return destination | 0xff000000u;

    uint32_t result = 0xff000000u;
    for (int shift = 0; shift < 24; shift += 8)
    {
        const int raw = (source >> shift) & 255;
        const int dest = (destination >> shift) & 255;
        // NativeAlphaData stores RGB*(A+1)/256 before DD32 composition.
        const int premultiplied = raw * (alpha + 1) / 256;
        const int channel = shift == 16 ? color.mRed : shift == 8 ? color.mGreen : color.mBlue;
        const int tint = channel * color.mAlpha / 255;
        int output;
        if (copyNative)
            output = premultiplied;
        else if (drawMode != Graphics::DRAWMODE_NORMAL)
            output = std::min(255, dest + (white ? premultiplied : premultiplied * tint / 256));
        else if (!stretch && !white && alpha == 255 && color.mAlpha == 255)
            // Unstretched DD Blt has this special case; fast stretch does not.
            output = premultiplied * channel / 256;
        else if (white)
            output = dest * (256 - alpha) / 256 + premultiplied;
        else
            output = (dest * (256 - effectiveAlpha) + premultiplied * tint) / 256;
        result |= static_cast<uint32_t>(output) << shift;
    }
    return result;
}

void SoftwareScreenImage::Blt(Image* image, int x, int y, const Rect& sourceRect,
    const Color& color, int drawMode, bool linearFilter)
{
    // Native unstretched DD Blt dispatches only modes0/1. Stretch has a
    // separate nonzero→additive dispatch and intentionally differs here.
    if (drawMode != Graphics::DRAWMODE_NORMAL && drawMode != Graphics::DRAWMODE_ADDITIVE)
        return;
    auto* source = dynamic_cast<MemoryImage*>(image);
    if (!source || sourceRect.mWidth <= 0 || sourceRect.mHeight <= 0)
        return;
    // Volatile source arithmetic is a separate unaudited native path. Preserve
    // the previous implementation there rather than inventing its DD behavior.
    if (source->mIsVolatile)
        return MemoryImage::Blt(image, x, y, sourceRect, color, drawMode, linearFilter);
    if (x < 0 || y < 0 || x + sourceRect.mWidth > mWidth || y + sourceRect.mHeight > mHeight ||
        sourceRect.mX < 0 || sourceRect.mY < 0 || sourceRect.mX + sourceRect.mWidth > source->mWidth ||
        sourceRect.mY + sourceRect.mHeight > source->mHeight)
        return;
    image->mDrawn = true;
    const uint32_t* pixels = source->GetBits();
    source->CommitBits();
    uint32_t* destination = GetBits();
    for (int row = 0; row < sourceRect.mHeight; ++row)
        for (int column = 0; column < sourceRect.mWidth; ++column)
        {
            const int destIndex = (y + row) * mWidth + x + column;
            const uint32_t pixel = pixels[(sourceRect.mY + row) * source->mWidth + sourceRect.mX + column];
            destination[destIndex] = CompositePixel(pixel, destination[destIndex], color, drawMode,
                false, source->mHasAlpha, source->mHasTrans);
        }
    BitsChanged();
}

void SoftwareScreenImage::StretchBlt(Image* image, const Rect& destinationRect,
    const Rect& sourceRect, const Rect& clipRect, const Color& color, int drawMode, bool fastStretch)
{
    auto* source = dynamic_cast<MemoryImage*>(image);
    if (!source || destinationRect.mWidth <= 0 || destinationRect.mHeight <= 0 ||
        sourceRect.mWidth <= 0 || sourceRect.mHeight <= 0 || sourceRect.mX < 0 || sourceRect.mY < 0 ||
        sourceRect.mX + sourceRect.mWidth > source->mWidth || sourceRect.mY + sourceRect.mHeight > source->mHeight)
        return;
    if (source->mIsVolatile)
        return MemoryImage::StretchBlt(image, destinationRect, sourceRect, clipRect, color, drawMode, fastStretch);
    Rect clipped;
    FRect sample;
    if (!StretchBltClipHelper(sourceRect, clipRect.Intersection(Rect(0, 0, mWidth, mHeight)), destinationRect, sample, clipped))
        return;
    image->mDrawn = true;
    if (!fastStretch)
    {
        // Native opaque-screen slow dispatch: zero-ARGB literal MemoryImage
        // sampled with the original white-normal kernel, then DD virtual Blt
        // with the caller's color/mode. Raw resampling is not this operation.
        MemoryImage temporary(mApp);
        temporary.Create(clipped.mWidth, clipped.mHeight);
        temporary.SlowStretchBlt(image, Rect(0, 0, clipped.mWidth, clipped.mHeight), sample,
            Color::White, Graphics::DRAWMODE_NORMAL);
        Blt(&temporary, clipped.mX, clipped.mY, Rect(0, 0, clipped.mWidth, clipped.mHeight), color, drawMode, false);
        return;
    }
    const uint32_t* pixels = source->GetBits();
    source->CommitBits();
    uint32_t* destination = GetBits();
    // Native DD software fast sampling converts to16.16 AFTER clipping.
    // int64_t avoids overflow outside the audited finite int32 range; no
    // half-pixel offset or per-pixel source clamp is introduced.
    const int64_t stepX = static_cast<int64_t>(sample.mWidth * 65536.0 / clipped.mWidth);
    const int64_t stepY = static_cast<int64_t>(sample.mHeight * 65536.0 / clipped.mHeight);
    int64_t qy = static_cast<int64_t>(sample.mY * 65536.0);
    for (int row = 0; row < clipped.mHeight; ++row, qy += stepY)
    {
        int64_t qx = static_cast<int64_t>(sample.mX * 65536.0);
        for (int column = 0; column < clipped.mWidth; ++column, qx += stepX)
        {
            const int index = (clipped.mY + row) * mWidth + clipped.mX + column;
            const uint32_t pixel = pixels[(qy >> 16) * source->mWidth + (qx >> 16)];
            destination[index] = CompositePixel(pixel, destination[index], color, drawMode,
                true, source->mHasAlpha, source->mHasTrans);
        }
    }
    BitsChanged();
}

void SoftwareScreenImage::StretchBltMirror(Image* image, const Rect& destinationRect,
    const Rect& sourceRect, const Rect& clipRect, const Color& color, int drawMode, bool fastStretch)
{
    auto* source = dynamic_cast<MemoryImage*>(image);
    if (!source || destinationRect.mWidth <= 0 || destinationRect.mHeight <= 0 ||
        sourceRect.mWidth <= 0 || sourceRect.mHeight <= 0 || sourceRect.mX < 0 || sourceRect.mY < 0 ||
        sourceRect.mX + sourceRect.mWidth > source->mWidth || sourceRect.mY + sourceRect.mHeight > source->mHeight)
        return;
    if (source->mIsVolatile)
        return MemoryImage::StretchBltMirror(image, destinationRect, sourceRect, clipRect, color, drawMode, fastStretch);
    image->mDrawn = true;
    Rect clipped;
    FRect sample;
    if (!StretchBltMirrorClipHelper(sourceRect, clipRect.Intersection(Rect(0, 0, mWidth, mHeight)), destinationRect, sample, clipped))
        return;
    const uint32_t* pixels = source->GetBits();
    source->CommitBits();
    uint32_t* destination = GetBits();
    // Native DD mirror stretch always uses fixed16 in software, including when
    // fastStretch=false. Sampling moves forward; the destination moves left.
    // Reversing a source temporary before ordinary Stretch selects other texels.
    const int64_t stepX = static_cast<int64_t>(sample.mWidth * 65536.0 / clipped.mWidth);
    const int64_t stepY = static_cast<int64_t>(sample.mHeight * 65536.0 / clipped.mHeight);
    int64_t qy = static_cast<int64_t>(sample.mY * 65536.0);
    for (int row = 0; row < clipped.mHeight; ++row, qy += stepY)
    {
        int64_t qx = static_cast<int64_t>(sample.mX * 65536.0);
        for (int column = 0; column < clipped.mWidth; ++column, qx += stepX)
        {
            const int index = (clipped.mY + row) * mWidth + clipped.mX + clipped.mWidth - 1 - column;
            const uint32_t pixel = pixels[(qy >> 16) * source->mWidth + (qx >> 16)];
            destination[index] = CompositePixel(pixel, destination[index], color, drawMode,
                true, source->mHasAlpha, source->mHasTrans);
        }
    }
    BitsChanged();
}

void SoftwareScreenImage::FillRect(const Rect& rect, const Color& color, int drawMode)
{
    if (drawMode != Graphics::DRAWMODE_NORMAL && drawMode != Graphics::DRAWMODE_ADDITIVE)
        return;
    const Rect clipped = rect.Intersection(Rect(0, 0, mWidth, mHeight));
    if (clipped.mWidth <= 0 || clipped.mHeight <= 0)
        return;
    uint32_t* bits = GetBits();
    const int alpha = color.mAlpha;
    for (int y = clipped.mY; y < clipped.mY + clipped.mHeight; ++y)
        for (int x = clipped.mX; x < clipped.mX + clipped.mWidth; ++x)
        {
            uint32_t& pixel = bits[y * mWidth + x];
            uint32_t result = 0xff000000u;
            for (int shift = 0; shift < 24; shift += 8)
            {
                const uint32_t mask = 255u << shift;
                const int channel = shift == 16 ? color.mRed : shift == 8 ? color.mGreen : color.mBlue;
                uint32_t output;
                if (drawMode == Graphics::DRAWMODE_ADDITIVE)
                    output = static_cast<uint32_t>(std::min(255,
                        static_cast<int>((pixel >> shift) & 255) + channel * alpha / 255)) << shift;
                else if (alpha == 255)
                    // Native RGB32 opaque fill omits the correction term. Its
                    // positive channels therefore map to channel-1, not channel.
                    output = ((static_cast<uint32_t>(channel) * mask) >> 8) & mask;
                else
                {
                    const uint32_t weighted = static_cast<uint32_t>((channel * alpha + 127) >> 8);
                    const uint32_t mapped = ((weighted * mask + mask) >> 8) & mask;
                    output = ((((pixel & mask) * static_cast<uint32_t>(256 - alpha)) >> 8) & mask) + mapped;
                }
                result |= output;
            }
            pixel = result;
        }
    BitsChanged();
}

void SoftwareScreenImage::BltMirror(Image* image, int x, int y, const Rect& sourceRect,
    const Color& color, int drawMode, bool linearFilter)
{
    if (drawMode != Graphics::DRAWMODE_NORMAL && drawMode != Graphics::DRAWMODE_ADDITIVE)
        return;
    auto* source = dynamic_cast<MemoryImage*>(image);
    if (!source || sourceRect.mWidth <= 0 || sourceRect.mHeight <= 0 || sourceRect.mX < 0 || sourceRect.mY < 0 ||
        sourceRect.mX + sourceRect.mWidth > source->mWidth || sourceRect.mY + sourceRect.mHeight > source->mHeight)
        return;
    if (source->mIsVolatile)
        return MemoryImage::BltMirror(image, x, y, sourceRect, color, drawMode, linearFilter);
    image->mDrawn = true;
    source->CommitBits();
    // Keep the existing alias-safe reversed temporary. Native DD unscaled mirror
    // always uses pixel alpha, even if source mode flags force opaque or are stale.
    MemoryImage mirrored(mApp);
    mirrored.Create(sourceRect.mWidth, sourceRect.mHeight);
    uint32_t* output = mirrored.GetBits();
    const uint32_t* pixels = source->GetBits();
    for (int row = 0; row < sourceRect.mHeight; ++row)
        for (int column = 0; column < sourceRect.mWidth; ++column)
            output[row * sourceRect.mWidth + column] = pixels[(sourceRect.mY + row) * source->mWidth + sourceRect.mX + sourceRect.mWidth - 1 - column];
    mirrored.BitsChanged();
    mirrored.SetImageMode(true, true);
    const Rect clipped = Rect(x, y, sourceRect.mWidth, sourceRect.mHeight).Intersection(Rect(0, 0, mWidth, mHeight));
    if (clipped.mWidth > 0 && clipped.mHeight > 0)
        Blt(&mirrored, clipped.mX, clipped.mY, Rect(clipped.mX - x, clipped.mY - y, clipped.mWidth, clipped.mHeight), color, drawMode, linearFilter);
}
