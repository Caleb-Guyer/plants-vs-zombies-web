/*
 * Portions of this file are based on the PopCap Games Framework
 * Copyright (C) 2005-2009 PopCap Games, Inc.
 *
 * Copyright (C) 2026 Zhou Qiankang <wszqkzqk@qq.com>
 *
 * SPDX-License-Identifier: LGPL-3.0-or-later AND LicenseRef-PopCap
 *
 * This file is part of PvZ-Portable.
 *
 * PvZ-Portable is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PvZ-Portable is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with PvZ-Portable. If not, see <https://www.gnu.org/licenses/>.
 */

#include <SDL.h>
#include <emscripten.h>
#include <emscripten/html5.h>

#include <memory>
#include <type_traits>

#include "SexyAppBase.h"
#include "graphics/GLInterface.h"
#include "graphics/GLImage.h"
#include "widget/WidgetManager.h"

using namespace Sexy;

void SexyAppBase::MakeWindow()
{
	if (mWindow)
	{
		// Use the browser Fullscreen API; SDL_SetWindowFullscreen has no effect on Emscripten.
		EMSCRIPTEN_RESULT aFullscreenResult = !mIsWindowed
			? emscripten_request_fullscreen("#canvas-container", EM_FALSE)
			: emscripten_exit_fullscreen();
		if (aFullscreenResult != EMSCRIPTEN_RESULT_SUCCESS)
			Sexy::LogInfoLn("Browser fullscreen request returned {}.", aFullscreenResult);
	}
	else
	{
		SDL_Init(SDL_INIT_VIDEO);

		Uint32 winFlags = SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN;

		SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
		SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
		SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 0);
		SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 0);
		SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 0);

		using WindowPtr = std::unique_ptr<SDL_Window, decltype(&SDL_DestroyWindow)>;
		using GLContextPtr = std::unique_ptr<std::remove_pointer_t<SDL_GLContext>, decltype(&SDL_GL_DeleteContext)>;

		WindowPtr window(SDL_CreateWindow(
			mTitle.c_str(),
			SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
			mWidth, mHeight, winFlags), &SDL_DestroyWindow);
		GLContextPtr context(nullptr, &SDL_GL_DeleteContext);

		if (window)
			context.reset(SDL_GL_CreateContext(window.get()));

		if (!context)
		{
			Sexy::LogErrorLn("Failed to create WebGL context.");
			return;
		}

		SDL_GL_SetSwapInterval(0);

		mWindow = (void*)window.release();
		mContext = (void*)context.release();
	}

	// A request can be pending or rejected. Browser events supply its later result.
	EmscriptenFullscreenChangeEvent aFullscreenStatus{};
	mIsWindowed = emscripten_get_fullscreen_status(&aFullscreenStatus) != EMSCRIPTEN_RESULT_SUCCESS || !aFullscreenStatus.isFullscreen;

	if (mGLInterface == nullptr)
	{
		mGLInterface = std::make_unique<GLInterface>(this);
		if (!InitGLInterface())
		{
			mGLInterface = nullptr;
			return;
		}
	}

	bool isActive = mActive;
	mActive = !!(SDL_GetWindowFlags((SDL_Window*)mWindow) & SDL_WINDOW_INPUT_FOCUS);

	mPhysMinimized = false;
	if (mMinimized)
	{
		if (mMuteOnLostFocus)
			Unmute(true);

		mMinimized = false;
		isActive = mActive;
		RehupFocus();
	}

	if (isActive != mActive)
		RehupFocus();

	ApplyRequestedRenderMode();

	ReInitImages();

	mWidgetManager->mImage = mGLInterface->GetScreenImage();
	mWidgetManager->MarkAllDirty();

	mGLInterface->UpdateViewport();
	mWidgetManager->Resize(mScreenBounds, mGLInterface->mPresentationRect);
}
