// SPDX-License-Identifier: LGPL-3.0-or-later
#include "QoLDialog.h"
#include "GameButton.h"
#include "../../LawnApp.h"
#include "../../Resources.h"
#include "../LawnCommon.h"
#include "graphics/Graphics.h"
#include "graphics/Font.h"
#include <algorithm>
#include "widget/Checkbox.h"
#include "widget/WidgetManager.h"
#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#endif

using namespace Sexy;

static int QoLStoneButtonWidth(int theDesiredWidth, int theTextWidth, int theCaps, int theTile)
{
	theTile = std::max(1, theTile);
	int aWidth = theCaps + std::max(0, (theDesiredWidth - theCaps) / theTile) * theTile;
	while (aWidth < theTextWidth + 12) aWidth += theTile;
	return aWidth;
}


enum { QOL_AUTO_PAUSE = 30, QOL_REMEMBER_SPEED, QOL_COOLDOWNS,
	QOL_CONTROLS, QOL_BACKUPS, QOL_DEFAULTS, QOL_BACK };

QoLDialog::QoLDialog(LawnApp* theApp) : LawnDialog(theApp, QOL_DIALOG_ID,
	true, "More Options", "", "", Dialog::BUTTONS_NONE)
{
	auto& aSettings = mApp->GetQoLSettings();
	mAutoPauseCheckbox = MakeNewCheckbox(QOL_AUTO_PAUSE, this, aSettings.mAutoPause);
	mRememberSpeedCheckbox = MakeNewCheckbox(QOL_REMEMBER_SPEED, this, aSettings.mRememberSpeed);
	mCooldownCheckbox = MakeNewCheckbox(QOL_COOLDOWNS, this, aSettings.mShowCooldownNumbers);
	mControlsButton = MakeButton(QOL_CONTROLS, this, "Controls");
	mBackupsButton = MakeButton(QOL_BACKUPS, this, "Backups");
	mDefaultsButton = MakeButton(QOL_DEFAULTS, this, "Reset Controls");
	mBackButton = MakeButton(QOL_BACK, this, "Back");
	for (int i = 0; i < 12; i++)
		mKeyButtons[i] = MakeButton(i, this, "");
	mApp->CenterDialog(this, 640, 555);
	RefreshPage();
}

QoLDialog::~QoLDialog() = default;

void QoLDialog::AddedToManager(WidgetManager* theManager)
{
	LawnDialog::AddedToManager(theManager);
	for (auto& aButton : mKeyButtons) AddWidget(aButton.get());
	AddWidget(mControlsButton.get()); AddWidget(mBackupsButton.get());
	AddWidget(mDefaultsButton.get()); AddWidget(mBackButton.get());
	AddWidget(mAutoPauseCheckbox.get()); AddWidget(mRememberSpeedCheckbox.get());
	AddWidget(mCooldownCheckbox.get());
}

void QoLDialog::RemovedFromManager(WidgetManager* theManager)
{
	for (auto& aButton : mKeyButtons) RemoveWidget(aButton.get());
	RemoveWidget(mControlsButton.get()); RemoveWidget(mBackupsButton.get());
	RemoveWidget(mDefaultsButton.get()); RemoveWidget(mBackButton.get());
	RemoveWidget(mAutoPauseCheckbox.get()); RemoveWidget(mRememberSpeedCheckbox.get());
	RemoveWidget(mCooldownCheckbox.get());
	LawnDialog::RemovedFromManager(theManager);
}

void QoLDialog::Resize(int x, int y, int width, int height)
{
	LawnDialog::Resize(x, y, width, height);
	if (!mBackButton) return; // Base construction sizes before child creation.
	mAutoPauseCheckbox->Resize(386, 130, 46, 45);
	mRememberSpeedCheckbox->Resize(386, 178, 46, 45);
	mCooldownCheckbox->Resize(386, 226, 46, 45);
	const int aCaps = IMAGE_BUTTON_LEFT->mWidth + IMAGE_BUTTON_RIGHT->mWidth;
	const int aTile = IMAGE_BUTTON_MIDDLE->mWidth;
	auto aPlace = [&](LawnStoneButton* theButton, int theX, int theY, int theWidth)
	{
		const int aText = FONT_DWARVENTODCRAFT18GREENINSET->StringWidth(theButton->mLabel);
		const int aWidth = QoLStoneButtonWidth(theWidth, aText, aCaps, aTile);
		theButton->Resize(theX + (theWidth - aWidth) / 2, theY, aWidth, 46);
	};
	aPlace(mControlsButton.get(), 112, 292, 416);
	aPlace(mBackupsButton.get(), 112, 344, 416);
	for (int i = 0; i < 12; i++)
		aPlace(mKeyButtons[i].get(), 54 + (i / 6) * 274, 136 + (i % 6) * 47, 252);
	aPlace(mDefaultsButton.get(), 54, 425, 252);
	aPlace(mBackButton.get(), mControlsPage ? 328 : 112, 425, mControlsPage ? 252 : 416);
}

void QoLDialog::RefreshPage()
{
	mDialogHeader = mControlsPage ? "Controls" : "More Options";
	mAutoPauseCheckbox->SetVisible(!mControlsPage);
	mRememberSpeedCheckbox->SetVisible(!mControlsPage);
	mCooldownCheckbox->SetVisible(!mControlsPage);
	mControlsButton->SetVisible(!mControlsPage);
	mBackupsButton->SetVisible(!mControlsPage);
	mDefaultsButton->SetVisible(mControlsPage);
	const auto& aSettings = mApp->GetQoLSettings();
	for (int i = 0; i < 12; i++)
	{
		mKeyButtons[i]->SetVisible(mControlsPage);
		mKeyButtons[i]->SetLabel(mCapturing == i ? "Press a key..." :
			QoLSettings::ActionName(i) + ": " + QoLSettings::KeyName(aSettings.mHotkeys[i]));
	}
	Resize(mX, mY, mWidth, mHeight);
	MarkDirty();
}

void QoLDialog::Persist()
{
	mStatus = mApp->SaveQoLSettings() ? "" : "Unable to save settings.";
	RefreshPage();
}

void QoLDialog::Draw(Graphics* g)
{
	LawnDialog::Draw(g);
	const Color aColor(107, 109, 145);
	if (!mControlsPage)
	{
		PvzpDrawString(g, "Auto Pause", 377, 157,
			FONT_DWARVENTODCRAFT18, aColor, DrawStringJustification::DS_ALIGN_RIGHT);
		PvzpDrawString(g, "Remember Speed", 377, 205,
			FONT_DWARVENTODCRAFT18, aColor, DrawStringJustification::DS_ALIGN_RIGHT);
		PvzpDrawString(g, "Recharge Timers", 377, 253,
			FONT_DWARVENTODCRAFT18, aColor, DrawStringJustification::DS_ALIGN_RIGHT);
	}
	else if (mCapturing >= 0)
	{
		PvzpDrawString(g, "Delete: Clear", mWidth / 2, 503,
			FONT_DWARVENTODCRAFT12, Color(224, 187, 98), DrawStringJustification::DS_ALIGN_CENTER);
	}
	if (!mStatus.empty())
		PvzpDrawString(g, mStatus, mWidth / 2, mControlsPage && mCapturing >= 0 ? 526 : 503,
			FONT_DWARVENTODCRAFT12, Color(224, 187, 98), DrawStringJustification::DS_ALIGN_CENTER);
}

void QoLDialog::CheckboxChecked(int theId, bool checked)
{
	auto& aSettings = mApp->GetQoLSettings();
	if (theId == QOL_AUTO_PAUSE) aSettings.mAutoPause = checked;
	if (theId == QOL_REMEMBER_SPEED)
	{
		aSettings.mRememberSpeed = checked;
		if (checked) aSettings.mPreferredDoubleSpeed = mApp->mDoubleGameSpeed;
	}
	if (theId == QOL_COOLDOWNS) aSettings.mShowCooldownNumbers = checked;
	mApp->PlaySample(SOUND_BUTTONCLICK);
	Persist();
}

void QoLDialog::ButtonDepress(int theId)
{
	if (theId >= 0 && theId < 12 && mControlsPage)
	{
		mCapturing = theId;
		mStatus.clear();
		RefreshPage();
	}
	else if (theId == QOL_CONTROLS)
	{
		mControlsPage = true; mCapturing = -1; mStatus.clear(); RefreshPage();
	}
	else if (theId == QOL_BACKUPS)
	{
#ifdef __EMSCRIPTEN__
		EM_ASM({ if (window.PVZSaveRecovery) window.PVZSaveRecovery.open(); });
#else
		mStatus = "Backups are unavailable."; RefreshPage();
#endif
	}
	else if (theId == QOL_DEFAULTS)
	{
		mApp->GetQoLSettings().ResetHotkeys(); mCapturing = -1; Persist();
	}
	else if (theId == QOL_BACK)
	{
		if (mControlsPage) { mControlsPage = false; mCapturing = -1; mStatus.clear(); RefreshPage(); }
		else
		{
			mApp->KillDialog(QOL_DIALOG_ID);
			if (auto* aOptions = mApp->GetDialog(Dialogs::DIALOG_NEWOPTIONS))
				mApp->mWidgetManager->SetFocus(aOptions);
		}
	}
}

void QoLDialog::KeyDown(KeyCode theKey)
{
	if (mCapturing >= 0)
	{
		if (theKey == KEYCODE_ESCAPE) { mCapturing = -1; mStatus.clear(); RefreshPage(); return; }
		const int aKey = theKey == KEYCODE_BACK || theKey == KEYCODE_DELETE ? 0 : static_cast<int>(theKey);
		if (!QoLSettings::IsBindable(aKey))
			mStatus = "Use a letter, number or arrow.";
		else if (!mApp->GetQoLSettings().SetBinding(mCapturing, aKey))
			mStatus = "Key already in use.";
		else { mCapturing = -1; Persist(); return; }
		RefreshPage();
	}
	else if (theKey == KEYCODE_ESCAPE) ButtonDepress(QOL_BACK);
}
