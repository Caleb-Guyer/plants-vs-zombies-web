// SPDX-License-Identifier: LGPL-3.0-or-later
#ifndef __QOLDIALOG_H__
#define __QOLDIALOG_H__

#include "LawnDialog.h"
#include "widget/CheckboxListener.h"
#include <array>

constexpr int QOL_DIALOG_ID = 7001;

class QoLDialog : public LawnDialog, public Sexy::CheckboxListener
{
public:
	std::array<std::unique_ptr<LawnStoneButton>, 12> mKeyButtons;
	std::unique_ptr<LawnStoneButton> mControlsButton;
	std::unique_ptr<LawnStoneButton> mBackupsButton;
	std::unique_ptr<LawnStoneButton> mDefaultsButton;
	std::unique_ptr<LawnStoneButton> mBackButton;
	std::unique_ptr<Sexy::Checkbox> mAutoPauseCheckbox;
	std::unique_ptr<Sexy::Checkbox> mRememberSpeedCheckbox;
	std::unique_ptr<Sexy::Checkbox> mCooldownCheckbox;
	bool mControlsPage = false;
	int mCapturing = -1;
	std::string mStatus;

	QoLDialog(LawnApp* theApp);
	~QoLDialog() override;
	void AddedToManager(Sexy::WidgetManager*) override;
	void RemovedFromManager(Sexy::WidgetManager*) override;
	void Resize(int x, int y, int width, int height) override;
	void Draw(Sexy::Graphics*) override;
	void ButtonDepress(int theId) override;
	void CheckboxChecked(int theId, bool checked) override;
	void KeyDown(Sexy::KeyCode theKey) override;
	void RefreshPage();
	void Persist();
};

#endif
