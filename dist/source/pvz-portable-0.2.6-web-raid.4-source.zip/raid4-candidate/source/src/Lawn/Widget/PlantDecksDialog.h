// SPDX-License-Identifier: LGPL-3.0-or-later
#ifndef PVZ_PLANT_DECKS_DIALOG_H
#define PVZ_PLANT_DECKS_DIALOG_H
#include "LawnDialog.h"
#include "../System/DeckPresets.h"
#include "widget/EditListener.h"
#include <array>
#include <memory>

class SeedChooserScreen;
namespace Sexy { class EditWidget; }

class PlantDecksDialog : public LawnDialog, public Sexy::EditListener
{
public:
    static constexpr int DIALOG_ID = 7002;
    SeedChooserScreen* mChooser;
    DeckPresets mPresets;
    int mSelected = 0;
    bool mStoreWritable = true;
    std::string mStatus;
    std::array<std::unique_ptr<LawnStoneButton>, DeckPresets::SLOT_COUNT> mSlots;
    std::unique_ptr<LawnStoneButton> mSaveButton, mLoadButton, mDeleteButton;
    std::unique_ptr<Sexy::EditWidget> mNameEdit;

    PlantDecksDialog(LawnApp* app, SeedChooserScreen* chooser);
    ~PlantDecksDialog() override;
    void AddedToManager(WidgetManager* manager) override;
    void RemovedFromManager(WidgetManager* manager) override;
    void Resize(int x, int y, int width, int height) override;
    void Draw(Graphics* g) override;
    void ButtonDepress(int id) override;
    void KeyDown(KeyCode key) override;
    void EditWidgetText(int, const std::string&) override {}
    void SelectSlot(int slot);
    void RefreshButtons();
};
#endif
