// SPDX-License-Identifier: LGPL-3.0-or-later
#include "MenderBloom.h"
#include "MenderBloomArt.h"
#include "../Board.h"
#include "../Plant.h"
#include "../../LawnApp.h"
#include "../../SexyAppFramework/graphics/MemoryImage.h"
#include "../../SexyAppFramework/graphics/Graphics.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "../../PvzpLib/PvzpParticle.h"
#include "../../PvzpLib/EffectSystem.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/FilterEffect.h"
#include <array>
#include <cstdint>
#include <memory>
#include <vector>

namespace MenderBloom
{
bool IsEligibleTarget(const Plant& healer, const Plant& target)
{
    return &healer != &target && healer.mBoard && target.mBoard == healer.mBoard &&
        target.mApp == healer.mApp && target.mIsOnBoard && !target.mDead &&
        !target.mSquished && target.mOnBungeeState == NOT_ON_BUNGEE &&
        target.mPlantHealth > 0 && target.mPlantMaxHealth > target.mPlantHealth &&
        target.mState != STATE_DOINGSPECIAL && IsPersistentTargetSeed(target.mSeedType) &&
        InRange(target.mPlantCol - healer.mPlantCol, target.mRow - healer.mRow);
}

void RetireLegacyHealingParticles(Board& board)
{
    if (!board.mApp || !board.mApp->mEffectSystem || !board.mApp->mEffectSystem->mParticleHolder)
        return;
    // Called once after loading a board. Menu trophy effects were discarded
    // when the board was created; these unowned sparkles are old healing pulses.
    // Preserve a pending finite pulse's saved lifetime rather than restarting it.
    for (PvzpParticleSystem* sparkle : board.mApp->mEffectSystem->mParticleHolder->mParticleSystems)
    {
        if (sparkle->mDead || sparkle->mIsAttachment || sparkle->mEffectType != PARTICLE_TROPHY_SPARKLE)
            continue;
        for (auto* node = sparkle->mEmitterList.mHead; node; node = node->mNext)
        {
            PvzpParticleEmitter* emitter = sparkle->mParticleHolder->mEmitters.DataArrayGet(
                static_cast<unsigned int>(node->mValue));
            if (!emitter->mDead && emitter->mEmitterCrossFadeCountDown == 0)
                emitter->mEmitterCrossFadeCountDown = kHealingFrames;
        }
    }
}

void Update(Plant& healer)
{
    if (healer.mSeedType != kSeed || !healer.mBoard || !healer.mApp ||
        !healer.IsInPlay() || healer.mApp->mGameScene != SCENE_PLAYING ||
        healer.mBoard->mPaused || healer.mBoard->mTimeStopCounter > 0 ||
        healer.mBoard->mLevelComplete || healer.mBoard->HasLevelAwardDropped() ||
        healer.mDead || healer.mPlantHealth <= 0 || healer.mIsAsleep ||
        healer.mSquished || healer.mOnBungeeState != NOT_ON_BUNGEE)
        return;
    if (healer.mDoSpecialCountdown > 0) --healer.mDoSpecialCountdown;
    if (healer.mStateCountdown > 0) --healer.mStateCountdown;
    if (healer.mStateCountdown > 0) return;

    bool healed = false;
    for (Plant* target : healer.mBoard->mPlants)
    {
        if (!IsEligibleTarget(healer, *target)) continue;
        const int previous = target->mPlantHealth;
        target->mPlantHealth = BoundedHeal(previous, target->mPlantMaxHealth);
        if (target->mPlantHealth == previous) continue;
        healed = true;
        // The native trophy sparkle loops. Its existing per-emitter cutoff
        // gives this repair pulse a finite lifetime without changing the shared
        // trophy definition, artwork or serialized particle layout.
        if (PvzpParticleSystem* sparkle = healer.mApp->AddPvzpParticle(
            target->mX + 40, target->mY + 28, target->mRenderOrder + 2, PARTICLE_TROPHY_SPARKLE))
            for (auto* node = sparkle->mEmitterList.mHead; node; node = node->mNext)
            {
                PvzpParticleEmitter* emitter = sparkle->mParticleHolder->mEmitters.DataArrayGet(
                    static_cast<unsigned int>(node->mValue));
                emitter->mEmitterCrossFadeCountDown = kHealingFrames;
            }
        if (target->mSeedType == SEED_GARLIC && previous < target->mPlantMaxHealth / 3 &&
            target->mPlantHealth >= target->mPlantMaxHealth / 3)
            if (Reanimation* body = healer.mApp->ReanimationTryToGet(target->mBodyReanimID))
                body->AssignRenderGroupToPrefix("Garlic_stem", RENDER_GROUP_NORMAL);
    }
    if (healed)
    {
        healer.mStateCountdown = kPulseInterval;
        healer.mDoSpecialCountdown = kHealingFrames;
    }
}

namespace
{
struct SpriteCache
{
    std::array<std::unique_ptr<Sexy::MemoryImage>, 4> images;
    std::array<std::array<std::unique_ptr<Sexy::MemoryImage>, NUM_FILTER_EFFECTS>, 3> filtered;
};
SpriteCache& Cache()
{
    static SpriteCache cache;
    return cache;
}

std::unique_ptr<Sexy::MemoryImage> MakeImage(const uint32_t* argb)
{
    std::vector<uint32_t> pixels(argb, argb + MenderBloomArt::kWidth * MenderBloomArt::kHeight);
    auto image = std::make_unique<Sexy::MemoryImage>();
    image->SetBits(pixels.data(), MenderBloomArt::kWidth, MenderBloomArt::kHeight);
    return image;
}

void EnsureImages()
{
    static_assert(MenderBloomArt::kWidth == 80 && MenderBloomArt::kHeight == 80,
        "Mender-bloom layers share the registered native plant canvas");
    SpriteCache& cache = Cache();
    if (cache.images[0]) return;
    cache.images[0] = MakeImage(MenderBloomArt::kHeadArgb);
    cache.images[1] = MakeImage(MenderBloomArt::kStemArgb);
    cache.images[2] = MakeImage(MenderBloomArt::kHeadBlinkArgb);
    cache.images[3] = MakeImage(MenderBloomArt::kArgb);
    for (int layer = 0; layer < 3; ++layer)
        for (int filter = 0; filter < NUM_FILTER_EFFECTS; ++filter)
            cache.filtered[layer][filter].reset(FilterEffectCreateImage(cache.images[layer].get(), static_cast<FilterEffect>(filter)));
}

Sexy::Image* GetLayerImage(int layer, FilterEffect filter)
{
    EnsureImages();
    if (filter >= 0 && filter < NUM_FILTER_EFFECTS && Cache().filtered[layer][filter])
        return Cache().filtered[layer][filter].get();
    return Cache().images[layer].get();
}

void DrawLayer(Sexy::Graphics* graphics, Reanimation& carrier, int layer, const LayerPose& pose)
{
    Sexy::Image* image = GetLayerImage(layer, carrier.mFilterEffect);
    SexyMatrix3 local;
    PvzpScaleRotateTransformMatrix(local, pose.centerX, pose.centerY,
        pose.angle, pose.scaleX, pose.scaleY);
    SexyMatrix3 matrix;
    SexyMatrix3Multiply(matrix, carrier.mOverlayMatrix, local);
    SexyMatrix3Translation(matrix, graphics->mTransX, graphics->mTransY);
    Sexy::Color color = carrier.mColorOverride;
    if (graphics->GetColorizeImages()) color = ColorsMultiply(color, graphics->GetColor());
    if (color.mAlpha <= 0) return;
    const Sexy::Rect source(0, 0, image->GetWidth(), image->GetHeight());
    carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect, color, graphics->GetDrawMode(), source);
    if (carrier.mEnableExtraAdditiveDraw)
    {
        Sexy::Color additive = carrier.mExtraAdditiveColor;
        additive.mAlpha = ColorComponentMultiply(additive.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, image, matrix, graphics->mClipRect, additive,
            Sexy::Graphics::DRAWMODE_ADDITIVE, source);
    }
    if (carrier.mEnableExtraOverlayDraw)
    {
        Sexy::Color overlay = carrier.mExtraOverlayColor;
        overlay.mAlpha = ColorComponentMultiply(overlay.mAlpha, color.mAlpha);
        carrier.ReanimBltMatrix(graphics, GetLayerImage(layer, FILTER_EFFECT_WHITE), matrix,
            graphics->mClipRect, overlay, Sexy::Graphics::DRAWMODE_NORMAL, source);
    }
}

void HideCarrier(Reanimation& carrier)
{
    if (carrier.mDefinition && carrier.mTrackInstances)
        carrier.AssignRenderGroupToPrefix("", RENDER_GROUP_HIDDEN);
}
}

void EnsurePlantReanimation(Plant& plant)
{
    if (plant.mSeedType != kSeed || !plant.mApp || plant.mDead || plant.mSquished || plant.mPlantHealth <= 0) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (body && body->mReanimationType != REANIM_SUNFLOWER)
    {
        plant.EndBlink();
        plant.mApp->RemoveReanimation(plant.mBodyReanimID);
        plant.mBodyReanimID = REANIMATIONID_NULL;
        body = nullptr;
    }
    if (!body)
    {
        const float offsetY = PlantDrawHeightOffset(plant.mBoard, &plant, kSeed, plant.mPlantCol, plant.mRow);
        body = plant.mApp->AddReanimation(0.0f, offsetY, plant.mRenderOrder + 1, REANIM_SUNFLOWER);
        body->SetFramesForLayer("anim_idle");
        body->mLoopType = REANIM_LOOP;
        body->mIsAttachment = true;
        plant.mBodyReanimID = plant.mApp->ReanimationGetID(body);
        if (plant.mBlinkCountdown <= 0) plant.mBlinkCountdown = 400;
    }
    // Its native saved phase is an animation clock; none of the Sunflower's
    // original images or production behavior are rendered or used here.
    body->mAnimRate = std::max(1, body->mFrameCount) / kIdlePeriodSeconds;
    HideCarrier(*body);
    if (Reanimation* blink = plant.mApp->ReanimationTryToGet(plant.mBlinkReanimID)) HideCarrier(*blink);
}

void DrawPlantRig(Sexy::Graphics* graphics, const Plant& plant, Reanimation& carrier)
{
    if (plant.mSeedType != kSeed || carrier.mDead || plant.mDead || plant.mPlantHealth <= 0) return;
    bool blink = plant.mIsAsleep;
    if (plant.mApp)
        if (Reanimation* expression = plant.mApp->ReanimationTryToGet(plant.mBlinkReanimID))
            blink = blink || (!expression->mDead && expression->mLoopCount == 0 &&
                expression->mAnimTime >= 0.2f && expression->mAnimTime <= 0.8f);
    const bool active = !plant.mIsAsleep && !plant.mSquished && plant.mOnBungeeState == NOT_ON_BUNGEE;
    const float phase = active ? carrier.mAnimTime : 0.0f;
    const int glow = active ? plant.mDoSpecialCountdown : 0;
    blink = blink || (glow > kHealingFrames / 3 && glow < kHealingFrames * 4 / 5);
    DrawLayer(graphics, carrier, 1, GetStemPose(phase, glow));
    DrawLayer(graphics, carrier, blink ? 2 : 0, GetHeadPose(phase, glow));
}

Sexy::Image* GetImage()
{
    EnsureImages();
    return Cache().images[3].get();
}

void DrawSprite(Sexy::Graphics* graphics, float x, float y, float scaleX, float scaleY)
{
    PvzpDrawImageScaledF(graphics, GetImage(), x, y, scaleX, scaleY);
}

void DisposeImage()
{
    SpriteCache& cache = Cache();
    for (auto& image : cache.images) image.reset();
    for (auto& layer : cache.filtered)
        for (auto& image : layer) image.reset();
}
}
