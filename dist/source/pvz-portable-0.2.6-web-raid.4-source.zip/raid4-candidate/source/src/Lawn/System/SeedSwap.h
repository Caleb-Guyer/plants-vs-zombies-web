// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

// Seed Swap keeps a fixed number of occupied squares. Native dropped packets
// replace a surviving plant rather than buying a new square of defense.
namespace SeedSwap
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_SEED_SWAP;
inline constexpr ChallengeState kState = static_cast<ChallengeState>(104);
inline constexpr int kOpeningDelay = 1200;
inline constexpr int kPacketLimit = 6;
inline constexpr int kPacketLifetime = 3000;
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestWave = 8;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kState; }

inline constexpr std::array<SeedType, 8> kDropSeeds = {
    SEED_REPEATER, SEED_SNOWPEA, SEED_CABBAGEPULT, SEED_CACTUS,
    SEED_SPLITPEA, SEED_KERNELPULT, SEED_TALLNUT, SEED_MELONPULT
};
constexpr bool IsDropSeed(SeedType seed)
{
    for (SeedType allowed : kDropSeeds) if (seed == allowed) return true;
    return false;
}
constexpr bool IsGardenSeed(SeedType seed) { return seed == SEED_PEASHOOTER || seed == SEED_WALLNUT || IsDropSeed(seed); }

struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
inline constexpr std::array<StartingPlant, 15> kStartingPlants = {{
    {SEED_PEASHOOTER,1,0}, {SEED_PEASHOOTER,2,0}, {SEED_WALLNUT,5,0},
    {SEED_PEASHOOTER,1,1}, {SEED_PEASHOOTER,2,1}, {SEED_WALLNUT,5,1},
    {SEED_PEASHOOTER,1,2}, {SEED_PEASHOOTER,2,2}, {SEED_WALLNUT,5,2},
    {SEED_PEASHOOTER,1,3}, {SEED_PEASHOOTER,2,3}, {SEED_WALLNUT,5,3},
    {SEED_PEASHOOTER,1,4}, {SEED_PEASHOOTER,2,4}, {SEED_WALLNUT,5,4}
}};

struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; };
using Wave = std::array<Spawn, kLargestWave>;
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {{{ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_NORMAL,0}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_DOOR,1}, {ZOMBIE_DOOR,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_PAIL,2}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_POLEVAULTER,0}, {ZOMBIE_POLEVAULTER,4}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_DOOR,1}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_BALLOON,1}, {ZOMBIE_DOOR,0}, {ZOMBIE_DOOR,4}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_DIGGER,3}, {ZOMBIE_PAIL,0}, {ZOMBIE_PAIL,4}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,2}}},
    {{{ZOMBIE_FOOTBALL,2}, {ZOMBIE_POLEVAULTER,1}, {ZOMBIE_POLEVAULTER,3}, {ZOMBIE_DOOR,0}, {ZOMBIE_DOOR,4}, {ZOMBIE_TRAFFIC_CONE,2}}},
    {{{ZOMBIE_FLAG,2}, {ZOMBIE_PAIL,0}, {ZOMBIE_PAIL,4}, {ZOMBIE_DOOR,1}, {ZOMBIE_DOOR,3}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,4}}}
}};

// The saved drop ordinal gives repeatable choices across resume. The first six
// kills teach useful swaps. Special waves repeat their counters instead of
// relying on an early Cactus or Split Pea still being on the lawn much later.
constexpr SeedType SeedForDrop(int wave, int ordinal)
{
    if (wave < 0 || wave >= kWaveCount || ordinal < 0) return SEED_NONE;
    constexpr std::array<SeedType, 6> opening = {
        SEED_REPEATER, SEED_SNOWPEA, SEED_CABBAGEPULT, SEED_REPEATER, SEED_CACTUS, SEED_SPLITPEA
    };
    if (ordinal < static_cast<int>(opening.size())) return opening[ordinal];
    constexpr std::array<SeedType, 6> early = {
        SEED_CABBAGEPULT, SEED_KERNELPULT, SEED_REPEATER, SEED_TALLNUT, SEED_SNOWPEA, SEED_SPLITPEA
    };
    constexpr std::array<SeedType, 8> middle = {
        SEED_MELONPULT, SEED_CACTUS, SEED_REPEATER, SEED_TALLNUT,
        SEED_CABBAGEPULT, SEED_SPLITPEA, SEED_KERNELPULT, SEED_SNOWPEA
    };
    constexpr std::array<SeedType, 3> balloons = { SEED_CACTUS, SEED_REPEATER, SEED_CABBAGEPULT };
    constexpr std::array<SeedType, 3> diggers = { SEED_SPLITPEA, SEED_MELONPULT, SEED_TALLNUT };
    constexpr std::array<SeedType, 8> late = {
        SEED_MELONPULT, SEED_TALLNUT, SEED_CACTUS, SEED_REPEATER,
        SEED_SPLITPEA, SEED_CABBAGEPULT, SEED_KERNELPULT, SEED_SNOWPEA
    };
    const unsigned int index = static_cast<unsigned int>(ordinal - opening.size());
    if (wave <= 3) return early[index % early.size()];
    if (wave <= 5) return middle[index % middle.size()];
    if (wave == 6) return balloons[index % balloons.size()];
    if (wave == 7) return diggers[index % diggers.size()];
    return late[index % late.size()];
}
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave]) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
constexpr int RowForSpawn(int wave, int ordinal)
{
    return wave >= 0 && wave < kWaveCount && ordinal >= 0 && ordinal < ZombieCount(wave)
        ? kWaves[wave][ordinal].mRow : -1;
}
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave])
        if (spawn.mType != ZOMBIE_INVALID) output[count++] = spawn.mType;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DIGGER));
    for (auto& allowed : output) allowed = false;
    for (const Wave& wave : kWaves) for (const Spawn& spawn : wave)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
static_assert(static_cast<int>(kMode) == 77);
static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
