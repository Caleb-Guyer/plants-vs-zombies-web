// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Zombie;

// A support zombie whose native saved summon counter carries his call cadence.
// Speed is derived from the live callers; it never overwrites an actor's base
// velocity, stacks, changes chewing speed or survives its source being disabled.
namespace RallyZombie
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_RALLY_POINT;
inline constexpr ChallengeState kState = static_cast<ChallengeState>(110);
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestWave = 8;
inline constexpr int kStartingSun = 250;
inline constexpr int kOpeningDelay = 1200;
inline constexpr int kWarmupTicks = 450;
inline constexpr int kCycleTicks = 700;
inline constexpr int kCallTicks = 160;
inline constexpr int kRadiusX = 180;
inline constexpr int kRadiusRows = 1;
inline constexpr float kSpeedMultiplier = 1.45f;
inline constexpr int kBodyHealth = 340;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kState; }
inline constexpr std::array<SeedType, 6> kSeeds = {
    SEED_SUNFLOWER, SEED_CABBAGEPULT, SEED_SNOWPEA,
    SEED_WALLNUT, SEED_CHERRYBOMB, SEED_SQUASH
};
struct StartingPlant { SeedType mSeed; int mCol; int mRow; };
inline constexpr std::array<StartingPlant, 7> kStartingPlants = {{
    {SEED_CABBAGEPULT,1,0}, {SEED_CABBAGEPULT,1,1}, {SEED_CABBAGEPULT,1,2},
    {SEED_CABBAGEPULT,1,3}, {SEED_CABBAGEPULT,1,4},
    {SEED_SUNFLOWER,0,1}, {SEED_SUNFLOWER,0,3}
}};
struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; };
using Wave = std::array<Spawn, kLargestWave>;
// Start with an unarmored demonstration. Later calls cover two adjacent lanes
// and armor protects the caller; lobbed cabbages, frost and timed explosives
// all remain native counters. There are no fast or instant-kill attackers.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {{{ZOMBIE_RALLY,2}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,1}}},
    {{{ZOMBIE_RALLY,3}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,0}}},
    {{{ZOMBIE_RALLY,1}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}}},
    {{{ZOMBIE_RALLY,3}, {ZOMBIE_NORMAL,2}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,1}}},
    {{{ZOMBIE_RALLY,2}, {ZOMBIE_DOOR,2}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_RALLY,1}, {ZOMBIE_RALLY,3}, {ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_RALLY,2}, {ZOMBIE_PAIL,2}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_RALLY,1}, {ZOMBIE_RALLY,3}, {ZOMBIE_DOOR,1}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_RALLY,2}, {ZOMBIE_DOOR,2}, {ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_RALLY,1}, {ZOMBIE_RALLY,3}, {ZOMBIE_PAIL,2}, {ZOMBIE_DOOR,1}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,4}}}
}};
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave]) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
constexpr int RowForSpawn(int wave, int ordinal)
{
    return wave >= 0 && wave < kWaveCount && ordinal >= 0 && ordinal < ZombieCount(wave)
        ? kWaves[wave][ordinal].mRow : -1;
}
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave])
        if (spawn.mType != ZOMBIE_INVALID) output[count++] = spawn.mType;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_RALLY));
    for (auto& allowed : output) allowed = false;
    for (const Wave& wave : kWaves) for (const Spawn& spawn : wave)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = static_cast<int>(kSeeds.size());
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
    bank.RefreshAllPackets();
}
bool IsZombie(const Zombie& zombie);
bool IsRallying(const Zombie& zombie);
float MovementMultiplier(const Zombie& zombie);
void Update(Zombie& zombie);
void UpdateBoard(Board& board);
static_assert(static_cast<int>(kMode) == 80);
static_assert(static_cast<int>(ZOMBIE_RALLY) == 33);
static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
