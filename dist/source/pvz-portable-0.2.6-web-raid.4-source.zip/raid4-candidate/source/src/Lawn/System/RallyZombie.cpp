// SPDX-License-Identifier: LGPL-3.0-or-later
#include "RallyZombie.h"
#include "RallyRaid.h"
#include "../Board.h"
#include "../Zombie.h"
#include "../../LawnApp.h"
#include <cmath>

namespace RallyZombie
{
bool IsZombie(const Zombie& zombie) { return zombie.mZombieType == ZOMBIE_RALLY; }

static bool CanWalk(const Zombie& zombie)
{
    return !zombie.mDead && zombie.mBodyHealth > 0 && zombie.mHasHead &&
        !zombie.mMindControlled && !zombie.mBlowingAway && !zombie.mIsEating &&
        zombie.mIceTrapCounter == 0 && zombie.mButteredCounter == 0 &&
        zombie.mZombiePhase == PHASE_ZOMBIE_NORMAL &&
        zombie.mZombieHeight == HEIGHT_ZOMBIE_NORMAL && !zombie.mInPool;
}

bool IsRallying(const Zombie& zombie)
{
    return IsZombie(zombie) && CanWalk(zombie) && zombie.mHasArm && zombie.mHasObject &&
        zombie.mSummonCounter > 0 && zombie.mSummonCounter <= kCallTicks;
}

float MovementMultiplier(const Zombie& zombie)
{
    if (!zombie.mBoard || !zombie.mApp || !(IsMode(zombie.mApp->mGameMode) || RallyRaid::IsMode(zombie.mApp->mGameMode)) ||
        zombie.mFromWave < 0 || !CanWalk(zombie)) return 1.0f;
    switch (zombie.mZombieType)
    {
    case ZOMBIE_NORMAL: case ZOMBIE_TRAFFIC_CONE: case ZOMBIE_PAIL:
    case ZOMBIE_DOOR: case ZOMBIE_RALLY:
        break;
    default:
        return 1.0f;
    }
    for (const Zombie* caller : zombie.mBoard->mZombies)
    {
        if (caller == &zombie || caller->mFromWave < 0 || !IsRallying(*caller) ||
            caller->mPosX < 0 || caller->mPosX > 780) continue;
        if (std::abs(caller->mRow - zombie.mRow) <= kRadiusRows &&
            std::abs(caller->mPosX - zombie.mPosX) <= kRadiusX)
            return kSpeedMultiplier;
    }
    return 1.0f;
}

void Update(Zombie& zombie)
{
    if (!IsZombie(zombie) || !CanWalk(zombie) || !zombie.mHasArm || !zombie.mHasObject) return;
    if (zombie.mSummonCounter <= 0 || zombie.mSummonCounter > kCycleTicks)
        zombie.mSummonCounter = kCycleTicks;
    else
        --zombie.mSummonCounter;
}

void UpdateBoard(Board& board)
{
    if (!(IsMode(board.mApp->mGameMode) || RallyRaid::IsMode(board.mApp->mGameMode)) || board.mApp->mGameScene != SCENE_PLAYING ||
        board.mPaused || board.HasLevelAwardDropped()) return;
    // Advance callers as a group before any actor walks. All recipients see
    // the same call phase, independent of DataArray iteration order.
    for (Zombie* zombie : board.mZombies) Update(*zombie);
}
}
