// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

class Board;
class Plant;
class Zombie;

// A five-board placement puzzle. Native saved board, challenge, packet and
// actor fields carry preparation, finite inventory, fuses and stage progress.
namespace ChainReaction
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_CHAIN_REACTION;
inline constexpr ChallengeState kPlanning = static_cast<ChallengeState>(106);
inline constexpr ChallengeState kResolving = static_cast<ChallengeState>(107);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(108);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(109);
inline constexpr int kBoardCount = 5;
inline constexpr int kTransitionTicks = 180;
inline constexpr int kSeedCount = 10;

constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{
    return IsMode(mode) && state >= kPlanning && state <= kFinished;
}
constexpr bool IsPlanning(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kPlanning; }
constexpr bool IsExplosive(SeedType seed)
{
    return seed == SEED_CHERRYBOMB || seed == SEED_JALAPENO || seed == SEED_POTATOMINE;
}

struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mCol = 0; int mRow = 0; int mOffsetX = 0; };
struct Puzzle
{
    std::array<SeedType, 3> mSeeds;
    std::array<Spawn, 12> mZombies;
};
// Layouts are deliberately spatial: a compact blast, one complete lane, an
// isolated mine lane, two separate blast shapes, then all three tools together.
// Reserve the top lawn row so native zombie heads stay below the conveyor HUD.
inline constexpr std::array<Puzzle, kBoardCount> kBoards = {{
    {{SEED_CHERRYBOMB, SEED_NONE, SEED_NONE}, {{
        {ZOMBIE_NORMAL,5,1}, {ZOMBIE_TRAFFIC_CONE,5,2}, {ZOMBIE_NORMAL,5,3}}}},
    {{SEED_JALAPENO, SEED_NONE, SEED_NONE}, {{
        {ZOMBIE_NORMAL,2,2}, {ZOMBIE_TRAFFIC_CONE,4,2}, {ZOMBIE_PAIL,6,2}, {ZOMBIE_DOOR,8,2}}}},
    {{SEED_POTATOMINE, SEED_CHERRYBOMB, SEED_NONE}, {{
        {ZOMBIE_NORMAL,3,1}, {ZOMBIE_TRAFFIC_CONE,3,1,6},
        {ZOMBIE_NORMAL,6,2}, {ZOMBIE_PAIL,6,3}, {ZOMBIE_NORMAL,6,4}}}},
    {{SEED_JALAPENO, SEED_CHERRYBOMB, SEED_NONE}, {{
        {ZOMBIE_TRAFFIC_CONE,2,1}, {ZOMBIE_NORMAL,5,1}, {ZOMBIE_DOOR,8,1},
        {ZOMBIE_NORMAL,6,2}, {ZOMBIE_PAIL,6,3}, {ZOMBIE_TRAFFIC_CONE,6,4}}}},
    {{SEED_CHERRYBOMB, SEED_JALAPENO, SEED_POTATOMINE}, {{
        {ZOMBIE_NORMAL,2,1}, {ZOMBIE_PAIL,5,1}, {ZOMBIE_DOOR,8,1},
        {ZOMBIE_TRAFFIC_CONE,7,2}, {ZOMBIE_PAIL,7,3}, {ZOMBIE_NORMAL,7,4},
        {ZOMBIE_NORMAL,3,4}, {ZOMBIE_TRAFFIC_CONE,3,4,6}}}}
}};

constexpr int ZombieCount(int stage)
{
    if (stage < 0 || stage >= kBoardCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kBoards[stage].mZombies) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kBoardCount);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    // Real opponents are placed from the saved stage layout, not wave spawns.
    // Keeping the ordinary wave index below this bound also prevents a native
    // death callback from awarding the whole challenge after an early board.
    return kBoardCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for (auto& allowed : output) allowed = false;
    for (const Puzzle& board : kBoards) for (const Spawn& spawn : board.mZombies)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = kSeedCount;
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].mPacketType = SEED_NONE;
}

void Populate(Board& board);
void ResetStage(Board& board, int stage);
void Commit(Board& board);
void Update(Board& board);
void PreparePlant(Plant& plant);
void RestoreButton(Board& board);
bool IsPlanning(const Board& board);
bool CanPlant(const Board& board, SeedType seed);
bool HoldsZombie(Zombie& zombie);
}
