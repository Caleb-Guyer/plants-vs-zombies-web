// SPDX-License-Identifier: LGPL-3.0-or-later
#include "DeckPresets.h"
#include "PlayerInfo.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/PvzpCommon.h"
#include "misc/Buffer.h"
#include <format>

static std::string DeckFile(LawnApp* app)
{
    return GetAppDataPath(std::format("userdata/qol-decks-{}.txt", app->mPlayerInfo->mId));
}

bool DeckPresets::Load(LawnApp* app)
{
    if (!app || !app->mPlayerInfo) return false;
    Sexy::Buffer buffer;
    if (!app->ReadBufferFromFile(DeckFile(app), &buffer)) return true;
    if (buffer.GetDataLen() < 0 || buffer.GetDataLen() > 8192) return false;
    return Decode(std::string(reinterpret_cast<const char*>(buffer.GetDataPtr()), buffer.GetDataLen()));
}

bool DeckPresets::Save(LawnApp* app) const
{
    if (!app || !app->mPlayerInfo) return false;
    const std::string text = Encode();
    DeckPresets validated;
    if (!validated.Decode(text)) return false;
    MkDir(GetAppDataPath("userdata"));
    return app->WriteBytesToFile(DeckFile(app), text.data(), static_cast<unsigned long>(text.size()));
}
