// SPDX-License-Identifier: LGPL-3.0-or-later
#ifndef __QOLSETTINGS_H__
#define __QOLSETTINGS_H__

#include <array>
#include <string>
#include <string_view>

// Versioned, per-profile preferences. Native profile and Board save bytes stay
// unchanged; the app persists this separate text record under userdata/.
class QoLSettings
{
public:
	static constexpr int HOTKEY_COUNT = 12;
	static constexpr int SHOVEL_ACTION = 10;
	static constexpr int SPEED_ACTION = 11;
	bool mAutoPause = true;
	bool mRememberSpeed = true;
	bool mPreferredDoubleSpeed = false;
	bool mShowCooldownNumbers = false;
	std::array<int, HOTKEY_COUNT> mHotkeys{};

	QoLSettings();
	void ResetHotkeys();
	bool SetBinding(int theAction, int theKey);
	bool Decode(std::string_view theText);
	std::string Encode() const;
	static bool IsBindable(int theKey);
	static std::string KeyName(int theKey);
	static std::string ActionName(int theAction);
};

#endif
