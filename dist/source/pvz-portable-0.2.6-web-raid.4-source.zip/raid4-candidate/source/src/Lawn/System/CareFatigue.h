// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "IntensiveCare.h"
#include <cmath>
#include <cstdint>

// A rendering pose, never a plant state. Native attack, health, targeting,
// attachment clocks and save data remain the authority for the actual plant.
namespace CareFatigue
{
inline constexpr int kTiredHealth = 180;

struct Pose
{
    float mLean = 0.0f;
    float mScaleY = 1.0f;
    float mShade = 1.0f;
    bool mActive = false;
};

inline Pose GetPose(int health, int shootingCounter, uint32_t counter, int row, int col)
{
    if (health > kTiredHealth || health <= 0) return {};
    const float phase = static_cast<float>((counter + row * 73 + col * 41) % 600) * 0.010471976f;
    const float breath = (1.0f + std::sin(phase)) * 0.5f;
    if (health <= IntensiveCare::kExhaustedHealth)
    {
        // A low resting silhouette and slow breathing stay legible at lawn
        // scale without borrowing the sleeping mushrooms' floating Zs.
        return {0.56f + breath * 0.018f, 0.60f + breath * 0.018f, 0.86f, true};
    }

    const float tired = static_cast<float>(kTiredHealth - health) /
        static_cast<float>(kTiredHealth - IntensiveCare::kExhaustedHealth);
    const float amount = 0.18f + tired * 0.82f;
    // Let native attack poses reach the unchanged projectile launch point.
    // The droop is strongest between attacks, when the plant catches its breath.
    const float idle = shootingCounter > 0 ? 0.0f : 1.0f;
    return {(0.10f + breath * 0.08f) * amount * idle,
        1.0f - (0.12f + breath * 0.04f) * amount * idle,
        1.0f - 0.045f * amount, true};
}

template<class Matrix>
Matrix Transform(const Pose& pose, float pivotX, float pivotY, const Matrix& original)
{
    const float c = std::cos(pose.mLean);
    const float s = std::sin(pose.mLean);
    Matrix result = original;
    // Clockwise lean and a shorter stalk, hinged at the planted base. Compose
    // with every native part's existing matrix, including attached blink art.
    result.m00 = c * original.m00 - s * pose.mScaleY * original.m10;
    result.m01 = c * original.m01 - s * pose.mScaleY * original.m11;
    result.m02 = pivotX + c * (original.m02 - pivotX) - s * pose.mScaleY * (original.m12 - pivotY);
    result.m10 = s * original.m00 + c * pose.mScaleY * original.m10;
    result.m11 = s * original.m01 + c * pose.mScaleY * original.m11;
    result.m12 = pivotY + s * (original.m02 - pivotX) + c * pose.mScaleY * (original.m12 - pivotY);
    return result;
}
}
