// SPDX-License-Identifier: LGPL-3.0-or-later
#include "QoLSettings.h"
#include <sstream>

QoLSettings::QoLSettings()
{
	ResetHotkeys();
}

void QoLSettings::ResetHotkeys()
{
	mHotkeys = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'S', 'F'};
}

bool QoLSettings::IsBindable(int theKey)
{
	return theKey == 0 || (theKey >= '0' && theKey <= '9') ||
		(theKey >= 'A' && theKey <= 'Z') || (theKey >= 37 && theKey <= 40) ||
		(theKey >= 96 && theKey <= 105);
}

bool QoLSettings::SetBinding(int theAction, int theKey)
{
	if (theAction < 0 || theAction >= HOTKEY_COUNT || !IsBindable(theKey))
		return false;
	for (int i = 0; i < HOTKEY_COUNT; i++)
		if (i != theAction && theKey != 0 && mHotkeys[i] == theKey)
			return false;
	mHotkeys[theAction] = theKey;
	return true;
}

bool QoLSettings::Decode(std::string_view theText)
{
	if (theText.size() > 4096)
		return false;
	std::istringstream aStream{std::string(theText)};
	std::string aMagic;
	int aVersion, aPause, aRemember, aSpeed, aCooldown;
	if (!(aStream >> aMagic >> aVersion >> aPause >> aRemember >> aSpeed >> aCooldown) ||
		aMagic != "PVZQOL" || aVersion != 1 ||
		(aPause != 0 && aPause != 1) || (aRemember != 0 && aRemember != 1) ||
		(aSpeed != 0 && aSpeed != 1) || (aCooldown != 0 && aCooldown != 1))
		return false;
	QoLSettings aParsed;
	aParsed.mHotkeys.fill(0);
	for (int i = 0; i < HOTKEY_COUNT; i++)
	{
		int aKey;
		if (!(aStream >> aKey) || !aParsed.SetBinding(i, aKey))
			return false;
	}
	aStream >> std::ws;
	if (!aStream.eof())
		return false;
	aParsed.mAutoPause = aPause != 0;
	aParsed.mRememberSpeed = aRemember != 0;
	aParsed.mPreferredDoubleSpeed = aSpeed != 0;
	aParsed.mShowCooldownNumbers = aCooldown != 0;
	*this = aParsed;
	return true;
}

std::string QoLSettings::Encode() const
{
	std::ostringstream aStream;
	aStream << "PVZQOL 1\n" << mAutoPause << ' ' << mRememberSpeed << ' '
		<< mPreferredDoubleSpeed << ' ' << mShowCooldownNumbers << '\n';
	for (int aKey : mHotkeys)
		aStream << aKey << ' ';
	aStream << '\n';
	return aStream.str();
}

std::string QoLSettings::KeyName(int theKey)
{
	if (theKey == 0) return "None";
	if ((theKey >= '0' && theKey <= '9') || (theKey >= 'A' && theKey <= 'Z'))
		return std::string(1, static_cast<char>(theKey));
	if (theKey >= 96 && theKey <= 105) return "Num " + std::to_string(theKey - 96);
	if (theKey == 37) return "Left";
	if (theKey == 38) return "Up";
	if (theKey == 39) return "Right";
	if (theKey == 40) return "Down";
	return "None";
}

std::string QoLSettings::ActionName(int theAction)
{
	if (theAction >= 0 && theAction < 10) return "Seed " + std::to_string(theAction + 1);
	if (theAction == SHOVEL_ACTION) return "Shovel";
	if (theAction == SPEED_ACTION) return "Speed";
	return "Control";
}
