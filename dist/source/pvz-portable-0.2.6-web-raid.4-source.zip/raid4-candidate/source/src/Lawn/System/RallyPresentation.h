// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
class Zombie;
class ZombieDrawPosition;
class Reanimation;
namespace Sexy { class Graphics; class Image; }

// The native zombie rig supplies all body and arm artwork. A small shaded
// megaphone is painted once and follows the rig's hand, scale and color.
namespace RallyPresentation
{
void Initialize(Zombie& zombie);
void PrepareRig(Reanimation& carrier);
void Draw(Zombie& zombie, Sexy::Graphics* graphics, const ZombieDrawPosition& drawPosition);
void DrawRig(Sexy::Graphics* graphics, Reanimation& carrier, bool rallying = false,
    float progress = 0.5f, bool hasArm = true, bool hasObject = true);
Sexy::Image* GetBonusImage();
void DisposeImage();
}
