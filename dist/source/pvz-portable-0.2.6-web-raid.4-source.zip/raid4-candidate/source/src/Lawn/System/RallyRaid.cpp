// SPDX-License-Identifier: LGPL-3.0-or-later
#include "RallyRaid.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../GridItem.h"
#include "../Coin.h"
#include "../SeedPacket.h"
#include "../Projectile.h"
#include "../../LawnApp.h"
#include <algorithm>

namespace RallyRaid
{
void Populate(Board& board)
{
    Challenge& challenge=*board.mChallenge;
    const int stage=std::clamp(challenge.mSurvivalStage,0,kBoardCount-1);
    challenge.mSurvivalStage=stage;
    challenge.mChallengeState=kActive;
    challenge.mChallengeStateCounter=0;
    challenge.mChallengeScore=0;
    board.mSunMoney=kBoards[stage].mSun;
    board.mCurrentWave=0;
    board.mProgressMeterWidth=0;
    board.mZombieCountDown=100000;
    board.mZombieCountDownStart=100000;
    board.mNextSurvivalStageCounter=0;
    board.mShowShovel=false;
    board.mBonusLawnMowersRemaining=0;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    // These are the same native brain actors and bite counters as I, Zombie.
    for(int row=0;row<5;++row)
    {
        GridItem* brain=board.mGridItems.DataArrayAlloc();
        brain->mGridItemType=GRIDITEM_IZOMBIE_BRAIN;
        brain->mGridX=0;brain->mGridY=row;
        brain->mRenderOrder=Board::MakeRenderOrder(RENDER_LAYER_PLANT,row,0);
        brain->mGridItemCounter=70;
        brain->mPosX=board.GridToPixelX(0,row)-40;
        brain->mPosY=board.GridToPixelY(0,row)+40;
    }
    for(const Defender& defender:kBoards[stage].mPlants)
    {
        if(defender.mSeed==SEED_NONE) continue;
        Plant* plant=board.NewPlant(defender.mCol,defender.mRow,defender.mSeed,SEED_NONE);
        // Authored cardboard defenders are already awake, as native daytime
        // I, Zombie mushroom formations are; the normal unlock rule is untouched.
        plant->SetSleeping(false);
        challenge.IZombieSetupPlant(plant);
    }
}

void ResetStage(Board& board,int stage)
{
    for(Zombie* zombie:board.mZombies) if(!zombie->mDead) zombie->DieNoLoot();
    for(Plant* plant:board.mPlants) if(!plant->mDead) plant->Die();
    for(Coin* coin:board.mCoins) if(!coin->mDead) coin->Die();
    for(GridItem* item:board.mGridItems) if(!item->mDead) item->GridItemDie();
    for(Projectile* projectile:board.mProjectiles) if(!projectile->mDead) projectile->Die();
    board.mChallenge->mSurvivalStage=std::clamp(stage,0,kBoardCount-1);
    board.mLevelAwardSpawned=false;
    Populate(board);
}

void OnBrainsCleared(Board& board,int row)
{
    Challenge& challenge=*board.mChallenge;
    if(challenge.mChallengeState!=kActive || board.HasLevelAwardDropped()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    if(challenge.mSurvivalStage==kBoardCount-1)
    {
        challenge.mChallengeState=kFinished;
        challenge.SpawnLevelAward(0,row);
    }
    else
    {
        challenge.mChallengeState=kTransition;
        challenge.mChallengeStateCounter=kTransitionTicks;
    }
}

void Update(Board& board)
{
    Challenge& challenge=*board.mChallenge;
    if(!IsCurrentRules(board.mApp->mGameMode,challenge.mChallengeState) || board.mPaused ||
        board.mApp->mGameScene!=SCENE_PLAYING || board.HasLevelAwardDropped()) return;
    board.mShowShovel=false;
    if(challenge.mChallengeState!=kTransition) return;
    if(--challenge.mChallengeStateCounter>0) return;
    challenge.PuzzleNextStageClear();
    for(Coin* coin:board.mCoins) if(!coin->mDead) coin->Die();
    for(Projectile* projectile:board.mProjectiles) if(!projectile->mDead) projectile->Die();
    Populate(board);
}
}
