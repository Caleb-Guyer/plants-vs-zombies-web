// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include "../../ConstEnums.h"
#include <array>
#include <initializer_list>

class Board;

// Native I, Zombie combat and brains, with five fixed authored defenses.
// Existing challenge state/stage/timer fields carry the complete save state.
namespace RallyRaid
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_RALLY_RAID;
inline constexpr ChallengeState kActive = static_cast<ChallengeState>(111);
inline constexpr ChallengeState kTransition = static_cast<ChallengeState>(112);
inline constexpr ChallengeState kFinished = static_cast<ChallengeState>(113);
inline constexpr int kBoardCount = 5;
inline constexpr int kSeedCount = 5;
inline constexpr int kRallyCost = 100;
inline constexpr int kDeploymentColumn = 4;
inline constexpr int kTransitionTicks = 120;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state)
{ return IsMode(mode) && state >= kActive && state <= kFinished; }

inline constexpr std::array<SeedType,kSeedCount> kSeeds = {
    SEED_ZOMBIE_NORMAL, SEED_ZOMBIE_TRAFFIC_CONE, SEED_ZOMBIE_PAIL,
    SEED_ZOMBIE_SCREEN_DOOR, SEED_ZOMBIE_RALLY
};
struct Defender { SeedType mSeed=SEED_NONE; int mCol=0; int mRow=0; };
struct Puzzle { int mSun; std::array<Defender,12> mPlants; };
// Empty right-hand lawn remains the original I, Zombie deployment area.
// The first board introduces a cross-lane call; frost and healing join later.
inline constexpr std::array<Puzzle,kBoardCount> kBoards = {{
    {450, {{{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,1,1},{SEED_PEASHOOTER,1,2},
            {SEED_PEASHOOTER,1,3},{SEED_PEASHOOTER,1,4}}}},
    {550, {{{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,2,0},{SEED_REPEATER,1,1},
            {SEED_PEASHOOTER,1,2},{SEED_REPEATER,1,3},{SEED_PEASHOOTER,1,4},{SEED_PEASHOOTER,2,4}}}},
    {600, {{{SEED_PEASHOOTER,1,0},{SEED_PEASHOOTER,2,1},{SEED_LANTERNSHROOM,1,2},
            {SEED_PEASHOOTER,3,2},{SEED_PEASHOOTER,2,3},{SEED_PEASHOOTER,1,4},
            {SEED_SNOWPEA,1,1},{SEED_SNOWPEA,1,3}}}},
    {650, {{{SEED_PEASHOOTER,1,0},{SEED_REPEATER,2,1},{SEED_MENDERBLOOM,1,2},
            {SEED_PEASHOOTER,2,2},{SEED_REPEATER,2,3},{SEED_PEASHOOTER,1,4},
            {SEED_FUMESHROOM,3,0},{SEED_FUMESHROOM,3,4}}}},
    {750, {{{SEED_PEASHOOTER,1,0},{SEED_REPEATER,2,1},{SEED_LANTERNSHROOM,1,1},
            {SEED_SNOWPEA,2,2},{SEED_MENDERBLOOM,1,3},{SEED_REPEATER,2,3},
            {SEED_PEASHOOTER,1,4},{SEED_FUMESHROOM,3,0},{SEED_FUMESHROOM,3,4}}}}
}};
constexpr int PlantCount(int stage)
{
    if (stage<0 || stage>=kBoardCount) return 0;
    int count=0;for(const Defender& plant:kBoards[stage].mPlants) count+=plant.mSeed!=SEED_NONE;
    return count;
}
template<std::size_t Waves,std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    for(auto& wave:output) for(auto& zombie:wave) zombie=ZOMBIE_INVALID;
    return kBoardCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    for(auto& allowed:output) allowed=false;
    for(ZombieType type:{ZOMBIE_NORMAL,ZOMBIE_TRAFFIC_CONE,ZOMBIE_PAIL,ZOMBIE_DOOR,ZOMBIE_RALLY}) output[type]=true;
}
template<class Bank> void FillSeedBank(Bank& bank)
{
    bank.mNumPackets=kSeedCount;
    for(int i=0;i<kSeedCount;++i) bank.mSeedPackets[i].SetPacketType(kSeeds[i]);
    bank.RefreshAllPackets();
}
void Populate(Board& board);
void ResetStage(Board& board,int stage);
void Update(Board& board);
void OnBrainsCleared(Board& board,int row);
static_assert(static_cast<int>(kMode)==81 && static_cast<int>(SEED_ZOMBIE_RALLY)==77);
}
