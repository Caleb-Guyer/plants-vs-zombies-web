// SPDX-License-Identifier: LGPL-3.0-or-later
#include "ChainReaction.h"
#include "../Board.h"
#include "../Challenge.h"
#include "../Plant.h"
#include "../Zombie.h"
#include "../SeedPacket.h"
#include "../Coin.h"
#include "../GridItem.h"
#include "../Widget/GameButton.h"
#include "../../LawnApp.h"
#include "../../PvzpLib/Reanimator.h"
#include "../../PvzpLib/PvzpParticle.h"
#include "../../PvzpLib/PvzpFoley.h"
#include "../../Resources.h"
#include <algorithm>

namespace ChainReaction
{
bool IsPlanning(const Board& board)
{
    return board.mApp && board.mChallenge && IsPlanning(board.mApp->mGameMode, board.mChallenge->mChallengeState);
}

bool CanPlant(const Board& board, SeedType seed) { return IsPlanning(board) && IsExplosive(seed); }

bool HoldsZombie(Zombie& zombie)
{
    return zombie.mBoard && IsPlanning(*zombie.mBoard) && zombie.IsOnBoard() && !zombie.IsDeadOrDying();
}

void PreparePlant(Plant& plant)
{
    if (!plant.mBoard || !IsPlanning(*plant.mBoard) || !IsExplosive(plant.mSeedType)) return;
    Reanimation* body = plant.mApp->ReanimationTryToGet(plant.mBodyReanimID);
    if (!body) return;
    if (plant.mSeedType == SEED_POTATOMINE)
    {
        // The native preview/IZombie armed pose avoids a preparation wait.
        plant.mState = STATE_POTATO_ARMED;
        plant.mStateCountdown = 0;
        body->SetFramesForLayer("anim_armed");
        body->mLoopType = REANIM_LOOP;
        body->mAnimRate = 12.0f;
    }
    else
    {
        // Use the original idle art while the native fuse waits for Let's Rock.
        body->mAnimTime = 0.0f;
        body->SetFramesForLayer("anim_idle");
        body->mLoopType = REANIM_LOOP;
    }
}

void Populate(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    const int stage = std::clamp(challenge.mSurvivalStage, 0, kBoardCount - 1);
    challenge.mSurvivalStage = stage;
    challenge.mChallengeState = kPlanning;
    challenge.mChallengeStateCounter = 0;
    board.mCurrentWave = 0;
    board.mZombieCountDown = 100000;
    board.mZombieCountDownStart = 100000;
    board.mShowShovel = false;
    board.mSunMoney = 0;
    board.ClearCursor();
    FillSeedBank(*board.mSeedBank);
    for (SeedType seed : kBoards[stage].mSeeds)
        if (seed != SEED_NONE) board.mSeedBank->AddSeed(seed, true);
    for (const Spawn& spawn : kBoards[stage].mZombies)
    {
        if (spawn.mType == ZOMBIE_INVALID) continue;
        Zombie* zombie = board.AddZombieInRow(spawn.mType, spawn.mRow, 0);
        // Offset the native collision rectangle into the intended lawn cell.
        zombie->mPosX = static_cast<float>(board.GridToPixelX(spawn.mCol, spawn.mRow) - 17 + spawn.mOffsetX);
        zombie->mX = static_cast<int>(zombie->mPosX);
        if (Reanimation* body = board.mApp->ReanimationTryToGet(zombie->mBodyReanimID))
        {
            if (body->TrackExists("anim_idle")) zombie->PlayZombieReanim("anim_idle", REANIM_LOOP, 0, 12.0f);
            else body->mAnimRate = 0.0f;
        }
        zombie->UpdateReanim();
    }
    // The native intro camera may still be moving. Show the planning control
    // from the first normal Update, as Last Stand does, rather than over it.
    board.mStoreButton->mBtnNoDraw = true;
    board.mStoreButton->mDisabled = true;
}

void RestoreButton(Board& board)
{
    if (!board.mStoreButton) return;
    GameButton* button = board.mStoreButton.get();
    const bool planning = IsPlanning(board);
    button->mParentWidget = &board;
    button->mBtnNoDraw = !planning;
    button->mDisabled = !planning;
    button->SetLabel("[LETS_ROCK_BUTTON]");
    button->Resize(300, 548, 210, 46);
}

void ResetStage(Board& board, int stage)
{
    // Called only on a newly created replacement board after native Retry or
    // Restart. Discard its first-board actors, then populate the captured stage.
    for (Zombie* zombie : board.mZombies) if (!zombie->mDead) zombie->DieNoLoot();
    for (Plant* plant : board.mPlants) if (!plant->mDead) plant->Die();
    for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
    for (GridItem* item : board.mGridItems) if (!item->mDead) item->GridItemDie();
    board.mChallenge->mSurvivalStage = std::clamp(stage, 0, kBoardCount - 1);
    Populate(board);
}

void Commit(Board& board)
{
    if (!IsPlanning(board) || board.mApp->mGameScene != SCENE_PLAYING || board.mPaused || board.HasLevelAwardDropped()) return;
    board.ClearCursor();
    board.ClearAdviceImmediately();
    board.mChallenge->mChallengeState = kResolving;
    board.mChallenge->mChallengeStateCounter = 0;
    board.mStoreButton->mBtnNoDraw = true;
    board.mStoreButton->mDisabled = true;
    for (Plant* plant : board.mPlants)
        if (!plant->mDead && (plant->mSeedType == SEED_CHERRYBOMB || plant->mSeedType == SEED_JALAPENO))
            if (Reanimation* body = board.mApp->ReanimationTryToGet(plant->mBodyReanimID))
            {
                board.mApp->PlayFoley(FOLEY_REVERSE_EXPLOSION);
                body->SetFramesForLayer("anim_explode");
                body->mLoopType = REANIM_PLAY_ONCE_AND_HOLD;
                body->mAnimTime = 0.0f;
                body->mLastFrameTime = 0.0f;
                body->mLoopCount = 0;
            }
    for (Zombie* zombie : board.mZombies)
        if (!zombie->mDead && !zombie->IsDeadOrDying()) zombie->StartWalkAnim(0);
}

void Update(Board& board)
{
    Challenge& challenge = *board.mChallenge;
    if (!IsCurrentRules(board.mApp->mGameMode, challenge.mChallengeState) || board.mPaused ||
        board.mApp->mGameScene != SCENE_PLAYING || board.HasLevelAwardDropped()) return;
    board.mShowShovel = false;
    if (challenge.mChallengeState == kPlanning)
    {
        if (board.mStoreButton->mBtnNoDraw) RestoreButton(board);
        return;
    }
    if (challenge.mChallengeState == kTransition)
    {
        if (--challenge.mChallengeStateCounter > 0) return;
        challenge.PuzzleNextStageClear();
        for (Coin* coin : board.mCoins) if (!coin->mDead) coin->Die();
        Populate(board);
        return;
    }
    if (challenge.mChallengeState != kResolving) return;
    ++challenge.mChallengeStateCounter;
    if (!board.AreEnemyZombiesOnScreen())
    {
        if (challenge.mSurvivalStage == kBoardCount - 1)
        {
            challenge.mChallengeState = kFinished;
            challenge.SpawnLevelAward(4, 2);
        }
        else
        {
            challenge.mChallengeState = kTransition;
            challenge.mChallengeStateCounter = kTransitionTicks;
        }
        return;
    }
    bool pending = false;
    for (Plant* plant : board.mPlants)
        if (!plant->mDead && plant->mPlantHealth > 0 && IsExplosive(plant->mSeedType) &&
            plant->mState != STATE_DOINGSPECIAL)
            pending = true;
    // Do not fail an armed mine waiting for a real zombie to approach it.
    if (!pending && challenge.mChallengeStateCounter > 120) board.ZombiesWon(nullptr);
}
}
