// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

// A small, fixed garden faces authored lanes. Combat plants are moved in place,
// never rebuilt: their native IDs, health and attack clocks survive a move.
namespace GardenShuffle
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_GARDEN_SHUFFLE;
inline constexpr ChallengeState kState = static_cast<ChallengeState>(103);
inline constexpr int kMoveCooldown = 100;
inline constexpr int kOpeningDelay = 1800;
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestWave = 6;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kState; }
constexpr bool CanMoveSeed(SeedType seed)
{
    return seed == SEED_REPEATER || seed == SEED_SNOWPEA || seed == SEED_WALLNUT;
}

struct StartingPlant
{
    SeedType mSeed;
    int mCol;
    int mRow;
};
inline constexpr std::array<StartingPlant, 6> kStartingPlants = {{
    {SEED_REPEATER, 1, 1}, {SEED_REPEATER, 2, 1},
    {SEED_REPEATER, 1, 3}, {SEED_SNOWPEA, 1, 2},
    {SEED_WALLNUT, 5, 1}, {SEED_WALLNUT, 5, 3}
}};

struct Spawn
{
    ZombieType mType = ZOMBIE_INVALID;
    int mRow = 0;
};
using Wave = std::array<Spawn, kLargestWave>;

// Early pairs allow time to learn the glove. Later waves rotate among three
// lanes; the final flag adds a third lane rather than an unseen speed spike.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {{{ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,0}}},
    {{{ZOMBIE_NORMAL,2}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_NORMAL,0}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,0}}},
    {{{ZOMBIE_NORMAL,1}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,1}}},
    {{{ZOMBIE_DOOR,2}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_TRAFFIC_CONE,0}}},
    {{{ZOMBIE_NORMAL,3}, {ZOMBIE_POLEVAULTER,1}, {ZOMBIE_NORMAL,1}, {ZOMBIE_TRAFFIC_CONE,3}}},
    {{{ZOMBIE_PAIL,4}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,4}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,0}}},
    {{{ZOMBIE_DOOR,0}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,1}}},
    {{{ZOMBIE_FLAG,2}, {ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_NORMAL,0}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,2}}}
}};

constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave]) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
constexpr int RowForSpawn(int wave, int ordinal)
{
    return wave >= 0 && wave < kWaveCount && ordinal >= 0 && ordinal < ZombieCount(wave)
        ? kWaves[wave][ordinal].mRow : -1;
}
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave])
        if (spawn.mType != ZOMBIE_INVALID) output[count++] = spawn.mType;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOOR));
    for (auto& allowed : output) allowed = false;
    for (const Wave& wave : kWaves)
        for (const Spawn& spawn : wave)
            if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}

static_assert(static_cast<int>(kMode) == 76);
static_assert(ZombieCount(0) == 2 && ZombieCount(kWaveCount - 1) == kLargestWave);
}
