// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include "../../ConstEnums.h"
#include <array>
#include <cstddef>

// The recovery station and its patients use native Plant instances throughout.
// Existing health, cursor, challenge and conveyor fields carry the entire game.
namespace IntensiveCare
{
inline constexpr GameMode kMode = GAMEMODE_CHALLENGE_INTENSIVE_CARE;
inline constexpr ChallengeState kState = static_cast<ChallengeState>(105);
inline constexpr int kWaveCount = 10;
inline constexpr int kLargestWave = 6;
inline constexpr int kOpeningDelay = 3000;
inline constexpr int kMoveCooldown = 100;
inline constexpr int kSupplyInterval = 1200;
inline constexpr int kSeedCount = 10;
inline constexpr int kCrewLimit = 10;
inline constexpr int kMenderCol = 0;
inline constexpr int kBedCol = 1;
inline constexpr int kWallCol = 6;
inline constexpr int kStartingHealth = 240;
inline constexpr int kConveyorHealth = 180;
inline constexpr int kFatigueInterval = 25;
inline constexpr int kFatigueAmount = 1;
inline constexpr int kExhaustedHealth = 60;
inline constexpr int kWarningHealth = 100;
constexpr bool IsMode(GameMode mode) { return mode == kMode; }
constexpr bool IsCurrentRules(GameMode mode, ChallengeState state) { return IsMode(mode) && state == kState; }
constexpr bool IsBedCell(int col, int row) { return col == kBedCol && row >= 0 && row < 5; }
constexpr bool CanDeployAt(int col, int row) { return col >= 2 && col < 9 && row >= 0 && row < 5; }
constexpr bool IsCrewSeed(SeedType seed)
{
    return seed == SEED_PEASHOOTER || seed == SEED_REPEATER || seed == SEED_SNOWPEA ||
        seed == SEED_KERNELPULT || seed == SEED_CABBAGEPULT || seed == SEED_MELONPULT;
}
constexpr bool IsProtectedPlant(SeedType seed, int col, int row)
{
    if (row < 0 || row >= 5) return false;
    return (col == kMenderCol && seed == SEED_MENDERBLOOM) ||
        (IsBedCell(col, row) && (seed == SEED_FLOWERPOT || IsCrewSeed(seed)));
}
constexpr bool CanAttack(SeedType seed, int col, int health)
{
    return !IsCrewSeed(seed) || (col >= 2 && col < 9 && health > kExhaustedHealth);
}
constexpr int FatiguedHealth(int health)
{
    return health > kExhaustedHealth ? health - kFatigueAmount : health;
}

inline constexpr std::array<SeedType, 3> kOpeningSeeds = {
    SEED_REPEATER, SEED_SNOWPEA, SEED_KERNELPULT
};
inline constexpr std::array<SeedType, 8> kSupplySeeds = {
    SEED_CABBAGEPULT, SEED_REPEATER, SEED_SNOWPEA, SEED_KERNELPULT,
    SEED_REPEATER, SEED_MELONPULT, SEED_SNOWPEA, SEED_CABBAGEPULT
};
constexpr SeedType SeedForSupply(int ordinal)
{
    if (ordinal < 0) return SEED_NONE;
    if (ordinal < static_cast<int>(kOpeningSeeds.size())) return kOpeningSeeds[ordinal];
    return kSupplySeeds[(ordinal - kOpeningSeeds.size()) % kSupplySeeds.size()];
}
template<class Bank>
void FillSeedBank(Bank& bank)
{
    bank.mNumPackets = kSeedCount;
    // Empty native conveyor slots must not call SetPacketType: that function
    // looks up a combat plant's recharge time, and SEED_NONE has no definition.
    for (int i = 0; i < bank.mNumPackets; ++i) bank.mSeedPackets[i].mPacketType = SEED_NONE;
}

struct StartingPlant { SeedType mSeed; int mCol; int mRow; int mHealth; };
inline constexpr std::array<StartingPlant, 20> kStartingPlants = {{
    {SEED_MENDERBLOOM,0,0,300}, {SEED_FLOWERPOT,1,0,300}, {SEED_REPEATER,3,0,kStartingHealth}, {SEED_WALLNUT,6,0,4000},
    {SEED_MENDERBLOOM,0,1,300}, {SEED_FLOWERPOT,1,1,300}, {SEED_REPEATER,3,1,kStartingHealth}, {SEED_WALLNUT,6,1,4000},
    {SEED_MENDERBLOOM,0,2,300}, {SEED_FLOWERPOT,1,2,300}, {SEED_REPEATER,3,2,kStartingHealth}, {SEED_WALLNUT,6,2,4000},
    {SEED_MENDERBLOOM,0,3,300}, {SEED_FLOWERPOT,1,3,300}, {SEED_REPEATER,3,3,kStartingHealth}, {SEED_WALLNUT,6,3,4000},
    {SEED_MENDERBLOOM,0,4,300}, {SEED_FLOWERPOT,1,4,300}, {SEED_REPEATER,3,4,kStartingHealth}, {SEED_WALLNUT,6,4,4000}
}};

struct Spawn { ZombieType mType = ZOMBIE_INVALID; int mRow = 0; };
using Wave = std::array<Spawn, kLargestWave>;
// Pressure grows through armor and extra lanes, not hard counters. Every lane
// starts defended; the opening leaves time to recover the first three patients.
inline constexpr std::array<Wave, kWaveCount> kWaves = {{
    {{{ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_NORMAL,0}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,2}}},
    {{{ZOMBIE_DOOR,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_TRAFFIC_CONE,1}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,4}, {ZOMBIE_NORMAL,0}}},
    {{{ZOMBIE_PAIL,4}, {ZOMBIE_TRAFFIC_CONE,2}, {ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_DOOR,1}, {ZOMBIE_TRAFFIC_CONE,3}, {ZOMBIE_NORMAL,0}, {ZOMBIE_NORMAL,2}, {ZOMBIE_NORMAL,3}}},
    {{{ZOMBIE_PAIL,0}, {ZOMBIE_DOOR,2}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_NORMAL,1}, {ZOMBIE_NORMAL,4}}},
    {{{ZOMBIE_FLAG,2}, {ZOMBIE_TRAFFIC_CONE,0}, {ZOMBIE_TRAFFIC_CONE,4}, {ZOMBIE_DOOR,1}, {ZOMBIE_NORMAL,3}, {ZOMBIE_NORMAL,2}}}
}};
constexpr int ZombieCount(int wave)
{
    if (wave < 0 || wave >= kWaveCount) return 0;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave]) if (spawn.mType != ZOMBIE_INVALID) ++count;
    return count;
}
constexpr int RowForSpawn(int wave, int ordinal)
{
    return wave >= 0 && wave < kWaveCount && ordinal >= 0 && ordinal < ZombieCount(wave)
        ? kWaves[wave][ordinal].mRow : -1;
}
constexpr int ComposeWave(int wave, ZombieType* output, int capacity)
{
    if (wave < 0 || wave >= kWaveCount || !output || capacity <= ZombieCount(wave)) return -1;
    for (int i = 0; i < capacity; ++i) output[i] = ZOMBIE_INVALID;
    int count = 0;
    for (const Spawn& spawn : kWaves[wave])
        if (spawn.mType != ZOMBIE_INVALID) output[count++] = spawn.mType;
    return count;
}
template<std::size_t Waves, std::size_t Slots>
int PopulateWaves(ZombieType (&output)[Waves][Slots])
{
    static_assert(Waves >= kWaveCount && Slots > kLargestWave);
    for (auto& wave : output) for (auto& zombie : wave) zombie = ZOMBIE_INVALID;
    for (int i = 0; i < kWaveCount; ++i) ComposeWave(i, output[i], static_cast<int>(Slots));
    return kWaveCount;
}
template<std::size_t Count>
void PopulateAllowedZombies(bool (&output)[Count])
{
    static_assert(Count > static_cast<std::size_t>(ZOMBIE_DOOR));
    for (auto& allowed : output) allowed = false;
    for (const Wave& wave : kWaves) for (const Spawn& spawn : wave)
        if (spawn.mType != ZOMBIE_INVALID) output[spawn.mType] = true;
}
static_assert(static_cast<int>(kMode) == 78);
static_assert(ZombieCount(kWaveCount - 1) == kLargestWave);
}
