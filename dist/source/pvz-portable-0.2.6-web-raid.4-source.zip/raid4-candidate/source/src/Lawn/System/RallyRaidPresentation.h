// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once

#include <string>

class Plant;
namespace Sexy { class Graphics; class Image; }

namespace RallyRaidPresentation
{
Sexy::Image* GetBonusImage();
std::string LevelLabel(int stage);
// Native I, Zombie paints its defenses as cardboard cutouts. Custom plants
// need their actual accepted sprite, not their hidden carrier's original art.
bool DrawCustomPlant(Sexy::Graphics* graphics, Plant& plant);
void DisposeImage();
}
