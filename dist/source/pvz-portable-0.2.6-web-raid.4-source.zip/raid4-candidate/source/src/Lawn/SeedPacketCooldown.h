// SPDX-License-Identifier: LGPL-3.0-or-later
#ifndef PVZ_SEED_PACKET_COOLDOWN_H
#define PVZ_SEED_PACKET_COOLDOWN_H
#include <algorithm>
#include <cstdint>

inline int SeedPacketCooldownSeconds(bool refreshing, bool active, int refreshTime, int refreshCounter)
{
    if (!refreshing || active || refreshTime <= 0) return 0;
    // Update() makes a packet ready on the first update AFTER refreshTime.
    const int64_t remaining = std::max<int64_t>(0, static_cast<int64_t>(refreshTime) -
        std::max(0, refreshCounter)) + 1;
    return static_cast<int>((remaining + 99) / 100);
}
#endif
