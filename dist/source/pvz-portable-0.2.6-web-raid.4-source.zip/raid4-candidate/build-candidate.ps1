$ErrorActionPreference='Stop'
$candidateRoot=$PSScriptRoot
$taskTools=Join-Path (Split-Path -Parent (Split-Path -Parent $candidateRoot)) 'toolchain'
$taskSdk=Join-Path $taskTools 'emsdk-d7b4130688bfa348392b921ab04015aa15c4f154'
$taskCmake=Join-Path $taskTools 'cmake-3.31.9-windows-x86_64\bin\cmake.exe'
$taskPython=Join-Path $taskSdk 'python\3.13.3_64bit\python.exe'
$env:PATH=(Join-Path $taskTools 'bin')+';'+(Join-Path $taskTools 'msys64\usr\bin')+';'+(Join-Path $taskSdk 'upstream\emscripten')+';'+(Join-Path $taskTools 'ninja-1.13.2')+';'+(Split-Path -Parent $taskCmake)+';'+$env:PATH
$env:EM_CONFIG=Join-Path $taskSdk '.emscripten'
$env:EM_CACHE=Join-Path $taskTools 'em-cache'
$env:EMSDK=$taskSdk
$env:EMSDK_PYTHON=$taskPython
$env:EMSDK_NODE=Join-Path $taskSdk 'node\24.19.0_64bit\node.exe'
$env:PVZ_BUILD_PYTHON=$taskPython
$env:EMCC_TEMP_DIR=Join-Path $candidateRoot 'build-temp'
$env:PYTHONNOUSERSITE='1'
$env:MSYSTEM='MSYS'
New-Item -ItemType Directory -Path $env:EMCC_TEMP_DIR -Force | Out-Null
& $taskPython (Join-Path $taskSdk 'upstream\emscripten\emcmake.py') $taskCmake -S (Join-Path $candidateRoot 'source') -B (Join-Path $candidateRoot 'build') -G Ninja -DCMAKE_BUILD_TYPE=Release ('-DCMAKE_MAKE_PROGRAM='+(Join-Path $taskTools 'ninja-1.13.2\ninja.exe')) -DDO_FIX_BUGS=OFF -DPVZ_DEBUG=OFF -DLOW_MEMORY=OFF
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& $taskCmake --build (Join-Path $candidateRoot 'build') --parallel 4
exit $LASTEXITCODE
