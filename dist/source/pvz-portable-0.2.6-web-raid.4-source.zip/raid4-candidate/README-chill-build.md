# Attack-only Chill cardboard animation: source and tests

Exact published Raid.3 parent source SHA-256:
dc02a3d87a227e3b6b890cd03894999dea831c62a6d184fc2a0bc281425e51a3.
The parent archive has 23,994,234 bytes, 919 entries and 828 production files
under raid3-candidate/source/. Current recipes and source use raid4-candidate/.

Raid.4 holds Chill-shroom completely still and open-eyed during Rally Raid
idle, including no-target readiness, cooldown and the frost tail. A scoped exact
neutral overlay replaces the breathing draw pose; the carrier's prior overlay
and filter are restored. Live windup, release and recoil remain. Shared normal
idle and Mender behavior, animation clocks, accepted artwork/content metadata,
boards, budgets, combat, IDs, the native I, Zombie UI fix and saves are unchanged.
Only CMake/ProjectVersion.cmake and RallyRaidPresentation.cpp differ from Raid.3.

Build the normal Release browser engine with build-chill.py. Muted Care,
Chain Reaction, Rally Zombie and Rally Raid CLI drivers link the same production
objects with test-only entry points. All seventeen native reports and eight
backend JS/WASM artifacts remain release gates. Raid retains 32 scenarios and
16 speed pairs: 24 legal winning runs, four native-UI controls and four plant
animation controls. Body-only tests require still Raid idle, retained attacks
and moving normal-mode idle. Published Raid.3 breathing and earlier static
renderers are authenticated negative fixtures; no whole older source archive
is required for these inherited fixtures. Test hardware never opens audio.

package-chill.py authenticates source/build/test receipts and byte-exact
upstream/Raid.3 patch reconstruction. Patches are web-raid.4.patch and
raid3-to-raid4.patch. Existing site-source packaging preserves the pinned
Rally.3 source reference used by native-UI validation.
